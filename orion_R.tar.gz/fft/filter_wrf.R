library(ncdf4)
library(ncdf)

ncname <- "./indata/wrfout_d01_2012-06-05_18:00:00"
nc <- open.ncdf(ncname, readunlim=FALSE )
x <- get.var.ncdf(nc,"west_east")
y <- get.var.ncdf(nc,"south_north")
z <- get.var.ncdf(nc,"bottom_top")
nx <- length(x)
ny <- length(y)
nz <- length(z)

u <- get.var.ncdf(nc,"U")

test <- fft(u[,40,1])
magn <- Mod(test[1:(length(test)/2)+1])

x.axis <- 1:length(magn)
y.axis <- magn

x11()
plot(x=x.axis,y=y.axis,type='l')
lines(x=x.axis,y=y.axis,type='l',col='red')
close.ncdf(nc)

ux.axis <- 1:length(u[,40,1])
uy.axis <- u[,40,3]
plot(x=ux.axis,y=uy.axis,type='l')
lines(x=ux.axis,y=uy.axis,type='l',col='blue')

invtest <- fft(test, inverse=TRUE)/length(test)

#to plot psinc from gsi

test <- "test_039"

library(ncdf)

var <- "ps2D"

ncname <- paste('./indata/',test,'/incr_latlon.nc',sep='')
nc <- open.ncdf(ncname, readunlim=FALSE, write=TRUE )

xdim <- nc$dim[["lon"]]
ydim <- nc$dim[["lat"]]
psincr <- get.var.ncdf(nc,var)
close.ncdf(nc)

gridvals <- psincr

north <- 90
south <- -90
left <- 0
right <- 359

nx <- dim(gridvals)[1]
ny <- dim(gridvals)[2]

xx <- seq(left,right,(right-left)/(nx-1))
yy <- seq(south,north,(north-south)/(ny-1))

width <- 800
height <- 600

picname <- paste('./pics/psincr/psincr_latlon_',test,'.png',sep='')
png(picname,width=width, height=height,bg="white")
#for mean
#filled.contour(xx,yy,gridvals,zlim=c(-200,200),nlevels=16,color.palette=rainbow)

#for individual
filled.contour(xx,yy,gridvals,zlim=c(-400,400),nlevels=16,color.palette=rainbow)

dev.off()



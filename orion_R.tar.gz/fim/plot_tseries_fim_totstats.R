test <- "test_027"

prefix <- "fim_stats_Global3D"
vars <- c("mass","watervapor","cloudwater")
nvars <- length(vars)

tcolors <- c("red","violetred2","blue")

indir="./indata/diags/"

plotdates <- c("2012/11/01","2012/11/05","2012/11/10",
               "2012/11/15","2012/11/20","2012/11/25","2012/11/30")
nmaxtimes <- 1e3
ntests <- length(tests)
ntimes <- 0

ncolumns <- 2

allstats <- array(NA,c(nvars,nmaxtimes))


ivar <- 1

for (ivar in 1:nvars) {

    var <- vars[ivar]

    fname <- paste(indir,prefix,var,"_",test,".log",sep='')

    thisfile <- file(fname,"ra")
    
    vartable <- try(
    read.table(thisfile,header=FALSE,skip=0,sep=' '),silent=TRUE)
    if (class(vartable)=="try-error") {
	print(c("FILE EMPTY",c(field,level)))
	close(thisfile)			  
    next } 
    close(thisfile)


    nlines <- dim(vartable)[1]
    dates <- NULL
    times <- NULL

    if (ntimes < nlines) {

        for (i in 1:nlines) {

	    years <- vartable[i,1] %/% 1000000
	    months <- (vartable[i,1] %% 1000000) %/% 10000
	    days  <-  (vartable[i,1] %% 10000) %/% 100
	    hours <-  (vartable[i,1] %% 100)

	    dates <- c(dates,paste(as.character(years),"-",
		 as.character(months),"-",as.character(days),sep=""))
	    times <- c(times,paste(as.character(hours),":00:00",sep=""))
	}    

    ntimes <- nlines


    alldates <- as.POSIXlt(paste(dates,times),"UTC")

    }
	
    j <- ncolumns

    allstats[ivar,1:nlines] <-  as.array(vartable[,j])

    picname <-  paste("./pics/",prefix,var,"_",test,".png",sep='')

    ymax <- max(allstats[ivar,],na.rm=TRUE)
    ymin <- min(allstats[ivar,],na.rm=TRUE)
    xmin <- min(alldates)
    xmax <- max(alldates)
     
    png(picname,width=600, height=400.,bg="white")

    plot(alldates,allstats[ivar,1:ntimes],type="l",lwd=2,lty=1,
    cex=1.,col=tcolors[ivar],xlab='Time',ylab='',yaxs="i",xaxs="i",
    ylim=c(ymin,ymax),xaxt='n',main=vars[ivar])

    axis.POSIXct(1,alldates,format="%Y/%m/%d",at=plotdates)
#    axis.POSIXct(1,alldates,format="%d %b %Y",at=plotdates)

    dev.off()				

}






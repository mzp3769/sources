
p_models <- array(0.,c(ndays+1,nens))
p_obs <- p_models
tmp <- array(NA,nens)

j <- 0

for (iday in 2:ndays) {
    print(iday)
    k <- 0
    for (ist in 1:nstations) {
        if (is.na(allobs8hrmax[iday,ist]) ||
            any(is.na(allmodels8hrmax[iday,,ist]))) {
           next
        }

        i <- iday-1
        while(any(is.na(thresholds[i,]))) {
              i <- i-1
        }
        tmp <- thresholds[i,]

        k <- k+1
        j <- j+1

        for (itthresh in 1:ntthresh) {
            for (iens in 1:nens) {
                if (allmodels8hrmax[iday,iens,ist] >= tmp[itthresh]) { 
                   p_models[iday,itthresh] <- p_models[iday,itthresh]+1
                }
   
                if (allmodels8hrmax[iday,iens,ist] >= 
                    thresholds[ndays+1,itthresh]) { 
                   p_models[ndays+1,itthresh] <- 
                   p_models[ndays+1,itthresh]+1
                }
            }

            if (allobs8hrmax[iday,ist] >= tmp[itthresh]) {
               p_obs[iday,itthresh] <- p_obs[iday,itthresh]+1 
            }

            if (allobs8hrmax[iday,ist] >= 
                   thresholds[ndays+1,itthresh]) {
               p_obs[ndays+1,itthresh] <- p_obs[ndays+1,itthresh]+1 
            }
        }
    }
    p_models[iday,] <- p_models[iday,]/(nens*k)
    p_obs[iday,] <- p_obs[iday,]/k
}

p_models[ndays+1,] <- p_models[ndays+1,]/(nens*j)
p_obs[ndays+1,] <- p_obs[ndays+1,]/j



                            


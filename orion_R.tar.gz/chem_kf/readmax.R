# to read 2d 1hr/8hr max files from Stu

cmodels <- c('aurams'  , 'bams15k' , 'bams45k',
             'chronos' , 'cmaq1'   , 'ui12k'  ,
#             'wrf1'    , 'wrf2'    )
             'wrf2'    )

indir <- '/export/scratch/pagowski/stuff/chem/indata'

nens <- length(cmodels)
nstations <- 360
ndays <- 56

freq <- '_8hrmx'
suffix <- paste(freq,'_2d',sep="")
obsfile <- paste(indir,'/','obs',suffix,sep="")
modelfiles <- c(paste(indir,'/',cmodels,suffix,sep=""))

allobs8hrmax <- array(0.,c(ndays,nstations))	
allmodels8hrmax <- array(0.,c(ndays,nens,nstations))	

fobs <- file(obsfile,"ra")
i <- 1
for (n in 1:ndays) {
    date <- scan(fobs,what='1',n=1)
    print(n)
    print(date)
    allobs8hrmax[i,] <- array(scan(fobs,what=0.,n=nstations),
                        nstations)
    for (ist in 1:nstations) {
        if (allobs8hrmax[i,ist] < 0.) {
            allobs8hrmax[i,ist] <- NA
        }
    }
    i <- i+1
}
close(fobs)

for (j in 1:nens) {
    fmodel <- file(modelfiles[j],"ra")
    i <- 1
    print(cmodels[j])
    for (n in 1:ndays) {
        date <- scan(fmodel,what='1',n=1)
        print(date)	
        allmodels8hrmax[i,j,] <- array(scan(fmodel,what=0.,n=nstations),
				  nstations)
        for (ist in 1:nstations) {
            if (allmodels8hrmax[i,j,ist] < 0.) {
                allmodels8hrmax[i,j,ist] <- NA
            }
        }
        i <- i+1
    }
    close(fmodel)
}


freq <- '_1hrmx'
suffix <- paste(freq,'_2d',sep="")
obsfile <- paste(indir,'/','obs',suffix,sep="")
modelfiles <- c(paste(indir,'/',cmodels,suffix,sep=""))

allobs1hrmax <- array(0.,c(ndays,nstations))	
allmodels1hrmax <- array(0.,c(ndays,nens,nstations))	

fobs <- file(obsfile,"ra")
i <- 1
for (n in 1:ndays) {
    date <- scan(fobs,what='1',n=1)
    print(n)
    print(date)
    allobs1hrmax[i,] <- array(scan(fobs,what=0.,n=nstations),
                        nstations)
    for (ist in 1:nstations) {
        if (allobs1hrmax[i,ist] < 0.) {
            allobs1hrmax[i,ist] <- NA
        }
    }
    i <- i+1
}
close(fobs)

for (j in 1:nens) {
    fmodel <- file(modelfiles[j],"ra")
    i <- 1
    print(cmodels[j])
    for (n in 1:ndays) {
        date <- scan(fmodel,what='1',n=1)
        print(date)	
        allmodels1hrmax[i,j,] <- array(scan(fmodel,what=0.,n=nstations),
				  nstations)
        for (ist in 1:nstations) {
            if (allmodels1hrmax[i,j,ist] < 0.) {
                allmodels1hrmax[i,j,ist] <- NA
            }
        }
        i <- i+1
    }
    close(fmodel)
}


rmsepred <- array(NA,nstations)
rmsekf   <- array(NA,nstations)
aveobs <- array(NA,nstations)

abskf <-array(0,nstations)
abspred <-array(0,nstations)

for (i in 1:nstations) {
    k <- 0
    print(i)
    obs <-array(NA,nhours)
    pred <-array(NA,nhours)
    for (j in 1:nhours) {
        if (allobs[j,i] >= 0.) {
            obs[j] <- allobs[j,i]
        } 
        if (min(allmodels[j,,i]) >= 0.) {
            pred[j] <- mean(allmodels[j,,i])
#            pred[j] <- allmodels[j,7,i]
        }
    }	
    kf <- kalmanfilter[,i]
    aveobs[i] <- mean(obs, na.rm=TRUE)
    rmsepred[i]  <- sum((pred-obs)^2, na.rm=TRUE)
    rmsekf[i]  <- sum((kf-obs)^2, na.rm=TRUE)
    
    if (is.nan(aveobs[i]) || rmsepred[i]==0 || rmsekf[i]==0) {
        abskf[i] <- NA
        abspred[i] <- NA
        rmsepred[i] <- NA
        rmsekf[i] <- NA
        next
    }

    for (j in 1:nhours) {
         if (!is.na(obs[j]) && !is.na(pred[j]) && !is.na(kf[j])) {
            abskf[i] <- (abs(kf[j]-aveobs[i])+
                         abs(obs[j]-aveobs[i]))^2+
                         abskf[i]
            abspred[i] <- (abs(pred[j]-aveobs[i])+
                           abs(obs[j]-aveobs[i]))^2+
                           abspred[i]
         }
    }
}


iofapred <- 1 - sum(rmsepred,na.rm=TRUE)/sum(abspred,na.rm=TRUE)
iofakf <- 1 - sum(rmsekf,na.rm=TRUE)/sum(abskf,na.rm=TRUE)


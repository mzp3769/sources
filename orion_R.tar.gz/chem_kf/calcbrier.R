nmodels <- nens
nintervals <- nmodels+1
allmodelsxhrmax <- singlem_kf1hrmax[,1:nmodels,] 
#allmodelsxhrmax <- allmodels1hrmax[,1:nmodels,]
allobsxhrmax <- allobs1hrmax

o_singlem <- array(NA,length(allobs1hrmax))
m_singlem <- o_singlem

j <- 0

thres <- 85.

for (iday in 1:ndays) {
    print(iday)
    k <- 0
    for (ist in 1:nstations) {

        if (is.na(allobsxhrmax[iday,ist]) ||
            any(is.na(allmodelsxhrmax[iday,,ist]))) {
           next
        }

        j <- j+1

        p_m <- 0

        for (iens in 1:nmodels) {
            if (allmodelsxhrmax[iday,iens,ist] > thres) { 
               p_m <- p_m+1
            }               
        }
	m_singlem[j] <- p_m/nmodels

        if (allobsxhrmax[iday,ist] > thres) {
	    o_singlem[j] <- 1.
        } else {
            o_singlem[j] <- 0.
        }
    }
}

source("brier.ensemble.R")
brierclass <- brier.ensemble(o_singlem[1:j],m_singlem[1:j],
baseline=NULL,n.members=nmodels )


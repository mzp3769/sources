#8hr

thresh8hr <- c(50,70,85)
nthresh <- length(thresh8hr)

a8hr <- array(0,c(nens+2,nthresh))
b8hr <- array(0,c(nens+2,nthresh))
c8hr <- array(0,c(nens+2,nthresh))
d8hr <- array(0,c(nens+2,nthresh))

for (iday in 1:ndays) {
    print(iday)
    for (ist in 1:nstations) {
        if (is.na(allobs8hrmax[iday,ist]) ||
            is.na(eqw8hrmax[iday,ist]) ||
            any(is.na(allmodels8hrmax[iday,,ist])) ||
            is.na(kf8hrmax[iday,ist])) next 

        for (ith in 1:nthresh) {
            if (allobs8hrmax[iday,ist] > thresh8hr[ith] ) {

                for (iens in 1:nens) {
                    if (allmodels8hrmax[iday,iens,ist] > thresh8hr[ith]) {
                       a8hr[iens,ith] <- a8hr[iens,ith] + 1	
                    } else {
                       c8hr[iens,ith] <- c8hr[iens,ith] + 1
                    }
                }

                if (kf8hrmax[iday,ist] > thresh8hr[ith]) {
                    a8hr[nens+1,ith] <- a8hr[nens+1,ith] + 1
                } else {
                    c8hr[nens+1,ith] <- c8hr[nens+1,ith] + 1
                }
                if (eqw8hrmax[iday,ist] > thresh8hr[ith]) {
                    a8hr[nens+2,ith] <- a8hr[nens+2,ith] + 1
                } else {
                    c8hr[nens+2,ith] <- c8hr[nens+2,ith] + 1
                }

            } else {

                for (iens in 1:nens) {
                    if (allmodels8hrmax[iday,iens,ist] > thresh8hr[ith]) {
                       b8hr[iens,ith] <- b8hr[iens,ith] + 1	
                    } else {
                       d8hr[iens,ith] <- d8hr[iens,ith] + 1
                    }
                }

                if (kf8hrmax[iday,ist] > thresh8hr[ith]) {
                    b8hr[nens+1,ith] <- b8hr[nens+1,ith] + 1
                } else {
                    d8hr[nens+1,ith] <- d8hr[nens+1,ith] + 1
                }
                if (eqw8hrmax[iday,ist] > thresh8hr[ith]) {
                    b8hr[nens+2,ith] <- b8hr[nens+2,ith] + 1
                } else {
                    d8hr[nens+2,ith] <- d8hr[nens+2,ith] + 1
                }
            }
        }
    }
}             


#1hr

thresh1hr <- c(50,70,85)
nthresh <- length(thresh1hr)

a1hr <- array(0,c(nens+2,nthresh))
b1hr <- array(0,c(nens+2,nthresh))
c1hr <- array(0,c(nens+2,nthresh))
d1hr <- array(0,c(nens+2,nthresh))

for (iday in 1:ndays) {
    print(iday)
    for (ist in 1:nstations) {
        if (is.na(allobs1hrmax[iday,ist]) ||
            is.na(eqw1hrmax[iday,ist]) ||
            any(is.na(allmodels1hrmax[iday,,ist])) ||
            is.na(kf1hrmax[iday,ist])) next 

        for (ith in 1:nthresh) {
            if (allobs1hrmax[iday,ist] > thresh1hr[ith] ) {

                for (iens in 1:nens) {
                    if (allmodels1hrmax[iday,iens,ist] > thresh1hr[ith]) {
                       a1hr[iens,ith] <- a1hr[iens,ith] + 1	
                    } else {
                       c1hr[iens,ith] <- c1hr[iens,ith] + 1
                    }
                }

                if (kf1hrmax[iday,ist] > thresh1hr[ith]) {
                    a1hr[nens+1,ith] <- a1hr[nens+1,ith] + 1
                } else {
                    c1hr[nens+1,ith] <- c1hr[nens+1,ith] + 1
                }
                if (eqw1hrmax[iday,ist] > thresh1hr[ith]) {
                    a1hr[nens+2,ith] <- a1hr[nens+2,ith] + 1
                } else {
                    c1hr[nens+2,ith] <- c1hr[nens+2,ith] + 1
                }

            } else {

                for (iens in 1:nens) {
                    if (allmodels1hrmax[iday,iens,ist] > thresh1hr[ith]) {
                       b1hr[iens,ith] <- b1hr[iens,ith] + 1	
                    } else {
                       d1hr[iens,ith] <- d1hr[iens,ith] + 1
                    }
                }

                if (kf1hrmax[iday,ist] > thresh1hr[ith]) {
                    b1hr[nens+1,ith] <- b1hr[nens+1,ith] + 1
                } else {
                    d1hr[nens+1,ith] <- d1hr[nens+1,ith] + 1
                }
                if (eqw1hrmax[iday,ist] > thresh1hr[ith]) {
                    b1hr[nens+2,ith] <- b1hr[nens+2,ith] + 1
                } else {
                    d1hr[nens+2,ith] <- d1hr[nens+2,ith] + 1
                }
            }
        }
    }
}             


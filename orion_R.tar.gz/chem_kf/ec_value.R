#to calculate economic value of forecasts

tot8hr <- (a8hr+b8hr+c8hr+d8hr)
aa8hr <- a8hr/tot8hr
bb8hr <- b8hr/tot8hr
cc8hr <- c8hr/tot8hr
dd8hr <- d8hr/tot8hr

tot1hr <- (a1hr+b1hr+c1hr+d1hr)
aa1hr <- a1hr/tot1hr
bb1hr <- b1hr/tot1hr
cc1hr <- c1hr/tot1hr
dd1hr <- d1hr/tot1hr

rvec <- seq(0,1,by=.0025)
rlength <- length(rvec)
ecv8hr <- array(NA,c((nens+2),nthresh,rlength))
ecv1hr <- ecv8hr

ecvfunc <- function(a,b,c,r,rlength) {
   o <- a+c
   ecv <- array(NA,rlength) 
   for (i in 1:rlength) {
      ecv[i] <- (min(o,r[i])-(a+b)*r[i]-c)/(min(o,r[i])-o*r[i])
   }
   return(ecv)
}

for (iens in 1:(nens+2)) {
    for (ith in 1:nthresh) {
        ecv8hr[iens,ith,] <- ecvfunc(aa8hr[iens,ith],bb8hr[iens,ith],
                                     cc8hr[iens,ith],rvec,rlength)
        ecv1hr[iens,ith,] <- ecvfunc(aa1hr[iens,ith],bb1hr[iens,ith],
                                     cc1hr[iens,ith],rvec,rlength)
    }    
}        

#to calculate economic value of ensemble forecasts

thres <- 85.
allmodelsxhrmax <-  allmodels8hrmax 
#allmodelsxhrmax <-  singlem_kf8hrmax[,1:nmodels,]
allobsxhrmax <- allobs8hrmax
rvec <- seq(0,1,by=.0025)
rlength <- length(rvec)
econv <- array(NA,c(nintervals,rlength))

nmodels <- nens
nintervals <- nmodels+1

a <- array(0.,nintervals)
b <- a
c <- a
d <- a

source("probs.R")

source("ecvfunc_r.R")

for (i in 1:nintervals) {
#    tot <- a[i]+b[i]+c[i]+d[i]
#    aa <- a[i]/tot
#    bb <- b[i]/tot
#    cc <- c[i]/tot
#    dd <- d[i]/tot
#    econv[i,] <- ecvfunc(aa,bb,cc,i/nintervals,rlength)

    tot <- a[i]+b[i]+c[i]+d[i]
    s <- (a[i]+c[i])/tot
    h <- a[i]/(a[i]+c[i])
    f <- b[i]/(b[i]+d[i])
    econv[i,] <- ecvfunc(h,f,s,rlength)
}


#print(a)
#print(b)
#print(c)
#print(d)
#for (i in 1:nintervals) {
#    print(sum(a[i],b[i],c[i],d[i]))
#}

#for (i in 1:nintervals) {
#    print(sum(a[i],c[i]))
#}
#print(o)

#for (i in 1:nintervals) {
#    print(sum(b[i],d[i]))
#}
#print(no)

#print(j)








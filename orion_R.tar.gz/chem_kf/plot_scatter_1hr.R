postscript("scatter_kf_1hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlims <- c(0,120)
ylims <- c(0,120)


xlabstring <- expression(paste("Observations ",O[3]," (ppbv)"))
ylabstring <- expression(paste("DLR ",O[3]," (ppbv)"))

plot(allobs1hrmax,kf1hrmax,type="p",col="black",
     xlim=xlims,ylim=ylims,pch=19,cex=.2,xaxs="i",yaxs="i",
     xlab=xlabstring,ylab=ylabstring)
lines(xlims,ylims,type="l",col="black")

text(10,110,labels="d",cex=1.3,vfont=c("serif","plain"))

dev.off()


postscript("scatter_eqw_1hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring <- expression(paste("Observations ",O[3]," (ppbv)"))
ylabstring <- expression(paste("AVE ",O[3]," (ppbv)"))

plot(allobs1hrmax,eqw1hrmax,type="p",col="black",
     xlim=xlims,ylim=ylims,pch=19,cex=.2,xaxs="i",yaxs="i",
     xlab=xlabstring,ylab=ylabstring)
lines(xlims,ylims,type="l",col="black")

text(10,110,labels="e",cex=1.3,vfont=c("serif","plain"))

dev.off()


postscript("scatter_persist_1hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring <- expression(paste("Observations ",O[3]," (ppbv)"))
ylabstring <- expression(paste("Persistence ",O[3]," (ppbv)"))

plot(allobs1hrmax,persist1hrmax,type="p",col="black",
     xlim=xlims,ylim=ylims,pch=19,cex=.2,xaxs="i",yaxs="i",
     xlab=xlabstring,ylab=ylabstring)
lines(xlims,ylims,type="l",col="black")

text(10,110,labels="f",cex=1.3,vfont=c("serif","plain"))

dev.off()

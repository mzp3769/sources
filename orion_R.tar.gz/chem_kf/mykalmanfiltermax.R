# myKalmanFilter(obs, models, delta)
# Author: MP CIRA, June 2005 

myKalmanFiltermax <- function(obs, models, delta) {

    tlength  <- length(obs)	    
    mykf <- array(NA,tlength)
    weights <- array(NA,c(tlength,nens))
    phi <- array(NA,nens)
    psi <- array(NA,nens)

    n <- 1
    d <- .1
    s <- d/n
    m <- array(1./nens,nens)	
    c <- array(1.,nens)
    for (t in seq(1,tlength)) {
           modelst <- models[t,]
           obst <- obs[t]

           dobreak <- 0
           for (iens in 1:nens) {
                if (is.na(modelst[iens])) {
                    mykf[t] <- NA
                    weights[t,] <- NA
#                    print(t)
                    dobreak <- 1
                    break
                }
           }

           if (dobreak==1) next
  
           if (is.na(obst)) {
               mykf[t] <- NA
               weights[t,] <- NA
#               print(t)
               next
           }

           f <- as.numeric(crossprod(modelst,m))
           mykf[t] <- f
           weights[t,] <- m
           phi <- c/delta
           psi <- as.numeric(crossprod(modelst^2,phi)) + s

           n <- n+1
           e <- obst-f
           d <- d + s*e^2/psi
           s <- d/n

           k <- c(modelst * phi)/psi
           m <- m + k*e
           c <- s/psi * phi

    }

    kflistmax <- list("kfmax"=mykf,"weightsmax"=weights)

return(kflistmax)

}



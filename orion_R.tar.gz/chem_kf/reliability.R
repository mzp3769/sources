nmodels <- nens
allmodelsxhrmax <- allmodels1hrmax
allobsxhrmax <- allobs1hrmax

p_obs <- array(0.,c(ndays+1,nens+1))
p_models <- array(0.,c(ndays+1,nens+1))

j <- 0

thres <- 83.

brier <- 0
rel <- 0.
resol <- 0.

for (iday in 1:ndays) {
    print(iday)
    k <- 0
    for (ist in 1:nstations) {
        if (is.na(allobsxhrmax[iday,ist]) ||
            any(is.na(allmodelsxhrmax[iday,,ist]))) {
           next
        }

        k <- k+1
        j <- j+1

        p_m <- 0
        for (iens in 1:nens) {
            if (allmodelsxhrmax[iday,iens,ist] > thres) { 
               p_m <- p_m+1
            }               
        }
        p_models[iday,p_m+1] <- p_models[iday,p_m+1]+1  
        p_models[ndays+1,p_m+1] <- p_models[ndays+1,p_m+1]+1  


	o <- 0
        if (allobsxhrmax[iday,ist] > thres) {
           p_obs[iday,p_m+1] <- p_obs[iday,p_m+1]+1
           p_obs[ndays+1,p_m+1] <- p_obs[ndays+1,p_m+1]+1
	   o <- 1
        }
    rel <- (p_m/(nmodels+1)-o)^2+rel
    brier <- (p_m/(nmodels+1)-o)^2 + brier 

    }

    p_obs[iday,] <- p_obs[iday,]/p_models[iday,]
    p_models[iday,] <- p_models[iday,]/k
}

#p_obs[ndays+1,] <- p_obs[ndays+1,]/sum(p_obs[ndays+1,])#j
#p_obs[ndays+1,] <- p_obs[ndays+1,]/j
p_obs[ndays+1,] <- p_obs[ndays+1,]/p_models[ndays+1,]
p_models[ndays+1,] <- p_models[ndays+1,]/j

rel <- rel/j
brier <- brier/j
                            


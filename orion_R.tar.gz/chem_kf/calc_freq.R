#allobs8hrmax
#allmodels8hrmax
#match(75,sorted_models8hrmax$x)

nall_mod <- ndays*nens*nstations
nall_mod_daily <- nens*nstations
n_nna_models_daily <- array(NA,ndays)
n_nna_obs_daily <- array(NA,ndays)
unsorted_models8hrmax <- array(NA,nall_mod)
unsorted_models8hrmax_daily <- array(NA,c(ndays,nall_mod_daily))
sorted_models8hrmax_daily <- array(NA,c(ndays,nstations*nens,2))


nall_obs <- ndays*nstations
nall_obs_daily <- nstations
unsorted_obs8hrmax <- array(NA,nall_obs)
unsorted_obs8hrmax_daily <- array(NA,c(ndays,nall_obs_daily))
sorted_obs8hrmax_daily <- unsorted_obs8hrmax_daily


i <- 0
j <- 0
for (iday in 1:ndays) { 
    k <- 0
    print("assigning")
    print(iday)
    for (ist in 1:nstations) {
        if (is.na(allobs8hrmax[iday,ist]) ||
            any(is.na(allmodels8hrmax[iday,,ist]))) {
           next
        }
        i <- i+1
        j <- (i-1)*nens+1
        unsorted_models8hrmax[j:(j+nens-1)] <- 
                             allmodels8hrmax[iday,(1:nens),ist]
        unsorted_obs8hrmax[i] <- allobs8hrmax[iday,ist]

        k <- k+1
        l <- (k-1)*nens+1
        unsorted_models8hrmax_daily[iday,l:(l+nens-1)] <- 
                             allmodels8hrmax[iday,(1:nens),ist]
        unsorted_obs8hrmax_daily[iday,k] <- allobs8hrmax[iday,ist]

#checking for correct conversion
#        if (i == 15000) {
#            print(unsorted_obs8hrmax[i])
#            print(unsorted_models8hrmax[j:(j+nens-1)])
#            print(allobs8hrmax[iday,ist])
#            print(allmodels8hrmax[iday,,ist])
#        }
    }
    n_nna_models_daily[iday] <- l+nens-1
    n_nna_obs_daily[iday] <- k
}

n_nna_models <- j+nens-1
n_nna_obs <- i

sorted_models8hrmax <- sort(unsorted_models8hrmax,
                            decreasing = FALSE,method = "shell",
                            index=TRUE)

for (iday in 1:ndays) {
     print(iday)
     list <- sort(unsorted_models8hrmax_daily[iday,],
                  decreasing = FALSE,method = "shell",
                  index=TRUE)
     if ((n_nna_obs_daily[iday]==0) ||
         (n_nna_models_daily[iday]==0)) {
        sorted_models8hrmax_daily[iday,,] <- NA
     } else {

        sorted_models8hrmax_daily[iday,(1:n_nna_models_daily[iday]),1] <-
                             list$x 
        sorted_models8hrmax_daily[iday,(1:n_nna_models_daily[iday]),2] <-
                             list$ix 
     }
}

n_freq <- c(1:n_nna_models)/n_nna_models

#get thresholds
ntthresh <- nens
thresholds <- array(NA,c(ndays+1,ntthresh))

for (iday in 1:ndays) {
    for (itthresh in 1:ntthresh) {
        i <- n_nna_models_daily[iday]*itthresh/ntthresh
        thresholds[iday,itthresh] <- sorted_models8hrmax_daily[iday,i,1]
    }
} 

for (itthresh in 1:ntthresh) {
     i <- n_nna_models*itthresh/ntthresh
     thresholds[ndays+1,itthresh] <- sorted_models8hrmax$x[i]
}
    


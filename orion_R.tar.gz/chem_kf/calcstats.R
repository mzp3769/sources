eqwpred <- array(NA,c(nhours,nstations))

rmsepred <- array(NA,nhours)
rmsekf   <- array(NA,nhours)
biaspred <- array(NA,nhours)
biaskf   <- array(NA,nhours)
corpred <- array(NA,nhours)
corkf   <- array(NA,nhours)


rrmsepred <- array(NA,nstations)
rrmsekf   <- array(NA,nstations)
bbiaspred <- array(NA,nstations)
bbiaskf   <- array(NA,nstations)
aveobs <- array(NA,nstations)
avepred <- array(NA,nstations)
avekf <- array(NA,nstations)
ccorpred <- array(NA,nstations)
ccorkf <- array(NA,nstations)
stdevobs <- array(NA,nstations)
stdevpred <- array(NA,nstations)
stdevkf <- array(NA,nstations)
obsplt <- array(NA,c(nhours,nstations))
eqwpredplt <- array(NA,c(nhours,nstations))

ntot <- 0

for (i in 1:nstations) {
    k <- 0
    print(i)
    obs <-array(NA,nhours)
    pred <-array(NA,nhours)
    for (j in 1:nhours) {
        if (allobs[j,i] >= 0. && min(allmodels[j,,i]) >= 0.) {
            ntot <- ntot + 1
        }

        if (allobs[j,i] >= 0.) {
            obs[j] <- allobs[j,i]
            obsplt[j,i] <- obs[j]
        } 
        if (min(allmodels[j,,i]) >= 0.) {
            pred[j] <- mean(allmodels[j,,i])
#            pred[j] <- mean(allmodels[j,7,i])
            eqwpredplt[j,i] <- pred[j]
        }
    }



    kf <- kalmanfilter[,i]

    aveobs[i] <- mean(obs, na.rm=TRUE)
    avepred[i] <- mean(pred, na.rm=TRUE)
    avekf[i] <- mean(kf, na.rm=TRUE)
    stdevobs[i] <- sd(obs, na.rm=TRUE)
    stdevpred[i] <- sd(pred, na.rm=TRUE)
    stdevkf[i] <- sd(kf, na.rm=TRUE)
    ccorpred[i] <- cor(obs,pred,use="complete.obs")
    ccorkf[i] <- cor(obs,kf,use="complete.obs")
    rrmsepred[i]  <- 
                    #sqrt
                         (mean((pred-obs)^2, na.rm=TRUE))
    rrmsekf[i]  <- 
                    #sqrt
                         (mean((kf-obs)^2, na.rm=TRUE))

#    bbiaspred[i]  <- 
#                    #sqrt
#                         (mean((pred-obs), na.rm=TRUE))
#    bbiaskf[i]  <- 
#                    #sqrt
#                         (mean((kf-obs), na.rm=TRUE))


}

for (j in 1:nhours) {
     rmsepred[j] <- 
                    #sqrt
                    (mean((eqwpredplt[j,]-obsplt[j,])^2,na.rm=TRUE))
     biaspred[j] <- mean((eqwpredplt[j,]-obsplt[j,]),na.rm=TRUE)
     rmsekf[j] <- 
                    #sqrt 
                    (mean((kalmanfilter[j,]-obsplt[j,])^2,na.rm=TRUE))
     biaskf[j] <- mean((kalmanfilter[j,]-obsplt[j,]),na.rm=TRUE)


     corpred[j] <- cor(eqwpredplt[j,],obsplt[j,],
                        use="complete.obs")
     corkf[j] <- cor(kalmanfilter[j,],obsplt[j,],
                        use="complete.obs")

     }

rmsepredave <- sqrt(mean(rmsepred,na.rm=TRUE))
biaspredave <- mean(biaspred,na.rm=TRUE)
corpredave <- sqrt(mean(corpred,na.rm=TRUE))

rmsekfave <- sqrt(mean(rmsekf,na.rm=TRUE))
biaskfave <- mean(biaskf,na.rm=TRUE)
corkfave <- mean(corkf,na.rm=TRUE)

bbiaspred <- mean((avepred-aveobs),na.rm=TRUE)
bbiaskf <- mean((avekf-aveobs),na.rm=TRUE)
rrmsepredave <- sqrt(mean(rrmsepred,na.rm=TRUE))
rrmsekfave <- sqrt(mean(rrmsekf,na.rm=TRUE))
ccorpredave <- mean(ccorpred,na.rm=TRUE)
ccorkfave <- mean(ccorkf,na.rm=TRUE)    

stdevobsave <- mean(stdevobs,na.rm=TRUE)
stdevpredave <- mean(stdevpred,na.rm=TRUE)
stdevkfave <- mean(stdevkf,na.rm=TRUE)

allstats <- array(c(bbiaspred,bbiaskf,rrmsepredave,rrmsekfave,
                    ccorpredave,ccorkfave),6)
#                    stdevobsave,stdevpredave,stdevkfave),10)


#title <- paste(cmodels[1:nens],sep="")
title <- "all_resultss.txt"

write(cmodels,file=title,ncolumns=nens,append=TRUE)
write(paste("delta = ",as.character(delta),time),file=title,append=TRUE)
write(allstats,file=title,ncolumns=10,append=TRUE)

title <- "all_results.txt"
allstats2 <- array(c(biaspredave,biaskfave,rmsepredave,rmsekfave,
                  corpredave,corkfave),6)
write(cmodels,file=title,ncolumns=nens,append=TRUE)
write(paste("delta = ",as.character(delta),time),file=title,append=TRUE)
write(allstats2,file=title,ncolumns=10,append=TRUE)

#rm(allobs,allmodels)

nmodels <- nens
nintervals <- nmodels+1
allmodelsxhrmax <- singlem_kf1hrmax[,1:nmodels,]
allobsxhrmax <- allobs1hrmax

o_singlem <- array(NA,length(allobs1hrmax))
m_singlem <- array(NA,c(length(allobs1hrmax),nmodels))

j <- 0

thres <- 50.

for (iday in 1:ndays) {
    print(iday)
    k <- 0
    for (ist in 1:nstations) {
        if (is.na(allobsxhrmax[iday,ist]) ||
            any(is.na(allmodelsxhrmax[iday,,ist]))) {
           next
        }

        j <- j+1

        for (iens in 1:nmodels) {
            if (allmodelsxhrmax[iday,iens,ist] >= thres) { 
		m_singlem[j,iens] <- 1.
	    } else {
                m_singlem[j,iens] <- 0.
            }               
        }

        if (allobsxhrmax[iday,ist] >= thres) {
	    o_singlem[j] <- 1.
        } else {
            o_singlem[j] <- 0.
        }
    }
}

brier(o_singlem[1:j],m_singlem[1:j,])
cols <- rainbow(100)
#plot reliability - jgr

postscript("reliability_1hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

par(ann=TRUE)
par(mar=c(4,4,2,2))
par(lab=c(4,4,4))
par(las=0)
par(cex.axis=1)
par(cex.lab=1)
plot(c(0:nens)/nens,o501,type="l",lwd=3,
col="blue",xlim=c(0,1),ylim=c(0,1.),
xlab="forecast probability",ylab="observed frequency",
xaxs="i",yaxs="i")
points(c(0:nens)/nens,o501,type="p",pch=19,cex=1,col="blue")


lines(c(0:nens)/nens,o701,type="l",lwd=3,
col="purple")
points(c(0:nens)/nens,o701,type="p",pch=19,cex=1,col="purple")

lines(c(0:nens)/nens,o851,type="l",lwd=3,
col="red")
points(c(0:nens)/nens,o851,type="p",pch=19,cex=1,col="red")


lines(seq(0,1,by=.1),seq(0,1,by=.1),type="l",lwd=2,lty=2,col="black")

par(plt=c(.165,.4,.7,.9))
par(new=TRUE)
par(lab=c(1,1,1))
par(ann=FALSE)

plot(c(0:nens)/nens,(0:nens)/nens, type = "n",axes=FALSE,yaxs="i")
lines(c(0:nens)/nens-0.025,m501,type="h",lwd=4,
col="blue")

lines(c(0:nens)/nens,m701,type="h",lwd=4,
col="purple")

lines(c(0:nens)/nens+.025,m851,type="h",lwd=4,
col="red")


lines(seq(-.25,1.25,by=(1.5/7)),
array(b501$obar,nens+1),type="l",lty=5,lwd=2,
col="blue")

lines(seq(-.25,1.25,by=(1.5/7)),
array(b701$obar,nens+1),type="l",lty=5,lwd=2,
col="purple")


lines(seq(-.25,1.25,by=(1.5/7)),
array(b851$obar,nens+1),type="l",lty=5,lwd=2,
col="red")



#axis(1,pos=.0,labels=FALSE,tcl=.1)
#axis(3,pos=1,labels=FALSE,tcl=.1)
lines(c(-1:(nens+1))/nens,c(-1:(nens+1))/nens*0)
lines(c(-1:(nens+1))/nens,c(-1:(nens+1))/nens*0+1)
axis(2,labels=FALSE,tcl=.1)
#par(lab=c(1,1,1))
par(cex.axis=.75)
par(las=1)
axis(4,tcl=.2,at=c(0,.5,1.))
text(.175,.8,labels="b",cex=1.5,vfont=c("serif","plain"))


dev.off()
# myKalmanFilter(obs, models, par, algorithm)
# Author: MP CIRA, June 2005 
# Adapten from Luca's code for the ensemble
# Description: Kalman filters data
# Input
#   obs = array of observations
#   models = array of predictions for ensembles
#   weights for the ensembles
#   par = parameters
#       par$varobs = observation variance 
#       par$varweights = prediction variance 
#       par$iperiod = initialization period (training period)
#       par$mv = value corresponding to missing value 
#   Algorithm = specifies which approach to filter
#       1 = current operational mode, where coefficients are calculated
#       only from data at the same time of day
#       2 = calculates coefficients from the previous 'par$update' hours
# Output
#   newKf = Kalman filtered predictions. Time series aligned with the
#   prediction.


myKalmanFilter <- function(obs, models, weights, par, algorithm) {

    # 1 enforces concentrations to be >=0.
    enforcePositiveValues  <- 1
    
# Initialization
    errobscov  <- par$varobs
    errweightscov  <- errproccov
    tlength  <- length(obs)	    
    weights <- array(1./nens,c(nens,tlength))

    origpred  <- models  %*% weights
    pred <- array(NA,tlength)
    errproccov  <- array(0.,c(nens,nens))
    identity <- array(0.,c(nens,nens))
    for (i in 1:nens) { 
        identity[i,i] <- 1. 
        errproccov[i,i] <- par$varobs*par$ratio
    }
    weightst <- array(NA,c(nens,1))
    modelst <-  array(NA,c(1,nens))

    i <- 1
    if (algorithm == 1){
       weightst[,] <- weights[,1]
       for (hour in 1:24) {
           for (t in seq(24+hour,tlength,by=24)) {
               obst <- obs[t]
               modelst[,] <- models[t,]
               modelstt <- t(modelst)
               predt <- modelst %*% weightst
               if (predt > 0 && obst  > 0 ) {
                   pred[t] <- predt
                   errweightscov <- errweightscov + errproccov
                   inv <-  as.numeric(modelst %*% errweightscov %*% 
                         modelstt +  errobscov) 
                   kgain <- (errweightscov %*% t(modelst))/inv

	           weightst <- weightst +  kgain %*% (obst - predt)

                   errweightscov <- (identity - kgain %*% modelst) %*% 
                                 errweightscov
                   i <- i+1
                   weights[,t] <- weightst
                   print(weightst)
               } else {
                   pred[t] <- NA
                   obs[t] <- NA
               }  
#                   if (weights[,t] < 0) weights[,t] <- 0
	   }
       }
# Shift the bias such that the bias from 
# the previous day is used when combined with the model forecasts

#       weights[,25:tlength] <- weights[1:(tlength-24)]    


    } else { if (algorithm == 2) {
        weightst[,] <- weights[,1]
        for (t in 2:tlength) {
            obst <- obs[t]
            modelst[,] <- models[t,]
            modelstt <- t(modelst)
            predt <- modelst %*% weightst
            if (predt > 0 && obst  > 0 ) {
                pred[t] <- predt
                errweightscov <- errweightscov + errproccov
                inv <-  as.numeric(modelst %*% errweightscov %*%
                      modelstt +  errobscov)
                kgain <- (errweightscov %*% t(modelst))/inv

                weightst <- weightst +  kgain %*% (obst - predt)

                errweightscov <- (identity - kgain %*% modelst) %*%
                                 errweightscov
                i <- i+1
                weights[,t] <- weightst
                print(weightst)
             } else {
                 pred[t] <- NA
                 obs[t] <- NA
             }

        }

    }

# Low pass filter
    for (t in 2:{tlength-1}) {
        x[t] <- 0.5*x[t] + 0.25*(x[t-1] + x[t+1])
    }

    for (t in 2:{tlength-1}) {
        x[t] <- 0.5*x[t] + 0.25*(x[t-1] + x[t+1])
    }

# Remove bias from forecast

    for (t in 1:tlength) {
        if (pred[t] >=0.) {
            kf[t] <- pred[t] - x[t]
# Enforcing positive values
            if (enforcePositiveValues == 1) {
                if (kf[t] < 0) {
                   kf[t] <- 0
                }
            }
        }
    }

# Start time
    t1 <- maxtlength 
# End time
    t2 <- tlength-1 + maxtlength + timeZoneVancouver-par$timeZone   

    time <- t1:t2

#    errorPred <- (sum(errorPred) / errorC)^0.5
#    errorKf <- (sum(errorKf) / errorC)^0.5

# Readjust kalman filtered output:

    newKf <- originalPred
    newKf[(1-par$start[2]+maxtlength):
	(originaltlength-par$start[2]+mintlength)] <- kf

    kalmanfilter <-list("time"=time,"obs"=obs,"pred"=pred,"newKf"=newKf)
#			"errorPred"=errorPred,"errorKf"=errorKf)

return(kalmanfilter)

}



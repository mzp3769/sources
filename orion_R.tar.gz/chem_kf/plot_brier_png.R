#8hr

brier8hr <- array(NA,c(4,3))
brier8hr[1,1] <- b508$bs
brier8hr[2,1] <- b508$bs.reliability
brier8hr[3,1] <- b508$bs.resol
brier8hr[4,1] <- b508$bs.uncert

brier8hr[1,2] <- b708$bs
brier8hr[2,2] <- b708$bs.reliability
brier8hr[3,2] <- b708$bs.resol
brier8hr[4,2] <- b708$bs.uncert


brier8hr[1,3] <- b858$bs
brier8hr[2,3] <- b858$bs.reliability
brier8hr[3,3] <- b858$bs.resol
brier8hr[4,3] <- b858$bs.uncert


postscript("brier_8hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("Brier score and its components")

barplot(brier8hr,
beside=TRUE,xlim=c(1,20),space=c(0,2),
#names.arg=c("50","70","85"),col=rainbow(4),
names.arg=c("50","70","85"),
ylim=c(0,.3),xlab=xlabstring,ylab=ylabstring,
legend=c("BS","REL","RES","UNC"))
axis(1,at=c(0,50))
text(2,.275,labels="a",cex=1.5,vfont=c("serif","plain"))

dev.off()

#1hr

brier1hr <- array(NA,c(4,3))
brier1hr[1,1] <- b501$bs
brier1hr[2,1] <- b501$bs.reliability
brier1hr[3,1] <- b501$bs.resol
brier1hr[4,1] <- b501$bs.uncert

brier1hr[1,2] <- b701$bs
brier1hr[2,2] <- b701$bs.reliability
brier1hr[3,2] <- b701$bs.resol
brier1hr[4,2] <- b701$bs.uncert


brier1hr[1,3] <- b851$bs
brier1hr[2,3] <- b851$bs.reliability
brier1hr[3,3] <- b851$bs.resol
brier1hr[4,3] <- b851$bs.uncert


postscript("brier_1hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("Brier score and its components")

barplot(brier1hr,
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("50","70","85"),
ylim=c(0,.3),xlab=xlabstring,ylab=ylabstring,
legend=c("BS","REL","RES","UNC"))
axis(1,at=c(0,50))
text(2,.275,labels="b",cex=1.5,vfont=c("serif","plain"))

dev.off()


#8hr

brier8hrsm <- array(NA,c(4,3))
brier8hrsm[1,1] <- b508sm$bs
brier8hrsm[2,1] <- b508sm$bs.reliability
brier8hrsm[3,1] <- b508sm$bs.resol
brier8hrsm[4,1] <- b508sm$bs.uncert

brier8hrsm[1,2] <- b708sm$bs
brier8hrsm[2,2] <- b708sm$bs.reliability
brier8hrsm[3,2] <- b708sm$bs.resol
brier8hrsm[4,2] <- b708sm$bs.uncert


brier8hrsm[1,3] <- b858sm$bs
brier8hrsm[2,3] <- b858sm$bs.reliability
brier8hrsm[3,3] <- b858sm$bs.resol
brier8hrsm[4,3] <- b858sm$bs.uncert


postscript("brier_8hrsm.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("Brier score and its components")

barplot(brier8hrsm,
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("50","70","85"),
ylim=c(0,.3),xlab=xlabstring,ylab=ylabstring,
legend=c("BS","REL","RES","UNC"))
axis(1,at=c(0,50))
text(2,.275,labels="a",cex=1.5,vfont=c("serif","plain"))

dev.off()

#1hr

brier1hrsm <- array(NA,c(4,3))
brier1hrsm[1,1] <- b501sm$bs
brier1hrsm[2,1] <- b501sm$bs.reliability
brier1hrsm[3,1] <- b501sm$bs.resol
brier1hrsm[4,1] <- b501sm$bs.uncert

brier1hrsm[1,2] <- b701sm$bs
brier1hrsm[2,2] <- b701sm$bs.reliability
brier1hrsm[3,2] <- b701sm$bs.resol
brier1hrsm[4,2] <- b701sm$bs.uncert


brier1hrsm[1,3] <- b851sm$bs
brier1hrsm[2,3] <- b851sm$bs.reliability
brier1hrsm[3,3] <- b851sm$bs.resol
brier1hrsm[4,3] <- b851sm$bs.uncert


postscript("brier_1hrsm.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("Brier score and its components")

barplot(brier1hrsm,
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("50","70","85"),
ylim=c(0,.3),xlab=xlabstring,ylab=ylabstring,
legend=c("BS","REL","RES","UNC"))
axis(1,at=c(0,50))
text(2,.275,labels="b",cex=1.5,vfont=c("serif","plain"))

dev.off()



# KalmanFilter3(obs, pred, par, algorithm)
# Author: Thomas Nipen - converted from MATLAB to R by M.P.
# Date: 050331
# Description: Kalman filters data
# Input
#   obs = array of observations
#   pred = array of predictions
#   par = parameters
#       par$varo = observation variance threshold
#       par$varp = prediction variance threshold
#       par$iperiod = initialization period (training period)
#       par$mv = value corresponding to missing value - removed to be < 0
#       par$update = time between update (24 hours) (only for algorithm 2)
#       par$start = start time of time series [obs pred]. For AQ data,
#           par$start = [8 15]
#       par$timeZone = timeZone of measurements (for output graphics). For
#       AQ data = 0 (UTC).
#   Algorithm = specifies which approach to filter
#       1 = current operational mode, where coefficients are calculated
#       only from data at the same time of day
#       2 = calculates coefficients from the previous 'par$update' hours
# Output
#   newKf = Kalman filtered predictions. Time series aligned with the
#   prediction.


KalmanFilter3 <- function(obs, pred, par, algorithm) {
# Parameters
    timeZoneVancouver <- -8
    # 1 enforces concentrations to be >=0.
    enforcePositiveValues  <- 1
    
# Initialization
    
    originalPred  <- pred
    originaltlength  <- length(obs)
    
    # Adjust starting time of different time series
    mintlength  <- min(par$start)
    maxtlength  <- max(par$start)
    reductiontlength  <- maxtlength - mintlength
    obs  <- obs[(1-par$start[1]+maxtlength):
		(originaltlength-par$start[1]+mintlength)]
    pred  <- pred[(1-par$start[2]+maxtlength):
		(originaltlength-par$start[2]+mintlength)]
   
    tlength  <- length(obs)
    kf  <- array(NA,tlength)   # Stores KF predictions
    y  <- array(0.,tlength)    # Forecast error
    x  <- array(0.,tlength)    # Bias

    y  <- pred - obs     # 
    ratio  <- 1
#1 & 2    ratio  <- 0.01
    x[1]  <- 0.             # Initial bias

# Calculate coefficients
# sigv = "sigmasubepsilon" in the paper
# sigw = "sigmasubeta" in the paper
# Kalman_gain = "beta" in the aper
# p_"var" means previous "deltat" (as in the paper) "var" value

    if (algorithm == 1){
       for (hour in 1:24) {
           for (t in seq(24+hour,tlength,by=24)) {
                # Initial values
                px  <- 1            # Previous bias
                LastError  <- 0       # Previous error
                kalmangain  <- 1
                sigv  <- 1
                psigv  <- 1000

                if(obs[t] >= 0. && pred[t] >= 0. ) {
                    y[t-24] <- LastError
                    if (y[t - 24] != par$missing){
                        kalmangain  <- (psigv + par$varo)/
			               (psigv + par$varo + par$varp)
                        psigv <- (psigv + par$varo)*(1- kalmangain)
                        sigv <- sigv +
                        (kalmangain * ((y[t] - y[t - 24])^2/2 - sigv))
                    }
                    sigw <- ratio * sigv
                    kalmangain <- (px + sigw)/(px + sigw + sigv)
                    px <- (px + sigw) * (1 - kalmangain)
                    x[t] <- x[t - 24] + kalmangain *(y[t] - x[t - 24])
                    LastError <- y[t]
                } else {
                    LastError <- par$missing
                    px <- px + ratio * sigv
                    if (px > 10000)
                        px <- 10000
                    x[t] <- x[t-24]
                }
	   }
       }
# Shift the bias such that the bias from 
# the previous day is used when combined with the model forecasts$

       x[25:tlength] <- x[1:(tlength-24)]    

    } else { if (algorithm == 2) {
        for (t in 2:tlength) {
            # Initial values
            px <- 1            # Previous bias
            LastError <- 0       # Previous error
            kalmangain <- 1
            sigv <- 1
            psigv <- 1000

            if(obs[t] >= 0. && pred[t] >= 0.) {
                y[t - 1] <- LastError
                if (y[t - 1] != par$missing) {
                    kalmangain  <- (psigv + par$varo)/
                    (psigv + par$varo + par$varp)
                    psigv <- (psigv + par$varo)*(1- kalmangain)
                    sigv <- sigv +
                    (kalmangain * ((y[t] - y[t-1])^2/2 - sigv))
                }
                sigw <- ratio * sigv
                kalmangain <- (px + sigw)/(px + sigw + sigv)
                px <- (px + sigw) * (1 - kalmangain)
                x[t] <- x[t - 1] + kalmangain *(y[t] - x[t - 1])
                LastError <- y[t]
            } else {
                LastError <- par$missing
                px <- px + ratio * sigv
                if(px > 10000) {
                    px <- 10000
                }
                x[t] <- x[t-1]
            }
        }
        x[(1+par$update):tlength] <- x[1:(tlength-par$update)]
        x[1:par$update] <- array(0., par$update)
        }
    }
 

# Low pass filter
    for (t in 2:{tlength-1}) {
        x[t] <- 0.5*x[t] + 0.25*(x[t-1] + x[t+1])
    }

    for (t in 2:{tlength-1}) {
        x[t] <- 0.5*x[t] + 0.25*(x[t-1] + x[t+1])
    }

# Remove bias from forecast

    for (t in 1:tlength) {
        if (pred[t] >=0.) {
            kf[t] <- pred[t] - x[t]
# Enforcing positive values
            if (enforcePositiveValues == 1) {
                if (kf[t] < 0) {
                   kf[t] <- 0
                }
            }
        }
    }

# Start time
    t1 <- maxtlength + timeZoneVancouver-par$timeZone         
# End time
    t2 <- tlength-1 + maxtlength + timeZoneVancouver-par$timeZone   

    time <- t1:t2

#    errorPred <- (sum(errorPred) / errorC)^0.5
#    errorKf <- (sum(errorKf) / errorC)^0.5

# Readjust kalman filtered output:

    newKf <- originalPred
    newKf[(1-par$start[2]+maxtlength):
	(originaltlength-par$start[2]+mintlength)] <- kf

    kalmanfilter <-list("time"=time,"obs"=obs,"pred"=pred,"newKf"=newKf)
#			"errorPred"=errorPred,"errorKf"=errorKf)

return(kalmanfilter)

}



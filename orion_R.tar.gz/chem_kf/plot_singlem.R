#plotting hourly maxes for single models

allobsxhrmax <- allobs8hrmax
singlem_kfxhrmax <- singlem_kf8hrmax
ist <- 25
ymax <- 100

cols <- rainbow(100)

icol <- 40
plot(c(1:ndays),allobsxhrmax[,ist],type="l",lwd=2,
col="red",ylim=c(0,ymax))
for (imodel in 1:nens) {
    lines(c(1:ndays),singlem_kfxhrmax[,imodel,ist],type="l",lwd=1,
    col=cols[imodel*5+icol])
}

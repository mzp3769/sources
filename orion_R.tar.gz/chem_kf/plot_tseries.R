postscript("tseries.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

#good performance
nt1 <- 864
nt2 <- 984
nst <- 50

#bad performance - not really
#nt1 <- 164
#nt2 <- 284
#nst <- 30
#nst <- 130



xlabstring <- expression("time (hours)")
ylabstring <- expression(paste(O[3],"  concentration (ppbv)"))

plot(seq(nt1,nt2),eqwpredplt[nt1:nt2,nst],type="l",lwd=2,col="blue",
ylim=c(0,70),xaxs="i",yaxs="i",
xlab=xlabstring,ylab=ylabstring)
lines(seq(nt1,nt2),obsplt[nt1:nt2,nst],type="l",lwd=2,col="red")
lines(seq(nt1,nt2),kalmanfilter[nt1:nt2,nst],type="l",lwd=2,
col="purple")
text(nt1+8,65,labels="a",cex=1.3,vfont=c("serif","plain"))
dev.off()

postscript("weights.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring <- expression("time (hours)")
ylabstring <- expression("weights")

#par(xaxp=c(0.05,.20,1))

plot(seq(nt1,nt2),weights[nt1:nt2,1,nst],type="l",lwd=2,col="red",
ylim=c(0.07,.18),xaxs="i",yaxs="i",
xlab=xlabstring,ylab=ylabstring)
lines(seq(nt1,nt2),weights[nt1:nt2,2,nst],type="l",lwd=2,col="blue")
lines(seq(nt1,nt2),weights[nt1:nt2,3,nst],type="l",lwd=2,col="purple")
lines(seq(nt1,nt2),weights[nt1:nt2,4,nst],type="l",lwd=2,col="green")
lines(seq(nt1,nt2),weights[nt1:nt2,5,nst],type="l",lwd=2,col="yellow")
lines(seq(nt1,nt2),weights[nt1:nt2,6,nst],type="l",lwd=2,col="orange")
lines(seq(nt1,nt2),weights[nt1:nt2,7,nst],type="l",lwd=2,col="brown")
text(nt1+8,.175,labels="b",cex=1.3,vfont=c("serif","plain"))

dev.off()
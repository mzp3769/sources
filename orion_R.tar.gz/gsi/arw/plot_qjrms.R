#to plot scales and variances for gsi_ens

times <- c("00z","12z")
timesl <- c("00 UTC","12 UTC")
ntimes <- length(times)


indir <- "./indata"

vara <- "o3" 
varaa <- "O3"
maxstdeva <- 30
xlabela <- expression(paste("O3: Stdev [ppbv]",sep=""))
#xlabela <- expression(
#paste("O",[3],"Stdev [ppbv]"),sep="")

varb <- "pm2.5"
varbb <- "PM2.5"
maxstdevb <- 3.0
xlabelb <- expression(paste("PM2.5: Stdev [",mu,"g"," ",
                      m^{-3},"]",sep="")) 

namep <- paste(indir,'/','eta.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1)
etalevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=1)
   etalevels[k] <- data
}
close(infile)

hlscalea <- array(NA,c(ntimes,nzp))
vlscalea <- array(NA,c(ntimes,nzp))
stdeva <- array(NA,c(ntimes,nzp))

hlscaleb <- array(NA,c(ntimes,nzp))
vlscaleb <- array(NA,c(ntimes,nzp))
stdevb <- array(NA,c(ntimes,nzp))



for (i in 1:ntimes) {
name <- paste(indir,'/',vara,'_scales_ens_',times[i],sep="")
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   hlscalea[i,k] <- data[2]*1.e-3
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   vlscalea[i,k] <- data[2]
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   stdeva[i,k] <- data[2]
}

close(infile)

}


for (i in 1:ntimes) {
name <- paste(indir,'/',varb,'_scales_ens_',times[i],sep="")
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   hlscaleb[i,k] <- data[2]*1.e-3
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   vlscaleb[i,k] <- data[2]
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   stdevb[i,k] <- data[2]
}

close(infile)

}

par(mar=c(5, 4, 4, 2) + 0.1)
par(mgp=c(2.,1,0))

nz <- nzl

hlscale <- max(hlscalea,hlscaleb)

xmin <- 0
xmax <- ((max(hlscale)%/%100)*100+100)
ymin <- 0
ymax <- 1

tiff("./pngs/hcor_scales_gsi_ens.tiff",width = 600, 
height = 600,bg="white")

plot(hlscalea[1,1:nz],etalevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Lengthscale [km]",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1.,cex.lab=1.,type="l",lwd=1,cex=1.)
points(hlscalea[1,1:nz],etalevels[1:nz],col="black",pch=17,cex=1.0)

lines(hlscaleb[1,1:nz],etalevels[1:nz],lwd=1)
points(hlscaleb[1,1:nz],etalevels[1:nz],col="black",pch=15,cex=1.0)

lines(hlscalea[2,1:nz],etalevels[1:nz],lwd=1)
points(hlscalea[2,1:nz],etalevels[1:nz],col="black",pch=24,cex=1.0)

lines(hlscaleb[2,1:nz],etalevels[1:nz],lwd=1)
points(hlscaleb[2,1:nz],etalevels[1:nz],col="black",pch=22,cex=1.0)

legend(x=0,y=0,lwd=1,pch=c(17,15,24,22),
legend=c(paste(varaa,timesl[1]),
         paste(varbb,timesl[1]),
         paste(varaa,timesl[2]),
         paste(varbb,timesl[2])),
         col="black",cex=1.)

dev.off()

vlscale <- max(vlscalea,vlscaleb)

xmin <- 0
xmax <- 12 #((max(vlscale)%/%1)*1+1)
ymin <- 0
ymax <- 1

tiff("./pngs/vcor_scales_gsi_ens.tiff",
width = 600, height = 600,bg="white")

plot(vlscalea[1,1:nz],etalevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Grid unit",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=1,cex=1)
points(vlscalea[1,1:nz],etalevels[1:nz],col="black",pch=17,cex=1.0)

lines(vlscaleb[1,1:nz],etalevels[1:nz],lwd=1)
points(vlscaleb[1,1:nz],etalevels[1:nz],col="black",pch=15,cex=1.0)

lines(vlscalea[2,1:nz],etalevels[1:nz],lwd=1)
points(vlscalea[2,1:nz],etalevels[1:nz],col="black",pch=24,cex=1.0)

lines(vlscaleb[2,1:nz],etalevels[1:nz],lwd=1)
points(vlscaleb[2,1:nz],etalevels[1:nz],col="black",pch=22,cex=1.0)



legend(x=xmax,y=0,lwd=1,pch=c(17,15,24,22),
legend=c(paste(varaa,timesl[1]),
         paste(varbb,timesl[1]),
         paste(varaa,timesl[2]),
         paste(varbb,timesl[2])),
         col="black",xjust=1,cex=1.)

dev.off()

xmin <- 0
xmax <- maxstdeva
ymin <- 0
ymax <- 1

tiff("./pngs/stdev_gsi_ens.tiff",width = 600, height = 600,bg="white")


plot(stdeva[1,1:nz]*1.e3,etalevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab=xlabela,ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1.,cex.lab=1.,type="l",lwd=1,cex=1)
points(stdeva[1,1:nz]*1.e3,etalevels[1:nz],col="black",pch=17,cex=1.)

lines(stdevb[1,1:nz]*10,etalevels[1:nz],lwd=1)
points(stdevb[1,1:nz]*10,etalevels[1:nz],col="black",pch=15,cex=1.)

lines(stdeva[2,1:nz]*1.e3,etalevels[1:nz],lwd=1)
points(stdeva[2,1:nz]*1.e3,etalevels[1:nz],col="black",pch=24,cex=1.)

lines(stdevb[2,1:nz]*10,etalevels[1:nz],lwd=1)
points(stdevb[2,1:nz]*10,etalevels[1:nz],col="black",pch=22,cex=1.)

legend(x=xmax,y=0,lwd=1,pch=c(17,15,24,22),
legend=c(paste(varaa,timesl[1]),
         paste(varbb,timesl[1]),
         paste(varaa,timesl[2]),
         paste(varbb,timesl[2])),
         col="black",cex=1.,xjust=1)

axis(3,at=c(0,5,10,15,20,25,30),
       labels=c("0.0","0.5","1.0","1.5","2.0","2.5","3.0"),)
mtext(side=3,line=2.5,xlabelb)

dev.off()


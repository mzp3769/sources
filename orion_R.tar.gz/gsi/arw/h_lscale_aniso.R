#to plot anisotropic correlations scales for gsi

BIN <- TRUE

if (BIN==TRUE) {
#begin bin read
name <- "./indata/hdist_cor_aniso.bin"
infile <- file(name,"rb")
trash <- readBin(infile,what=numeric(), n=1,size=4)
trash <- readBin(infile,what=integer(), n=4,size=4)
nx <- trash[1]
ny <- trash[2]
nz <- trash[3]
trash <- readBin(infile,what=numeric(), n=1,size=4)

correl <- array(NA,c(nx,ny,nz))
for (k in 1:nz) {
for (j in 1:ny) {
trash <- readBin(infile,what=numeric(), n=1,size=4)
correl[,j,k] <- readBin(infile,what=numeric(), n=nx,size=4)
trash <- readBin(infile,what=numeric(), n=1,size=4)
}}
close(infile)
#end binary read

x11(width=5.6,height=5)

nxx <- 50
nyy <- 50
x <- 1:nxx
y <- 1:nyy
zmin <- -1
zmax <- 1
nlevs <- 20
for (k in 1:nz) {
filled.contour(x,y,correl[1:nxx,1:nyy,k],
               nlevels=nlevs,zlim=range(zmin,zmax),
               color.palette=rainbow)

locator()
}


} else {
#begin ascii read

name <- "./indata/hdist_cor_aniso.txt"

infile <- file(name,"ra")
data <- scan(infile,what=1,n=4)
nx <- data[1]
ny <- data[2]
nz <- data[3]
correl <- array(NA,c(nx,ny,nz))
for (k in 1:nz) {
for (j in 1:ny) {
correl[,j,k] <- scan(infile,what=1,n=nx,quiet=TRUE)
}}
close(infile)
#end ascii read

x11(width=5.6,height=5)

nxx <- 50
nyy <- 50
x <- 1:nxx
y <- 1:nyy
zmin <- -1.
zmax <- 1.
nlevs <- 20
for (k in 1:nz) {
filled.contour(x,y,correl[1:nxx,1:nyy,k],
               nlevels=nlevs,zlim=range(zmin,zmax),
               color.palette=rainbow)

locator()
}
}
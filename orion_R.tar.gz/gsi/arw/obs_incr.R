#to plot q-q plot for obs increment

var <- "o3"
limits <- c(-60,60)
var <- "PM2_5_DRY"

for (i in 1:54) {
    if (i < 10) ic <- paste('0',as.character(i),sep="") else 
    ic <- as.character(i)
    name <- paste('./indata/increment/',var,'/obs_incr.',ic,'.bin',sep='')
    print(name)
    infile <- file(name,"rb")
    trash <- readBin(infile,what=integer(), n=1,size=4)
    j <- readBin(infile,what=integer(), n=1,size=4) + 2
    newincr <- readBin(infile,what=numeric(), n=j,size=4)
    close(infile)
    if (i > 1) incr <- c(incr,newincr[3:j]) else incr <- newincr[3:j]
}

incrsort <- sort(incr)


x11(width=5.6,height=5.6)

tiff("./pngs/qq_obs_incr.tiff",width = 600, height = 600)

qqmath(data=NULL,incrsort,qnorm,ylim=limits)

#dev.off()

#distribution=function(p) qlnorm(p, meanlog = 0, sdlog = 1))



#qqmath(~rlnorm(1000,meanlog = 0, sdlog = 1),distribution=qlnorm)
#qqmath(data=NULL,incrsort,distribution = function(p) 
#qgamma(p, shape=2, rate = 1,lower.tail = TRUE,log.p = FALSE))

#to plot scales and variances for qjrms

indir <- "./indata/pm_opt_2"

var <- "o3" 
#var <- "pm2.5"

times <- c("00z","06z","12z","18z")
timesl <- c("00 UTC","06 UTC","12 UTC","18 UTC")
ntimes <- length(times)

namep <- paste(indir,'/','p_ave.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1)
plevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=2)
   plevels[k] <- data[2]*1.e-2
}
close(infile)

hlscale <- array(NA,c(ntimes,nzp))
vlscale <- array(NA,c(ntimes,nzp))
stdev <- array(NA,c(ntimes,nzp))

for (i in 1:ntimes) {
name <- paste(indir,'/',var,'_','scales','_',times[i],sep="")
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   hlscale[i,k] <- data[2]*1.e-3
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   vlscale[i,k] <- data[2]
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   stdev[i,k] <- data[2]
}

close(infile)

nz <- nzl -1 
for (k in 1:nz) {
   vs <- vlscale[i,k]
   ivs <- vs %/% 1
   rvs <- vs %% 1
   del <- (plevels[k]-plevels[k+ivs])+
          (plevels[k+ivs]-plevels[k+ivs+1])*rvs
   vlscale[i,k] <- del
}

}

xmin <- 0
xmax <- ((max(hlscale)%/%100)*100+100)
ymin <- 50
ymax <- 1000

png("./pngs/hcor_scales_qj.png",width = 1000, height = 1000,bg="white")

plot(hlscale[1,1:nz],plevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Lengthscale [km]",ylab="Pressure [hPa]",xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=1,cex=4)
points(hlscale[1,1:nz],plevels[1:nz],col="black",pch=22)

lines(hlscale[2,1:nz],plevels[1:nz],lwd=1)
points(hlscale[2,1:nz],plevels[1:nz],col="black",pch=23)

lines(hlscale[3,1:nz],plevels[1:nz],lwd=1)
points(hlscale[3,1:nz],plevels[1:nz],col="black",pch=24)

lines(hlscale[4,1:nz],plevels[1:nz],lwd=1)
points(hlscale[4,1:nz],plevels[1:nz],col="black",pch=25)

legend(x=0,y=50,lwd=1,pch=c(22,23,24,25),
legend=timesl,col="black",cex=1.5)

dev.off()

xmin <- 0
xmax <- ((max(vlscale)%/%100)*100+100)
ymin <- 50
ymax <- 1000

png("./pngs/vcor_scales_qj.png",width = 1000, height = 1000,bg="white")

plot(vlscale[1,1:nz],plevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Lengthscale [hPa]",ylab="Pressure [hPa]",xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=1,cex=4)
points(vlscale[1,1:nz],plevels[1:nz],col="black",pch=22)

lines(vlscale[2,1:nz],plevels[1:nz],lwd=1)
points(vlscale[2,1:nz],plevels[1:nz],col="black",pch=23)

lines(vlscale[3,1:nz],plevels[1:nz],lwd=1)
points(vlscale[3,1:nz],plevels[1:nz],col="black",pch=24)

lines(vlscale[4,1:nz],plevels[1:nz],lwd=1)
points(vlscale[4,1:nz],plevels[1:nz],col="black",pch=25)

legend(x=150,y=50,lwd=1,pch=c(22,23,24,25),
legend=timesl,col="black",cex=1.5)

dev.off()

xmin <- 0
xmax <- ((max(stdev)%/%100)*100+100)
ymin <- 50
ymax <- 1000

png("./pngs/stdev_qj.png",width = 1000, height = 1000,bg="white")

plot(stdev[1,1:nz],plevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Lengthscale [hPa]",ylab="Pressure [hPa]",xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=1,cex=4)
points(stdev[1,1:nz],plevels[1:nz],col="black",pch=22)

lines(stdev[2,1:nz],plevels[1:nz],lwd=1)
points(stdev[2,1:nz],plevels[1:nz],col="black",pch=23)

lines(stdev[3,1:nz],plevels[1:nz],lwd=1)
points(stdev[3,1:nz],plevels[1:nz],col="black",pch=24)

lines(stdev[4,1:nz],plevels[1:nz],lwd=1)
points(stdev[4,1:nz],plevels[1:nz],col="black",pch=25)

legend(x=150,y=50,lwd=1,pch=c(22,23,24,25),
legend=timesl,col="black",cex=1.5)

dev.off()


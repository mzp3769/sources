#to plot scales and variances for gsi_ens

times <- c("00z")
timesl <- c("00 UTC")
ntimes <- length(times)


indir <- "./indata"

vara <- "o3" 
varaa <- "O3"
maxstdeva <- 35
xlabela <- expression(paste("O3: Stdev [ppbv]",sep=""))
#xlabela <- expression(
#paste("O",[3],"Stdev [ppbv]"),sep="")

varb <- "pm2.5"
varbb <- "PM2.5"
maxstdevb <- 3.5
xlabelb <- expression(paste("PM2.5: Stdev [",mu,"g"," ",
                      m^{-3},"]",sep="")) 


times <- c("12z")
timesl <- c("12 UTC")
ntimes <- length(times)

namep <- paste(indir,'/','eta.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1)
etalevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=1)
   etalevels[k] <- data
}
close(infile)

hlscalea <- array(NA,c(ntimes,nzp))
vlscalea <- array(NA,c(ntimes,nzp))
stdeva <- array(NA,c(ntimes,nzp))

hlscaleb <- array(NA,c(ntimes,nzp))
vlscaleb <- array(NA,c(ntimes,nzp))
stdevb <- array(NA,c(ntimes,nzp))



for (i in 1:ntimes) {
name <- paste(indir,'/',vara,'_','scales','_',times[i],sep="")
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   hlscalea[i,k] <- data[2]*1.e-3
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   vlscalea[i,k] <- data[2]
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   stdeva[i,k] <- data[2]
}

close(infile)

}


for (i in 1:ntimes) {
name <- paste(indir,'/',varb,'_','scales','_',times[i],sep="")
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   hlscaleb[i,k] <- data[2]*1.e-3
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   vlscaleb[i,k] <- data[2]
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   stdevb[i,k] <- data[2]
}

close(infile)

}

par(mar=c(5, 4, 4, 2) + 0.1)
par(mgp=c(2.,1,0))

nz <- nzl

hlscale <- max(hlscalea,hlscaleb)

xmin <- 0
xmax <- ((max(hlscale)%/%100)*100+100)
ymin <- 0
ymax <- 1

tiff("./pngs/hcor_scales_gsi_ens.tiff",width = 600, height = 600,bg="white")

plot(hlscalea[1,1:nz],etalevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Lengthscale [km]",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1.,cex.lab=1.,type="l",lwd=1,cex=1.)
points(hlscalea[1,1:nz],etalevels[1:nz],col="black",pch=22,cex=0.85)

lines(hlscaleb[1,1:nz],etalevels[1:nz],lwd=1)
points(hlscaleb[1,1:nz],etalevels[1:nz],col="black",pch=25,cex=0.85)

legend(x=0,y=0,lwd=1,pch=c(22,25),
legend=c(varaa,varbb),col="black",cex=0.85)

dev.off()

vlscale <- max(vlscalea,vlscaleb)

xmin <- 0
xmax <- 12 #((max(vlscale)%/%1)*1+1)
ymin <- 0
ymax <- 1

tiff("./pngs/vcor_scales_gsi_ens.tiff",width = 600, height = 600,bg="white")

plot(vlscalea[1,1:nz],etalevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Grid unit",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=1,cex=1)
points(vlscalea[1,1:nz],etalevels[1:nz],col="black",pch=22,cex=0.85)

lines(vlscaleb[1,1:nz],etalevels[1:nz],lwd=1)
points(vlscaleb[1,1:nz],etalevels[1:nz],col="black",pch=25,cex=0.85)

legend(x=xmax,y=0,lwd=1,pch=c(22,25),
legend=c(varaa,varbb),col="black",xjust=1,cex=0.85) 

dev.off()

xmin <- 0
xmax <- maxstdeva
ymin <- 0
ymax <- 1

tiff("./pngs/stdev_gsi_ens.tiff",width = 600, height = 600,bg="white")


plot(stdeva[1,1:nz]*1.e3,etalevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab=xlabela,ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1.,cex.lab=1.,type="l",lwd=1,cex=1)
points(stdeva[1,1:nz]*1.e3,etalevels[1:nz],col="black",pch=22,cex=0.85)

lines(stdevb[1,1:nz]*10,etalevels[1:nz],lwd=1)
points(stdevb[1,1:nz]*10,etalevels[1:nz],col="black",pch=25,cex=0.85)

legend(x=xmax,y=0,lwd=1,pch=c(22,25),
legend=c(varaa,varbb),col="black",cex=.85,xjust=1) 

axis(3,at=c(0,5,10,15,20,25,30,35),
       labels=c("0.0","0.5","1.0","1.5","2.0","2.5","3.0","3.5"),)
mtext(side=3,line=2.5,xlabelb)

dev.off()


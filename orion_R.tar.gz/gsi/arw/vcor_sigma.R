#to plot vertical correlations for gsi
ptop <- 50.
psfc <- 1000.
half <- 0.5
namep <- paste('/Volumes/Scratch/stuff/R/gsi/arw/indata/eta.txt',sep="")
infile <- file(namep,"ra")
nz <- scan(infile,what=1,n=1)
etalevels <- array(NA,nz)
sigma <- array(NA,nz)
dsigma <- array(NA,nz)

for (k in 1:nz) {
   data <- scan(infile,what=1,n=1)
   etalevels[k] <- data
   sigma[k] <- log(((psfc-ptop)*etalevels[k]+ptop)/psfc)
}
close(infile)

dsigma[1]=sigma[1]-sigma[2]
for (k in 2:(nz-1)) {
  dsigma[k]=half*(sigma[k-1]-sigma[k+1])
}
dsigma[nz]=sigma[nz-1]-sigma[nz]

name <- "/Volumes/Scratch/stuff/R/gsi/arw/indata/vlevel_cor.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1)

correl <- array(1,c(nz,nz))

for (k in 1:(nz-1)) {
    for (l in (k+1):nz) {
        data <- scan(infile,what=1,n=3,quiet=TRUE)
	correl[k,l] <- data[3]
        correl[l,k] <- data[3]
    }
} 

close(infile)

nlevs=20
zmin <- min(correl)
zmax <- max(correl)	
#x <- etalevels[1:nz-1]
x <- sigma[1:nz-1]
y <- x

#graphics.off()

#x11(width=5.6,height=5)

filled.contour(x[(nz-1):1],y[(nz-1):1],correl[(nz-1):1,(nz-1):1],
               nlevels=nlevs,zlim=range(zmax,zmin),
               color.palette=rainbow)


#x11(width=5,height=5)

#library(lattice)
#contourplot(correl[1:(nz-1),1:(nz-1)],row.values=eta[1:(nz-1)],
#column.values=eta[1:(nz-1)],xlim=c(1,0),ylim=c(1,0),region=TRUE,
#col.regions=topo.colors)
#col.regions=rainbow(nz),colorkey=TRUE)
#detach()

#can't figure out how that works
#colorkey <- list(at=c(0.,0.2,0.4,0.6,0.8),height=.4)
#colorkey$at=c(0.,0.2,0.4,0.6,0.8),colorkey$ticknumber=2,
#colorkey$height=.4)



x11(width=5,height=5)

colors <- rainbow(nz)

plot(x,correl[1,1:(nz-1)],type="l",lwd=2,col=colors[1])

for (k in 2:nz) {
lines(x,correl[k,1:(nz-1)],type="l",lwd=2,col=colors[k])
}

b <- 2
form <- yy ~ exp(-xx^b/(2.*l^b))
vscale <- array(NA,nz)

for (k in 1:(nz-1)) {
   print(k)
   xx <- x - sigma[k] 
   yy <- correl[k,1:(nz-1)]
   data <- coef(nls(form, start=list(l = -2.),
#algorithm="port", #virtually same as default
#algorithm="plinear", #slightly shorter than default
                    na.action=na.omit))
   vscale[k] <- abs(data[1])
}

x11(width=5,height=5)

for (k in 1:(nz-1)) {
    plot(x,correl[k,1:(nz-1)],type="l",lwd=2,col=colors[k],xlim=c(0,-2.5))
    shift <- sigma[k] 
    xx <- x - shift
    yy <- exp(-xx^b/(2.*vscale[k]^b))
    lines(x,yy,lwd=2,col=colors[k])
    locator()
}
vscale[nz] <- vscale[nz-1]


for (k in 1:(nz-1)) {
    if (    




scales <- array(NA,c(2,nz))
scales[1,1:nz] <- seq(1,nz)
scales[2,1:nz] <- vscale

title <- "./indata/v_lscale_R.txt"
write(nz,file=title,ncolumns=1,append=FALSE)
write(scales,file=title,ncolumns=2,append=TRUE)

x11(width=5,height=5)
plot(vscale[1:(nz-1)],sigma[1:(nz-1)],type="l",lwd=2,col="black",
ylim=c(0,-2.5),xaxs="i",yaxs="i",)

x11(width=5,height=5)
plot(vscale[1:(nz-1)],c(1:(nz-1)),type="l",lwd=2,col="black",
ylim=c(1,(nz-1)),xaxs="i",yaxs="i")

x11(width=5,height=5)
plot(vscale[1:(nz-1)],etalevels[1:(nz-1)],type="l",lwd=2,col="black",
ylim=c(1,0),xaxs="i",yaxs="i")



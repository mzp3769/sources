#to plot correlations for gsi

name <- "/Volumes/Scratch/stuff/R/gsi/arw/indata/p_ave.txt"
infile <- file(name,"ra")
nzp <- scan(infile,what=1,n=1)
plevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=2)
   plevels[k] <- data[2]*1.e-2
}
close(infile)

name <- "/Volumes/Scratch/stuff/R/gsi/arw/indata/h_lscale_R.txt"
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
hlscale <- array(NA,nzl)

for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   hlscale[k] <- data[2]*1.e-3
}
close(infile)

xmin <- 0
xmax <- (max(hlscale)%/%100)*100+100
ymin <- 1
ymax <- 50

x11(width=5,height=5)

plot(hlscale,1:nzl,
   col=colors[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab="Lengthscale",ylab="Pressure",xaxs="i",yaxs="i",
   cex.axis=2,type="l",lwd=2)
#points(hlscale,plevels,col=colors[1],pch=20)


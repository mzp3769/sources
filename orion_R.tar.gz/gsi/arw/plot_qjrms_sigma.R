#to plot scales and variances for qjrms

indir <- "./indata/pm_opt_2"

namep <- paste(indir,'/','p_ave.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1)
plevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=2)
   plevels[k] <- data[2]*1.e-2
}
close(infile)

namep <- paste(indir,'/','eta.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1)
etalevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=1)
   etalevels[k] <- data
}
close(infile)

xmin <- 0
xmax <- nzp+1
ymin <- 0
ymax <- 1

png("./pngs/p_sigma_qj.png",width = 400, height = 400,bg="white")

par("mar"=c(5,4,4,4)+.1))
plot(1:nzp,etalevels[1:nzp],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Level",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=1,cex=4)
points(1:nzp,etalevels[1:nzp],col="black",pch=20)
points(1:nzp,plevels[1:nzp],col="black",pch=20)
plot(1:nzp,plevels[1:nzp])
axis(4,at=c(1,.8,.6,.4,.2,.0),cex.lab=1.5,cex.axis=1.5,labels=c()

plot(plevels[1:nzp],etalevels[1:nzp],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Level",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=1,cex=4)


#x <- 1:nzp
#eta <- etalevels[1:nzp]
#xyplot(eta ~ x,
#   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
#   xlab="Level",ylab="Sigma")



dev.off()

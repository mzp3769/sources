#plot time series for da verification for calnex

indir <- "./indata/calnex"
outdir <- "./pngs/calnex"
utc <- 7

var <- "PM2_5_DRY"
hour <- "00"

fname_noda <-  paste(indir,'/noassim/','stats_',var,'_',
hour,'.txt.',utc,sep="")

infile_noda <- file(fname_noda,"ra")
data <- scan(infile_noda,what=1,nlines=1)
ntimes <- data[1]
nstats <- data[2]
allstats_noda <- array(NA,c(ntimes,nstats))
for (i in 1:ntimes) {
    allstats_noda[i,] <- scan(infile,what=1,nlines=1)
}

close(infile_noda)


fname_da <-  paste(indir,'/assim/','stats_',var,'_',
hour,'.txt.',utc,sep="")
infile_da <- file(fname_da,"ra")
data <- scan(infile_noda,what=1,nlines=1)
ntimes <- data[1]
nstats <- data[2]
allstats_da <- array(NA,c(ntimes,nstats))
for (i in 1:ntimes) {
    allstats_da[i,] <- scan(infile,what=1,nlines=1)
}

close(infile_da)

tiffname <- paste(outdir,'/tseries_bias.',utc,'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- expression("Time (UTC)")
ylabstring <- expression(paste(" Bias [",mu,"g"," ",
                      m^{-3},"]",sep=""))

xmin <- 0
xmax <- 48

ymin <- min(allstats_noda[,3],allstats_da[,3])
ymax <- max(allstats_noda[,3],allstats_da[,3])

zero <- array(0,ntimes)

plot(allstats_noda[,1],allstats_noda[,3],xlim=c(xmin,xmax),
ylim=c(ymin,ymax),col="red",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=4,cex=1.)
lines(allstats_da[,1],allstats_da[,3],col="blue",lwd=4)
lines(allstats_da[,1],zero,lwd=1)
dev.off()


tiffname <- paste(outdir,'/tseries_prmse.',utc,'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- expression("Time (UTC)")
ylabstring <- expression(paste(" PRMSE [",mu,"g"," ",
                      m^{-3},"]",sep=""))

xmin <- 0
xmax <- 48

ymin <- min(allstats_noda[,4],allstats_da[,4])
ymax <- max(allstats_noda[,4],allstats_da[,4])

plot(allstats_noda[,1],allstats_noda[,4],xlim=c(xmin,xmax),
ylim=c(ymin,ymax),col="red",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=4,cex=1.)
lines(allstats_da[,1],allstats_da[,4],col="blue",lwd=4)
dev.off()


tiffname <- paste(outdir,'/tseries_corr.',utc,'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- expression("Time (UTC)")
ylabstring <- expression(paste(" CORR"))

xmin <- 0
xmax <- 48

ymin <- min(allstats_noda[,5],allstats_da[,5])
ymax <- max(allstats_noda[,5],allstats_da[,5])

plot(allstats_noda[,1],allstats_noda[,5],xlim=c(xmin,xmax),
ylim=c(ymin,ymax),col="red",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=4,cex=1.)
lines(allstats_da[,1],allstats_da[,5],col="blue",lwd=4)
dev.off()


tiffname <- paste(outdir,'/tseries_concave.',utc,'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- expression("Time (UTC)")
ylabstring <- expression(paste(" CONC [",mu,"g"," ",
                      m^{-3},"]",sep=""))


xmin <- 0
xmax <- 48

ymin <- min(allstats_noda[,8],allstats_noda[,9],allstats_da[,9])
ymax <- max(allstats_noda[,8],allstats_noda[,9],allstats_da[,9])

plot(allstats_noda[,1],allstats_noda[,8],xlim=c(xmin,xmax),
ylim=c(ymin,ymax),col="black",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=4,cex=1.)
lines(allstats_noda[,1],allstats_noda[,9],col="red",lwd=4)
lines(allstats_da[,1],allstats_da[,9],col="blue",lwd=4)

dev.off()



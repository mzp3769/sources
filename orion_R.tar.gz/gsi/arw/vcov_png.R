#to plot vertical covariances for gsi
name <- "./indata/vlevel_cov.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1)

cov <- array(NA,c(nz,nz))
stdev <- array(NA,nz)

for (k in 1:nz) {
    for (l in k:nz) {
        data <- scan(infile,what=1,n=3)
	cov[k,l] <- data[3]
        cov[l,k] <- data[3]
    }
    stdev[k]=sqrt(cov[k,k])
} 

close(infile)

nlevs=20
zmin <- min(cov)
zmax <- max(cov)	
x <- 1:(nz-1)
y <- x

#graphics.off()

png("./pngs/vcov.png",width = 575, height = 500,bg="white")


filled.contour(x,y,cov[1:(nz-1),1:(nz-1)],
               nlevels=nlevs,zlim=range(zmin,zmax),
               color.palette=rainbow)

dev.off()


png("./pngs/stdev.png",width = 575, height = 500,bg="white")
plot(stdev[1:(nz-1)],1:(nz-1),
col=colors[1],xlim=c(0.,max(stdev)),ylim=c(1,nz-1),
xlab="Stdev",ylab="Vertical level",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=3)

dev.off()

library(ncdf)

var <- "o3"
limits <- c(-100,100)
var <- "PM2_5_DRY"
limits <- c(-40,40) #for PM2_5_DRY

for (i in 1:54) {
    if (i < 10) ic <- paste('0',as.character(i),sep="") else 
    ic <- as.character(i)
    ncname <- paste('./indata/increment/',var,'/diff_',ic,'.nc',sep='')
    print(ncname)
    nc <- open.ncdf(ncname, readunlim=FALSE )	
    newincr <- as.vector(get.var.ncdf( nc, var ))
    close.ncdf(nc)
    if (i > 1) incr <- c(incr,newincr) else incr <- newincr
}

if (var == "o3") factor <- 1.e3 else factor <- 1.

incrsort <- (sort(incr)-mean(incr))*factor
#incrsort <- sort(incr)*factor

#end binary read

x11(width=5.6,height=5.6)

tiff("./pngs/qq_bckg_incr.tiff",width = 600, height = 600)

qqmath(data=NULL,incrsort,qnorm,ylim=limits)

dev.off()

qqmath(~rlnorm(1000,meanlog = 0, sdlog = 1),distribution=qlnorm)
qqmath(data=NULL,incrsort,distribution = function(p) 
qgamma(p, shape=2, rate = 1,lower.tail = TRUE,log.p = FALSE))
#distribution=function(p) qlnorm(p, meanlog = 0, sdlog = 1))


#to plot vertical covariances for gsi
name <- "/Volumes/Scratch/stuff/R/gsi/arw/indata/stdev.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1)

stdev <- array(NA,nz)

for (k in 1:nz) {
    data <- scan(infile,what=1,n=2)
    stdev[k]=data[2]
} 

close(infile)

nlevs=20
zmin <- min(cov)
zmax <- max(cov)	
x <- 1:(nz-1)
y <- x

#graphics.off()

x11(width=5,height=5)
plot(stdev[1:(nz-1)],1:(nz-1),
col=colors[1],xlim=c(0.,max(stdev)),ylim=c(1,nz-1),
xlab="Stdev",ylab="Vertical level",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=3)

scales[1,1:nz] <- seq(1,nz)
scales[2,1:nz] <- stdev

title <- "./indata/vlevel_stdev_R_test.txt"
write(nz,file=title,ncolumns=1,append=FALSE)
write(scales,file=title,ncolumns=2,append=TRUE)


#to plot scales and variances for cmaq

indir <- "./indata"

#var <- "o3" 
#maxstdev <- 7
#xlabel <- "Stdev [ppbv]"

var <- "pm2.5"
maxstdev <- 4
xlabel <- expression(paste("Stdev [",mu,g," ",m^{-3},"]",,sep="")) 

etamin <- 0.4

times <- c("00z","06z","12z","18z")
timesl <- c("00 UTC","06 UTC","12 UTC","18 UTC")
ntimes <- length(times)

namep <- paste(indir,'/','cmaq_eta.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1)
etalevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=1)
   etalevels[k] <- data
}
close(infile)

hlscale <- array(NA,c(ntimes,nzp))
vlscale <- array(NA,c(ntimes,nzp))
stdev <- array(NA,c(ntimes,nzp))

for (i in 1:ntimes) {
name <- paste(indir,'/',var,'_scales_cmaq_',times[i],sep="")
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   hlscale[i,k] <- data[2]*1.e-3
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   vlscale[i,k] <- data[2]
}

nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   stdev[i,k] <- data[2]
}

close(infile)

}

nz <- nzl

xmin <- 0
xmax <- ((max(hlscale)%/%100)*100+50)
ymin <- etamin
ymax <- 1

tiff("./pngs/hcor_scales_cmaq.tiff",width = 600, height = 600,bg="white")

plot(hlscale[1,1:nz],etalevels[1:nz],
   xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Lengthscale [km]",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1.,cex.lab=1.,type="l",lwd=2,cex=1.,col="black")
points(hlscale[1,1:nz],etalevels[1:nz],col="black",pch=22,cex=1)

lines(hlscale[2,1:nz],etalevels[1:nz],lwd=2,col="red")
points(hlscale[2,1:nz],etalevels[1:nz],col="red",pch=23,cex=1)

lines(hlscale[3,1:nz],etalevels[1:nz],lwd=2,col="blue")
points(hlscale[3,1:nz],etalevels[1:nz],col="blue",pch=24,cex=1)

lines(hlscale[4,1:nz],etalevels[1:nz],lwd=2,col="green")
points(hlscale[4,1:nz],etalevels[1:nz],col="green",pch=25,cex=1)

legend(x=0,y=etamin,lwd=1,pch=c(22,23,24,25),
legend=timesl,col=c("black","red","blue","green"),cex=1)

dev.off()

xmin <- 0
xmax <- ((max(vlscale)%/%1)*1+1)
ymin <- etamin
ymax <- 1

tiff("./pngs/vcor_scales_cmaq.tiff",width = 600, height = 600,bg="white")

plot(vlscale[1,1:nz],etalevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Grid unit",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=2,cex=1)
points(vlscale[1,1:nz],etalevels[1:nz],col="black",pch=22,cex=1)

lines(vlscale[2,1:nz],etalevels[1:nz],lwd=2,col="red")
points(vlscale[2,1:nz],etalevels[1:nz],col="red",pch=23,cex=1)

lines(vlscale[3,1:nz],etalevels[1:nz],lwd=2,col="blue")
points(vlscale[3,1:nz],etalevels[1:nz],col="blue",pch=24,cex=1)

lines(vlscale[4,1:nz],etalevels[1:nz],lwd=2,col="green")
points(vlscale[4,1:nz],etalevels[1:nz],col="green",pch=25,cex=1)

legend(x=xmax,y=etamin,lwd=1,pch=c(22,23,24,25),
legend=timesl,col=c("black","red","blue","green"),cex=1,xjust=1)

dev.off()

xmin <- 0
xmax <- maxstdev
ymin <- etamin
ymax <- 1

tiff("./pngs/stdev_cmaq.tiff",width = 600, height = 600,bg="white")

plot(stdev[1,1:nz],etalevels[1:nz],
   col="black",xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab=xlabel,ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1.,cex.lab=1.,type="l",lwd=2,cex=1)
points(stdev[1,1:nz],etalevels[1:nz],col="black",pch=22,cex=1)

lines(stdev[2,1:nz],etalevels[1:nz],lwd=2,col="red")
points(stdev[2,1:nz],etalevels[1:nz],col="red",pch=23,cex=1)

lines(stdev[3,1:nz],etalevels[1:nz],lwd=2,col="blue")
points(stdev[3,1:nz],etalevels[1:nz],col="blue",pch=24,cex=1)

lines(stdev[4,1:nz],etalevels[1:nz],lwd=2,col="green")
points(stdev[4,1:nz],etalevels[1:nz],col="green",pch=25,cex=1)

if (var=="o3") {
   just <- 0
   xx <- 0
} else {
   just <- 1
   xx <- xmax
}

legend(x=xx,y=etamin,lwd=1,pch=c(22,23,24,25),
legend=timesl,col=c("black","red","blue","green"),cex=1,xjust=just)

dev.off()


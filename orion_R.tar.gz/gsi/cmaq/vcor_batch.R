#to plot vertical correlations for gsi
name <- "./indata/vlevel_cor.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1)

correl <- array(1,c(nz,nz))

for (k in 1:(nz-1)) {
    for (l in (k+1):nz) {
        data <- scan(infile,what=1,n=3,quiet=TRUE)
	correl[k,l] <- data[3]
        correl[l,k] <- data[3]
    }
} 

close(infile)

nlevs=20
zmin <- min(correl)
zmax <- max(correl)	
x <- 1:(nz-1)
y <- x

#graphics.off()

#x11(width=5.6,height=5)

#filled.contour(x,y,correl[1:(nz-1),1:(nz-1)],
#               nlevels=nlevs,zlim=range(zmin,zmax),
#               color.palette=rainbow)


#x11(width=5,height=5)

colors <- rainbow(nz)

#plot(x,correl[1,1:(nz-1)],type="l",lwd=2,col=colors[1])

#for (k in 2:nz) {
#lines(x,correl[k,1:(nz-1)],type="l",lwd=2,col=colors[k])
#}


b <- 2
form <- yy ~ exp(-xx^b/(l^b))
vscale <- array(NA,nz)

for (k in 1:(nz-1)) {
   print(k)
   xx <- x - k 
   yy <- correl[k,1:(nz-1)]
   data <- coef(nls(form, start=list(l = 3.),
#algorithm="port", #virtually same as default
#algorithm="plinear", #slightly shorter than default
                    na.action=na.omit))
   vscale[k] <- data[1]
}

#x11(width=5,height=5)

for (k in 1:(nz-1)) {
    plot(x,correl[k,1:(nz-1)],type="l",lwd=2,col=colors[k])
    shift <- k 
    xx <- x - shift
    yy <- exp(-xx^b/(vscale[k]^b))
    lines(x,yy,lwd=2,col=colors[k])
    locator()
}
vscale[nz] <- vscale[nz-1]

vscale <- vscale/sqrt(2.)

scales <- array(NA,c(2,nz))
scales[1,1:nz] <- seq(1,nz)
scales[2,1:nz] <- vscale

title <- "./indata/v_lscale_R.txt"
write(nz,file=title,ncolumns=1,append=FALSE)
write(scales,file=title,ncolumns=2,append=TRUE)

#to plot scales and variances for cmaq

indir <- "./indata"

#var <- "o3" 
#maxstdev <- 7
#xlabel <- "Stdev [ppbv]"

ntimes <- 1

var <- "pm2.5"
maxstdev <- 4

namep <- paste(indir,'/','cmaq_eta.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1)
etalevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=1)
   etalevels[k] <- data
}
close(infile)

hlscale <- array(NA,c(ntimes,nzp))
vlscale <- array(NA,c(ntimes,nzp))
stdev <- array(NA,c(ntimes,nzp))

for (i in 1:ntimes) {
name <- paste(indir,'/','h_lscale_R.txt',sep='')	
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   hlscale[i,k] <- data[2]
}

close(infile)

name <- paste(indir,'/','v_lscale_R.txt',sep='')	
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   vlscale[i,k] <- data[2]
}

close(infile)

name <- paste(indir,'/','stdev_R.txt',sep='')	
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   stdev[i,k] <- data[2]
}

close(infile)

}


nz <- nzl

hlscale <- hlscale/1000

xmin <- 0
xmax <- ((max(hlscale)%/%10)*10+10)
ymin <- 1
ymax <- nz

png("./pics/hscales_cmaq.png",width = 600, height = 600,bg="white")

plot(hlscale[1,1:nz],seq(1,nz),
   xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab="Lengthscale [km]",ylab="Grid level",xaxs="i",yaxs="i",
   cex.axis=1.25,cex.lab=1.25,type="l",lwd=4,cex=1.25,col="red")

dev.off()

xmin <- 0
xmax <- ((max(vlscale)%/%1)*1+1)
ymin <- 1
ymax <- nz

png("./pics/vscales_cmaq.png",width = 600, height = 600,bg="white")

xlabel <- expression(paste("Stdev [",mu,g," ",m^{-3},"]",,sep="")) 

plot(vlscale[1,1:nz],seq(1,nz),
   col="red",xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab="Grid unit",ylab="Grid level",xaxs="i",yaxs="i",
   cex.axis=1.25,cex.lab=1.25,type="l",lwd=4,cex=1.25)

dev.off()

xmin <- 0
xmax <- maxstdev
ymin <- 1
ymax <- nz

png("./pics/stdev_cmaq.png",width = 600, height = 600,bg="white")

xlabel <- expression(paste("Stdev [",mu,g," ",m^{-3},"]",,sep="")) 

plot(stdev[1,1:nz],seq(1,nz),
   col="red",xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab=xlabel,ylab="Grid level",xaxs="i",yaxs="i",
   cex.axis=1.25,cex.lab=1.25,type="l",lwd=4,cex=1.25)
dev.off()


#to plot vertical correlations for gsi
name <- "/export/scratch2/pagowski/stuff/R/gsi/nmm/indata/vlevel_cor.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1)

correl <- array(1,c(nz,nz))

for (k in 1:(nz-1)) {
    for (l in (k+1):nz) {
        data <- scan(infile,what=1,n=3,quiet=TRUE)
	correl[k,l] <- data[3]
        correl[l,k] <- data[3]
    }
} 

close(infile)

b <- 2
form <- yy ~ exp(-xx^b/(l^b))
vscale <- array(NA,nz)

for (k in 1:(nz-1)) {
   print(k)
   xx <- x - k 
   yy <- correl[k,1:(nz-1)]
   data <- coef(nls(form, start=list(l = 10.),#algorithm="plinear",
                    na.action=na.omit))
   vscale[k] <- data[1]
}

vscale <- vscale/sqrt(2.)

xmin <- 0
xmax <- max(vscale,na.rm=TRUE)

png("./pngs/vscale.png",width = 500, height = 500,bg="white")
plot(vscale[1:(nz-1)],1:(nz-1),type="l",col="red",lwd=3,
xlab="Lengthscale",ylab="Model level",xaxs="i",yaxs="i",
xlim=c(xmin,xmax),cex.axis=2)
dev.off()
gaspari <- function(r) {

a1 <- -0.25
a2 <- 0.5
a3 <- 0.625
a4 <- 5.0/3.0
a5 <- 1.0
a6 <- 1.0/12.0
a7 <- -5.0
a8 <- 4.0
a9 <- -2.0/3.0

# Gaspari-Cohn gaspari function.
# r should be positive, and normalized so gaspari = 0 at r = 1
# very close to exp(-(r/c)**2), where c = 0.388

 if (r <= a2) {
    rr <- 2.*r
    gaspari <- ( ( ( a1*rr +a2)*rr +a3 )*rr -a4)*rr*rr + a5
 }
 else {
      if (r < a5) {
      rr <- 2.*r 
      gaspari <- (((( a6*rr -a2 )*rr +a3 )*rr +a4 )*rr +a7)*rr + a8 + a9/rr
      }
      else {
      gaspari <- 0.
 }}

}

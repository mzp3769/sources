vars <- c("Z","U","V","UV","TH","QV","TKE")

nens <-  as.integer(try(
system("ls -1 ./indata/*prof*.txt | wc -l",intern=TRUE)))

prefix <- "./indata/mynn_noah_prof_"
suffix <- ".txt"

#allcolors <- colors()
#mycolors <- allcolors[seq(length.out=nens,from=10,by=10)]

mycolors <- rainbow(nens)

iens <- 1 
test <- sprintf("%03d",iens)
fname <- paste(prefix,test,suffix,sep='')
thisfile <- file(fname,"ra")
dims <- scan(thisfile,what=1,nlines=1)
close(thisfile)

nz <- dims[1]
nvars <- dims[2]

profs <- array(NA,c(nz,nvars,nens))

for (iens in 1:nens) {

    test <- sprintf("%03d",iens)
    fname <- paste(prefix,test,suffix,sep='') 
    thisfile <- file(fname,"ra")
    trash <- scan(thisfile,what=1,nlines=1)

    for (k in 1:nz) {
    	profs[k,,iens] <- scan(thisfile,what=.1,nlines=1)
	}
	close(thisfile)

}

ymin <- 0
ymax <- max(profs[,1,1])

for (ivar in 2:nvars) {

    name <- vars[ivar]
    xmin <- min(profs[,ivar,])
    xmax <- max(profs[,ivar,])

    picname <-  paste("./pics/",name,"_prof.png",sep='')

    png(picname,width=300, height=400.,bg="white")

    plot(profs[,ivar,1],profs[,1,1],type="l",lwd=1,lty=1,
    cex=1.,col=mycolors[1],xlab=vars[ivar],ylab=vars[1],
    yaxs="i",xlim=c(xmin,xmax),ylim=c(ymin,ymax))
       
    for (iens in 2:nens) {
        lines(profs[,ivar,iens],profs[,1,iens],
	col=mycolors[iens],type="l",lwd=1,lty=1)
    }

    dev.off()

}

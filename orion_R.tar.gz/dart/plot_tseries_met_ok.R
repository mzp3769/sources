test <- "test_104"

fields3d <- c("TT","UU","VV","GHT","QVAPOR")
levels <- c("P925","P850","P700","P500","P250")
fields2d <- c("T2","Q2","U10","V10")
suffix <- "cnt.txt"

stats <- c("FBAR","OBAR","FSTDEV","OSTDEV","PR_CORR","ME","BCMSE","RMSE")
minstat <- 10

statname1 <- "RMSE"
statname2 <- "RMSE"

plotdates <- c("2010/06/01","2010/07/01")

indir=paste("./indata/",test,sep='')

for (field in fields3d) {
    for (level in levels) {
    	print(c(field,level))
        fname <- paste(indir,'/',field,'_',level,'_',suffix,sep="")
	thisfile <- file(fname,"ra")
	names <- scan(thisfile,what='a',sep=',',nlines=1)
 	vartable <- try(
	read.table(thisfile,header=FALSE,skip=0,sep=','),silent=TRUE)
	if (class(vartable)=="try-error") {
	print(c("FILE EMPTY",c(field,level)))
	close(thisfile)			  
	next } 
	close(thisfile)
	ndate <- which(names=="FCST_VALID_BEG")
	ntotal <-  which(names=="TOTAL")
	
	total <- vartable[,ntotal]

	nlines <- length(total)

	istat1 <- which(names==statname1)
	istat2 <- which(names==statname2)

	totdays <- NULL
	hours <- NULL
	statplot1 <- NULL
	statplot2 <- NULL

	for (i in 1:nlines) {
	if (total[i] < minstat) next
	totdays <- c(totdays,as.numeric(substr(vartable[i,ndate],1,8)))
	hours <- c(hours,as.numeric(substr(vartable[i,ndate],10,11)))
	statplot1 <- c(statplot1,vartable[i,istat1])
	statplot2 <- c(statplot2,vartable[i,istat2])

	}

	years <- totdays %/%10000
	months <- (totdays %% 10000) %/% 100
	days <-  (totdays %% 10000) %% 100

	alldates <- paste(as.character(years),"-",as.character(months),"-",
	as.character(days),sep="")	
	times <- paste(as.character(hours),":00:00",sep="")

	alldates <- as.POSIXlt(paste(alldates,times),"UTC")


	if (istat1==istat2) {
	fieldname <-  paste(field,'_',level,'_',test,sep='')
        picname <-  paste("./pics/",fieldname,'_',statname1,
        '.png',sep='')

	ymax <- max(statplot1)
	ymin <- min(statplot1)

	xmax <- max(alldates)	

	png(picname,width=600, height=400.,bg="white")
	plot(alldates,statplot1,type="l",lwd=4,cex=1.,col="blue",
	xlab='',	ylab=statname1,xaxs="i",
	ylim=c(ymin,ymax),
	xaxt='n',	main=fieldname)
	axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
	dev.off()
	}
	else {
	fieldname <-  paste(field,'_',level,'_',test,sep='')

        picname <-  paste("./pics/",fieldname,'_',statname1,'_',
        statname2,'.png',sep='')

	xmax <- max(alldates)
	ymax <- max(statplot1,statplot2)
	ymin <- min(statplot1,statplot2)

	png(picname,width=600, height=400.,bg="white")
	plot(alldates,statplot1,type="l",lwd=4,cex=1.,col="blue",xaxs="i",
	xlab='',	ylab=paste(statname1,statname2),
	cex.axis=1.,cex.lab=1.,ylim=c(ymin,ymax),
	xaxt='n',	main=fieldname)
	lines(alldates,statplot2,col="red",lwd=4)
	legend(x=xmax,y=ymax,xjust=1,yjust=1,col=c("blue","red"),
	lwd=4,legend=c(statname1,statname2),cex=1)
	axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
	dev.off()
	}
    }
}

for (field in fields2d) {
    	print(field)
        fname <- paste(indir,'/',field,'_',suffix,sep="")
	thisfile <- file(fname,"ra")
	names <- scan(thisfile,what='a',sep=',',nlines=1)
 	vartable <- try(
	read.table(thisfile,header=FALSE,skip=0,sep=','),silent=TRUE)
	if (class(vartable)=="try-error") {
	print(c("FILE EMPTY",field))
	close(thisfile)			  
	next } 
	close(thisfile)
	ndate <- which(names=="FCST_VALID_BEG")
	ntotal <-  which(names=="TOTAL")
	
	total <- vartable[,ntotal]

	nlines <- length(total)

	istat1 <- which(names==statname1)
	istat2 <- which(names==statname2)

	totdays <- NULL
	hours <- NULL
	statplot1 <- NULL
	statplot2 <- NULL

	for (i in 1:nlines) {
	if (total[i] < minstat) next
	day <- as.numeric(substr(vartable[i,ndate],1,8))
	totdays <- c(totdays,day)
	hour <- as.numeric(substr(vartable[i,ndate],10,11))
	hours <- c(hours,hour)
	statplot1 <- c(statplot1,vartable[i,istat1])
	statplot2 <- c(statplot2,vartable[i,istat2])
	}

	if (statname1=="BCMSE") statplot1=sqrt(statplot1) 
	if (statname2=="BCMSE") statplot2=sqrt(statplot2) 

        years <- totdays %/%10000
        months <- (totdays %% 10000) %/% 100
        days <-  (totdays %% 10000) %% 100

        alldates <- paste(as.character(years),"-",as.character(months),"-",
        as.character(days),sep="")
        times <- paste(as.character(hours),":00:00",sep="")

        alldates <- as.POSIXlt(paste(alldates,times),"UTC")

	if (istat1==istat2) {
	fieldname <-  paste(field,'_',test,sep='')
        picname <-  paste("./pics/",fieldname,'_',statname1,
        '.png',sep='')

	ymax <- max(statplot1)
	ymin <- min(statplot1)

	png(picname,width=600, height=400.,bg="white")
	plot(alldates,statplot1,type="l",lwd=4,cex=1.,col="blue",xaxs="i",
	xlab='',	ylab=statname1,
	cex.axis=1.,cex.lab=1.,ylim=c(ymin,ymax),
	xaxt='n',	main=fieldname)
	axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
	dev.off()
	}
	else {
	fieldname <-  paste(field,'_',test,sep='')

        picname <-  paste("./pics/",fieldname,'_',statname1,'_',
        statname2,'.png',sep='')

	xmax <- max(alldates)
	ymax <- max(statplot1,statplot2)
	ymin <- min(statplot1,statplot2)

	png(picname,width=600, height=400.,bg="white")
	plot(alldates,statplot1,type="l",lwd=4,cex=1.,col="blue",xaxs="i",
	xlab='Time',	ylab=paste(statname1,statname2),
	cex.axis=1.,cex.lab=1.,ylim=c(ymin,ymax),
	xaxt='n',	main=fieldname)
	axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
	lines(alldates,statplot2,col="red",lwd=4)
	legend(x=xmax,y=ymax,xjust=1,yjust=1,col=c("blue","red"),
	lwd=4,legend=c(statname1,statname2),cex=1)
	dev.off()
	}
}


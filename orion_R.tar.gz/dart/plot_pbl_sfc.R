vars <- c("Time","TSFC","QSFC","UST","HFX","QFX",
     "alpha_l","alpha_f")

nvars <- length(vars)

nens <-  as.integer(try(
system("ls -1 ./indata/*sfc*.txt | wc -l",intern=TRUE)))

prefix <- "./indata/mynn_noah_sfc_"
suffix <- ".txt"

mycolors <- rainbow(nens)

iens <- 1 
test <- sprintf("%03d",iens)
fname <- paste(prefix,test,suffix,sep='')
thisfile <- file(fname,"ra")

ntimes <- length(scan(thisfile,what='1.',sep='\n',nlines=-10))
close(thisfile)

tseries <- array(NA,c(ntimes,nvars,nens))

for (iens in 1:nens) {

    test <- sprintf("%03d",iens)
    fname <- paste(prefix,test,suffix,sep='') 
    thisfile <- file(fname,"ra")

    for (k in 1:ntimes) {
    	tseries[k,,iens] <- scan(thisfile,what=.1,nlines=1)
	}
	close(thisfile)

}

xmin <- tseries[1,1,1]
xmax <- tseries[ntimes,1,1]

for (ivar in 2:nvars) {

    name <- vars[ivar]
    ymin <- min(tseries[,ivar,])
    ymax <- max(tseries[,ivar,])

    picname <-  paste("./pics/",name,"_sfc.png",sep='')

    png(picname,width=500, height=300.,bg="white")

    plot(tseries[,1,1],tseries[,ivar,1],type="l",lwd=1,lty=1,
    cex=1.,col=mycolors[1],xlab=vars[1],ylab=vars[ivar],
    yaxs="i",xlim=c(xmin,xmax),ylim=c(ymin,ymax))
       
    for (iens in 2:nens) {
        lines(tseries[,1,iens],tseries[,ivar,iens],
	col=mycolors[iens],type="l",lwd=1,lty=1)
    }

    dev.off()

}

for (ivar in 2:nvars) {

    ymin <- min(tseries[,ivar,1])
    ymax <- max(tseries[,ivar,1])

    name <- vars[ivar]

    picname <-  paste("./pics/",name,"_single.png",sep='')

    png(picname,width=500, height=300.,bg="white")

    plot(tseries[,1,1],tseries[,ivar,1],type="l",lwd=1,lty=1,
    cex=1.,col=mycolors[1],xlab=vars[1],ylab=vars[ivar],
    yaxs="i",xlim=c(xmin,xmax),ylim=c(ymin,ymax))

    dev.off()

}
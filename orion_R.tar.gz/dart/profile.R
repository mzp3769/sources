#to plot a profile of increment
library(ncdf)

ncname <- './indata/increment/t.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
t <- get.var.ncdf(nc,"T")
close.ncdf(nc)

ncname <- './indata/increment/p.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
pb <- get.var.ncdf(nc,"PB")
pp <- get.var.ncdf(nc,"P")
close.ncdf(nc)

ncname <- './indata/increment/gsi.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
gsi <- get.var.ncdf(nc,"PM2_5_DRY")
close.ncdf(nc)

ncname <- './indata/increment/enkf.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
enkf <- get.var.ncdf(nc,"PM2_5_DRY")
close.ncdf(nc)

top <- 25
levels <- 1:top

xlabstring <- expression(
paste("PM2.5 increment ","[",mu,"g","  ",m^{-3},"]",sep=""))
ylabstring <- "model level"
xmax <- max(gsi,enkf)
ymax <- top
tiff("./pics/increment.tiff",width = 400, height = 600,
bg="white")
plot(gsi[1:top],levels,type="l",col="green",lwd=6,
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",)
lines(enkf[1:top],levels,col="orange",lwd=6)
legend(x=xmax,y=ymax,xjust=1,yjust=1,
col=c("green","orange"),legend=c("GSI","EnKF_NoMet_Ratio"),
lwd=6)

dev.off()

tiff("./pics/Theta.tiff",width = 400, height = 600,
bg="white")
xlabstring <- expression(
paste(Theta,"[K]",sep=""))
plot((t+300)[1:top],levels,type="l",col="red",lwd=6,
xlab=xlabstring,ylab=ylabstring,yaxs="i",)
dev.off()

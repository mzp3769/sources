#to plot a profile of increment
library(ncdf)

ncname <- './indata/profile/profile_nomet.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
t <- get.var.ncdf(nc,"T")
close.ncdf(nc)

nc <- open.ncdf(ncname, readunlim=FALSE )
pm2_5 <- get.var.ncdf(nc,"PM2_5_DRY")
close.ncdf(nc)

top <- 40
levels <- 1:top

xlabstring <- expression(
paste("PM2.5 profile ","[",mu,"g","  ",m^{-3},"]",sep=""))
ylabstring <- "model level"
xmax <- max(pm2_5)
ymax <- top
tiff("./pics/pm2_5.tiff",width = 600, height = 600,
bg="white")
plot(pm2_5[1:top],levels,type="l",col="green",lwd=6,
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",)
dev.off()

tiff("./pics/Theta.tiff",width = 600, height = 600,
bg="white")
xlabstring <- expression(
paste(Theta,"[K]",sep=""))
plot((t+300)[1:top],levels,type="l",col="red",lwd=6,
xlab=xlabstring,ylab=ylabstring,yaxs="i",)
dev.off()

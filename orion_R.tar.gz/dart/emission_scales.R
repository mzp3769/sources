library(ncdf)
library(spatial)
library(nlme)
require(stats)

varname <- "E_PM25J"
#varname <- "E_ECJ"
#varname <- "E_ORGJ"
#varname <- "E_SO4J"
#varname <- "E_NO3J"
source("gaspari.R")

emismin <- 1.e-10

ncname <- "./indata/wrfchemi_00z_d01"
nc <- open.ncdf(ncname, readunlim=FALSE )
x <- get.var.ncdf(nc,"west_east")
y <- get.var.ncdf(nc,"south_north")
z <- get.var.ncdf(nc,"emissions_zdim")
nx <- length(x)
ny <- length(y)
nz <- length(z)

nxy=nx*ny
varin <- get.var.ncdf(nc,varname)

close.ncdf(nc)

xx <- array(NA,c(nxy))
yy <- array(NA,c(nxy))
varvec <- array(NA,c(nxy))

#var <- log(pmax(varin[,,1,1],emismin))
var <- varin[,,1,1]

k <- 1
for (j in 1:ny) {
for (i in 1:nx) {
    if (var[i,j] > emismin) {
       	xx[k] <- x[i]
        yy[k] <- y[j] 
    	varvec[k] <- log(var[i,j])
	k <- k+1
     }
}}

npoints <- k-1

varframe <- data.frame(y=yy[1:npoints],x=xx[1:npoints],
z=varvec[1:npoints])

surface <- surf.ls(2,varframe)

#x11(width=5,height=5)
#variogram(surface,300,lty=1,pch=19,cex=0.15,col="black")
x11(width=5,height=5)
correlogram(surface,100,lty=1,pch=19,cex=0.15,col="blue")
#axis(side=1,at=c(5,10,15))
abline(v=10)

model <- gls(varvec ~ xx+yy)
#plot(Variogram(model,form=~xx+yy))

#tests <- c("test_129","test_131","test_134","test_130")#,"test_128")
tests <- c("test_147","test_146","test_142","test_144")#,"test_128")
#tests <- c("test_206","test_205","test_201","test_204")
tests <- c("test_141","test_136","test_137","test_140")
tcolors <- c("red","green","violet","blue","orange","black")
danames <- c("NoDA","GSI","EnKF_TOT","EnKF_SPEC","GSI_2")


names <- c("BIAS","PRMSE","CORR") # (3,4,5)
colnumber <- 4

year_start <- "2010"
month_start <- "05"
day_start <- "26"
hour_start <- "00"
minute_start <- "30"
secont_start <- "00"

days2skip <- 6

plotdates <- c("2010/06/01","2010/07/01")
plottimes <- c("00:30:00","06:30:00","12:30:00","18:30:00")
assimtimes <- c("00:00:00","06:00:00","12:00:00","18:00:00")


#eliminate erroneous observations from calculating statistics
#max values for "BIAS","PRMSE","CORR"
allstats_max <- c(-20.,20.,1.)

#name <- names[colnumber]
#ylabstring <- as.character(expression(name," [",mu,"g"," ", m^{-3},"]",sep=""))
#ylabstring <- expression(paste("[",mu,"g","  ",m^{-3},"]",sep=""))

ntests <- length(tests)

outdir <- "./pics/"
indir <- "./../indata/"       

varname <- "PM2_5_DRY"

yyyymmdd_start <- paste(year_start,month_start,day_start,sep="-")

time_start <- paste(hour_start,minute_start,secont_start,sep=":")

date_start <- as.POSIXlt(paste(yyyymmdd_start,time_start),"UTC")

date_skip <- date_start+days2skip*3600*24

times_ave <-  format(seq(date_start,by=3600,length=24),"%T")

#plot time series for da verification for calnex

#WRITE(outunit,'(f7.2,i10,7e15.7)')date,nobsvalid_s,&
#                &bias_s,patrmse_s,corr_s,stdevobs_s,stdevfcst_s,&
#                   3      4        5
#                &obsave_s,fcstave_s

ntimes <- NULL
nmaxtimes <- 1e4

allstats <- array(NA,c(ntests,nmaxtimes))

k <- 1

for (test in tests) {
    fname <-  paste(indir,test,'/stats_',varname,'.txt',sep="")
    infile <- file(fname,"ra")
    vartable <- try(
    read.table(infile,header=FALSE,skip=0),silent=TRUE)
    if (class(vartable)=="try-error") {
#    print(c("FILE EMPTY",infile))
    close(infile)
    next }
    ntimes <- c(ntimes,length(vartable[,1]))
    if (ntimes[k] > nmaxtimes) {
    print("CRY FOUL: INCREASE nmaxtimes")
    stop(paste("nmaxtimes = ",as.character(nmaxtimes)," ntimes[",
    as.character(k),"] =",as.character(ntimes[k])))
    }
    allstats[k,1:ntimes[k]] <- as.array(vartable[,colnumber])
    close(infile)
    k <- k+1
}

alldates <- seq(date_start,by=3600,length=max(ntimes))

allstats_ave <- array(0,c(ntests,24))

k <- 1

for (test in tests[1:ntests]) {

    jj <- array(0,24)

    for (i in (1:ntimes[k])) {	

        if ( (! is.nan(allstats[k,i])) && 
       	    (alldates[i] > date_skip ) &&
            (abs(allstats[k,i]) < 
	       abs(allstats_max[colnumber-2])) ) {
    	 j=(i-1)%%24+1
    	 jj[j] <- jj[j]+1
	 allstats_ave[k,j] <- allstats_ave[k,j] + allstats[k,i]
	}
    }


    allstats_ave[k,] <- allstats_ave[k,]/jj

    k <- k+1

}

pdfname <- paste(outdir,varname,'_',names[colnumber-2],'.pdf',sep="")
pdf(pdfname,height=5.5,width=7,bg="white")

xlabstring <- expression("Time")
ylabstring <- names[colnumber-2]


xmin <- min(alldates)
xmax <- max(alldates)

ymin <- min(allstats,na.rm=TRUE)
ymax <- max(allstats,na.rm=TRUE)

plot(alldates[1:ntimes[1]],allstats[1,1:ntimes[1]],
ylim=c(ymin,ymax),col=tcolors[1],
xlab='',ylab=ylabstring,xaxt='n',yaxs="i",xaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=2,cex=1.)
axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
zero <- array(0,max(ntimes))
lines(alldates[1:ntimes[1]],zero,col="black",lwd=1)

k <- 2
for (test in tests[k:ntests]) {
lines(alldates[1:ntimes[k]],allstats[k,1:ntimes[k]],
col=tcolors[k],lwd=2)
k <- k+1
}


if (colnumber == 3 || colnumber == 5) {
legend(x=xmax,y=ymin,xjust=1,yjust=0,col=tcolors[1:ntests],
lwd=2,legend=danames[1:ntests],cex=0.9)
} else {
legend(x=xmax,y=ymax,xjust=1,yjust=1,col=tcolors[1:ntests],
lwd=2,legend=danames[1:ntests],cex=0.9)
}
dev.off()

#plot average stats

pdfname <- paste(outdir,varname,'_',names[colnumber-2],'_ave.pdf',sep="")
pdf(pdfname,height=5.5,width=7,bg="white")

xmin <- min(as.POSIXlt(paste(yyyymmdd_start,times_ave),"UTC"))
xmax <- max(as.POSIXlt(paste(yyyymmdd_start,times_ave),"UTC"))

if (colnumber == 3 ) {
ymin <- -2 #min(allstats_ave)-1
ymax <- 2 #max(allstats_ave)+1
yloc <- ymax
yjust <- 1
ylabstring <- expression(paste("BIAS [",mu,"g","  ",m^{-3},"]"))
}


if (colnumber == 4) {
ymin <- 4 ##min(allstats_ave)-1
ymax <- 10 #max(allstats_ave)+1
yloc <- ymin
yjust <- 0
ylabstring <- expression(paste("PRMSE [",mu,"g","  ",m^{-3},"]"))
}

if (colnumber == 5) {
ymin <- 0.3 #min(allstats_ave)-.1
ymax <- 0.8 #max(allstats_ave)+.1     
yloc <- ymin
yjust <- 0
ylabstring <- "CORR"
}


tmpdates <- as.POSIXlt(paste(yyyymmdd_start,times_ave),"UTC")

plottimes <- as.POSIXlt(paste(yyyymmdd_start,plottimes),"UTC")

assimtimes <- as.POSIXlt(paste(yyyymmdd_start,assimtimes),"UTC")


xlabstring <- expression("TIME [UTC]")


plot(tmpdates,allstats_ave[1,],
ylim=c(ymin,ymax),col=tcolors[1],
xlab=xlabstring,ylab=ylabstring,xaxt='n',xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=4,cex=1.)

axis.POSIXct(1,tmpdates,format="%H:%M",at=plottimes)
zero <- array(0,24)
lines(tmpdates,zero,col="black",lwd=2)

k <- 2
for (test in tests[k:ntests]) {
lines(tmpdates,allstats_ave[k,],col=tcolors[k],lwd=4)
k <- k+1
}

yassim <- c(ymin,ymax)

for (i in 1:length(assimtimes)) {
        lines(c(assimtimes[i],assimtimes[i]),yassim,lwd=3)
}

#abline("v"=assimtimes) does not work

if (colnumber == 3) {

legend(x=xmax,y=yloc,xjust=1,yjust=yjust,col=tcolors[1:ntests],
lwd=4,legend=danames[1:ntests],cex=0.85)

}
dev.off()








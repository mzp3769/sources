#to plot a profile of increment
library(ncdf)

coords <- c(45,6) #x,y
#coords <- c(44,6) #x,y
#coords <- c(52,6) #x,y
coords <- c(46,6)

ncname <- '../indata/increment/t_p_pb.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
t <- get.var.ncdf(nc,"T")
pb <- get.var.ncdf(nc,"PB")
pp <- get.var.ncdf(nc,"P")
close.ncdf(nc)

ncname <- '../indata/increment/gsi.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
gsi <- get.var.ncdf(nc,"PM2_5_DRY")
close.ncdf(nc)

ncname <- '../indata/increment/enkf.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
enkf <- get.var.ncdf(nc,"PM2_5_DRY")
close.ncdf(nc)

top <- 23
levels <- 1:top

pprof <- -log((pp[coords[1],coords[2],]
              +pb[coords[1],coords[2],])/
              (pp[coords[1],coords[2],1]+pb[coords[1],coords[2],1]))


enkfprof <- enkf[coords[1],coords[2],]
gsiprof <- gsi[coords[1],coords[2],]
tprof <- t[coords[1],coords[2],] 


ymin <- min(pprof[1:top])
ymax <- max(pprof[1:top])
xmin <- min(enkfprof,gsiprof)
xmax <- max(enkfprof,gsiprof)+0.1*max(enkfprof,gsiprof)


xlabstring <- expression(
paste("PM2.5 ","[",mu,"g","  ",m^{-3},"]",sep=""))
ylabstring <- expression(paste(-log,"(p/",p[s],")"))

pdf("./pics/increment_p.pdf",width = 3.5, height = 7,
bg="white")
plot(gsiprof[1:top],pprof[1:top],type="l",col="green",lwd=3,
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
xlim=c(xmin,xmax),ylim=c(ymin,ymax))
lines(enkfprof[1:top],pprof[1:top],col="violet",lwd=3)
legend(x=xmax,y=ymax,xjust=1,yjust=1,
col=c("green","violet"),legend=c("GSI","EnKF_TOT"),
lwd=3,cex=0.9)

dev.off()

pdf("./pics/Theta_p.pdf",width = 3.5, height = 7,
bg="white")
xlabstring <- expression(
paste(Theta," [K]",sep=""))
plot((tprof+300)[1:top],pprof[1:top],type="l",col="red",lwd=3,
xlab=xlabstring,ylab=ylabstring,yaxs="i",)
dev.off()



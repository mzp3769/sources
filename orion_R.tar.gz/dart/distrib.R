#this may be junk

m <- log(mu^2/(sqrt(sigma^2+mu^2)))
s <- sqrt(log((sigma/mu)^2+1))

mu <- exp((2*m+s^2)/2)
sigma <- sqrt(exp(2*m+2*s^2)-exp(2*m+s^2))
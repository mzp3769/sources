fields3d <- c("TT","UU","VV","GHT","QVAPOR")
levels <- c("P925","P850","P700","P500","P250")
fields2d <- c("T2","Q2","U10","V10")
suffix <- "rhist.txt"

indir="./indata/test_3"

for (field in fields3d) {
    for (level in levels) {
        fname <- paste(indir,'/',field,'_',level,'_',suffix,sep="")
	thisfile <- file(fname,"ra")
    	header <- scan(thisfile,what='a',sep=',',nlines=1)
#	ncol <- which(header=="N_RANK")+1 #corerct header
	nlines <- length(scan(thisfile,what='a',sep='\n',nlines=-10))
	close(thisfile)
	thisfile <- file(fname,"ra")	
	var <- read.table(thisfile,skip=0,sep=',',nrows=nlines)	
	
	close(thisfile)
    }
}

prefix <- "_sim_"
suffix <- ".nc"

fieldsc <- c("RAINC_HGTM_h","RAINC_HGTP_h","RAINC_HGT_h")
fieldsnc <- c("RAINNC_HGTM_h","RAINNC_HGTP_h","RAINNC_HGT_h")

sim <- array(length(abc)*length(cab)*length(nums))


ii <- 0
jj <- 0
for (fieldc in fieldsc) {
sig <- substr(fieldc,10,10)
if (sig=='_') sig=""

jj <- jj+1
fieldnc <- fieldsnc[jj]

for (k in nums) {
if (k < 110) {
year <- "_2004"
} else {
year <- "_2005"
}

for (jchar in cab) {
for (ichar in abc) {

ii <- ii+1
sim[ii] <- paste(prefix,as.character(k),jchar,ichar,sep="")

#here

fnamec <- paste(dir,"/",fieldc,sim[ii],year,suffix,sep="")
print(fnamec)
fnamenc <- paste(dir,"/",fieldnc,sim[ii],year,suffix,sep="")
print(fnamenc)


# the input file is hourly the average over dimensions

nc <- open.ncdf(fnamec,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

raincave <- array(0.,c(24))
for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
raincave[j] <- data1[i]+raincave[j]
}
rm(data1)

nc <- open.ncdf(fnamenc,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

rainncave <- array(0.,c(24))
for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
rainncave[j] <- data1[i]+rainncave[j]
}
rm(data1)

raintot <- array(0.,c(2,24))
raintot[1,] <- raincave
raintot[2,] <- rainncave
field="RAINTOT"
#fname <- paste("./posts/",field,domain,sim[ii],"histogram_",
#                month,year,".eps",sep="")
#postscript(fname,width=2.95, height=6.,
#horizontal = FALSE, onefile = FALSE, paper = "special",
#           family = "Helvetica")

fname <- paste("./pngs/",field,sig,sim[ii],"_histogram",
               ".png",sep="")
png(fname,width=300, height=600.,bg="white")

par(font.axis=2)

barplot(raintot,space=0,col=c("royalblue","skyblue"),
xlim=c(.93,24),ylim=c(0,15),
axes=TRUE,xlab="time(UTC)",ylab="precip (mm)")

par(font=2)
mtext(side = 1, at=5.525,"06")
mtext(side = 1, at=11.525,"12")
mtext(side = 1, at=17.525,"18")
mtext(side = 1, at=23.525,"00")
text(12,17,labels=fieldc,cex=.6)
dev.off()

}}}}
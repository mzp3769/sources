library(ncdf)
library(spatial)
library(nlme)
require(stats)

varname <- "E_PM25J"
source("gaspari.R")

emismin <- 1.e-10

ncname <- "./indata/wrfchemi_00z_d01"
nc <- open.ncdf(ncname, readunlim=FALSE )
x <- get.var.ncdf(nc,"west_east")
y <- get.var.ncdf(nc,"south_north")
z <- get.var.ncdf(nc,"emissions_zdim")
nx <- length(x)
ny <- length(y)
nz <- length(z)

nxy=nx*ny
varin <- get.var.ncdf(nc,varname)

xx <- array(x,c(nxy))
yy <- array(NA,c(nxy))
varvec <- array(NA,c(nxy))

var <- log(pmax(emismin,varin[,,1,1]))

k <- 0
for (j in 1:ny) {
for (i in 1:nx) {
k <- k+1
    yy[k] <- y[j]
    varvec[k] <- var[i,j]
}}


close.ncdf(nc)

lscale_gaspari <- 10 #scale does not matter since later all scaled by stdev

nx1 <- nx/4
ny1 <- ny/4

seed <- 1
stdev <- sd(varvec)
mu <- 0

scalefac <- 0

i <- 1
j <- 1

for (k in -lscale_gaspari:(nx1+lscale_gaspari)) {
for (l in -lscale_gaspari:(ny1+lscale_gaspari)) {
r <- sqrt((i-k)^2 + (j-l)^2)
scalefac <- scalefac+gaspari(r/lscale_gaspari)
print(c(k,l,scalefac))
}}

set.seed(seed, kind = NULL)
#randvect <- rlnorm(nxy, meanlog=mu, sdlog=stdev)
randvect <- rnorm(nxy, mean=mu, sd=stdev)/scalefac
randvect <- array(nxy,1)
ij <- 0

var_incr <- array(0,c(nx,ny))

for (i in 1:nx1) {
for (j in 1:ny1) {

ij <- ij+1

for (k in -lscale_gaspari:(nx1+lscale_gaspari)) {
for (l in -lscale_gaspari:(ny1+lscale_gaspari)) {
r <- sqrt((i-k)^2 + (j-l)^2)
var_incr[i,j] <- var_incr[i,j]+gaspari(r/lscale_gaspari)*randvect[ij]
}}
}}

x11(width=8,height=5)
filled.contour(x[1:nx1],y[1:ny1],var_incr[1:nx1,1:ny1],
xaxs = "i", yaxs = "i",nlevels=20,color.palette=rainbow)

#image(x[1:nx1], y[1:ny1], var_incr[1:nx1,1:ny1],col=rainbow(20))

#dx <- 1
#dy <- 1

#emiss <- setup.image.smooth( nrow=ny, ncol=nx,  dx=dx, dy=dy,
#             theta=5, xwidth=5, ywidth=5)

# <- image.smooth(var_incr, dx=dx, dy=dy, emiss)
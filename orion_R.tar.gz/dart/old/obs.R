library(ncdf)
ncname1 <- "./indata/obs_sequence_008.nc"
ncname2 <- "./indata/obs_sequence_009.nc"

nc1 <- open.ncdf(ncname1, readunlim=FALSE )
obstypes1 <- get.var.ncdf( nc1, "ObsTypes")
ObsTypesMetaData1 <- get.var.ncdf( nc1, "ObsTypesMetaData")
obs_type1 <- get.var.ncdf( nc1, "obs_type")
location1 <- get.var.ncdf( nc1, "location")
time1 <- get.var.ncdf( nc1, "time")
obs1 <- get.var.ncdf( nc1, "observations")
close.ncdf(nc1)

nx1 <- length(time1)

nc2 <- open.ncdf(ncname2, readunlim=FALSE )
obstypes2 <- get.var.ncdf( nc2, "ObsTypes")
ObsTypesMetaData2 <- get.var.ncdf( nc2, "ObsTypesMetaData")
obs_type2 <- get.var.ncdf( nc2, "obs_type")
location2 <- get.var.ncdf( nc2, "location")
time2 <- get.var.ncdf( nc2, "time")
obs2 <- get.var.ncdf( nc2, "observations")
close.ncdf(nc2)

nx2 <- length(time2)

nx <- nx1 + nx2

o3loc <- array(0,c(2,nx))
pmloc <- array(0,c(2,nx))
o3 <- array(0,c(2,nx))
pm <- array(0,c(2,nx))
location <- array(0,c(2,nx))
obs <- array(0,c(2,nx))

location[1,] <- c(location1[1,],location2[1,])
location[2,] <- c(location1[2,],location2[2,])
obs_type <- c(obs_type1,obs_type2)
time <- c(time1,time2)
obs[1,] <- c(obs1[1,],obs2[1,])	
obs[2,] <- c(obs1[2,],obs2[2,])	

no3 <- 0
npm <- 0
for (i in 1:nx1) {
    if (location[1,i] > 260 && location[1,i] < 300 &&
        location[2,i] > 25 && location[2,i] < 55 &&
        time < 148143.1)               
        {

	if (obs_type[i] == 38)  {
		no3 <- no3+1	
		o3loc[,no3] <- location[1:2,i]
		o3[,no3] <- obs[,i] 
        }

	if (obs_type[i] == 39)  {
		npm <- npm+1	
		pmloc[,npm] <- location[1:2,i]
		pm[,npm] <- obs[,i] 
        }

	}
}

png("o3.png",width = 575, height = 500,bg="white")
quilt.plot(o3loc[1,1:no3],o3loc[2,1:no3],o3[1,1:no3],
nrow=125,ncol=125)
dev.off()

png("o3stdev.png",width = 575, height = 500,bg="white")
quilt.plot(o3loc[1,1:no3],o3loc[2,1:no3],sqrt(o3[2,1:no3]),
nrow=125,ncol=125)
dev.off()

png("pm.png",width = 575, height = 500,bg="white")
quilt.plot(pmloc[1,1:npm],pmloc[2,1:npm],pm[1,1:npm],
nrow=100,ncol=100)
dev.off()

png("pmstdev.png",width = 575, height = 500,bg="white")
quilt.plot(pmloc[1,1:npm],pmloc[2,1:npm],sqrt(pm[2,1:npm]),
nrow=100,ncol=100)
dev.off()


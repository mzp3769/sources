test <- "test_104"

fields3d <- c("TT","UU","VV","GHT","QVAPOR")
levels <- c("P925","P850","P700","P500","P250")
fields2d <- c("T2","Q2","U10","V10")
suffix <- "rhist.txt"

indir=paste("./indata/",test,sep='')

for (field in fields3d) {
    for (level in levels) {
    	print(c(field,level))
        fname <- paste(indir,'/',field,'_',level,'_',suffix,sep="")
	thisfile <- file(fname,"ra")
	names <- scan(thisfile,what='a',sep=',',nlines=1)
 	vartable <- try(
	read.table(thisfile,header=FALSE,skip=0,sep=','),silent=TRUE)
	if (class(vartable)=="try-error") {
	print(c("FILE EMPTY",c(field,level)))
	close(thisfile)			  
	next } 
	close(thisfile)
	ntotal <-  which(names=="TOTAL")
	n1 <- which(names=="N_RANK")+1
	n2 <- length(names)
	nranks <- n2-n1+1
	total <- sum(vartable[,ntotal])
	fieldname <-  paste(field,'_',level,'_',test,sep='')
	rank_diag <- colSums(vartable[,n1:n2])/total
#	rank_diag <- apply(data.matrix(vartable[,n1:n2]),2,sum)
	picname <-  paste("./pics/",fieldname,'_rhist.png',sep='')
	png(picname,width=600, height=600.,bg="white")
	barplot(rank_diag,space=0,names.arg=fieldname,col="skyblue")
# can also use hist(...)	
	dev.off()

    }
}

for (field in fields2d) {
    	print(field)
        fname <- paste(indir,'/',field,'_',suffix,sep="")
	thisfile <- file(fname,"ra")
	names <- scan(thisfile,what='a',sep=',',nlines=1)
 	vartable <- read.table(thisfile,header=FALSE,skip=0,sep=',')	
	close(thisfile)
	ntotal <-  which(names=="TOTAL")
	n1 <- which(names=="N_RANK")+1
	n2 <- length(names)
	nranks <- n2-n1+1
	total <- sum(vartable[,ntotal])
	fieldname <-  paste(field,'_',test,sep='')
	rank_diag <- colSums(vartable[,n1:n2])/total
#	rank_diag <- apply(data.matrix(vartable[,n1:n2]),2,sum)
	picname <-  paste("./pics/",fieldname,'_rhist.png',sep='')
	png(picname,width=600, height=600.,bg="white")
	barplot(rank_diag,space=0,names.arg=fieldname,
	col="skyblue")
	dev.off()
}


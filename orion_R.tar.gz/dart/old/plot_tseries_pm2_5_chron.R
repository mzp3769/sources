library("chron")
year_start <- "2010"
month_start <- "05"
day_start <- "26"
hour_start <- "00"
minute_start <- "30"
secont_start <- "00"


ddmmyyyy_start <- paste(day_start,month_start,year_start,sep="/")
time_start <- paste(hour_start,minute_start,secont_start,sep=":")

date_start <- chron(ddmmyyyy_start,time_start,
format=c(dates = "d/m/y",times = "h:m:s"))


#plot time series for da verification for calnex

#WRITE(outunit,'(f7.2,i10,7e15.7)')date,nobsvalid_s,&
#                &bias_s,patrmse_s,corr_s,stdevobs_s,stdevfcst_s,&
#                   3      4        5
#                &obsave_s,fcstave_s

names <- c("BIAS","PRMSE","CORR") # (3,4,5)
colnumber <- 3

#name <- names[colnumber]
#ylabstring <- as.character(expression(name," [",mu,"g"," ", m^{-3},"]",sep=""))
#ylabstring <- expression(paste("[",mu,"g","  ",m^{-3},"]",sep=""))

#tests <- c("test_2","test_3","test_6","test_4")
#tests <- c("test_3","test_10","test_9","test_4")
tests <- c("test_101","test_103","test_102") #,"test_9","test_4")
ntests <- length(tests)
tcolors <- c("green","blue","red") #,"skyblue","red")
#danames <- c("NODA","ENKF_10","ENKF_9","GSI")
danames <- c("ENKF_1","GSI","NODA")

outdir <- "./pics/"
indir <- "./indata/"       

varname <- "PM2_5_DRY"

ntimes <- NULL
allstats <- NULL

for (test in tests) {
    fname <-  paste(indir,test,'/stats_',varname,'.txt',sep="")
    infile <- file(fname,"ra")
    vartable <- try(
    read.table(infile,header=FALSE,skip=0),silent=TRUE)
    if (class(vartable)=="try-error") {
#    print(c("FILE EMPTY",infile))
    close(infile)
    next }
    ntimes <- c(ntimes,length(vartable[,1]))
    nstats <- length(vartable[1,])
    allstats <- rbind(allstats,vartable)
    close(infile)

}

maxntimes <- max(ntimes)

alldates <- NULL

for (i in (1:(maxntimes-1))) {	
    newdate <- chron(date_start + (i-1)/24)
    alldates <- c(alldates, newdate)
}


    
tiffname <- paste(outdir,varname,'_',names[colnumber-2],'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- expression("Time [hours]")
ylabstring <- names[colnumber-2]

xmin <- min(allstats[,1])
xmax <- max(allstats[,1])

ymin <- min(allstats[,colnumber],na.rm=TRUE)
ymax <- max(allstats[,colnumber],na.rm=TRUE)

zero <- array(0,max(ntimes))

plot(allstats[1:ntimes[1],1],allstats[1:ntimes[1],colnumber],
xlim=c(xmin,xmax),
ylim=c(ymin,ymax),col=tcolors[1],
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=2,cex=1.)

zero <- array(0,max(ntimes))
lines(allstats[1:ntimes[1],1],zero,col="black",lwd=2)

endline <- ntimes[1]
k <- 2
for (test in tests[k:ntests]) {
startline <- endline +1 
endline <- endline + ntimes[k]
lines(allstats[startline:endline,1],allstats[startline:endline,colnumber],
col=tcolors[k],lwd=2)
k <- k+1
}

#abline("v"=seq(0,xmax,6))


if (colnumber == 3 || colnumber == 5) {
legend(x=xmax,y=ymin,xjust=1,yjust=0,col=tcolors,
lwd=2,legend=danames,cex=1)
} else {
legend(x=xmax,y=ymax,xjust=1,yjust=1,col=tcolors,
lwd=2,legend=danames,cex=1)
}
dev.off()


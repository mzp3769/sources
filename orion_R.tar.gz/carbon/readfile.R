fname <- "out"
im1 <- 41
im2 <- 451
jm1 <- 36
jm2 <- 337

nx <- im2-im1+1
ny <- jm2-jm1+1

test <- array(scan(fname,what=0.,n=nx*ny),c(nx,ny))
#close(fname)
png("test.png",width = 630, height = 530,bg="lightgrey")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=test)
dev.off()

namea <- "./data/vars_8hrmx_2d.ascii"
nameb <- "./data/varst_8hrmx_2d.ascii"
ncolsa <- 2
col <- 1
cola <- 2

#x11()
#xlabstring=expression("Date")
#ylabstring=expression("sigmas")

xlabstring=expression(" ")
ylabstring=expression(" ")

postscript("varst.eps",width=3.32, height=1.5,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
#           family = "ComputerModern")
#           family = "NimbusSan")

infile <- file(namea,"ra")
a <- readLines(infile)
nrows <- length(a)
close(infile)

infile <- file(namea,"ra")
vara <-array(0,c(nrows,ncolsa))	
for (i in 1:nrows) {
	vara[i,] <- array(scan(infile,what=0.,n=ncolsa))
}
close(infile)

infile <- file(nameb,"ra")
varb <-array(0,c(nrows,ncolsa))	
for (i in 1:nrows) {
	varb[i,] <- array(scan(infile,what=0.,n=ncolsa))
}
close(infile)

margin=c(.4,.3,.2,.1)

########2nd fig
xmin <- 1.
xmax <- 56.
ymin <- 0.10
ymax <- 0.6

par(tcl=.5)
par(font=1)
par(mai=margin)
#par(plt=c(0.2,.8,0.2,.5))
#par(fin=c(3,2))
plot(vara[,col],vara[,cola],"l",col="black",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=.7,
xlab=xlabstring,ylab=ylabstring,
xaxs="i",yaxs="i",cex.axis=1.,cex.lab=1.,axes=FALSE)
plot(varb[,col],varb[,cola],"l",col="black",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=.7,
xlab=xlabstring,ylab=ylabstring,
xaxs="i",yaxs="i",cex.axis=1.,cex.lab=1.,axes=FALSE)
par(cex.axis=.7)
par(las = 0)
par(tcl=-.2)
axis(1,at=c(1,10,20,30,40,50),lwd=.7,labels=FALSE)
par(tcl=0)
axis(1,at=c(2,28,54),labels=c("Jul 1","days","Aug 30"),lwd=.7)
axis(1,at=c(1,56),lwd=.7,labels=FALSE)
par(las = 1)
par(tcl=0)
axis(4,pos=c(56,0.1),at=c(0.1,.6),lwd=.7,labels=FALSE)
par(tcl=0)
axis(3,at=c(1,56),lwd=.7,labels=FALSE)
par(tcl=0.)
par(las = 0)
axis(2,pos=c(1,.1),at=0.35,labels=FALSE,lwd=.7,cex=1.)
par(las = 1)
par(tcl=-.2)
axis(2,pos=c(1,0.1),at=c(0.1,.2,.3,.4,.5,.6),lwd=.7,labels=FALSE)
#mtext(c("0.1   ","0.2   ","0.3   ","0.4   ","0.5   ","0.6   "),side=2,
#outer=FALSE,at=c(.115,.215,.315,.415,.515,.615),cex=.6,lwd=.7)
#margin=c(.4,.45,.07,.1)
mtext(c(expression(paste(sigma[t],"  "))),side=2,outer=FALSE,
at=.67,cex=.8)
#legend(-0.1,0.0485,c("ITER","WRF"),col=c("red","blue"),lwd=5,bty="o")
text(3,0.55,labels="b",cex=.7,vfont=c("serif","plain"))
mtext(c("0.2   ","0.4   ","0.6   "),side=2,
outer=FALSE,at=c(.215,.415,.615),cex=.6,lwd=.7)
mtext(c(1,10,20,30,40,50),side=1,outer=FALSE,at=c(1,10,20,30,40,50),
cex=.6,lwd=.7)



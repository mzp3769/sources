namea <- "./data/stats_ave_neqw_8hrmx_2d.ascii"
ncolsa <- 5


xlabstring=expression("days ")
ylabstring=expression("weights")

postscript("iofa_20.eps",width=3.32, height=1.5,,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
#png("C_H.png",width = 380, height = 360,bg="lightblue")
#x11()
onefile <- TRUE
#pdf(file=ifelse(onefile,"C_H.5m.pdf"))
#pdf(file=ifelse(onefile,"t_ground.pdf"))

infile <- file(namea,"ra")
varlist <- scan(infile,list("",0,0.,0.,0.))
nrows <- length(varlist[[1]])
close(infile)

#layout(matrix(c(1,2), 1, 1, byrow = TRUE), respect=TRUE)
#par(mfrow=c(1,1))



#########1st fig

xmin <- 1
xmax <- nrows
ymin <- .72
ymax <- .74
margin=c(.4,.35,.2,.07)
#par(omd=c(.0,.115,.0,.0))
par(tcl=.2)
par(font=1)
par(mai=margin)
#par(plt=c(0.2,.8,0.2,.5))
#par(fin=c(3,2))
plot(varlist[[2]],varlist[[5]],"l",col="black",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=1,
xlab=xlabstring,ylab="",
xaxs="i",yaxs="i",cex.axis=.1,cex.lab=.1,axes=FALSE)
#par(ps=10)
text(2,.738,labels="c",cex=.7,vfont=c("serif","plain"))
par(cex.axis=.7)
par(las = 0)
par(tcl=0.)
axis(1,at=c(15),labels=c("length of  training period (days)"),lwd=.7)
par(tcl=-0.2)
axis(1,at=c(1,10,20,30),lwd=.7,labels=FALSE)
mtext(c(1,10,20,30),side=1,outer=FALSE,at=c(1,10,20,30),
cex=.6)
par(tcl=-.2)
axis(2,pos=c(1,.72),at=c(.72,.73,.74),lwd=.7,labels=FALSE)
axis(2,pos=c(1,.72),lwd=.7,labels=FALSE)
par(las = 1)
par(tcl=0)
axis(4,pos=c(30,.72),at=c(.72,.73,.74),lwd=.7,labels=FALSE)
par(tcl=0.0)
axis(3,at=c(1,30),lwd=.7,labels=FALSE)
par(tcl=0.0)
#axis(3,at=c(4,53),lwd=.7,labels=c("Jul 06","Aug 31"))
par(tcl=-.2)
mtext(c("0.72    ","0.73    ","0.74    "),side=2,
outer=FALSE,at=c(.7205,.7305,.7405),cex=.6)
#legend(-0.1,0.0485,c("ITER","WRF"),col=c("red","blue"),lwd=5,bty="o")
par(las = 1)
mtext("IofA ",side=2,outer=FALSE,at=.743,cex=.7)

library(ncdf)
dir <- "/export/scratch/pagowski/stuff/R/san_diego_2006/data"
fname <- "ebbr.nc"

nc <- open.ncdf(paste(dir,"/",fname,sep=""), readunlim=FALSE)

sensfluxname <- "h"
qcsensfluxname <- "qc_h"
latfluxname <- "e"
qclatfluxname <- "qc_e"
bowenname <- "bowen"
windname <- "wind_s"
qcwindname <- "qc_wind_s"

tairbotname <- "tair_bot"
qctairbotname <- "qc_tair_bot"
tairtopname <- "tair_top"
qctairtopname <- "qc_tair_top"

thumbotname <- "thum_bot"
qcthumbotname <- "qc_thum_bot"
thumtopname <- "thum_top"
qcthumtopname  <- "qc_thum_top"

presname <- "pres"
qcpresname <- "qc_pres"

humbotname <- "hum_bot"
qchumbotname <- "qc_hum_bot"
humtopname <- "hum_top"
qchumtopname <- "qc_hum_top"

times <- get.var.ncdf( nc, "time")
timeoffset <- get.var.ncdf( nc, "time_offset")
#alt <- get.var.ncdf( nc, "alt")
#lat <- get.var.ncdf( nc, "lat")
#lon <- get.var.ncdf( nc, "lon")

ntimes <- dim(times)

sensflux <- get.var.ncdf( nc, sensfluxname )
qcsensflux <- get.var.ncdf( nc, qcsensfluxname )

latflux <- get.var.ncdf( nc, latfluxname )
qclatflux <- get.var.ncdf( nc, qclatfluxname )

bowen <- get.var.ncdf( nc, bowenname )

wind <- get.var.ncdf( nc, windname )
qcwind <- get.var.ncdf( nc, qcwindname )

tairbot <- get.var.ncdf( nc, tairbotname)
qctairbot <- get.var.ncdf( nc, qctairbotname)
tairtop <- get.var.ncdf( nc, tairtopname)
qctairtop <- get.var.ncdf( nc, qctairtopname)

thumbot <- get.var.ncdf( nc, thumbotname)
qcthumbot <- get.var.ncdf( nc, qcthumbotname)
thumtop <- get.var.ncdf( nc, thumtopname)
qcthumtop <- get.var.ncdf( nc, qcthumtopname)

humbot <- get.var.ncdf( nc, humbotname)
qchumbot <- get.var.ncdf( nc, qchumbotname)
humtop <- get.var.ncdf( nc, humtopname)
qchumtop <- get.var.ncdf( nc, qchumtopname)

pres <- get.var.ncdf( nc, presname)
qcpres <- get.var.ncdf( nc, qcpresname)

close.ncdf(nc)

for (i in 1:ntimes) {
    if (qcwind[i] > 0) {
        wind[i] <- NA
    }
    if (qclatflux[i] > 0) {
        latflux[i] <- NA
    }

    if (qcsensflux[i] > 0) {
        sensflux[i] <- NA
    }

    if (qctairbot[i] > 0) {
        tairbot[i] <- NA
    }

    if (qctairtop[i] > 0) {
        tairtop[i] <- NA
    }

    if (qcthumbot[i] > 0) {
        thumbot[i] <- NA
    }

    if (qcthumtop[i] > 0) {
        thumtop[i] <- NA
    }

    if (qchumbot[i] > 0) {
        humbot[i] <- NA
    }

    if (qchumtop[i] > 0) {
        humtop[i] <- NA
    }

    if (qcpres[i] > 0) {
        pres[i] <- NA
    }

}

source("const.R")
pres <- pres*1.e3

tairbot <- tairbot + 273.15
tairtop <- tairtop + 273.15
thumbot <- thumbot + 273.15
thumtop <- thumtop + 273.15

humtop <- pmin(array(1,ntimes),humtop)
humbot <- pmin(array(1,ntimes),humbot)

#mixing ratio

	
esat <-   611.2*exp(17.67*(thumbot-273.15)/(thumbot-29.65))
qvbot <- .622*esat/(pres-0.378*esat)*humbot 
esat <-   611.2*exp(17.67*(thumtop-273.15)/(thumtop-29.65))
qvtop <- .622*esat/(pres-0.378*esat)*humtop

rho <- pres/(rgas*(tairbot*(1.+virtfactor*qvbot)))
thflux <- -sensflux/(rho*cp)
hflux <- -sensflux
qvflux <- -latflux/l_evap

rm(esat)

source("corrna.R")
for (i in 1:ntimes) {
   print(i)
   tairbot[i] <- corrnafunc(tairbot)
   tairtop[i] <- corrnafunc(tairtop)
   thumbot[i] <- corrnafunc(thumbot)
   thumtop[i] <- corrnafunc(thumtop)
   qvbot[i] <- corrnafunc(qvbot)
   qvtop[i] <- corrnafunc(qvtop)
   hflux[i] <- corrnafunc(hflux)
   thflux[i] <- corrnafunc(thflux)
   qvflux[i] <- corrnafunc(qvflux)
   wind[i] <- corrnafunc(wind)
}

source("params.R")

windbot <- wind
windtop <- wind
thairbot <- tairbot*(p_ref/pres)^rgascp
thairtop <- tairtop*(p_ref/pres)^rgascp
thvairbot <- thairbot*(1.+virtfactor*qvbot)
thvairtop <- thairtop*(1.+virtfactor*qvtop)

thvirtflux <- thflux+virtfactor*thvairbot*qvflux/rho

indices <- which(abs(thvirtflux) < epsmol, arr.ind=TRUE)
thvirtflux[indices] <- sign(thvirtflux[indices])*epsmol

#to get only positve values
#thvirtflux <- pmax(array(0,ntimes),thvirtflux)

source("newton.R")

ustar <- array(NA,ntimes)

for (i in 1:ntimes) {
    print(i)
    uo <- wind[i]
    thvll <- tairbot[i]
    thvflux <- thvirtflux[i]
    ustar[i] <- newtonfunc(-1.,2.,0.01)
    if (is.na(ustar[i])) {
        print(i %% 24)
        print(-sensflux[i])
        print(-latflux[i])
        print(wind[i])
        natimes[i] <- 1
    }
}


thvll <- thvairbot
mol <- molfunc(ustar,thvirtflux,thvll)
zetabot <- zbot/mol
zetatop <- ztop/mol
zetawind <- zwind/mol
zt <- zo/exp(2)
zq <- zo/exp(2)
ts <- thvll
qvs <- qvbot

for (i in 1:ntimes) {
    print(i)
    windbot[i] <- wind[i]*(log(zbot /zo) - psimfunc(zetabot[i] ))/
                      (log(zwind/zo) - psimfunc(zetawind[i]))
    windtop[i] <- wind[i]*(log(ztop /zo) - psimfunc(zetatop[i] ))/
                      (log(zwind/zo) - psimfunc(zetawind[i]))

    qvs[i] <- (qvtop[i]*(log(ztop/zq)-psihfunc(zetatop[i]))-
            qvbot[i]*(log(zbot/zq)-psihfunc(zetabot[i]))          )/
            ((log(ztop/zq)-psihfunc(zetatop[i])) -
             (log(zbot/zq)-psihfunc(zetabot[i])))
 
    ts[i] <- (thvairtop[i]*(log(ztop/zq)-psihfunc(zetatop[i]))-
            thvairbot[i]*(log(zbot/zq)-psihfunc(zetabot[i])))/
	    ((log(ztop/zq)-psihfunc(zetatop[i])) -
             (log(zbot/zq)-psihfunc(zetabot[i])))/
             (1.+virtfactor*qvs[i])*(pres[i]/p_ref)^rgascp
 
}

natimes <- array(0,ntimes)

oldwind <- wind
oldthflux <- thflux
oldhflux <- hflux
oldqvflux <- qvflux
oldustar <- ustar
oldthvirtflux <- thvirtflux
oldts <- ts
oldqvs <- qvs

ncols <- 10
allflux <- array(c(timeoffset,times,
           ustar,thvirtflux,thflux,hflux,qvflux,wind,ts,qvs),
                 c(ntimes,ncols))
file("sfc.txt","w")
for (i in 1:ntimes) {
    write(allflux[i,],file="sfc.txt",
    ncolumns=ncols,append=TRUE)
}

print("run fortran smoother")
stop("stop in calcustar.R")

allflux <- array(NA,c(ntimes,ncols-1))

infile <- file("sfc_smooth.txt","ra")
for (i in 1:ntimes) {
    allflux[i,] <- array(scan(infile,what=0.,n=ncols-1))
}

ustar <- allflux[,2]
thvirtflux <- allflux[,3]
thflux <- allflux[,4]
hflux <- allflux[,5]
qvflux <- allflux[,6]
wind <- allflux[,7]
ts <- allflux[,8]
qvs <- allflux[,9]

plot(timeoffset[1800:2200]/(3600*24),oldustar[1800:2200],
col="green","l",ylim=c(-1,1.5))
lines(timeoffset[1800:2200]/(3600*24),ustar[1800:2200],
col="green",lwd=3)

lines(timeoffset[1800:2200]/(3600*24),oldthvirtflux[1800:2200],
col="purple")
lines(timeoffset[1800:2200]/(3600*24),thvirtflux[1800:2200],
col="purple",lwd=3)

lines(timeoffset[1800:2200]/(3600*24),oldthflux[1800:2200],col="red")
lines(timeoffset[1800:2200]/(3600*24),thflux[1800:2200],col="red",
lwd=3)

plot(timeoffset[1800:2200]/(3600*24),oldqvflux[1800:2200],col="blue","l")
lines(timeoffset[1800:2200]/(3600*24),qvflux[1800:2200],col="blue",
lwd=3)

plot(timeoffset[1800:2200]/(3600*24),oldhflux[1800:2200],col="blue","l")
lines(timeoffset[1800:2200]/(3600*24),hflux[1800:2200],col="blue",
lwd=3)



plot(timeoffset[1800:2200]/(3600*24),oldwind[1800:2200],col="red","l")
lines(timeoffset[1800:2200]/(3600*24),wind[1800:2200],col="blue",lwd=3)

plot(timeoffset/(3600*24),natimes,"l",col="red",ylim=c(-1,1))

for (i in 2:ntimes-1)  {
    if ((natimes[i-1]==1) && (natimes[i]==1) && (natimes[i+1]==1)) 
    print(i)
}

ust <- array(NA,ntimes)

ust <- .Fortran("cubgcv",x=as.double(seq(1,ntimes)),
                  f=as.double(ustar),
                  df=as.double(array(1,ntimes)),
                  as.integer(ntimes),
                  y=as.double(array(0.,ntimes)),
                  c=as.double(array(0.,ntimes)),
                  ic=as.integer(ntimes-1),
                  var=as.double(-1.),
                  job=as.integer(0),
                  se=as.double(array(0.,ntimes)),
                  wk=as.double(0.,(7*(nmaxdata+2))),
                  ierr=as.integer(0))


allflux <- array(c(thflux,qvflux,wind),c(ntimes,3))
file("sfc.txt","w")
for (i in 1:ntimes) {
    write(allflux[i,],file="sfc.txt",ncolumns=4,append=TRUE)
}



source("newton.R")

z <- 10.
zo <- .1
hpbl <- 1500.

ustar <- array(NA,ntimes) 
natimes <- array(0.,ntimes) 

allflux <- array(NA,c(ntimes,4))

infile <- file("fluxes_smooth.txt","ra")
for (i in 1:ntimes) {
    allflux[i,] <- array(scan(infile,what=0.,n=4))
}

thflux <- allflux[,2]
qflux <- allflux[,3]
wind <- allflux[,4]

thvirtflux <- thflux+virtfactor*tair*qflux

for (i in 1:ntimes) {
    print(i)
    uo <- wind[i]
    thvll <- tair[i]
    thvflux <- thvirtflux[i]
    ustar[i] <- newtonfunc(-1.,2.,0.01)
    if (is.na(ustar[i])) {
        print(i %% 24)
        print(-sensflux[i])
        print(-latflux[i])
        print(wind[i])
        natimes[i] <- 1
    }
}

stop("stop in calcustar.R")

plot(timeoffset[1800:2200]/(3600*24),oldustar[1800:2200],
col="green","l",ylim=c(-1,1))
lines(timeoffset[1800:2200]/(3600*24),ustar[1800:2200],
col="green",lwd=3)

lines(timeoffset[1800:2200]/(3600*24),oldthvirtflux[1800:2200],
col="purple")
lines(timeoffset[1800:2200]/(3600*24),thvirtflux[1800:2200],
col="purple",lwd=3)

lines(timeoffset[1800:2200]/(3600*24),oldthflux[1800:2200],col="red")
lines(timeoffset[1800:2200]/(3600*24),thflux[1800:2200],col="red",
lwd=3)

lines(timeoffset[1800:2200]/(3600*24),oldqflux[1800:2200],col="blue")
lines(timeoffset[1800:2200]/(3600*24),qflux[1800:2200],col="blue",
lwd=3)


plot(timeoffset[1800:2200]/(3600*24),oldwind[1800:2200],
col="red","l")
lines(timeoffset[1800:2200]/(3600*24),wind[1800:2200],col="blue",lwd=3)

plot(timeoffset/(3600*24),natimes,"l",col="red",ylim=c(-1,1))

for (i in 2:ntimes-1)  {
    if ((natimes[i-1]==1) && (natimes[i]==1) && (natimes[i+1]==1)) 
    print(i)
}

ust <- array(NA,ntimes)

ust <- .Fortran("cubgcv",x=as.double(seq(1,ntimes)),
                  f=as.double(ustar),
                  df=as.double(array(1,ntimes)),
                  as.integer(ntimes),
                  y=as.double(array(0.,ntimes)),
                  c=as.double(array(0.,ntimes)),
                  ic=as.integer(ntimes-1),
                  var=as.double(-1.),
                  job=as.integer(0),
                  se=as.double(array(0.,ntimes)),
                  wk=as.double(0.,(7*(nmaxdata+2))),
                  ierr=as.integer(0))









allflux <- array(c(thflux,qflux,wind),c(ntimes,3))
file("fluxes.txt","w")
for (i in 1:ntimes) {
    write(allflux[i,],file="fluxes.txt",ncolumns=4,append=TRUE)
}

stop("run fortran smmother")

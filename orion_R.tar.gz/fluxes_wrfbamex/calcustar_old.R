dir <- "/export/scratch/pagowski/stuff/wrf1d/from_dorita"
fname <- "ebbr.nc"

nc <- open.ncdf(paste(dir,"/",fname,sep=""), readunlim=FALSE)

sensfluxname <- "h"
qcsensfluxname <- "qc_h"
latfluxname <- "e"
qclatfluxname <- "qc_e"
bowenname <- "bowen"
windname <- "wind_s"
qcwindname <- "qc_wind_s"
tairname <- "tair_bot"
qctairname <- "qc_tair_bot"
presname <- "pres"
qcpresname <- "qc_pres"

times <- get.var.ncdf( nc, "time")
timeoffset <- get.var.ncdf( nc, "time_offset")

ntimes <- dim(times)

sensflux <- get.var.ncdf( nc, sensfluxname )
qcsensflux <- get.var.ncdf( nc, qcsensfluxname )

latflux <- get.var.ncdf( nc, latfluxname )
qclatflux <- get.var.ncdf( nc, qclatfluxname )

bowen <- get.var.ncdf( nc, bowenname )

wind <- get.var.ncdf( nc, windname )
qcwind <- get.var.ncdf( nc, qcwindname )

tair <- get.var.ncdf( nc, tairname)
qctair <- get.var.ncdf( nc, qctairname)

pres <- get.var.ncdf( nc, presname)
qcpres <- get.var.ncdf( nc, qcpresname)

close.ncdf(nc)

for (i in 1:ntimes) {
    if (qcwind[i] > 0) {
        wind[i] <- NA
    }
    if (qclatflux[i] > 0) {
        latflux[i] <- NA
    }

    if (qcsensflux[i] > 0) {
        sensflux[i] <- NA
    }

    if (qctair[i] > 0) {
        tair[i] <- NA
    }
    if (qcpres[i] > 0) {
        pres[i] <- NA
    }

}

source("const.R")
tair <- tair+273.15
pres <- pres*1.e3
rho <- pres/(rgas*tair)
thflux <- -sensflux/(rho*cp)
qflux <- -latflux/(rho*l_evap)

source("corrna.R")
for (i in 1:ntimes) {
   print(i)
   thflux[i] <- corrnafunc(thflux)
   qflux[i] <- corrnafunc(qflux)
   wind[i] <- corrnafunc(wind)
}

natimes <- array(0,ntimes)
source("newton.R")

z <- 10.
zo <- .1
hpbl <- 1500.


thvirtflux <- thflux+virtfactor*tair*qflux
ustar <- array(NA,ntimes) 

for (i in 1:ntimes) {
    print(i)
    uo <- wind[i]
    thvll <- tair[i]
    thvflux <- thvirtflux[i]
    ustar[i] <- newtonfunc(-1.,2.,0.01)
    if (is.na(ustar[i])) {
        print(i %% 24)
        print(-sensflux[i])
        print(-latflux[i])
        print(wind[i])
        natimes[i] <- 1
    }
}

oldwind <- wind
oldthflux <- thflux
oldqflux <- qflux
oldustar <- ustar
oldthvirtflux <- thvirtflux

allflux <- array(c(ustar,thvirtflux,thflux,qflux,
                   wind),c(ntimes,5))
file("fluxes.txt","w")
for (i in 1:ntimes) {
    write(allflux[i,],file="fluxes.txt",
    ncolumns=5,append=TRUE)
}

stop("stop in calcustar.R")


allflux <- array(NA,c(ntimes,6))

infile <- file("fluxes_smooth.txt","ra")
for (i in 1:ntimes) {
    allflux[i,] <- array(scan(infile,what=0.,n=6))
}

ustar <- allflux[,2]
thvirtflux <- allflux[,3]
thflux <- allflux[,4]
qflux <- allflux[,5]
wind <- allflux[,6]

plot(timeoffset[1800:2200]/(3600*24),oldustar[1800:2200],
col="green","l",ylim=c(-1,1))
lines(timeoffset[1800:2200]/(3600*24),ustar[1800:2200],
col="green",lwd=3)

lines(timeoffset[1800:2200]/(3600*24),oldthvirtflux[1800:2200],
col="purple")
lines(timeoffset[1800:2200]/(3600*24),thvirtflux[1800:2200],
col="purple",lwd=3)

lines(timeoffset[1800:2200]/(3600*24),oldthflux[1800:2200],col="red")
lines(timeoffset[1800:2200]/(3600*24),thflux[1800:2200],col="red",
lwd=3)

lines(timeoffset[1800:2200]/(3600*24),oldqflux[1800:2200],col="blue")
lines(timeoffset[1800:2200]/(3600*24),qflux[1800:2200],col="blue",
lwd=3)


plot(timeoffset[1800:2200]/(3600*24),oldwind[1800:2200],
col="red","l")
lines(timeoffset[1800:2200]/(3600*24),wind[1800:2200],col="blue",lwd=3)

plot(timeoffset/(3600*24),natimes,"l",col="red",ylim=c(-1,1))

for (i in 2:ntimes-1)  {
    if ((natimes[i-1]==1) && (natimes[i]==1) && (natimes[i+1]==1)) 
    print(i)
}

ust <- array(NA,ntimes)

ust <- .Fortran("cubgcv",x=as.double(seq(1,ntimes)),
                  f=as.double(ustar),
                  df=as.double(array(1,ntimes)),
                  as.integer(ntimes),
                  y=as.double(array(0.,ntimes)),
                  c=as.double(array(0.,ntimes)),
                  ic=as.integer(ntimes-1),
                  var=as.double(-1.),
                  job=as.integer(0),
                  se=as.double(array(0.,ntimes)),
                  wk=as.double(0.,(7*(nmaxdata+2))),
                  ierr=as.integer(0))









allflux <- array(c(thflux,qflux,wind),c(ntimes,3))
file("fluxes.txt","w")
for (i in 1:ntimes) {
    write(allflux[i,],file="fluxes.txt",ncolumns=4,append=TRUE)
}

stop("run fortran smmother")

source("const.R")

molfunc <- function(ustar,thvirtflux,thv) {
        molength <- -ustar^3/(karman*grav/thvll*thvirtflux)
    return(molength)
}        


phimfunc <- function(zeta) {

    if 	(zeta < 0.)  {	
	phim <- sqrt(1./sqrt(1.-alphaunstable*zeta))
	} else {	
#holtstag debruin
	phim <- 1.+zeta*(b_stable*exp(-d_stable*zeta)-
        b_stable*d_stable*
        (zeta-c_stable/d_stable)*exp(-d_stable*zeta)+a_stable)
#old 
#	phim <- 1.+alphastable*zeta
    }	

    return(phim)
}

psimfunc <- function(zeta) {

    if (zeta < 0.) {
       x <- 1./phimfunc(zeta)
       psim <- 2.*log(.5*(1.+x))+log(.5*(1.+x*x))-2.*atan(x)+halfpi
    } else {
#holtstag debruin
       psim <- -b_stable*(zeta-c_stable/d_stable)*exp(-d_stable*zeta)-
            a_stable*zeta-b_stable*c_stable/d_stable
#old
#       psim <- -alphastable*zeta

    }
    
    return(psim)

}

psihfunc <- function(zeta) {

    if (zeta < 0.) {
       y <- sqrt(1.-alphaunstable*zeta)
       psih <- 2.*log(.5*(1.+y))
    } else {
#holtstag debruin
       psih=-b_stable*(zeta-c_stable/d_stable)*exp(-d_stable*zeta)-
             (sqrt(1.+a_stable*b_stable*zeta))^3-
             b_stable*c_stable/d_stable+1.
    }
    
    return(psih)

}



dpsifunc <- function(zeta,phi) {

    if (abs(zeta) < small) {
       dpsifunc <- (1.-phi)/small*sign(zeta)
    } else {
       dpsifunc <- (1.-phi)/zeta
    }

    return(dpsifunc)

}

wstarfunc <- function(hpbl,thll,thflux) {

   wstar <- (grav*hpbl*thflux/thll)**.33333

   return(wstar)

}


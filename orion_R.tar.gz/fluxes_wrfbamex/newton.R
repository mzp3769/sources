source("similfunc.R")

func  <- function(ustar) {
 
      A <- karman*grav/thvll*thvflux

      if (thvflux > 0.) {
          u <- sqrt(uo^2+wstarfunc(hpbl,thvll,thvflux)^2)
      } else {
          u <- uo
      }

      f <- ustar*log(zwind/zo) - ustar*psimfunc(-zwind*A/ustar^3)-karman*u

#      print(u)
      
      return(f)
}

dfunc <- function(ustar) {

      A <- karman*grav/thvll*thvflux

      if (thvflux > 0.) {
          u <- sqrt(uo^2+wstarfunc(hpbl,thvll,thvflux)^2)
      } else {
          u <- uo
      }

      df <- log(zwind/zo)+3.*(1.-phimfunc(-zwind*A/ustar^3))-
               psimfunc(-zwind*A/ustar^3)

      return(df)
}

newtonfunc <- function(x1,x2,xacc){

      maxit <- 20

      fl <- func(x1)
      fh <- func(x2)
#	print(fl)
#        print(fh)
#      print(u)

      if ( ((fl > 0.) && (fh > 0.)) || ((fl < 0.) && (fh < 0.)) ) {
#         stop("root not bracketed")
         rtsafe <- NA
         return(rtsafe)
      }

      if (fl == 0.) {
	rtsafe <- x1
        return(rtsafe)
      } 
      if (fh == 0.){
        rtsafe <- x2
        return(rtsafe)
      }

      if (fl < 0.) {
        xl <- x1
        xh <- x2
      } else {
        xh <- x1
        xl <- x2
      }

      rtsafe <- .5*(x1+x2)
      dxold <- abs(x2-x1)
      dx <- dxold

      f <- func(rtsafe)
      df <- dfunc(rtsafe)

      for (j in (1:maxit)) {
        if(((rtsafe-xh)*df-f)*((rtsafe-xl)*df-f) < 0. ||
	   abs(2.*f) > abs(dxold*df) ) {
          dxold <- dx
          dx <- 0.5*(xh-xl)
          rtsafe <- xl+dx
          if (xl == rtsafe) {
            return(rtsafe) 
          }
        } else {
          dxold <- dx
          dx <- f/df
          temp <- rtsafe
          rtsafe <- rtsafe-dx
          if (temp == rtsafe) {
	    return(rtsafe)
          }
        }
        if (abs(dx) < xacc) {
	   return(rtsafe)
        }

        f <- func(rtsafe)
        df <- dfunc(rtsafe)
        if (f < 0.) {
          xl <- rtsafe
        } else {
          xh <- rtsafe
        }
      }
      stop("rtsafe exceeding maximum iterations")
      return(rtsafe)
}

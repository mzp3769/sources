library("fields")
#fname <- "dust_mask_20160413.txt"
#fname <- "dust_mask_20140328.txt"
fname <- "smoke_mask_20160706.txt"
#fname <- "dust_mask_20160701.txt"
infile <- file(fname,"ra")
a <- readLines(infile)       
close(infile)
nvals <- length(a)

infile <- file(fname,"ra")

latlonmask <- array(NA,c(nvals,4))

for (k in 1:nvals) {
    	latlonmask[k,] <- scan(infile,what=0,n=4,quiet=TRUE)
}

close(infile)

png("mask_quilt.png",width = 575, height = 500,bg="white")
quilt.plot(latlonmask[,2],latlonmask[,1],latlonmask[,4],nrow=300,ncol=300)
dev.off()

#png("mask_image.png",width = 575, height = 500,bg="white")
#image.plot(latlonmask[,2],latlonmask[,1],latlonmask[,3],nrow=200,ncol=200)
#dev.off()

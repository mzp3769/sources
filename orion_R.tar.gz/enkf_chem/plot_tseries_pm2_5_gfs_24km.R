tests <- c("test_806","test_807","test_808","test_809")
tests <- c("test_810","test_811","test_812","test_813","test_814","test_815")

tests <- c("test_812","test_815")

tests <- c("test_816","test_817","test_818")

tests <- c("test_806","test_812") #aq_assim=0 vs. 1
tests <- c("test_812","test_817") #aero_ratios=0 vs. 1
tests <- c("test_817","test_816") #aod_nnr=0 vs. 1
tests <- c("test_816","test_818") #aero_feeback=0 vs. 1

tests <- c("test_817","test_816","test_819","test_820","test_822","test_823")

tests <- c("test_806","test_820","test_823","test_824")

tests <- c("test_806","test_812") #aq_assim=0 vs. 1
tests <- c("test_812","test_817") #aero_ratios=0 vs. 1
tests <- c("test_817","test_816") #aod_nnr=0 vs. 1

tests <- c("test_809","test_816","test_817","test_825","test_826")
tests <- c("test_901","test_902","test_904","test_905","test_909","test_101","test_102")

tests <- c("test_101","test_102","test_105","test_106")
#tests <- c("test_103","test_104")

colnumber <- 5

#danames <- c("NoDA","ENKF")#,"EnKF_TOT","EnKF_SPEC","EnKF_TOT_loc")
#danames <- c("NoDA","SFC+AOD","SFC")
#danames <- c("NoDA","SFC","SFC+AOD","AOD_EC","AOD_NASA")
#danames <- c("EnKF","EnKF_emiss")
danames <- tests


ntests <- length(tests)

tcolors <- c("violet","green","blue","red","orange","black","purple","paleturquoise","peachpuff","salmon")

tcolors <- c("blue","red","violet","green","orange","black","purple","paleturquoise","peachpuff","salmon")

tcolors <- rainbow(ntests+1,start=0.,end=1.)


#tcolors <- c("blue","red")
#danames <- c("NoDA","GSI")

Sys.setenv(TZ="UTC")

names <- c("BIAS","PRMSE","CORR","RMSE","STDEVO","STDEVF","AVEO","AVEF") 
#          (  3,    4,      5       6         7      8      9      10)
#for older runs RMSE not present



cycle_freq <- 6
ncycles <- 24/cycle_freq

year_start <- "2012"
month_start <- "05"
day_start <- "30"
hour_start <- "18"
minute_start <- "30"
secont_start <- "00"

days2skip <- 5

plotdates <- c("2012/06/01","2012/07/01","2012/08/01","2012/09/01")
#plotdates <- c("2012/06/01","2012/06/10","2012/06/21","2012/06/30")
plottimes <- c("00:30:00","06:30:00","12:30:00","18:30:00")
assimtimes <- c("00:00:00","06:00:00","12:00:00","18:00:00")

#eliminate erroneous observations from calculating statistics
#max values for "BIAS","PRMSE","CORR"
allstats_max <- c(-20.,20.,1.,50,50,100,100)

#name <- names[colnumber]
#ylabstring <- as.character(expression(name," [",mu,"g"," ", m^{-3},"]",sep=""))
#ylabstring <- expression(paste("[",mu,"g","  ",m^{-3},"]",sep=""))


outdir <- "./pics/"
indir <- "./indata/"       

varname <- "PM2_5_DRY"


#plot time series for da verification for calnex

#WRITE(outunit,'(f7.2,i10,7e15.7)')date,nobsvalid_s,&
#                &bias_s,patrmse_s,corr_s,stdevobs_s,stdevfcst_s,&
#                   3      4        5
#                &obsave_s,fcstave_s

ntimes <- NULL
nmaxtimes <- 1e4

allstats <- array(NA,c(ntests,nmaxtimes))
alltimes <- array(NA,c(ntests,nmaxtimes))

k <- 1

for (test in tests) {
    fname <-  paste(indir,test,'/stats_',varname,'.txt',sep="")
    infile <- file(fname,"ra")
    vartable <- try(
    read.table(infile,header=FALSE,skip=0),silent=TRUE)
    if (class(vartable)=="try-error") {
#    print(c("FILE EMPTY",infile))
    close(infile)
    next }
    ntimes <- c(ntimes,length(vartable[,1]))
    if (ntimes[k] > nmaxtimes) {
    print("CRY FOUL: INCREASE nmaxtimes")
    stop(paste("nmaxtimes = ",as.character(nmaxtimes)," ntimes[",
    as.character(k),"] =",as.character(ntimes[k])))
    }
    
    newvar <- sapply(vartable[,colnumber],FUN=function(x) ifelse(x!=0,x,NA))
    allstats[k,1:ntimes[k]] <- as.array(newvar)
    alltimes[k,1:ntimes[k]] <- as.array(vartable[,1])
    close(infile)
    k <- k+1
}

maxtimelength <- max(ntimes)

yyyymmdd_start <- paste(year_start,month_start,day_start,sep="-")

time_start <- paste(hour_start,minute_start,secont_start,sep=":")

if (as.POSIXlt(paste(yyyymmdd_start,time_start),"UTC") != 
    as.POSIXlt(paste(yyyymmdd_start),"UTC")+alltimes[1,1]*3600) {
print("Times not matching")
stop ("Times not matching")
}

date_start <- as.POSIXlt(paste(yyyymmdd_start,time_start),"UTC")

day_start <- as.POSIXlt(paste(yyyymmdd_start),"UTC")

alldates <- day_start+alltimes[1,1:maxtimelength]*3600

date_skip <- date_start+days2skip*3600*24+(24.5-alltimes[1,1])*3600

cycle_times <- seq(date_skip,by=cycle_freq*3600,length=ncycles)

skipindex <- which (date_skip==alldates)
iskipindex <- skipindex[length(skipindex)]

iskip <- iskipindex

newtime <- format(date_skip,"%T")
newdate <- alldates[iskipindex]

i <- 1

while ( newtime < format(alldates[iskipindex+i],"%T") ) {
      newtime <- format(alldates[iskipindex+i],"%T")
      i <- i+1
}
     
if (i == 24 ) {
   fcst_length <- 6
} else {
   fcst_length <- i
}

dateseries <- split(alldates,rep(1:ncycles,each=fcst_length))

allstatseries <- NULL

for (k in 1:ntests) {
    statseries <- split(allstats[k,1:ntimes[k]],
    rep(1:ncycles,each=fcst_length))
    allstatseries <- c(allstatseries,statseries)
}

pngname <- paste(outdir,varname,'_24km_',names[colnumber-2],'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- expression("Time")
ylabstring <- names[colnumber-2]

xmin <- min(alldates)
xmax <- max(alldates)

ymin <- min(allstats,na.rm=TRUE)
ymax <- max(allstats,na.rm=TRUE)

k <- 1

plot(alldates[1:maxtimelength],allstats[1,1:maxtimelength],
ylim=c(ymin,ymax),col=tcolors[k],
xlab='',ylab=ylabstring,xaxt='n',yaxs="i",xaxs="i",
cex.axis=1.,cex.lab=1.,type="n",lwd=2,cex=1.)
#axis.POSIXct(1,alldates,format="%D",at=plotdates)
axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
zero <- array(0,max(ntimes))
lines(alldates[1:ntimes[k]],zero,col="black",lwd=1)

for (k in 1:ntests) {
for (j in 1:ncycles) {
for (i in seq(1,length(dateseries[[j]]),by=fcst_length)) {
ind <- (k-1)*ncycles+j
lines(dateseries[[j]][i:(i+fcst_length-1)],
      allstatseries[[ind]][i:(i+fcst_length-1)],col=tcolors[k],lwd=2)
}}}

dev.off()

times_ave <- NULL

for (i in 1:ncycles) {
times_ave <- c(times_ave,format(seq(cycle_times[i],by=3600,
length=fcst_length),"%T"))
}

ltimes_ave <- length(times_ave)

allstats_ave <- array(0,c(ntests,ltimes_ave))
k <- 0
for (test in tests[1:ntests]) {
    k <- k+1
    jj <- array(0,ltimes_ave)

    for (i in (iskip:ntimes[k])) {	
        if ( (! is.na(allstats[k,i])) &&
            (abs(allstats[k,i]) <
               abs(allstats_max[colnumber-2]))) {
	 ii <- i-iskip
    	 j=ii%%ltimes_ave+1
    	 jj[j] <- jj[j]+1
	 allstats_ave[k,j] <- allstats_ave[k,j] + allstats[k,i]
	}
    }
    allstats_ave[k,] <- allstats_ave[k,]/jj
}

tmpdates <- as.POSIXlt(paste(yyyymmdd_start,times_ave),"UTC")
plottimes <- as.POSIXlt(paste(yyyymmdd_start,plottimes),"UTC")
assimtimes <- as.POSIXlt(paste(yyyymmdd_start,assimtimes),"UTC")


if (fcst_length > 6) {
   tmpdates[length(tmpdates)-2] <- tmpdates[length(tmpdates)-2]+3600*24
   tmpdates[length(tmpdates)-1] <- tmpdates[length(tmpdates)-1]+3600*24
   tmpdates[length(tmpdates)] <- tmpdates[length(tmpdates)]+3600*24
}

pngname <- paste(outdir,varname,'_ave_24km_',names[colnumber-2],'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- expression("TIME [UTC]")

if (colnumber < 5 ) {
   ymin <- min(allstats_ave)-1
   ymax <- max(allstats_ave)+1
} else {
   ymin <- min(allstats_ave)
   ymax <- max(allstats_ave)
}

plot(tmpdates,allstats_ave[1,],
ylim=c(ymin,ymax),col=tcolors[1],
xlab=xlabstring,ylab=ylabstring,xaxt='n',xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="n",lwd=4,cex=1.)

plottimes <- c(plottimes,plottimes[1]+3600*24)

axis.POSIXct(1,tmpdates,format="%H:%M",at=plottimes)
zero <- array(0,ncycles*fcst_length)
lines(tmpdates,zero,col="black",lwd=2)

for (k in 1:ntests) {
for (j in 1:ncycles) {
lines(tmpdates[((j-1)*fcst_length+1):(j*fcst_length)],
allstats_ave[k,((j-1)*fcst_length+1):(j*fcst_length)],
col=tcolors[k],lwd=4)
points(tmpdates[((j-1)*fcst_length+1):(j*fcst_length)],
allstats_ave[k,((j-1)*fcst_length+1):(j*fcst_length)],
col=tcolors[k],pch=19,cex=1)
}}

assimtimes <- c(assimtimes,assimtimes[1]+3600*24)


yassim <- c(ymin,ymax)

for (i in 1:length(assimtimes)) {
        lines(c(assimtimes[i],assimtimes[i]),yassim,lwd=3)
}

if ( fcst_length > 6 ) {
   xmax <- max(plottimes)+2*3600
} else	{
   xmax <- max(plottimes)-3600
}

if (colnumber == 4 ) {
  yjust <- 0
  yloc <- ymin
} else {
  yjust <- 1
  yloc <- ymax
}

legend(x=xmax,y=yloc,xjust=1,yjust=yjust,col=tcolors[1:ntests],
lwd=3,legend=danames[1:ntests],cex=0.9)

dev.off()
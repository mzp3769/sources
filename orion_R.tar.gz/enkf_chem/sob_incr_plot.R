#to plot a profile of increment
library(ncdf)

ncname <- './indata/diff_p25_ratios_stp.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
p25_stp <- get.var.ncdf(nc,"P25")
close.ncdf(nc)

ncname <- './indata/diff_p25_ratios.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
p25_sqrt <- get.var.ncdf(nc,"P25")
close.ncdf(nc)

ncname <- './indata/diff_p25_ratios_100iter.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
p25_sqrt_100 <- get.var.ncdf(nc,"P25")
close.ncdf(nc)

lev <- 1

nx <- dim(p25_stp)[1]
ny <- dim(p25_stp)[2]

keystring <- expression(paste("[",mu,"g","  ",m^{-3},"]"))

species <- "p25"
zlims <- c(-.1,.55)
data <- p25_sqrt_100[,,lev]

xmin <- 11
xmax <- 41
ymax <- 0.55
ymin <- -0.05
picname <- paste("./pics/",species,"_gauss.tiff",sep='')
tiff(picname,width = 800, height = 500,bg="white")
plot(11:41,p25_stp[11:41,17,1],yaxs="i",xaxs="i",col='black',lwd=5,
ylim=c(ymin,ymax),type='l',xlab='gridpoints',ylab='increment')
lines(11:41,p25_sqrt[11:41,17,1],lwd=5,col='red')
lines(11:41,p25_sqrt_100[11:41,17,1],lwd=5,col='blue')
legend(x=xmax,y=ymax,xjust=1,yjust=1,col=c('black','red','blue'),
lwd=2,legend=c('default_50','sqrt_50','sqrt_100'),cex=0.9)
dev.off()

picname <- paste("./pics/",species,"_contour.tiff",sep='')
tiff(picname,width = 800, height = 500,bg="white")
#filled.contour(1:nx,1:ny,data,
filled.contour(11:41,2:32,data[11:41,2:32],
nlevels=7,
#color.palette=rainbow,
col=c("lightskyblue","limegreen","yellow","orange",
"red","purple","violet"),
zlim=zlims,
xaxs="i",yaxs="i",
key.title = title(main=keystring))
dev.off()


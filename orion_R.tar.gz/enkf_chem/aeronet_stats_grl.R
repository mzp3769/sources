#to plot modis stats for several test on single plot

tests <- c("test_809","test_818","test_824","test_825","test_826")
tests <- c("test_824","test_825")
tests <- c("test_809","test_818")
tests <- c("test_825","test_826")
tests <- c("test_824","test_825")
#tests <- c("test_901","test_902","test_903","test_904","test_907","test_910","test_911","test_912")

#tests <- c("test_821","test_809","test_818","test_825","test_826")
#danames <- c("CLEAN","MOZ","AOD_MOZ","AOD_EC","AOD_NASA")

#tests <- c("test_826","test_828")
#danames <- c("NASA_AOD","NASA_AOD_SFC")

#tests <- c("test_825","test_818")
#danames <- c("EC_AOD","EC_AOD_SFC")

tests <- c(
"test_821","test_832",
"test_809","test_829",
"test_834","test_825",
"test_835","test_826")
danames <- c(
"CLEAN","CLEAN_AOD",
"MOZART","MOZ_AOD",
"MACC","MAC_AOD",
"MERRA","MER_AOD")

indir <- './outdata/'
outdir <- './pics/aeronet/'

waves <- c("440","500","675","870","1020","1640")
nwaves <- length(waves)

ntests <- length(tests)
ncols <- ntests/2+1
nnames <- ntests/2

cols <- rainbow(ncols,start=0.,end=1.)
#cols <- c("blue","red")

for (wave in waves) {

i <- 0       

for (test in tests) {

    i <- i+1

    fname <- paste(indir,'aeronet_',wave,'_',test,'.txt',sep='')    

    if (i == 1) {
        infile <- file(fname,"ra")
	header <-  scan(infile,what='a',nlines=1,sep=' ',quiet=TRUE)
    	a <- readLines(infile)       
    	close(infile)
	nfcsts <- length(a)
	nvars <- length(header)
	allvars <- array(NA,c(ntests,nfcsts,nvars))

    }

    infile <- file(fname,"ra")
    header <-  scan(infile,what='a',nlines=1,sep=' ',quiet=TRUE)
    
    for (j in 1:nfcsts) {
        allvars[i,j,] <- scan(infile,what=1,nlines=1,n=nvars,
	quiet=TRUE,sep=',')
    }

    close(infile)

}

xmin <- min(allvars[,1,1])
xmax <- max(allvars[,nfcsts,1])

for  (k in 2:nvars) {
    
    name <- header[k]

    if (name == 'correlations') {
        ymin <- 0.
    	ymax <- 1
    } else { 
        ymin <- min(allvars[,,k],na.rm=T)
        ymax <- max(allvars[,,k],na.rm=T)
	ymax <- ymax+.125 
#	ymax <- 2.*ymax 
    }

    if (name == 'bias') {
	xpos <- xmin
	xjust <- 0
        ypos <- ymax
	yjust <- 1 #never have legend - need  yjust <- 1
    } else { 
	xpos <- xmax
	xjust <- 0
      	ypos <- ymax
	yjust <- -1
    }

    if (name == 'bias') {	
	dname <- "BIAS"
    } else if (name == 'correlations') {
	dname <- "CORRELATION"
    } else {
         dname <- name
    }    

    xlabstring <- "FORECAST HOUR"
    ylabstring <- paste(dname,wave,'nm')

    pngname <- paste(outdir,'aeronet_',wave,'_',name,'.png',sep="")

    png(pngname,width=600, height=400,bg="white")

    par(oma=c(0.0,0.5,0.0,0.0))
    par(mar=c(5.1,4.75,4.1,2.1))

    plot(allvars[1,,1],allvars[1,,k],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
	type="l",pch=20,cex=1.,
    	cex.axis=1.5,cex.lab=1.5,
    	xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",col=cols[1],
	lty=2,lwd=4)

	nnames[1] <- danames[1]

    for (j in 2:ntests) {

    icol <- as.integer((j-1)/2+1)

    if (j %% 2 == 1) {
       ltype <- 2
       nnames[icol] <- danames[j]
    } else {
       ltype <- 1
    }
        lines(allvars[1,,1],allvars[j,,k],type='l',col=cols[icol],
	lty=ltype,lwd=4)
    }

    if (wave == "440") {

    legend(x=xpos,y=ypos,xjust=xjust,yjust=yjust,col=cols,
           lwd=4,legend=nnames,cex=1)

    }

    dev.off()

}}
tests <- c("test_141","test_149","test_138","test_139")
tcolors <- c("red","green","violet","blue")
danames <- c("NoDA","GSI","EnKF_TOT","EnKF_SPEC")

names <- c("BIAS","PRMSE","CORR") # (3,4,5)
colnumber <- 3

year_start <- "2010"
month_start <- "05"
day_start <- "26"
hour_start <- "00"
minute_start <- "00"
secont_start <- "00"

days2skip <- 6

plotdates <- c("2010/06/01","2010/07/01")
plottimes <- c("00:00:00","06:00:00","12:00:00","18:00:00")
assimtimes <- plottimes


#eliminate erroneous observations from calculating statistics
#max values for "BIAS","PRMSE","CORR"
allstats_max <- c(-20.,20.,1.)

#name <- names[colnumber]
#ylabstring <- as.character(expression(name," [",mu,"g"," ", m^{-3},"]",sep=""))
#ylabstring <- expression(paste("[",mu,"g","  ",m^{-3},"]",sep=""))

ntests <- length(tests)

outdir <- "./pics/"
indir <- "../indata/"       

varname <- "PM2_5_DRY"

yyyymmdd_start <- paste(year_start,month_start,day_start,
sep="-")

time_start <- paste(hour_start,minute_start,secont_start,
sep=":")

date_start <- as.POSIXlt(paste(yyyymmdd_start,time_start),"UTC")

date_skip <- date_start+days2skip*3600*24

times_ave <-  format(seq(date_start,by=6*3600,length=4),"%T")

#plot time series for da verification for calnex

#WRITE(outunit,'(f7.2,i10,7e15.7)')date,nobsvalid_s,&
#                &bias_s,patrmse_s,corr_s,stdevobs_s,stdevfcst_s,&
#                   3      4        5
#                &obsave_s,fcstave_s

ntimes <- NULL
nmaxtimes <- 1e4

allstats <- array(NA,c(ntests,nmaxtimes))

k <- 1

for (test in tests) {
    fname <-  paste(indir,test,'/stats_anal_',varname,'.txt',sep="")
    infile <- file(fname,"ra")
    vartable <- try(
    read.table(infile,header=FALSE,skip=0),silent=TRUE)
    if (class(vartable)=="try-error") {
#    print(c("FILE EMPTY",infile))
    close(infile)
    next }
    ntimes <- c(ntimes,length(vartable[,1]))
    if (ntimes[k] > nmaxtimes) {
    print("CRY FOUL: INCREASE nmaxtimes")
    stop(paste("nmaxtimes = ",as.character(nmaxtimes),
    " ntimes[",
    as.character(k),"] =",as.character(ntimes[k])))
    }
    allstats[k,1:ntimes[k]] <- as.array(vartable[,colnumber])
    close(infile)
    k <- k+1
}

alldates <- seq(date_start,by=6*3600,length=max(ntimes))

allstats_ave <- array(0,c(ntests,4))

k <- 1

for (test in tests[1:ntests]) {

    jj <- array(0,4)

    for (i in (1:ntimes[k])) {	

        if ( (! is.nan(allstats[k,i])) && 
       	    (alldates[i] > date_skip ) &&
            (abs(allstats[k,i]) < 
	       abs(allstats_max[colnumber-2])) ) {
    	 j=(i-1)%%4+1
    	 jj[j] <- jj[j]+1
	 allstats_ave[k,j] <- allstats_ave[k,j] + allstats[k,i]
	}
    }

    allstats_ave[k,] <- allstats_ave[k,]/jj

    k <- k+1

}

#plot average stats

pdfname <- 
paste(outdir,varname,'_',names[colnumber-2],'_anal_barplot.pdf',sep="")
pdf(pdfname,height=5.5,width=7,bg="white")

xmin <- min(as.POSIXlt(paste(yyyymmdd_start,times_ave),"UTC"))
xmax <- max(as.POSIXlt(paste(yyyymmdd_start,times_ave),"UTC"))

if (colnumber == 3 ) {
ymin <- min(allstats_ave)
ymax <- max(allstats_ave)
yloc <- ymin
yjust <- 0
ylabstring <- expression(paste("BIAS [",mu,"g","  ",m^{-3},"]"))
}


if (colnumber == 4) {
ymin <- 0
ymax <- max(allstats_ave)+1
ylabstring <- expression(paste("PRMSE [",mu,"g","  ",m^{-3},"]"))
}

if (colnumber == 5) {
ymin <- 0.
ymax <- 0.8
ylabstring <- "CORR"
}


tmpdates <- as.POSIXlt(paste(yyyymmdd_start,times_ave),"UTC")

plottimes <- as.POSIXlt(paste(yyyymmdd_start,plottimes),"UTC")

assimtimes <- as.POSIXlt(paste(yyyymmdd_start,assimtimes),"UTC")


if (colnumber == 3) {
barplot(allstats_ave,beside=TRUE,col=tcolors,
names.arg=format(tmpdates,"%H UTC"),ylab=ylabstring,ylim=c(ymin,ymax),
legend.text=danames)#,args.legend=)
} else {
barplot(allstats_ave,beside=TRUE,col=tcolors,
names.arg=format(tmpdates,"%H UTC"),ylab=ylabstring,ylim=c(ymin,ymax))
}
dev.off()
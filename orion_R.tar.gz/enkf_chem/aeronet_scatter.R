#to plot scatters for aeronet with different colors for forecasts  
#on the same figure

test <- "test_832"
indir <- paste('./indata/',test,'/aeronet',sep='')
outdir <- './pics/aeronet/'

picratio <- 1.07

fcsts <- as.character(seq(from=0,to=9,by=1))
nfcsts <- length(fcsts)

year <- "2012"
months <- c("06","07","08")
nmonths <- length(months)

nvals <-  array(0,nmonths)
ncolumns <- 3
aods <- c(1640,1020,870,675,500,440,340)
naods <- length(aods)

#340 for model is not calculated
l_340 <- 7

cols <-  rainbow(nfcsts+2,start=0.,end=1.)

devcur <- array(NA,naods)

naods <- length(aods)

correls <-  array(NA,c(naods,nfcsts)) 
ndatas <- array(NA,c(naods,nfcsts))
bias <- array(NA,c(naods,nfcsts))

xmax <- array(NA,naods)
xm <- 0

n <- 0	

for (fcst in fcsts) {

    fnames <- paste(indir,'/fcst_',year,months,'_',fcst,'.txt',sep='')

    i <- 0

    for (fname in fnames) {
        infile <- file(fname,"ra")
    	a <- readLines(infile)       
    	close(infile)
    	i <- i+1
    	nvals[i] <- (length(a)-1)/4
    }

    allnvals <- sum(nvals)

    vars <- array(NA,c(allnvals,2,naods))
    site <- array(NA,allnvals)
    coords <- array(NA,c(allnvals,3))

    j <- 0
    i <- 0

    for (fname in fnames) {
    infile <- file(fname,"ra")
    date <-  scan(infile,what='a',nlines=1,quiet=TRUE)
    print(date)

    i <- i+1

    for (k in 1:nvals[i]) {
    	j <- j+1
    	site[j] <- scan(infile,what='a',nlines=1,quiet=TRUE)
	coords[j,] <- array(scan(infile,what=0,n=ncolumns,nlines=1,
	       quiet=TRUE))
        vars[j,1,] <- array(scan(infile,what=0,n=naods,nlines=1,
	       quiet=TRUE))
 	vars[j,2,] <- array(scan(infile,what=0,n=naods,nlines=1,
	       quiet=TRUE))
    }

    close(infile)

    }

    l <- 1

    while (l < l_340) {

	if (n == 0) {

	   xmin <- 0
    	   xmax[l] <- max(vars[,,l])
#    xmax <- 1.5
           xlabstring <- paste("obs_",aods[l],sep='')
    	   ylabstring <-  paste("model_",aods[l],sep='')	


	   pngname <- paste(outdir,'allfcst_',aods[l],'_',test,
	   '.png',sep="")

	   png(pngname,width=600, height=600*picratio,bg="white")

	   plot(vars[,2,l],vars[,1,l],xlim=c(xmin,xmax[l]),
	   ylim=c(xmin,xmax[l]),
	   type="p",pch=20,cex=.5,
    	   cex.axis=1.,cex.lab=1.,col=cols[n],
    	   xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

	   devcur[l] <- dev.cur()

	   } else {
	   dev.set(devcur[l])
	   points(vars[,2,l],vars[,1,l],col=cols[n],pch=20,cex=.5)
	   }

	if (n == (nfcsts-1)) { 

	   x <- seq(0,xmax[l],by=xmax[l]/10)
	   lines(x,x,type='l',col='black',lwd=2)
	   legend(x=xmax[l],y=xmax[l],xjust=1,yjust=1,col=cols,
	   lwd=4,legend=paste(fcsts,"hr"),cex=1)
	   dev.off()
	}

	newvar <- apply(vars[,,l],1:2,FUN=function(x) ifelse(x >= 0,x,NA))

    	correls[l,(n+1)] <-  cor(newvar[,1],newvar[,2],
    	use='pairwise.complete.obs')
    	ndatas[l,(n+1)] <- sum(!is.na(newvar[,2]))
    	bias[l,(n+1)] <- mean(newvar[,1]-newvar[,2],na.rm=TRUE)

    	l <- l+1

    }

    l <- l_340

    newvar <- apply(vars[,,l],1:2,FUN=function(x) ifelse(x >= 0,x,NA))
    ndatas[l,(n+1)] <- sum(!is.na(newvar[,2]))

    n <- n+1 

}

cols <-  rainbow(naods,start=0.,end=1.)   

xmax <- max(as.numeric(fcsts))
xmin <- min(as.numeric(fcsts))
ymin <- 0
ymax <- 1

pngname <- paste(outdir,'correl_',test,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- 'Forecast hour'
ylabstring <- 'Correlation'

l <- 1

plot(as.numeric(fcsts),correls[l,],xlim=c(0,nfcsts-1),ylim=c(0,1),
type="l",lwd=4,
cex.axis=1.,cex.lab=1.,col=cols[l],
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

l <- 2

while (l < l_340) {
    lines(as.numeric(fcsts),correls[l,],col=cols[l],lwd=4)
    l <- l+1
}

legend(x=xmax,y=ymin,xjust=1,yjust=0,col=cols,
	   lwd=4,legend=paste(aods[1:(l_340-1)],"nm"),cex=1)

dev.off()


pngname <- paste(outdir,'bias_',test,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- 'Forecast hour'
ylabstring <- paste('Bias',aods[l])

xmax <- max(as.numeric(fcsts))
xmin <- min(as.numeric(fcsts))
ymin <- min(bias,na.rm=TRUE)-0.5*abs(max(bias,na.rm=TRUE))
ymax <- -ymin

pngname <- paste(outdir,'bias_',test,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- 'Forecast hour'
ylabstring <- 'Bias'

l <- 1

plot(as.numeric(fcsts),bias[l,],xlim=c(0,nfcsts-1),ylim=c(ymin,ymax),
type="l",lwd=4,
cex.axis=1.,cex.lab=1.,col=cols[l],
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

l <- 2

while (l < l_340) {
    lines(as.numeric(fcsts),bias[l,],col=cols[l],lwd=4)
    l <- l+1
}

legend(x=xmax,y=ymax,xjust=1,yjust=1,col=cols,
	   lwd=4,legend=paste(aods[1:(l_340-1)],"nm"),cex=1)

dev.off()

xmax <- max(as.numeric(fcsts))
xmin <- min(as.numeric(fcsts))
ymin <- 0
ymax <- max(ndatas)+100

pngname <- paste(outdir,'ndatas_',test,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- 'Forecast hour'
ylabstring <- 'Numer of observations'

l <- 1

plot(as.numeric(fcsts),ndatas[l,],xlim=c(0,nfcsts-1),ylim=c(ymin,ymax),
type="l",lwd=4,
cex.axis=1.,cex.lab=1.,col=cols[l],
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

l <- 2

while (l <= l_340) {
    lines(as.numeric(fcsts),ndatas[l,],col=cols[l],lwd=4)
    l <- l+1
}

legend(x=xmax,y=ymax,xjust=1,yjust=1,col=cols,
	   lwd=4,legend=paste(aods,"nm"),cex=1)

dev.off()

for (l in 1:naods ) {

    outfile <- paste('./outdata/aeronet_',aods[l],'_',test,'.txt',sep='')

    system(paste('rm -f',outfile))

    write('fcst_hour ndatas bias correlations',
    file=outfile,append=TRUE,sep='   ')

    i <- 0
    for (fcst in fcsts) {
        i <- i+1
	write(c(i-1,ndatas[l,i],bias[l,i],correls[l,i]),
        file=outfile,append=TRUE,sep=',   ',ncolumns=4)
    }
}



library(ncdf)


varname <- "RT_TENDF_STOCH"

ncname <- "./indata/rt_tend.nc"
nc <- open.ncdf(ncname, readunlim=FALSE )
x <- get.var.ncdf(nc,"west_east")
y <- get.var.ncdf(nc,"south_north")
z <- get.var.ncdf(nc,"bottom_top")
nx <- length(x)
ny <- length(y)
nz <- length(z)

varin <- get.var.ncdf(nc,varname)

close.ncdf(nc)

png("./pics/sppt.png",width=800, height=500.,bg="white")

filled.contour(x,y,varin[,,1],
xaxs = "i", yaxs = "i",nlevels=20,color.palette=rainbow)

graphics.off()

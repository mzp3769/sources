library(ncdf)
library(spatial)
#library(nlme)
#require(stats)

missing <- 1.e+30

varnames <- c("E_PM25J") #,"E_ECJ","E_ORGJ","E_SO4J","E_NO3J")
nvars <- length(varnames)

scalenames <- paste("L_",varnames,sep='')

ncname <- "./indata/wrfchemi_00z_d01"
nc <- open.ncdf(ncname, readunlim=FALSE, write=TRUE )

xdim <- nc$dim[["west_east"]]
ydim <- nc$dim[["south_north"]]
zdim <- nc$dim[["emissions_zdim"]]
tdim <- nc$dim[["Time"]]

nx <- xdim$len 
ny <- ydim$len
nz <- zdim$len
nt <- tdim$len

varins <- array(NA,c(nvars,nx,ny,nz,nt))

for (ivar in 1:nvars) {

    varins[ivar,,,,] <- get.var.ncdf(nc,varnames[ivar])

    scales <- array(10,c(nx,ny))

    lscalevar <- var.def.ncdf(scalenames[ivar], 'gpoints', 
    list(xdim,ydim,tdim), missing )

    nc <- var.add.ncdf( nc, lscalevar )

#for( i in 1:nt)
#    put.var.ncdf(nc,scalenames[ivar],scales,verbose=TRUE )
#    put.var.ncdf(nc,31,scales,verbose=TRUE )

}

#close.ncdf(nc)

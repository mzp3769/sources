#to plot obs data on irregular grid with quilt

library(akima)	  

indir <- './indata/PM2_5_DRY_obs'
outdir <- './outdata'

fname <- paste(indir,'/','PM2_5_DRY_obs_2012062900_2012063000.txt',
       sep='')

infile <- file(fname,"ra")
a <- readLines(infile)       

close(infile)

nrows <- length(a)
ncols <- 5

var <-array(0,c(nrows,ncols))

infile <- file(fname,"ra")
for (i in 1:nrows) {
        var[i,] <- array(scan(infile,what=0,n=ncols,sep=','))
}
close(infile)

nints <- 50

xseq <- seq(min(var[,2]),max(var[,2]),length=nints)
yseq <- seq(min(var[,3]),max(var[,3]),length=nints)

fld <- interp(var[,2],var[,3],var[,5],duplicate="mean",
	       xo=xseq,yo=yseq,linear=TRUE)

filled.contour(fld,)

#grid <- expand.grid(xseq,yseq)#

x <- var[,2]
y <- var[,3]
z <- var[,5]

#znew <- loess(z~x*y)

#z.fit <- predict(znew, grid)

#library(spam)
#library(maps)
#library(fields)

#quilt.plot(y,x,z)

#grid.l <- list(abcissa=xseq,ordinate=yseq)

#xg <- make.surface.grid( grid.l)

#fit <- Krig(ozone$x, ozone$y, theta=20)

outfile <- paste(outdir,'/','test.txt',sep='')


system(paste('rm -f',outfile))
for (i in 1:nints) {
    for (j in 1:nints) {
    	write(c(fld$x[i],fld$y[j],fld$z[i,j]),file=outfile,ncolumns=3,
	append=TRUE,sep=',   ')
}}

#filled.contour(fld$x,fld$y,fld$z)
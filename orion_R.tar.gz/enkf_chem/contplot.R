#to plot a profile of increment
test <- 'test_137'

library(ncdf)

ncname <- paste('../indata/',test,'/pm25_ph_phb.nc',sep='')
nc <- open.ncdf(ncname, readunlim=FALSE )
pm25 <- get.var.ncdf(nc,"PM2_5_DRY")
phb <- get.var.ncdf(nc,"PHB")
ph <- get.var.ncdf(nc,"PH")
close.ncdf(nc)

lev <- 23

nx <- dim(ph)[1]
ny <- dim(ph)[2]

picname <- paste("./pics/pm25_contour_",test,".tiff",sep='')
tiff(picname,width = 800, height = 500,bg="white")
filled.contour(1:nx,1:ny,pm25[,,lev],
nlevels=6,col=c("lightskyblue","limegreen","yellow",
"orange","red","purple","violet"),zlim=c(0,50),
xaxs="i",yaxs="i",
key.title = title(main=keystring))
dev.off()

picname <- paste("./pics/ph_contour_",test,".tiff",sep='')
tiff(picname,width = 800, height = 500,bg="white")
filled.contour(1:nx,1:ny,(ph[,,lev]),
nlevels=20,color.palette=topo.colors,
#nlevels=20,col=topo.colors(20),
#nlevels=6,col=c("lightskyblue","limegreen","yellow",
#"orange","red","purple","violet"),
xaxs="i",yaxs="i",
key.title = title(main='m'))
dev.off()


#to plot two pm25 profiles
library(ncdf)

ncname <- '../indata/test_137/prof.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
pm25_1 <- get.var.ncdf(nc,"PM2_5_DRY")
pb <- get.var.ncdf(nc,"PB")
pp <- get.var.ncdf(nc,"P")
close.ncdf(nc)

ncname <- '../indata/test_208/prof.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
pm25_2 <- get.var.ncdf(nc,"PM2_5_DRY")
close.ncdf(nc)

top <- 40
levels <- 1:top

pprof <- -log((pp+pb)/(pp[1]+pb[1]))



enkfprof1 <- pm25_1
enkfprof2 <- pm25_2

ymin <- min(pprof[1:top])
ymax <- 1. #max(pprof[1:top])
xmin <- min(enkfprof1,enkfprof2)
xmax <- max(enkfprof1,enkfprof2)+0.1*max(enkfprof1,enkfprof2)


xlabstring <- expression(
paste("PM2.5 ","[",mu,"g","  ",m^{-3},"]",sep=""))
ylabstring <- expression(paste(-log,"(p/",p[s],")"))

pdf("./pics/profiles.pdf",width = 3.5, height = 7,
bg="white")
plot(enkfprof1[1:top],pprof[1:top],type="l",col="violet",lwd=3,
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
xlim=c(xmin,xmax),ylim=c(ymin,ymax))
lines(enkfprof2[1:top],pprof[1:top],col="orange",lwd=3)
legend(x=xmax,y=ymax,xjust=1,yjust=1,
col=c("violet","orange"),legend=c("No_Met","Met"),
lwd=3,cex=0.9)

dev.off()



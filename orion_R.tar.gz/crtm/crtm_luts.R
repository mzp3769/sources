#to build a table for extiction coeff and SSA for CRTM table
library("ncdf4")
#library("fields")
library("akima")

#log_radius = 1 for NASA else for CRTM

log_radius <- 2

if (log_radius == 1) {
#NASA
   r_dust <- c(0.6359,1.3244,2.3012,4.1672,7.6707)
   r_seas <- c(0.0784,0.2656,1.0721,2.5515,7.3395)
   r_oc <- c(0.0876,0.0876)
   r_bc <- c(0.0392,0.0392)
   r_sulf <- c(0.1566,0.1566)
#just one radius for sulfate (second radius in NASA is volcanic)
   label <- "NASA"
} else {
#CRTM
   r_dust <- c(0.5500,1.4000,2.4000,4.5000,8.0000) 
#largest radius in the CRTM file is 7.9887
   r_dust <- c(0.5500,1.4000,2.4000,4.5000,7.9887) 
   r_seas <- c(0.3001,0.3001,1.0001,3.2500,7.4951)
   r_oc <- c(0.0872,0.0872)
   r_bc <- c(0.0355,0.0355)
   r_sulf <- c(0.2424,0.2424)
   label <- "CRTM"
}

indir <- "indata"
outdir <- "outdata"

crtm_luts_infile <- paste(indir,"/","AerosolCoeff.nc4",sep="")

nc <- nc_open(crtm_luts_infile,readunlim=FALSE,write=FALSE)
n_wavelengths <-  nc$dim[["n_Wavelengths"]]$len
n_radii <- nc$dim[["n_Radii"]]$len
n_types <- nc$dim[["n_Types"]]$len
n_rh <- nc$dim[["n_RH"]]$len
n_legendre_terms <- nc$dim[["n_Legendre_Terms"]]$len
n_phase_elements <- nc$dim[["n_Phase_Elements"]]$len
n_tnsl <-  nc$dim[["tnsl"]]$len
aerosol_type_name <- ncvar_get(varid="Aerosol_Type_Name",nc)
wavelengths <- ncvar_get(varid="Wavelength",nc)
reff <- ncvar_get(varid="Reff",nc)
rh <- ncvar_get(varid="RH",nc)
ke <-  ncvar_get(varid="ke",nc)
w <- ncvar_get(varid="w",nc)
g <- ncvar_get(varid="g",nc)
pcoeff <- ncvar_get(varid="pcoeff",nc)
nc_close(nc)

#correct rh[1] = NA
rh[1] <- 0

missval <- 1.e+30

#add/subtract offset to avoid warning from Chem_MieTableRead in polint
wave_aeronet <- c(340-0.0001,380,440,500,675,870,1020,1640+0.0001)*1e-9
n_aeronet <- length(wave_aeronet)

nasa_species <- c("DU","SS","OC","BC","SU")

outfiles <- c(paste(outdir,"/","optics_",nasa_species,"_",label,
		        ".nc",sep=""))

idust_crtm <- 1
iseas1_crtm <- 2
iseas2_crtm <- 3
iseas3_crtm <- 4
iseas4_crtm <- 5
ioc_crtm <- 6
ibc_crtm <- 7
isulf_crtm <- 8 

idust_nasa <- 1
iseas_nasa <- 2
ioc_nasa <- 3
ibc_nasa <- 4
isulf_nasa <- 5

lambda_dim <- ncdim_def("lambda","",1:n_aeronet,create_dimvar=FALSE)
rh_dim <- ncdim_def("rh","",1:n_rh,create_dimvar=FALSE)

lambda_out <- ncvar_def("lambda","m",list(lambda_dim),missval,
			longname="wavelength",prec="float")
lambda <- wave_aeronet

rh_out <-  ncvar_def("rh","fraction",list(rh_dim),
       	   	      longname="relative humidity",prec="float")

#dust begin

ndust <- length(r_dust)
reff_dust <- aperm(array(rep(r_dust),c(ndust,n_rh)))*1.e-6

radius_dim <- ncdim_def("radius","",1:ndust,create_dimvar=FALSE) 
radius_out <- ncvar_def("radius","m",
	              list(radius_dim),missval,
                      longname="dry particle effective radius",
		      prec="float")

reff_out <- ncvar_def("rEff","m",
	              list(rh_dim,radius_dim),missval,
                      longname="effective radius of bin",prec="float")

bext_out <- ncvar_def("bext","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass extinction efficiency",prec="float")
bsca_out <- ncvar_def("bsca","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass scattering efficiency",prec="float")

xyi <- array(NA,c(n_radii*n_wavelengths,2))

bext_vector <- array(NA,c(n_radii*n_wavelengths))
bsca_vector <- array(NA,c(n_radii*n_wavelengths))

for (l in seq(from=1, to=n_wavelengths*n_radii, by=n_radii)) {
    xyi[l:(l+n_radii-1),1] <- log(reff[,idust_crtm]*1.e-6)
    xyi[l:(l+n_radii-1),2] <- log(wavelengths[l%/%n_radii+1]*1.e-6)
    bext_vector[l:(l+n_radii-1)] <- ke[l%/%n_radii+1,1:n_radii,idust_crtm]
    bsca_vector[l:(l+n_radii-1)] <- bext_vector[l:(l+n_radii-1)]*
    				    w[l%/%n_radii+1,1:n_radii,idust_crtm]
}

xyo <- array(NA,c(ndust*n_aeronet,2))

#for dust reff_dust[1:n_rh,] = const
for (l in seq(from=1, to=n_aeronet*ndust, by=ndust)) {
    xyo[l:(l+ndust-1),1] <- log(reff_dust[1,])
    xyo[l:(l+ndust-1),2] <- log(wave_aeronet[l%/%ndust+1])
}

interp_out <- interpp(xyi[,1],xyi[,2],bext_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)

bext_tps_out <- interp_out$z

interp_out <- interpp(xyi[,1],xyi[,2],bsca_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)

bsca_tps_out <- interp_out$z

bext <- array(NA,c(n_aeronet,n_rh,ndust))
bsca <- array(NA,c(n_aeronet,n_rh,ndust))

for (i in 1:n_rh) {
    bext[,i,] <- matrix(bext_tps_out,nrow=n_aeronet,ncol=ndust,
			byrow=TRUE)
    bsca[,i,] <- matrix(bsca_tps_out,nrow=n_aeronet,ncol=ndust,
			byrow=TRUE)
}

outfile <- outfiles[idust_nasa]
mc <- nc_create(outfile,list(lambda_out,radius_out,rh_out,reff_out,
		bext_out,bsca_out))
ncvar_put(mc,lambda_out,lambda,start=1,count=n_aeronet)
ncvar_put(mc,radius_out,reff_dust[1,],start=1,count=ndust)
ncvar_put(mc,reff_out,reff_dust,start=c(1,1),count=c(n_rh,ndust))
ncvar_put(mc,rh_out,rh,start=1,count=n_rh)
ncvar_put(mc,bext_out,bext,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,ndust))
ncvar_put(mc,bsca_out,bsca,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,ndust))
nc_close(mc)

#dust end

#oc begin

noc <- length(r_oc)
reff_oc <- aperm(array(rep(r_oc),c(noc,n_rh)))*1e-6
#to account that smallest radius in NASA is greater than in CRTM
if (log_radius == 1) {
   indx <- which(reff[,ioc_crtm] < r_oc[1])
   reff_oc[indx,2] <- r_oc[1]*1.e-6
   reff_oc[(length(indx)+1):n_radii,2] <-
                     reff[(length(indx)+1):n_radii,ioc_crtm]*1e-6
} else {
   reff_oc[,2] <- reff[,ioc_crtm]*1.e-6
}

radius_dim <- ncdim_def("radius","",1:noc,create_dimvar=FALSE) 
radius_out <- ncvar_def("radius","m",
	              list(radius_dim),missval,
                      longname="dry particle effective radius",
		      prec="float")

reff_out <- ncvar_def("rEff","m",
	              list(rh_dim,radius_dim),missval,
                      longname="effective radius of bin",prec="float")

bext_out <- ncvar_def("bext","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass extinction efficiency",prec="float")
bsca_out <- ncvar_def("bsca","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass scattering efficiency",prec="float")


xyi <- array(NA,c(n_radii*n_wavelengths,2))

bext_vector <- array(NA,c(n_radii*n_wavelengths))
bsca_vector <- array(NA,c(n_radii*n_wavelengths))

for (l in seq(from=1, to=n_wavelengths*n_radii, by=n_radii)) {
    xyi[l:(l+n_radii-1),1] <- log(reff[,ioc_crtm]*1.e-6)
    xyi[l:(l+n_radii-1),2] <- log(wavelengths[l%/%n_radii+1]*1.e-6)
    bext_vector[l:(l+n_radii-1)] <- ke[l%/%n_radii+1,1:n_radii,ioc_crtm]
    bsca_vector[l:(l+n_radii-1)] <- bext_vector[l:(l+n_radii-1)]*
    				    w[l%/%n_radii+1,1:n_radii,ioc_crtm]
}

xyo <- array(NA,c(n_aeronet,2))

bext <- array(NA,c(n_aeronet,n_rh,noc))
bsca <- array(NA,c(n_aeronet,n_rh,noc))

#hydrophobic

for (l in seq(from=1, to=n_aeronet)) {
    xyo[l,1] <- log(reff_oc[1,1])
    xyo[l,2] <- log(wave_aeronet[l])
}

interp_out <- interpp(xyi[,1],xyi[,2],bext_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)

bext_tps_out <- interp_out$z

interp_out <- interpp(xyi[,1],xyi[,2],bsca_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)

bsca_tps_out <- interp_out$z

for (i in 1:n_rh) {
    bext[,i,1] <- matrix(bext_tps_out,nrow=n_aeronet,ncol=1,
			byrow=TRUE)
    bsca[,i,1] <- matrix(bsca_tps_out,nrow=n_aeronet,ncol=1,
			byrow=TRUE)
}

#hydrophilic

xyo <- array(NA,c(n_rh*n_aeronet,2))

for (l in seq(from=1, to=n_aeronet*n_radii, by=n_radii)) {
    xyo[l:(l+n_radii-1),1] <- log(reff_oc[,2])
    xyo[l:(l+n_radii-1),2] <- log(wave_aeronet[l%/%n_rh+1])
}

interp_out <- interpp(xyi[,1],xyi[,2],bext_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)

bext_tps_out <- interp_out$z

interp_out <- interpp(xyi[,1],xyi[,2],bsca_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)

bsca_tps_out <- interp_out$z

bext[,,2] <- matrix(bext_tps_out,nrow=n_aeronet,ncol=n_rh,
                         byrow=TRUE)
bsca[,,2] <- matrix(bsca_tps_out,nrow=n_aeronet,ncol=n_rh,
                         byrow=TRUE)

outfile <- outfiles[ioc_nasa]
mc <- nc_create(outfile,list(lambda_out,radius_out,rh_out,reff_out,
		bext_out,bsca_out))
ncvar_put(mc,lambda_out,lambda,start=1,count=n_aeronet)
ncvar_put(mc,radius_out,reff_oc[1,],start=1,count=noc)
ncvar_put(mc,reff_out,reff_oc,start=c(1,1),count=c(n_rh,noc))
ncvar_put(mc,rh_out,rh,start=1,count=n_rh)
ncvar_put(mc,bext_out,bext,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,noc))
ncvar_put(mc,bsca_out,bsca,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,noc))
nc_close(mc)

#oc end

#bc begin

nbc <- length(r_bc)
reff_bc <- aperm(array(rep(r_bc),c(nbc,n_rh)))*1e-6
#to account that smallest radius in NASA is greater than in CRTM
if (log_radius == 1) {
   indx <- which(reff[,ibc_crtm] < r_bc[1])
   reff_bc[indx,2] <- r_bc[1]*1.e-6
   reff_bc[(length(indx)+1):n_radii,2] <-
                     reff[(length(indx)+1):n_radii,ibc_crtm]*1e-6
} else {
   reff_bc[,2] <- reff[,ibc_crtm]*1.e-6
}


radius_dim <- ncdim_def("radius","",1:nbc,create_dimvar=FALSE) 
radius_out <- ncvar_def("radius","m",
	              list(radius_dim),missval,
                      longname="dry particle effective radius",
		      prec="float")

reff_out <- ncvar_def("rEff","m",
	              list(rh_dim,radius_dim),missval,
                      longname="effective radius of bin",prec="float")

bext_out <- ncvar_def("bext","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass extinction efficiency",prec="float")
bsca_out <- ncvar_def("bsca","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass scattering efficiency",prec="float")


xyi <- array(NA,c(n_radii*n_wavelengths,2))

bext_vector <- array(NA,c(n_radii*n_wavelengths))
bsca_vector <- array(NA,c(n_radii*n_wavelengths))

for (l in seq(from=1, to=n_wavelengths*n_radii, by=n_radii)) {
    xyi[l:(l+n_radii-1),1] <- log(reff[,ibc_crtm]*1.e-6)
    xyi[l:(l+n_radii-1),2] <- log(wavelengths[l%/%n_radii+1]*1.e-6)
    bext_vector[l:(l+n_radii-1)] <- ke[l%/%n_radii+1,1:n_radii,ibc_crtm]
    bsca_vector[l:(l+n_radii-1)] <- bext_vector[l:(l+n_radii-1)]*
    				    w[l%/%n_radii+1,1:n_radii,ibc_crtm]
}

xyo <- array(NA,c(n_aeronet,2))

bext <- array(NA,c(n_aeronet,n_rh,nbc))
bsca <- array(NA,c(n_aeronet,n_rh,nbc))

#hydrophobic

for (l in seq(from=1, to=n_aeronet)) {
    xyo[l,1] <- log(reff_bc[1,1])
    xyo[l,2] <- log(wave_aeronet[l])
}

#linear
interp_out <- interpp(xyi[,1],xyi[,2],bext_vector,xyo[,1],xyo[,2],
                   linear=TRUE,extrap=FALSE)
#                   linear=FALSE,extrap=TRUE)

bext_tps_out <- interp_out$z

interp_out <- interpp(xyi[,1],xyi[,2],bsca_vector,xyo[,1],xyo[,2],
                   linear=TRUE,extrap=FALSE)
#                   linear=FALSE,extrap=TRUE)

bsca_tps_out <- interp_out$z

for (i in 1:n_rh) {
    bext[,i,1] <- matrix(bext_tps_out,nrow=n_aeronet,ncol=1,
			byrow=TRUE)
    bsca[,i,1] <- matrix(bsca_tps_out,nrow=n_aeronet,ncol=1,
			byrow=TRUE)
}

#hydrophilic

xyo <- array(NA,c(n_rh*n_aeronet,2))

for (l in seq(from=1, to=n_aeronet*n_radii, by=n_radii)) {
    xyo[l:(l+n_radii-1),1] <- log(reff_bc[,2])
    xyo[l:(l+n_radii-1),2] <- log(wave_aeronet[l%/%n_rh+1])
}

interp_out <- interpp(xyi[,1],xyi[,2],bext_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)

bext_tps_out <- interp_out$z

interp_out <- interpp(xyi[,1],xyi[,2],bsca_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)
bsca_tps_out <- interp_out$z

bext[,,2] <- matrix(bext_tps_out,nrow=n_aeronet,ncol=n_rh,
                         byrow=TRUE)
bsca[,,2] <- matrix(bsca_tps_out,nrow=n_aeronet,ncol=n_rh,
                         byrow=TRUE)

outfile <- outfiles[ibc_nasa]
mc <- nc_create(outfile,list(lambda_out,radius_out,rh_out,reff_out,
		bext_out,bsca_out))
ncvar_put(mc,lambda_out,lambda,start=1,count=n_aeronet)
ncvar_put(mc,radius_out,reff_bc[1,],start=1,count=nbc)
ncvar_put(mc,reff_out,reff_bc,start=c(1,1),count=c(n_rh,nbc))
ncvar_put(mc,rh_out,rh,start=1,count=n_rh)
ncvar_put(mc,bext_out,bext,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,nbc))
ncvar_put(mc,bsca_out,bsca,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,nbc))
nc_close(mc)

#bc end

#sulf begin
#skip first reff[1,isulf_crtm] 
#to have coverage over whole RH on output

nsulf <- length(r_sulf)
reff_sulf <- matrix(rep(c(r_sulf[1],reff[2:n_radii,isulf_crtm]),nsulf),
		    nrow=n_rh,ncol=nsulf,byrow=FALSE)*1.e-6

radius_dim <- ncdim_def("radius","",1:nsulf,create_dimvar=FALSE) 
radius_out <- ncvar_def("radius","m",
	              list(radius_dim),missval,
                      longname="dry particle effective radius",
		      prec="float")

reff_out <- ncvar_def("rEff","m",
	              list(rh_dim,radius_dim),missval,
                      longname="effective radius of bin",prec="float")

bext_out <- ncvar_def("bext","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass extinction efficiency",prec="float")
bsca_out <- ncvar_def("bsca","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass scattering efficiency",prec="float")

xyi <- array(NA,c(n_radii*n_wavelengths,2))

bext_vector <- array(NA,c(n_radii*n_wavelengths))
bsca_vector <- array(NA,c(n_radii*n_wavelengths))

for (l in seq(from=1, to=n_wavelengths*n_radii, by=n_radii)) {
    xyi[l:(l+n_radii-1),1] <- log(reff[,isulf_crtm]*1.e-6)
    xyi[l:(l+n_radii-1),2] <- log(wavelengths[l%/%n_radii+1]*1.e-6)
    bext_vector[l:(l+n_radii-1)] <- ke[l%/%n_radii+1,1:n_radii,isulf_crtm]
    bsca_vector[l:(l+n_radii-1)] <- bext_vector[l:(l+n_radii-1)]*
    				    w[l%/%n_radii+1,1:n_radii,isulf_crtm]
}

xyo <- array(NA,c(n_rh*n_aeronet,2))

bext <- array(NA,c(n_aeronet,n_rh,nsulf))
bsca <- array(NA,c(n_aeronet,n_rh,nsulf))

for (l in seq(from=1, to=n_aeronet*n_radii, by=n_radii)) {
    xyo[l:(l+n_radii-1),1] <- log(reff_sulf[,1])
    xyo[l:(l+n_radii-1),2] <- log(wave_aeronet[l%/%n_rh+1])
}

interp_out <- interpp(xyi[,1],xyi[,2],bext_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)
bext_tps_out <- interp_out$z

interp_out <- interpp(xyi[,1],xyi[,2],bsca_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)

bsca_tps_out <- interp_out$z

bext[,,1] <- matrix(bext_tps_out,nrow=n_aeronet,ncol=n_rh,
                         byrow=TRUE)
bext[,,2] <- bext[,,1]

bsca[,,1] <- matrix(bsca_tps_out,nrow=n_aeronet,ncol=n_rh,
                 byrow=TRUE)
bsca[,,2] <- bsca[,,1]

#make exception for NASA to assign bext/bsca for radii smaller than
#the smallest radius CRTM since otherwise is 
#NA (linear) or negative (splines)

if (log_radius == 1) {
   bext[,1,] <- bext[,2,]   
   bsca[,1,] <- bsca[,2,]   
}

outfile <- outfiles[isulf_nasa]
mc <- nc_create(outfile,list(lambda_out,radius_out,rh_out,reff_out,
		bext_out,bsca_out))
ncvar_put(mc,lambda_out,lambda,start=1,count=n_aeronet)
ncvar_put(mc,radius_out,reff_sulf[1,],start=1,count=nsulf)
ncvar_put(mc,reff_out,reff_sulf,start=c(1,1),count=c(n_rh,nsulf))
ncvar_put(mc,rh_out,rh,start=1,count=n_rh)
ncvar_put(mc,bext_out,bext,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,nsulf))
ncvar_put(mc,bsca_out,bsca,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,nsulf))
nc_close(mc)

#sulf end

#seas begin

nseas <- length(r_seas)
if (log_radius == 1) {
reff_seas <- matrix(c(r_seas[1],reff[2:(n_radii-1),iseas1_crtm],
	              r_seas[2],reff[2:(n_radii-1),iseas1_crtm],
		      r_seas[3],reff[2:(n_radii-1),iseas2_crtm],
		      r_seas[3],reff[2:(n_radii-1),iseas3_crtm],
		      r_seas[4],reff[2:(n_radii-1),iseas4_crtm]),
		      nrow=n_rh,ncol=nseas,byrow=FALSE)*1.e-6
} else {
reff_seas <- matrix(c(reff[,iseas1_crtm],
	              reff[,iseas1_crtm],
	              reff[,iseas2_crtm],
		      reff[,iseas3_crtm],
		      reff[,iseas4_crtm]),
		      nrow=n_rh,ncol=nseas,byrow=FALSE)*1.e-6
}
radius_dim <- ncdim_def("radius","",1:nseas,create_dimvar=FALSE) 
radius_out <- ncvar_def("radius","m",
	              list(radius_dim),missval,
                      longname="dry particle effective radius",
		      prec="float")

reff_out <- ncvar_def("rEff","m",
	              list(rh_dim,radius_dim),missval,
                      longname="effective radius of bin",prec="float")

bext_out <- ncvar_def("bext","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass extinction efficiency",prec="float")
bsca_out <- ncvar_def("bsca","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass scattering efficiency",prec="float")

iseas_crtm <- iseas1_crtm
xyi <- array(NA,c(n_radii*n_wavelengths,2))

bext_vector <- array(NA,c(n_radii*n_wavelengths))
bsca_vector <- array(NA,c(n_radii*n_wavelengths))

bext <- array(NA,c(n_aeronet,n_rh,nseas))
bsca <- array(NA,c(n_aeronet,n_rh,nseas))

i <- 1
for (iseas_crtm in c(iseas1_crtm,iseas1_crtm,iseas2_crtm,
    	             iseas3_crtm,iseas4_crtm) ) {

  for (l in seq(from=1, to=n_wavelengths*n_radii, by=n_radii)) {
    xyi[l:(l+n_radii-1),1] <- log(reff[,iseas_crtm]*1.e-6)
    xyi[l:(l+n_radii-1),2] <- log(wavelengths[l%/%n_radii+1]*1.e-6)
    bext_vector[l:(l+n_radii-1)] <- ke[l%/%n_radii+1,1:n_radii,iseas_crtm]
    bsca_vector[l:(l+n_radii-1)] <- bext_vector[l:(l+n_radii-1)]*
    				    w[l%/%n_radii+1,1:n_radii,iseas_crtm]
  }


  xyo <- array(NA,c(n_rh*n_aeronet,2))


  for (l in seq(from=1, to=n_aeronet*n_radii, by=n_radii)) {
    xyo[l:(l+n_radii-1),1] <- log(reff_seas[,i])
    xyo[l:(l+n_radii-1),2] <- log(wave_aeronet[l%/%n_rh+1])
  }


  interp_out <- interpp(xyi[,1],xyi[,2],bext_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)
  bext_tps_out <- interp_out$z


  interp_out <- interpp(xyi[,1],xyi[,2],bsca_vector,xyo[,1],xyo[,2],
                      linear=TRUE,extrap=FALSE)
#                      linear=FALSE,extrap=TRUE)

  bsca_tps_out <- interp_out$z

  bext[,,i] <- matrix(bext_tps_out,nrow=n_aeronet,ncol=n_rh,
                      byrow=TRUE)

  bsca[,,i] <- matrix(bsca_tps_out,nrow=n_aeronet,ncol=n_rh,
                      byrow=TRUE)

  i <- i+1
 
}


outfile <- outfiles[iseas_nasa]
mc <- nc_create(outfile,list(lambda_out,radius_out,rh_out,reff_out,
		bext_out,bsca_out))
ncvar_put(mc,lambda_out,lambda,start=1,count=n_aeronet)
ncvar_put(mc,radius_out,reff_seas[1,],start=1,count=nseas)
ncvar_put(mc,reff_out,reff_seas,start=c(1,1),count=c(n_rh,nseas))
ncvar_put(mc,rh_out,rh,start=1,count=n_rh)
ncvar_put(mc,bext_out,bext,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,nseas))
ncvar_put(mc,bsca_out,bsca,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,nseas))
nc_close(mc)

#seas end

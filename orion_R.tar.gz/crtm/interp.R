#to build a table for extiction coeff and SSA for CRTM table
library("ncdf4")
library("fields")
library("akima")

xyi <- array(NA,c(n_radii*n_wavelengths,2))
z <- array(NA,c(n_radii*n_wavelengths)) 


#i <- 0
#for (l in 1:n_wavelengths) {
#    for (k in 1:n_radii) {
#    	i <- i+1
#        xyi[i,1] <- log(reff[k]*1.e-6)
#	xyi[i,2] <- log(wavelengths[l]*1.e-6)
#	z[i] <- ke[l,k,idust]
#}}

for (l in seq(from=1, to=n_wavelengths*n_radii, by=n_radii)) {
    xyi[l:(l+n_radii-1),1] <- log(reff[,1]*1.e-6)
    xyi[l:(l+n_radii-1),2] <- log(wavelengths[l%/%n_radii+1]*1.e-6)
    z[l:(l+n_radii-1)] <- ke[l%/%n_radii+1,1:n_radii,idust]
}

quilt.plot(xyi[,1],xyi[,2],z)

xyo <- array(NA,c(n_dust*n_aeronet,2))

for (l in seq(from=1, to=n_aeronet*n_dust, by=n_dust)) {
    xyo[l:(l+n_dust-1),1] <- log(reff_dust)   
    xyo[l:(l+n_dust-1),2] <- log(wave_aeronet[l%/%n_dust+1])
}

results <- interpp(xyi[,1],xyi[,2],z,xyo[,1],xyo[,2],
		   linear=FALSE,extrap=TRUE)

quilt.plot(results$x,results$y,results$z,zlim=c(0,1500))


grid.l <- list(abcissa=log(reff[,idust]*1.e-6),
	       oridinate=log(wavelengths*1.e-6))

xg <- make.surface.grid(grid.l)

results_tps <- Tps(xg,c(z))
surface(results_tps)

interp_tps_l0 <- predict(results_tps_l0,xyo)
quilt.plot(xyo[,1],xyo[,2],interp_tps_l0,zlim=c(0,1500))

interp_tps <- predict(results_tps,xyo)
quilt.plot(xyo[,1],xyo[,2],interp_tps,zlim=c(0,1500))

results$z-interp_tps



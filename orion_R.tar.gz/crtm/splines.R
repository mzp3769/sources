#to build a table for extiction coeff and SSA for CRTM table
library("ncdf4")
#library("fields")
#detach(package:fields, unload=TRUE)
#library(survival)
#detach(package:survival, unload=TRUE)
library("pspline")
#detach(package:pspline, unload=TRUE)

x <- c(0.0, 0.5, 1.5, 2.0, 3, 5.0, 6.0)
y <- c(1.5, 1.7, 8.0, 0.3, 4, 7.0,-0.1)
plot(x,y)
z <- seq(0,6,by=0.05)
lines(z, predict(sm.spline(x,y,df=6.5), z), col = "red")
lines(z, predict(sm.spline(x,y,df=4.5), z), col = "red")
#xy <- cbind(x,y)
#xy <- rbind(x,y)

#out <- Tps( x, y)
lines( out$x, out$fitted.values)


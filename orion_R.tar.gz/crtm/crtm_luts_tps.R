#to build a table for extiction coeff and SSA for CRTM table
library("ncdf4")
library("fields")
#library("akima")

indir <- "indata"
outdir <- "outdata"

missval <- 1.e+30

wave_aeronet <- c(340,380,440,500,675,870,1020,1640)*1e-9
n_aeronet <- length(wave_aeronet)

idust <- 1
iseas1 <- 2
iseas2 <- 3
iseas3 <- 4
iseas4 <- 5
ioc <- 6
ibc <- 7
isulf <- 8 

crtm_luts_infile <- paste(indir,"/","AerosolCoeff.nc4",sep="")

nc <- nc_open(crtm_luts_infile,readunlim=FALSE,write=FALSE)
n_wavelengths <-  nc$dim[["n_Wavelengths"]]$len
n_radii <- nc$dim[["n_Radii"]]$len
n_types <- nc$dim[["n_Types"]]$len
n_rh <- nc$dim[["n_RH"]]$len
n_legendre_terms <- nc$dim[["n_Legendre_Terms"]]$len
n_phase_elements <- nc$dim[["n_Phase_Elements"]]$len
n_tnsl <-  nc$dim[["tnsl"]]$len
aerosol_type_name <- ncvar_get(varid="Aerosol_Type_Name",nc)
wavelengths <- ncvar_get(varid="Wavelength",nc)
reff <- ncvar_get(varid="Reff",nc)
rh <- ncvar_get(varid="RH",nc)
ke <-  ncvar_get(varid="ke",nc)
w <- ncvar_get(varid="w",nc)
g <- ncvar_get(varid="g",nc)
pcoeff <- ncvar_get(varid="pcoeff",nc)
nc_close(nc)

#correct rh[1] = NA
rh[1] <- 0

lambda_dim <-  ncdim_def("lambda","",1:n_aeronet,create_dimvar=FALSE)
rh_dim <- ncdim_def("rh","",1:n_rh,create_dimvar=FALSE)

lambda_out <- ncvar_def("lambda","m",list(lambda_dim),missval,
			longname="wavelength",prec="double")
lambda <- wave_aeronet

rh_out <-  ncvar_def("rh","fraction",list(rh_dim),
       	   	      longname="relative humidity",prec="double")

#dust
n_dust=5
reff_dust <- aperm(array(rep(c(0.55,1.4,2.4,4.5,8.0)*1.e-6),
	          c(n_dust,n_rh)))

radius_dim <-  ncdim_def("radius","",1:n_dust,create_dimvar=FALSE) 
radius_out <- ncvar_def("radius","m",
	              list(radius_dim),missval,
                      longname="dry particle effective radius",
		      prec="double")

reff_out <- ncvar_def("rEff","m",
	              list(rh_dim,radius_dim),missval,
                      longname="effective radius of bin",prec="double")

bext_out <- ncvar_def("bext","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass extinction efficiency",prec="double")
bsca_out <- ncvar_def("bsca","m2 (kg dry mass)-1",
	              list(lambda_dim,rh_dim,radius_dim),missval,
                      longname="mass scattering efficiency",prec="double")


grid.in <- list(abcissa=log(reff[,idust]*1.e-6),
	        oridinate=log(wavelengths*1.e-6))
xgin <- make.surface.grid(grid.in)

grid.out <- list(abcissa=log(reff_dust[1,]),
                 oridinate=log(wave_aeronet))
xgout <- make.surface.grid(grid.out)

bext_vector <- array(NA,c(n_radii*n_wavelengths))
bsca_vector <- array(NA,c(n_radii*n_wavelengths))

for (l in seq(from=1, to=n_wavelengths*n_radii, by=n_radii)) {
    bext_vector[l:(l+n_radii-1)] <- ke[l%/%n_radii+1,1:n_radii,idust]
    bsca_vector[l:(l+n_radii-1)] <- bext_vector[l:(l+n_radii-1)]*
    				    w[l%/%n_radii+1,1:n_radii,idust]
}

bext_tps_in <- Tps(xgin, bext_vector, lambda=0)
bext_tps_out <- predict(bext_tps_in,xgout)
bsca_tps_in <- Tps(xgin, bsca_vector, lambda=0)
bsca_tps_out <- predict(bsca_tps_in,xgout)

#to plot original values
#surface(bext_tps_in)

#to plot interpolated values
#out.p <- as.surface(xgout,tps_out)
#filled.contour(out.p)

bext <- array(NA,c(n_aeronet,n_rh,n_dust))
bsca <- array(NA,c(n_aeronet,n_rh,n_dust))

for (i in 1:n_rh) {
    bext[,i,] <- matrix(bext_tps_out,nrow=n_aeronet,ncol=n_dust,
			byrow=TRUE)
    bsca[,i,] <- matrix(bsca_tps_out,nrow=n_aeronet,ncol=n_dust,
			byrow=TRUE)
}

outfile <- paste(outdir,"/","optics_DU.crtm_v2_4.nc",sep="")
mc <- nc_create(outfile,list(lambda_out,radius_out,rh_out,reff_out,
		bext_out,bsca_out))
ncvar_put(mc,lambda_out,lambda,start=1,count=n_aeronet)
ncvar_put(mc,radius_out,reff_dust[1,],start=1,count=n_dust)
ncvar_put(mc,reff_out,reff_dust,start=c(1,1),count=c(n_rh,n_dust))
ncvar_put(mc,rh_out,rh,start=1,count=n_rh)
ncvar_put(mc,bext_out,bext,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,n_dust))
ncvar_put(mc,bsca_out,bsca,
	  start=c(1,1,1),count=c(n_aeronet,n_rh,n_dust))
nc_close(mc)


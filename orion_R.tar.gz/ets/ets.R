#ets(f,q,o) - equaitable threat score as function of forecast area,
#              q=b/a, o=(a+c)/T, T=a+b+c+d in contingency table
#              for Atmos. Environ. paper.

etsfunc <- function(f,q,o) {
  
#   ets <- (f^2-f*q/(1+q))/(o+f^2-f/(1+q))
   ets <- (f/(1+q) - f*o)/(o+f-f/(1+q)-f*o)
 
   return(ets)
}
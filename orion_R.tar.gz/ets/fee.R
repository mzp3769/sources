feefunc <- function(ets) {

   fee <- ets/(ets+1)
   return(fee)

}
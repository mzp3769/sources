#ets(f,q,r) - equaitable threat score as function of forecast area,
#              q=b/a, o=(a+c)/T, T=a+b+c+d in contingency table
#              fro Atmos. Environ. paper.

etsafunc <- function(a,q,o) {
  
   ets <- ((a*(1+q))^2-a*q)/(o+(a*(1+q))^2-a)
 
   return(ets)
}
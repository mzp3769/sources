nx <- 301
ny <- 225
x <- 1:nx
y <- 1:ny
obs <- array(0,c(nx,ny))

fobs <- file("ASCII.obs","ra")
obs <- array(scan(fobs,what=0.,n=nx*ny),c(nx,ny))
close(fobs)
#lims <- range(obs)
x11()
filled.contour(x,y,obs,zlim=range(0.,6),nlevels=10,color.palette=rainbow)



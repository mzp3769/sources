nx <- 301
ny <- 225
nens <- 1
x <- 1:nx
y <- 1:ny
ruc <- array(0,c(nx,ny,nens))

fruc <- file("smooth.txt","ra")
for (k in (1:nens)) {
ruc[,,k] <- array(scan(fruc,what=0.,n=nx*ny),c(nx,ny))
#filled.contour(x,y,ruc[,,k],nlevels=10,color.palette=rainbow)
}
close(fruc)

#x11()
filled.contour(x,y,ruc[,,1],zlim=c(0.,5.),nlevels = 10,
color.palette=rainbow)



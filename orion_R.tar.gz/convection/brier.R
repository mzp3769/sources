# to read precip anc calculate brier

nens <- 5
ndata <- nens + 1
nlines <- 5475

nthres <- 9
thres <- c(1.,5.,10.,15.,20.,25.,30,35.,40)

infile <- 'data_for_R_0726'
precip <- array(NA,c(nlines,ndata))
prob <- array(NA,c(nlines,2,nthres))

fprecip <- file(infile,"ra")
tmp <- array(0.,ndata)
for (i in 1:nlines) {
    precip[i,] <- array(scan(fprecip,what=0.,n=ndata))
    for (ithr in 1:nthres) {
	    for (j in 1:ndata) {	
        	if (precip[i,j] > thres[ithr]) {
	            tmp[j] <- 1
        	} else {
            	tmp[j] <- 0
        	}
            }
	    prob[i,1,ithr] <- tmp[1]
	    prob[i,2,ithr] <- sum(tmp[2:ndata])/nens
    }
}
close(fprecip)

source("brier.ensemble.R")

brierarray <- array(NA,c(4,nthres))

for (ithr in 1:nthres) {
    brierclass <- brier.ensemble(prob[1:nlines,1,ithr],
                                 prob[1:nlines,2,ithr],
    baseline=NULL,n.members=nens )
    brierarray[1,ithr] <- brierclass$bs
    brierarray[2,ithr] <- brierclass$bs.reliability
    brierarray[3,ithr] <- brierclass$bs.resol
    brierarray[4,ithr] <- brierclass$bs.uncert
}



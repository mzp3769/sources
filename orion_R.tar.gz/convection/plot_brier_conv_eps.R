#
postscript("brier_precip1.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

xlabstring=expression("threshold ()")
ylabstring=expression("Brier score and its components")

barplot(brierarray[,1:3],
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("1","5","10"),
ylim=c(0,.4),xlab=xlabstring,ylab=ylabstring,
legend=c("BS","REL","RES","UNC"))
axis(1,at=c(0,50))
text(2,.275,labels="a",cex=1.5,vfont=c("serif","plain"))

dev.off()

postscript("brier_precip2.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

barplot(brierarray[,1:3],
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("1","5","10"),
ylim=c(0,.4),xlab=xlabstring,ylab=ylabstring,
legend=c("BS","REL","RES","UNC"))
axis(1,at=c(0,50))
text(2,.275,labels="a",cex=1.5,vfont=c("serif","plain"))

barplot(brierarray[,4:6],
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("1","5","10"),
ylim=c(0,.4),xlab=xlabstring,ylab=ylabstring,
legend=c("BS","REL","RES","UNC"))
axis(1,at=c(0,50))
text(2,.275,labels="a",cex=1.5,vfont=c("serif","plain"))


dev.off()

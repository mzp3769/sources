#name <- "T_adv_dz_prof.ascii"
#name <- "T_adv_tot_prof.ascii"
name <- "Q_prof.ascii"
#name <-  "T_41_prof.ascii"
#x11()
#dev.set(5)
level <- 1
infile <- file(name,"ra")
header <- list(varname="A",date="A",npoints=1)
header <- scan(infile,what=header,nmax=1)
a <- readLines(infile)
ntimes <- (length(a)+1)/(header$npoints+1)
close(infile)
png("q_sfc.png",bg="lightblue")
infile <- file(name,"ra")
var <-array(0,c(2,ntimes,header$npoints))
for (i in 1:ntimes) {
    	header <- scan(infile,what=header,nmax=1) 
	var[,i,] <- array(scan(infile,what=0.,n=2*header$npoints))
}
close(infile)
par(lab=c(1,4,7),las=3)
xlabstring=expression("UTC")
ylabstring=expression("Mixing ratio (g/kg)")
#ylabstring=expression("Temperature (K)")

plot(seq(0,ntimes-1,1),var[1,,level]*1.e3,"l",axes=TRUE,
xlab=xlabstring,ylab=ylabstring,
cex.lab=1.2,cex.axis=1.2,lwd=5,col="red",xaxt="n")

val <- ntimes-1
par(las=0)
axis(1,at=c(.0,val*.25,val*.5,val*.75,,val),labels=c("0600","0700",
"0800","0900","1000"))
#axis(2)
#axis(3)
#axis(4)


#plot(seq(0,ntimes-1,1),var[1,,]
#filled.contour(seq(0,ntimes-1,1),var[2,1,],var[1,,],nlevels=20,
#color.palette=rainbow)

#col=c("blue","skyblue1","violet","yellow2"))
#color.palette=terrain.colors)
#color.palette=topo.colors)
#color.palette=cm.colors)
#col = topo.colors(20))
#color.palette=rainbow,col = rainbow(10))
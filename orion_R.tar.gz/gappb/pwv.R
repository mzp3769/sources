library(ncdf)
library(RadioSonde)
nhour <- 24

dir <- "data"
abc <- c("b") #month
cab <- c("a") #soil moisture
nums <- c(103)


prefix <- "_sim_"
suffix <- ".nc"

fieldsc <- c("T")
fieldsnc <- c("P")
fieldsncs <- c("QV")

nsims <- length(nums)
sim <- array(NA,nsims)

jj <- 0

for (fieldc in fieldsc) {

jj <- jj+1
sig <- substr(fieldc,10,10)
if (sig=='_') sig=""

for (jchar in cab) {
ii <- 0
for (ichar in abc) {
ii <- ii+1
kk <- 0
for (k in nums) {
kk <- kk+1

if (k < 110) {
year <- "_2004"
} else {
year <- "_2005"
}

sim[kk] <- paste(prefix,as.character(k),jchar,ichar,sep="")


fnamec <- paste(dir,"/",fieldc,sim[kk],year,suffix,sep="")
print(fnamec)

nc <- open.ncdf(fnamec,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nz <- v1$varsize[1]
ntimes <- v1$varsize[2]
close.ncdf(nc)
ntimes <- ((ntimes-1)%/%24)*24+1

if (kk==1) {
pwv <- array(NA,c(ntimes,length(abc),length(fieldsc),nsims))
}

if (kk==1) {
  varaveth <- array(0.,c(nz,ntimes,nsims))
  th <- varaveth
  p <- th
  td <- th
}
ndays <- (ntimes-1)/24

varaveth[,,kk] <- data1

#p
fieldnc <- fieldsnc[jj]
fnamec <- paste(dir,"/",fieldnc,sim[kk],year,suffix,sep="")
print(fnamec)

nc <- open.ncdf(fnamec,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nz <- v1$varsize[1]
ntimes <- v1$varsize[2]
close.ncdf(nc)
ntimes <- ((ntimes-1)%/%24)*24+1

if (kk==1) {
  varave <- array(0.,c(nz,ntimes,nsims))
}

ter <- data1[1,1]/9.81

varave[,,kk] <- data1

#td
fieldnc <- fieldsncs[jj]
fnamec <- paste(dir,"/",fieldnc,sim[kk],year,suffix,sep="")
print(fnamec)

nc <- open.ncdf(fnamec,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nz <- v1$varsize[1]
ntimes <- v1$varsize[2]
close.ncdf(nc)
ntimes <- ((ntimes-1)%/%24)*24+1

if (kk==1) {
  varavetd <- array(0.,c(nz,ntimes,nsims))
}

varavetd[,,kk] <- data1

th[,,kk] <- varaveth[,,kk]
p[,,kk] <- varave[,,kk]
td[,,kk] <- varavetd[,,kk]


}

td <- (243.5*log(td*p/((0.622+td)*611.2)))/
      (17.67-log(td*p/((0.622+td)*611.2)))


colors <- rainbow(1)

for (i in 1:ntimes) {

  for (kk in 1:nsims) {
     sondes <- data.frame(
                     time=array(0,nz),
                     press=p[,i,kk]*1.e-2,temp=th[,i,kk],
                     dewpt=td[,i,kk],     rhum=array(NA,nz),
                     uwind=array(NA,nz),  vwind=array(NA,nz),
                     wspd=array(NA,nz),   wdir=array(NA,nz),
                     dz=array(NA,nz),
                     lon=array(NA,nz),    lat=array(NA,nz),
                     rng=array(NA,nz),    alt=array(NA,nz),
                     qp=array(0,nz),      qt=array(0,nz),
                     qh=array(0,nz),      qu=array(0,nz),
                     qv=array(0,nz),      quv=array(0,nz))
     pwv[i,ii,jj,kk] <- PWV(sondes)
#     pwv[i,ii,jj,kk] <- min(th[,i,kk])
  }
}

}}}






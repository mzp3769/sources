library(ncdf)
dir <- "data"
abc <- c("a","b","c")
cab <- c("c","a","b")
nums <- c(102:106,112:116)

prefix <- "_sim_"
suffix <- ".nc"

fieldsc <- c("RAINC_HGTM_h","RAINC_HGTP_h","RAINC_HGT_h")
fieldsnc <- c("RAINNC_HGTM_h","RAINNC_HGTP_h","RAINNC_HGT_h")

sim <- array(length(abc)*length(cab)*length(nums))
raintott <- array(NA,c(2,length(abc),length(fieldsc),
                      length(nums),length(cab)))


nfield <- length(fieldsc)
nsim <- length(nums)
nabc <- length(abc)
ncab <- length(cab)

nmonth <- nabc
nsoil <- ncab



jj <- 0
for (fieldc in fieldsc) {
sig <- substr(fieldc,10,10)
if (sig=='_') sig=""

jj <- jj+1
fieldnc <- fieldsnc[jj]

kk <- 0
for (k in nums) {
kk <- kk+1

if (k < 110) {
year <- "_2004"
} else {
year <- "_2005"
}

jjj <- 0
for (jchar in cab) {
jjj <- jjj+1

ii <- 0
for (ichar in abc) {
ii <- ii+1
sim[ii] <- paste(prefix,as.character(k),jchar,ichar,sep="")

fnamec <- paste(dir,"/",fieldc,sim[ii],year,suffix,sep="")
print(fnamec)
fnamenc <- paste(dir,"/",fieldnc,sim[ii],year,suffix,sep="")
print(fnamenc)


# the input file is hourly the average over dimensions

nc <- open.ncdf(fnamec,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

raincave <- array(0.,c(24))
for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
raincave[j] <- data1[i]+raincave[j]
}
rm(data1)

nc <- open.ncdf(fnamenc,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

rainncave <- array(0.,c(24))
for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
rainncave[j] <- data1[i]+rainncave[j]
}
rm(data1)

raintot <- array(0.,c(2,24))
raintot[1,] <- raincave
raintot[2,] <- rainncave

raintott[1,ii,jj,kk,jjj] <- sum(raincave)
raintott[2,ii,jj,kk,jjj] <- sum(rainncave)

}}}}



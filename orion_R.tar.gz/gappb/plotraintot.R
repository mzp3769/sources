# need to execute raintot.R first


for (imonth in 1:nmonth) {
  for (ifield in 1:nfield) {
    for (isoil in 1:nsoil) {

      mpwvaa <- mean(raintott[1,imonth,ifield,1:nsim1,isoil])
      raintott[1,imonth,ifield,1:nsim1,isoil] <-
      raintott[1,imonth,ifield,1:nsim1,isoil] - mpwvaa

      mpwvaa <- mean(raintott[1,imonth,ifield,(nsim1+1):nsim,isoil])
      raintott[1,imonth,ifield,(nsim1+1):nsim,isoil] <-
      raintott[1,imonth,ifield,(nsim1+1):nsim,isoil] - mpwvaa

      mpwvaa <- mean(raintott[2,imonth,ifield,1:nsim1,isoil])
      raintott[2,imonth,ifield,1:nsim1,isoil] <-
      raintott[2,imonth,ifield,1:nsim1,isoil] - mpwvaa

      mpwvaa <- mean(raintott[2,imonth,ifield,(nsim1+1):nsim,isoil])
      raintott[2,imonth,ifield,(nsim1+1):nsim,isoil] <-
      raintott[2,imonth,ifield,(nsim1+1):nsim,isoil] - mpwvaa

}}}



imonth <- 1 #month
ifield <- 3 #MP
isim <- 1 #sim
isoil <- 1 #soil moisture
nsim1 <- nsim/2

xvec <- seq(1,3,by=1)
xmin <- min(xvec)-1
xmax <- max(xvec)+1
ymin <- min(raintott[1,,,,])
ymax <- max(raintott[1,,,,])+10

axvec=c(1,2,3)
alxvec=c("1","2","3")

psize <- c(.5,.75,1.)
pchar <- c(19,19,19)
colors <- rainbow(nsim/2)

fname <- "./pngs/rainc_MP.png"
png(fname,width=700, height=700.,bg="white")

#x11(width=4.5,height=4.5)
plot(xvec,array(NA,3),col=colors[isim],type="p",
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab="soil",ylab="mm",yaxs="i",xaxs="i",cex.axis=1,xaxt = "n")
axis(1, at=axvec, labels=alxvec,cex.axis=1.2)


for (imonth in 1:nmonth) {
  for (isim in 1:nsim1) {
    points(xvec,raintott[1,imonth,ifield,isim,],
                  col=colors[isim],
                  type="p",cex=psize,pch=pchar)
    lines(xvec,raintott[1,imonth,ifield,isim,],
                  col=colors[isim],
                  type="l",lwd=3)

  }

  for (isim in (nsim1+1):nsim) {
    points(xvec,raintott[1,imonth,ifield,isim,],
                  col=colors[isim-nsim1],
                  type="p",cex=psize,pch=pchar)
    lines(xvec,raintott[1,imonth,ifield,isim,],
                 col=colors[isim-nsim1],
                 type="l",lwd=3)

  }
  legend(xmax-.75,ymax,cex=.5,
  lwd=3,c("GR","BFC","KR","KF","AR"),col=colors)
}

dev.off()

ymin <- min(raintott[2,,,,])
ymax <- max(raintott[2,,,,])+10

nsim1 <- nsim/2

#x11(width=4.5,height=4.5)
fname <- "./pngs/rainnc_MP.png"
png(fname,width=700, height=700.,bg="white")

plot(xvec,array(NA,3),col=colors[isim],type="p",
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab="soil",ylab="mm",yaxs="i",xaxs="i",cex.axis=1,xaxt = "n")
axis(1, at=axvec, labels=alxvec,cex.axis=1.2)


for (imonth in 1:nmonth) {
  for (isim in 1:nsim1) {
    points(xvec,raintott[2,imonth,ifield,isim,],
                  col=colors[isim],
                  type="p",cex=psize,pch=pchar)
    lines(xvec,raintott[2,imonth,ifield,isim,],
                  col=colors[isim],
                  type="l",lwd=3)

  }

  for (isim in (nsim1+1):nsim) {
    points(xvec,raintott[2,imonth,ifield,isim,],
                  col=colors[isim-nsim1],
                  type="p",cex=psize,pch=pchar)
    lines(xvec,raintott[2,imonth,ifield,isim,],
                 col=colors[isim-nsim1],
                 type="l",lwd=3)

  }
  legend(xmax-.75,ymax,cex=.5,
  lwd=3,c("GR","BFC","KR","KF","AR"),col=colors)
}

dev.off()

nsim1 <- nsim/2

ymin <- min(raintott[1,,,,]+raintott[2,,,,])
ymax <- max(raintott[1,,,,]+raintott[2,,,,])+10

#x11(width=4.5,height=4.5)
fname <- "./pngs/raintot_MP.png"
png(fname,width=700, height=700.,bg="white")

plot(xvec,array(NA,3),col=colors[isim],type="p",
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab="soil",ylab="mm",yaxs="i",xaxs="i",cex.axis=1,xaxt = "n")
axis(1, at=axvec, labels=alxvec,cex.axis=1.2)


for (imonth in 1:nmonth) {
  for (isim in 1:nsim1) {
    points(xvec,raintott[1,imonth,ifield,isim,]+
                raintott[2,imonth,ifield,isim,],
                  col=colors[isim],
                  type="p",cex=psize,pch=pchar)
    lines(xvec,raintott[1,imonth,ifield,isim,]+
               raintott[2,imonth,ifield,isim,],
                  col=colors[isim],
                  type="l",lwd=3)

  }

  for (isim in (nsim1+1):nsim) {
    points(xvec,raintott[1,imonth,ifield,isim,]+
                raintott[2,imonth,ifield,isim,],
                  col=colors[isim-nsim1],
                  type="p",cex=psize,pch=pchar)
    lines(xvec,raintott[1,imonth,ifield,isim,]+
               raintott[2,imonth,ifield,isim,],
                 col=colors[isim-nsim1],
                 type="l",lwd=3)

  }
  legend(xmax-.75,ymax,cex=.5,
  lwd=3,c("GR","BFC","KR","KF","AR"),col=colors)
}


dev.off()
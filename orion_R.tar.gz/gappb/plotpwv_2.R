# need to execute skewts_pwv.R first
i <- 2 #month
j <- 3 #MP
k <- 1 #sim

xvec <- seq(0,23,by=1)
xmin <- min(xvec)
xmax <- max(xvec)
ymin <- min(pwva[,i,j,],pwvb[,i,j,],pwvc[,i,j,])
ymax <- max(pwva[,i,j,],pwvb[,i,j,],pwvc[,i,j,])

pwvaa <- pwva
pwvaa[1,,,] <- pwva[24,,,]
pwvaa[2:24,,,] <-  pwva[1:23,,,]

pwvbb <- pwvb
pwvbb[1,,,] <- pwvb[24,,,]
pwvbb[2:24,,,]  <- pwvb[1:23,,,]

pwvcc <- pwvc
pwvcc[1,,,] <- pwvc[24,,,]
pwvcc[2:24,,,]  <- pwvc[1:23,,,]


colors <- rainbow(nsims/2)

nsims1 <- nsims/2

plot(xvec,pwvaa[,i,j,1],"l",col=colors[1],
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab="hour",ylab="mm",yaxs="i",xaxs="i",lwd=7,cex.axis=1)

for (kk in 2:nsims1) {
lines(xvec,pwvaa[,i,j,kk],col=colors[kk],lwd=7,lty=1)
}

for (kk in 1:nsims1) {
lines(xvec,pwvbb[,i,j,kk],col=colors[kk],lwd=9,lty=1)
}

for (kk in 1:nsims1) {
lines(xvec,pwvcc[,i,j,kk],col=colors[kk],lwd=5,lty=1)
}

nsims1 <- nsims/2+1

for (kk in nsims1:nsims) {
lines(xvec,pwvaa[,i,j,kk],col=colors[kk-nsims1+1],lwd=7,lty=1)
}

for (kk in nsims1:nsims) {
lines(xvec,pwvbb[,i,j,kk],col=colors[kk-nsims1+1],lwd=9,lty=1)
}

for (kk in nsims1:nsims) {
lines(xvec,pwvcc[,i,j,kk],col=colors[kk-nsims1+1],lwd=5,lty=1)
}


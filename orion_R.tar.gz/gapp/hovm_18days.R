library(ncdf)
nc <- open.ncdf( "/export/scratch/pagowski/stuff/gapp2005/indata/varfiles/combined/RAINNC_d_03_MYJ_min_2004-06-01_00:00:00_daily.nc", readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ntimes <- v1$varsize[3]
xave <- data1[1,,]
yave <- data1[,1,]


for (i in 1:ntimes) {for (j in 1:ny) {xave[j,i] <- mean(data1[,j,i])}}
for (i in 1:ntimes) {for (j in 1:nx) {yave[j,i] <- mean(data1[j,,i])}}

par(mar=c(2.1,4.1,2.1,0.1))
par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)

png("hovm_sn_18days.png",width = 414, height = 600,bg="white")
filled.contour(x=seq(1,ny),y=seq(1,ntimes),z=xave,nlevels=6,
levels=c(0.1,5,10,15,20,25,30),col = rainbow(7,start=.5,end=1.,
gamma=1.),plot.axes={axis(1,at=c(1,100,200,300,400),font=2);
axis(2,at=c(1,10,18),
labels=c("JUN01","JUN10","JUN18"),font=2)},
font=2,
xlab="S-N domain size",ylab="Days",
key.title = title(main="Precip\n(mm)"),key.axes=axis(4,font=2))
dev.off()


par(mar=c(2.1,4.1,2.1,0.1))
par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)

png("hovm_ew_18days.png",width = 348, height = 600,bg="white")
filled.contour(x=seq(1,nx),y=seq(1,ntimes),z=yave,nlevels=6,
levels=c(0.1,5,10,15,20,25,30),col = rainbow(7,start=.5,end=1.,
gamma=1.),plot.axes={axis(1,at=c(1,100,200,300),font=2);
axis(2,at=c(1,10,18),
labels=c("JUN01","JUN10","JUN18"),font=2)},
font=2,
xlab="E-W domain size",ylab="Days",
key.title = title(main="Precip\n(mm)"),key.axes=axis(4,font=2))
dev.off()


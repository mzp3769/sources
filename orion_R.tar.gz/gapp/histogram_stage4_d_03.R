dir <-'/export/scratch2/pagowski/stuff/gapp/outdata'
prefix <- "stage4"
month <- "_2004_06"
suffix <- "_diurnal.txt"
fobs <- file(paste(dir,'/',prefix,month,suffix,sep=""),"ra")

nhours <- 24
obs <- array(scan(fobs,what=0.,n=nx*ny),c(2,nhours))
close(fobs)

fname <- paste( "./pngs/old/stage4_histogram",month,".png",sep="")
png(fname,width=300, height=600,bg="white")

#fname <- paste( "./posts/stage4_histogram",month,".eps",sep="")
#postscript(fname,width=5.95, height=6.,
#horizontal = FALSE, onefile = FALSE, paper = "special",
#           family = "URWHelvetica")
par(font.axis=2)
barplot(obs[2,],space=0,col=c("skyblue"),
xlim=c(.93,24),ylim=c(0,10),
axes=TRUE,xlab="time(UTC)",ylab="precip (mm)")

par(font=2) 
mtext(side = 1, at=5.525,"06")
mtext(side = 1, at=11.525,"12")
mtext(side = 1, at=17.525,"18")
mtext(side = 1, at=23.525,"00")
#text(12,4.9,labels="A",cex=1.5)
dev.off()



library(ncdf)
sim <- "MYJ_ens_0"
field <- "RAINTOT"
freq <- "_accum"
domain <- "_d_01_"
date <- "_2004-09-01_00:00:00"
nc <- open.ncdf( paste("/export/scratch/pagowski/stuff/gapp2005/indata/processed/",field,domain,sim,date,freq,".nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ntimes <- v1$varsize[3]

par(mar=c(2.1,4.1,2.1,0.1))
par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)

#png(paste("accum_",field,domain,sim,freq,".png",sep=""),
#width = 414, height=414, bg="white")
fname <- paste("./posts/",field,domain,sim,freq,date,"_whole.eps",sep="")
#postscript(fname,width=5.95, height=6.,
postscript(fname,width=7.85, height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=data1,
levels=c(1,10,50,100,150,200,250,300),
,asp=1,
col = rainbow(7,start=.15,end=.75,
gamma=1.),plot.axes={axis(1,at=c(1,10,20,30),font=2);
axis(2,at=c(1,10,20,30),font=2)},
xaxs = "i", yaxs = "i",
font=2,xlab="E-W domain size",ylab="S-N domain size",
key.title = title(main="Precip\n(mm)"),
key.axes=axis(4,at=c(.1,10,50,100,150,200,250,300),font=2))
dev.off()



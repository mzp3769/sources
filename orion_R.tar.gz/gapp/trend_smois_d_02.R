library(ncdf)
domain <- "_d_02"
month="_jun"
year="_2004"
fields=c("SMOIS")

sims <- c("run_11aa","run_11ba","run_11ca",
          "run_12aa","run_12ba","run_12ca",
          "run_13aa","run_13ba","run_13ca",
          "run_14aa","run_14ba","run_14ca")

nsims <- length(sims)


for (field in fields) {

print(field)

k <- 0


for (sim in sims) {
k <- k+1

print(sim)

print("getting data")

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/",field,domain,month,year,".nc",sep=""), readunlim=FALSE )


v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[2]
close.ncdf(nc)

if (k==1) {
varave <- array(0.,c(ntimes,nsims))
}

ndays <- (ntimes-1)/24

varave[,k] <- data1[1,]

png(paste("./pngs/monthly_",field,domain,month,year,".png",sep=""),
width = 700, height = 500,bg="white")

ymin <- min(varave)
ymax <- max(varave)

xvec=c(1,240,480,720)
lxvec=c("01","10","20","30")

colors <- rainbow(nsims)

plot(c(2:ntimes),varave[2:ntimes,1],"l",col=colors[1],ylim=c(ymin,ymax),
xlab="June 2004",ylab="",xaxs="i",xaxt = "n",lwd=3,cex.axis=2)
axis(1, at=xvec, labels=lxvec,cex.axis=2)

for (i in 2:nsims) {
lines(c(2:ntimes),varave[2:ntimes,i],col=colors[i],lwd=3)
}

if (field=="QFX") {
legend(2.5,ymax,cex=.75,
lwd=3,c("YR","YRX","YRM","MN","MNX","MNM","MR","MRX","MRM","YN","YNX","YNM"),
col=colors)
}

dev.off()

}
}
library(ncdf)
domain <- "_d_02"
month="_jun"
year="_2004"
field="RAINTOT"
sims <- c("run_11aa","run_11ba","run_11ca",
          "run_12aa","run_12ba","run_12ca",
          "run_13aa","run_13ba","run_13ca",
          "run_14aa","run_14ba","run_14ca")

for (sim in sims) {

print(sim)

print("getting data")

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/","RAINNC_h",domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ntimes <- v1$varsize[3]
close.ncdf(nc)

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/","RAINC_h",domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data2 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ntimes <- v1$varsize[3]
close.ncdf(nc)

data1 <- data1 + data2

rm(data2)

ixs <- 1
ixe <- nx
jxs <- 1
jxe <- ny

raindaily <- array(0.,c(nx,ndays))

print("processing")
for (i in 1:ntimes) {
k <- (i-1)%/%24+1
for (j in 1:nx) {
raindaily[j,k] <- mean(data1[j,,i])+raindaily[j,k]
}}

yave <- raindaily

par(mar=c(2.1,4.1,2.1,0.1))
par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)

png(paste("./pngs/hovm_ew_",field,domain,"_",sim,month,year,".png",sep=""),
width = 500, height = 600,bg="white")
filled.contour(x=seq(1,nx),y=seq(1,ndays),z=yave,nlevels=6,
levels=c(0.1,5,10,15,20,25),col = rainbow(7,start=.5,end=1.,
gamma=1.),plot.axes={axis(1,at=c(1,50,100),font=2);
axis(2,at=c(1,10,20,30),
labels=c("JUN01","JUN10","JUN20","JUN30"),font=2)},
font=2,
xlab="E-W domain size",ylab="Days")
#key.title = title(main="Precip\n(mm)"),key.axes=axis(4,font=2))
dev.off()

}
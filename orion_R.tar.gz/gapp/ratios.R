library(ncdf)
domain <- "_d_02"
month="_jun"
year="_2004"

sims <- c("run_11aa","run_11ba","run_11ca",
          "run_12aa","run_12ba","run_12ca",
          "run_13aa","run_13ba","run_13ca",
          "run_14aa","run_14ba","run_14ca")

nsims <- length(sims)




recycl <- c(0.041457245879613,0.17547142803857,0.0243402473467113,
            0.0714962627276039,0.137541078798377,0.0281142137930761,
            0.0517706591325597,0.174579889091652,0.0325339307128166,
            0.0700763642813851,0.144969286420975,0.0227130544823887)

peffic <- c(0.0695661992206065,0.0944399707762417,0.067979435546634,
            0.0674576381443325,0.0752561431159586,0.0641706261565922,
            0.0877947404562131,0.102564150156815,0.0857110242004074,
            0.0532007059287171,0.0632086791432303,0.0497569584299899)

k <- 0

xvec <- c(1:4)
lxvec <- c("YR","MN","MR","YN")

for (sim in sims) {

png(paste("./pngs/recycling_ratio",domain,month,year,".png",sep=""),
width = 700, height = 700,bg="white")

xmin <- 0
xmax <- 5

ymin <- 0.
ymax <- max(recycl)+.02

colors <- rainbow(nsims/3)

ncols <- nsims/3

plot(1,recycl[1],col=colors[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="",ylab="Recycling ratio",xaxs="i",yaxs="i",cex.axis=2,type="p",cex=2,
pch=19,xaxt = "n")
axis(1, at=xvec, labels=lxvec,cex.axis=2)

for (i in 2:nsims) {
j <- i%%3
if (j==1) magn <- 2
if (j==2) magn <- 3
if (j==0) magn <- 1
k <- (i-1)%/%3 + 1
points(k,recycl[i],col=colors[k],cex=magn,pch=19)
}
dev.off()

png(paste("./pngs/peffic",domain,month,year,".png",sep=""),
width = 700, height = 700,bg="white")

xmin <- 0
xmax <- 5

ymin <- min(peffic)-.01
ymax <- max(peffic)+.01

colors <- rainbow(nsims/3)

ncols <- nsims/3


plot(1,peffic[1],col=colors[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="",ylab="Precipotation efficiency",yaxs="i",
xaxs="i",cex.axis=2,type="p",cex=2,pch=19,xaxt = "n")
axis(1, at=xvec, labels=lxvec,cex.axis=2)
for (i in 2:nsims) {
j <- i%%3
if (j==1) magn <- 2
if (j==2) magn <- 3
if (j==0) magn <- 1
k <- (i-1)%/%3 + 1
points(k,peffic[i],col=colors[k],cex=magn,pch=19)
}
dev.off()

}



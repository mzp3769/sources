library(ncdf)
sim <- "MYJ_NOAH_ens_0"
type <- "_4histogram"
domain <- "_d_01_"
month <-"_jul_2004" 

# the input file is the average over dimensions

field <- "RAINC"
nc <- open.ncdf(paste("/export/scratch/pagowski/stuff/gapp2005/indata/processed/",field,type,domain,sim,month,".nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

raincave <- array(0.,c(24))
for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
raincave[j] <- data1[i]+raincave[j]
}
rm(data1)

field <- "RAINNC"
nc <- open.ncdf(paste("/export/scratch/pagowski/stuff/gapp2005/indata/processed/",field,type,domain,sim,month,".nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

rainncave <- array(0.,c(24))
for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
rainncave[j] <- data1[i]+rainncave[j]
}
rm(data1)

raintot <- array(0.,c(2,24))
raintot[1,] <- raincave
raintot[2,] <- rainncave
field="RAINTOT"
fname <- paste( "./posts/",field,domain,sim,"_histogram",month,".eps",
sep="")
postscript(fname,width=5.95, height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
par(font.axis=2)

barplot(raintot,space=0,col=c("royalblue","skyblue"),
xlim=c(.93,24),ylim=c(0,10),
axes=TRUE,xlab="time(UTC)",ylab="precip (mm)")

par(font=2)
mtext(side = 1, at=5.525,"06")
mtext(side = 1, at=11.525,"12")
mtext(side = 1, at=17.525,"18")
mtext(side = 1, at=23.525,"00")
#text(12,4.9,labels="A",cex=1.5)
dev.off()
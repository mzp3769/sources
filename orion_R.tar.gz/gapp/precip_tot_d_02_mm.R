library(ncdf)
domain <- "_d_02"
month="_jun"
year="_2004"
field="RAINTOT"

sims <- c("run_11aa","run_11ba","run_11ca",
          "run_12aa","run_12ba","run_12ca",
          "run_13aa","run_13ba","run_13ca",
          "run_14aa","run_14ba","run_14ca")

for (sim in sims) {

print(sim)

print("getting data")

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/",field,domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ntimes <- v1$varsize[3]
close.ncdf(nc)

ixs <- 1
ixe <- nx
jxs <- 1
jxe <- ny


par(mar=c(2.1,4.1,2.1,0.1))
par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)

png(paste("./pngs/",field,"_accum",domain,"_",sim,month,year,".png",sep=""),
width = 505, height = 520,bg="white")

#fname <- paste("./posts/",field,domain,sim,freq,date,".eps",sep="")
#postscript(fname,width=5.95, height=6.,
#horizontal = FALSE, onefile = FALSE, paper = "special",
#           family = "URWHelvetica")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=data1[ixs:ixe,jxs:jxe],
levels=c(1,10,50,100,150,200,250,300),
,asp=1,
col = rainbow(7,start=.15,end=.75,
gamma=1.),plot.axes={axis(1,at=c(1,50,100),font=2);
axis(2,at=c(1,50,100),font=2)},
xaxs = "i", yaxs = "i",
font=2,xlab="E-W domain size",ylab="S-N domain size",
#key.title = title(main="Precip\n(mm)"),
key.axes=axis(4,at=c(.1,10,50,100,150,200,250,300),font=2))
dev.off()
}


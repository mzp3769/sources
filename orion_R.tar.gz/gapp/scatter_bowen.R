library(ncdf)
domain <- "_d_02"
month="_jun"
year="_2004"
fields=c("HFX")
xlv <- 2.5e6

sims <- c("run_11aa","run_11ba","run_11ca",
          "run_12aa","run_12ba","run_12ca",
          "run_13aa","run_13ba","run_13ca",
          "run_14aa","run_14ba","run_14ca")

nsims <- length(sims)


k <- 0

for (field in fields) {

print(field)

flux <- array(0,c(nsims))
rain <- flux

varave <- array(0.,c(24,nsims))
varqave <- varave
varrave <- varave
k <- 0

for (sim in sims) {


k <- k+1

print(sim)

print("getting data")

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/",field,"_total",domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

ndays <- (ntimes-1)/24

for (i in 2:ntimes) {
j <- (i-1)%%24
if (j == 0) j <- 24 
varave[j,k] <- data1[i]+varave[j,k]
}

rm(data1)

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/","QFX","_total",domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

ndays <- (ntimes-1)/24

for (i in 2:ntimes) {
j <- (i-1)%%24
if (j == 0) j <- 24
varqave[j,k] <- data1[i]+varqave[j,k]
}

rm(data1)


nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/","RAINNC_h","_total",domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/","RAINC_h","_total",domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data2 <- get.var.ncdf( nc, v1 )
close.ncdf(nc)

data1 <- data1+data2

for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24
varrave[j,k] <- data1[i]+varrave[j,k]
}
rm(data1)

#flux[k] <-  sum(varave[,k])
rain[k] <-  sum(varrave[,k])
flux[k] <- sum(varave[,k])/(sum(varqave[,k])*xlv)

}

png(paste("./pngs/scatter_","bowen_",domain,month,year,".png",sep=""),
width = 700, height = 700,bg="white")


flux <- flux
rain <- rain/ndays

xmin <- min(flux)-0.5
xmax <- max(flux)+0.5

ymin <- min(rain)
ymax <- max(rain)

colors <- rainbow(nsims/3)

plot(flux[1],rain[1],col=colors[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="Bowen",ylab="RAINTOT",xaxs="i",cex.axis=2,type="p",cex=2,pch=19)

for (i in 2:nsims) {
j <- i%%3
if (j==1) magn <- 2
if (j==2) magn <- 3
if (j==0) magn <- 1
k <- (i-1)%/%3 + 1
points(flux[i],rain[i],col=colors[k],cex=magn,pch=19)
if (j==0) {
lines(c(flux[i],flux[i-2],flux[i-1]),c(rain[i],rain[i-2],rain[i-1]),
      col=colors[k],lwd=4)
}
}
dev.off()

}
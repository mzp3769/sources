library(ncdf)
nc <- open.ncdf("/scratch/amb/pagowski/stuff/gapp2005/indata/HGT_d02.nc", readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ntimes <- v1$varsize[3]

ixs <- 12+12/3
ixe <- 12+12/3+324/3
jxs <- 12+12/3
jxe <- 12+12/3+384/3
nx <- ixe-ixs+1
ny <- jxe-jxs+1


par(mar=c(2.1,4.1,2.1,0.1))
par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)

png("./pngs/HGT_d02.png",width = 505, height=520, bg="white")
#fname <- paste("./posts/HGT_d02.eps")
#postscript(fname,width=5.95, height=6.,
#horizontal = FALSE, onefile = FALSE, paper = "special",
#           family = "URWHelvetica")



filled.contour(x=seq(1,nx),y=seq(1,ny),z=data1[ixs:ixe,jxs:jxe],
nlevels=6,levels=seq(500,4500,by = 500),
asp=1,col = terrain.colors(9),
#asp=1,col = topo.colors(5),
plot.axes={axis(1,at=c(1,10,50,100),font=2);
axis(2,at=c(1,50,100),font=2)},
xaxs = "i", yaxs = "i",
font=2,xlab="E-W domain size",ylab="S-N domain size",
#key.title = title(main="Elevation\n(m)"),
key.axes=axis(4,at=c(1000,2000,3000,4000),font=2)
)
dev.off()



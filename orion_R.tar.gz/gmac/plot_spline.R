#to plot illustation how spline works

nwaves <- 5
x <- array(NA,nwaves)
y <- array(NA,nwaves)

x <- c(413.,496.,670.,868.,1624.)
y <- c(0.752,0.605,0.351,0.200,0.050)

xi <- 550.
yi <- 0.516990242250108

xlim <- c((min(x)-10),max(x+10))

pngname <- "./outdata/spline.png"
png(pngname,width=600,height=400,bg="white")

plot(x,y,xlab="Wavelengths [nm]",ylab="AOD",
cex.axis=1.,cex.lab=1.,type="n",lwd=2,cex=1.)

points(x,y,pch=16,cex=1.5,col="black")
points(xi,yi,col="red",pch=16,cex=1.5)

dev.off()


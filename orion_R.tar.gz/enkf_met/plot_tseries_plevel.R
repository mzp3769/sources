test <- "test_911"

statnames <- c("ME","RMSE")

ftypes=c("prior","posterior")

fields3d <- c("TT","UU","VV","GHT","QVAPOR")
levels <- c("P925","P850","P700","P500","P250")
suffix <- "cnt.txt"

stats <- c("FBAR","OBAR","FSTDEV","OSTDEV","PR_CORR","ME","BCMSE","RMSE")
minstat <- 10


for (ftype in ftypes) {
for (statname in statnames) {

statname1 <- statname
statname2 <- statname


plotdates <- c("2012/06/01","2012/07/01","2012/08/01","2012/09/01")

times_ave <- seq(as.POSIXlt(plotdates[1],"UTC"),by=3600,length=24)
assimtimes <- seq(as.POSIXlt(plotdates[1],"UTC"),by=6*3600,length=4)


indir=paste("./indata/",test,"/point_stats_plevel_",ftype,sep='')

sumup <- function(k,statplot) {
     if (k > 24) {
     stop("hour need to be smaller than 24")
     }
     tindex <- 
     which(format(alldates,"%T")==format(times_ave[k],"%T"))
     if (length(tindex) < minstat ) {
     sumpup <- NA
     } else {
     sumup <- sum(statplot[tindex],na.rm=TRUE)/length(tindex)
     }
}

for (field in fields3d) {
    for (level in levels) {
    	print(c(field,level))
        fname <- paste(indir,'/',field,'_',level,'_',suffix,sep="")
	thisfile <- file(fname,"ra")
	names <- scan(thisfile,what='a',sep=',',nlines=1)
 	vartable <- try(
	read.table(thisfile,header=FALSE,skip=0,sep=','),silent=TRUE)
	if (class(vartable)=="try-error") {
	print(c("FILE EMPTY",c(field,level)))
	close(thisfile)			  
	next } 
	close(thisfile)
	ndate <- which(names=="FCST_VALID_BEG")
	ntotal <-  which(names=="TOTAL")

	total <- vartable[,ntotal]

	nlines <- length(total)

	istat1 <- which(names==statname1)
	istat2 <- which(names==statname2)

	totdays <- NULL
	hours <- NULL
	statplot1 <- NULL
	statplot2 <- NULL

	for (i in 1:nlines) {
	if (total[i] < minstat) next
	totdays <- c(totdays,as.numeric(substr(vartable[i,ndate],1,8)))
	hours <- c(hours,as.numeric(substr(vartable[i,ndate],10,11)))
	statplot1 <- c(statplot1,vartable[i,istat1])
	statplot2 <- c(statplot2,vartable[i,istat2])

	}

	years <- totdays %/%10000
	months <- (totdays %% 10000) %/% 100
	days <-  (totdays %% 10000) %% 100

	alldates <- paste(as.character(years),"-",
		 as.character(months),"-",as.character(days),sep="")	
	times <- paste(as.character(hours),":00:00",sep="")

	alldates <- as.POSIXlt(paste(alldates,times),"UTC")
	
	statave_1 <- NULL
	statave_2 <- NULL

	for (hour in seq(24)) {
	statave_1 <- c(statave_1,sumup(hour,statplot1))
	statave_2 <- c(statave_2,sumup(hour,statplot2))
        }

	if (istat1==istat2) {
	fieldname <-  paste(field,'_',level,'_',test,sep='')
	fname <-  paste(field,'_',level,sep='')
        picname <-  paste("./pics/",fieldname,'_',ftype,'_',statname1,
        '_tseries.png',sep='')

	ymax <- max(statplot1)
	ymin <- min(statplot1)

	xmax <- max(alldates)	

	png(picname,width=600, height=400.,bg="white")
	plot(alldates,statplot1,type="l",lwd=4,cex=1.,col="blue",
	xlab='',	ylab=statname1,xaxs="i",yaxs="i",
	ylim=c(ymin,ymax),
	xaxt='n',	main=fname)
	axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
	dev.off()

        picname <-  paste("./pics/",fieldname,'_',ftype,'_ave_',statname1,
        '_tseries.png',sep='')

	ymax <- max(statave_1,na.rm=TRUE)
	ymin <- min(statave_1,na.rm=TRUE)

	xmin <- min(times_ave)	
	xmax <- max(times_ave)	

	png(picname,width=600, height=400.,bg="white")
	plot(times_ave,statave_1,type="p",lwd=10,cex=1.,col="blue",
	xlab='Time UTC',ylab=statname1,
	ylim=c(ymin,ymax),
	xaxt='n',main=fname)
	axis.POSIXct(1,times_ave,format="%H:%M",at=assimtimes)
	dev.off()

	}
	else {
	fieldname <-  paste(field,'_',level,'_',test,sep='')
	fname <-  paste(field,'_',level,sep='')

        picname <-  paste("./pics/",fieldname,'_',ftype,'_',statname1,'_',
        statname2,'.png',sep='')

	xmax <- max(alldates)
	ymax <- max(statplot1,statplot2)
	ymin <- min(statplot1,statplot2)

	png(picname,width=600, height=400.,bg="white")
	plot(alldates,statplot1,type="l",lwd=4,cex=1.,col="blue",xaxs="i",
	xlab='',	ylab=paste(statname1,statname2),yaxs="i",
	cex.axis=1.,cex.lab=1.,ylim=c(ymin,ymax),
	xaxt='n',	main=fname)
	lines(alldates,statplot2,col="red",lwd=4)
	legend(x=xmax,y=ymax,xjust=1,yjust=1,col=c("blue","red"),
	lwd=4,legend=c(statname1,statname2),cex=1)
	axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
	dev.off()

        picname <-  paste("./pics/",fieldname,'_',ftype,'_ave_',statname1,'_',
        statname2,'.png',sep='')

	ymax <- max(c(statave_1,statave_2),na.rm=TRUE)
	ymin <- min(c(statave_1,statave_2),na.rm=TRUE)

	xmin <- min(times_ave)	
	xmax <- max(times_ave)	

	png(picname,width=600, height=400.,bg="white")
	plot(times_ave,statave_1,type="p",lwd=6,cex=1.,col="blue",
	xlab='Time UTC',ylab=paste(statname1,statname2),
	ylim=c(ymin,ymax),
	xaxt='n',main=fname)
	axis.POSIXct(1,times_ave,format="%H:%M",at=assimtimes)
	points(times_ave,statave_2,lwd=6,col="red")
	legend(x=xmax,y=ymax,xjust=1,yjust=1,col=c("blue","red"),
	lwd=4,legend=c(statname1,statname2),cex=1)
	dev.off()

	}
    }
}

}}
test <- "test_291"

fields2d <- c("T2","Q2","TD2")
fstarthours <- c(0,12)
fcstinterval <- 3


statnames <- c("FBAR","OBAR","FSTDEV","OSTDEV","PR_CORR",
               "ME","BCMSE","RMSE")

statnames <- c("PR_CORR","ME","BCMSE","RMSE")

fcst_length <- 69
nfcsts <- fcst_length/fcstinterval+1

suffix <- "cnt.txt"

minstat <- 3

Sys.setenv(TZ="UTC")

cycle_freq <- fstarthours[2]-fstarthours[1]
ncycles <- 24/cycle_freq
nvars <- length(fields2d)

infile=paste("./indata/",test,"/point_stats_sfc/allvars_cnt.txt",sep='')

calcstats <- function(fstat) {
     t0 <- which(field==vartable[,nvar])
     t1 <- which(fstarthour==shours)
     t2 <- which(fhour==fhours)
     timesl <- intersect(intersect(t0,t1),t2)
     if (length(t2) < minstat ) {
     statl <- NA
     } else {
     statl <- mean(fstat[timesl],na.rm=TRUE)
     }
     statout <- list(stat=statl,tindex=timesl)
     return(statout) 
}

orderstats <- function(fstat) {
     t0 <- which(field==vartable[,nvar])
     t1 <- which(fsdate==allinsdates)
     t2 <- which(fhour==fhours)
     timesl <- intersect(intersect(t0,t1),t2)
     statout <- list(tindex=timesl)
     return(statout) 
}

for (statname in statnames) {

fname <- infile
thisfile <- file(fname,"ra")
names <- scan(thisfile,what='a',sep=',',nlines=1)
vartable <- try(
read.table(thisfile,header=FALSE,skip=0,sep=','),silent=TRUE)
if (class(vartable)=="try-error") {
print(c("FILE EMPTY",field))
close(thisfile)			  
next } 
close(thisfile)

ndate <- which(names=="FCST_VALID_BEG")
ntotal <-  which(names=="TOTAL")
nvar <- which(names=="FCST_VAR")
nfcsthr <- which(names=="FCST_LEV")	
total <- vartable[,ntotal]

istat <- which(names==statname)

fstat <- vartable[,istat]

years <- as.numeric(substr(vartable[,1],1,4))
months <- as.numeric(substr(vartable[,1],5,6))
days <- as.numeric(substr(vartable[,1],7,8))
hours <- as.numeric(substr(vartable[,ndate],10,11))

onedate_start <- as.POSIXlt(paste(as.character(years[1]),"-",
        as.character(months[1]),"-",as.character(days[1]),sep=""))

time_s <-  paste(as.character(0),":00:00",sep="")

fhours <-  as.numeric(sub('L','',vartable[,nfcsthr],ignore.case=FALSE,fixed=FALSE))*
fcstinterval

ndates <- length(years)

onedate_s <- as.POSIXlt(paste(onedate_start,time_s),"UTC")

shours <- hours-fhours
mstindex <- which(shours < 0)

while (  length(which(shours < 0)) > 0 ) {
shours[shours < 0 ] <- shours[shours < 0 ] + 24
}

#apply below does not work
#apply(shours, 2, function(x) ifelse(x < 0, x + 24, x))

cycletime <- cycle_freq*3600

i <- 1
dates_ave <- list(seq(onedate_s+(i-1)*cycletime,by=3600*fcstinterval,
	  length=nfcsts))

for (i in 2:ncycles) {
dates_cyc <- list(seq(onedate_s+(i-1)*cycletime,by=3600*fcstinterval,
	  length=nfcsts))
dates_ave <- c(dates_ave,dates_cyc)
}

outfname <- paste("./outdata/",test,"_",statname,"_ave_sfc.txt",sep='')

write(c(statname,nvars,ncycles,nfcsts,fcstinterval)
     ,outfname
     ,ncolumns=5,append=FALSE)

for (field in fields2d) {

  write(field,outfname,ncolumns=1,append=TRUE)

  fstatplot <- array(NA,c(ncycles,nfcsts))

  i <- 0
  for (fstarthour in fstarthours) {
    i <- i+1

    j <- 0
    for (nhour in 1:nfcsts) {
      fhour <- (nhour-1)*fcstinterval
      j <- j+1
      fstatplot[i,j] <- calcstats(fstat)$stat
    }

    write(paste('"',format(dates_ave[[i]][1],"%Y-%m-%d %H:00:00"),
    		       " UTC",'"',sep=''),
    outfname,ncolumns=1,append=TRUE)
    write(fstatplot[i,],outfname,ncolumns=fcst_length,append=TRUE)
  }

}

next

#hourly output

allinsdates <- as.POSIXlt(paste(
                             substr(vartable[,1],1,4),"/",
                             substr(vartable[,1],5,6),"/",
                             substr(vartable[,1],7,8)," ",
                             sprintf("%02i",shours),
                             ":00:00",sep=''))

allinsdates[mstindex] <- allinsdates[mstindex]-24*3600

onedate_end <- max(allinsdates)

allfsdates <- seq(from=onedate_start,to=onedate_end,by=6*3600)
nfsdates <- length(allfsdates)

outfname <- paste("./outdata/",test,"_",statname,"_sfc.txt",sep='')

write(c(statname,nvars,ncycles,fcst_length,nfsdates)
     ,outfname
     ,ncolumns=5,append=FALSE)

fstatplot <- array(NA,fcst_length)

for (field in fields2d) {

  write(field,outfname,ncolumns=1,append=TRUE)

  for (i in 1:nfsdates) {
    fsdate <- allfsdates[i]
    for (fhour in 1:fcst_length) {
      ti <- orderstats(fstat)$tindex
      if (length(ti) == 0) {
         print("missing evaluation for date")
         print(fsdate+fhour*3600)
         fstatplot[fhour] <- NA
      } else {	 
         fstatplot[fhour] <- vartable[ti,istat]
      }
    }
    fsdate <- fsdate + 3600
    write(paste('"',format(fsdate,"%Y-%m-%d %H:00:00")," UTC",'"',sep=''),
    outfname,ncolumns=1,append=TRUE)

    write(fstatplot,outfname,ncolumns=9,append=TRUE)
  }
}

}
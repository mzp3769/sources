tests <- c("test_806","test_807","test_808","test_809","test_810",
"test_811","test_812","test_813","test_814","test_815")

tests <- c("test_806","test_809","test_810","test_811","test_812",
"test_813","test_814","test_815")

tests <- c("test_806","test_816","test_818","test_823")

danames <- c("NODA","SFC+AOD_M_NI","SFC+AOD_M_I","SFC+AOD_EC_I")


tcolors <- c("violet","green","blue","red","orange","black","purple",
"paleturquoise","peachpuff","salmon")

#tcolors <- c("blue","red","violet","green")
tests <- c("test_806","test_809","test_816","test_818","test_823","test_828")

tcolors <- rainbow(ntests+1,start=0.,end=1.)

ntests <- length(tests)

statnames <- c("OBAR","FBAR")

statnames <- c("ME")

#statnames <- c("RMSE")

if (!is.na(tests[2])) {
   if (tests[1] != tests[2] ) {
      statnames <- array(statnames[1],ntests)
   }
}

statnamepic <- statnames
#statnamepic <- paste(statnames[1:ntests],sep='',collapse='_')
lstnames <- paste(tests,statnames[1:ntests],sep='_')


##figure out how to trim white spaces from name


allstats <- NULL

fields <- NULL


for (k in 1:ntests) {

  test <- tests[k]

  allstats <- c(allstats,list(lstnames[k]))

  statname <- statnames[k]

  fname <- paste("./outdata/",test,"_",statname,
		 "_ave_sfc.txt",sep='')
  thisfile <- file(fname,"ra")

  data <- scan(thisfile,what='a',nlines=1)

  statname <- data[1]
  nvars <- as.integer(data[2])
  ncycles <- as.integer(data[3])
  fcst_length  <- as.integer(data[4])

  Sys.setenv(TZ="UTC")

  stats <- NULL

  for (i in 1:nvars) {

    field <- scan(thisfile,what='a',nlines=1)

    if (test == tests[1]) {
       fields <- c(fields,field)
    }

    stats <- c(stats,list(field))

    startd <- scan(thisfile,what='a',nlines=1)
    if (i == 1) {
    alldates <- list(seq(as.POSIXlt(startd),by=3600,
                     length=fcst_length))
    }
    data <- scan(thisfile,what=1,nlines=1)
    stats[[field]] <- list(data)
    for (j in 2:ncycles) {
        startd <- scan(thisfile,what='a',nlines=1)
	
	if (i == 1) {
    	alldates <- c(alldates,list(seq(as.POSIXlt(startd),
		        by=3600,length=fcst_length)))
        }

	data <- scan(thisfile,what=1,nlines=1)
	stats[[field]] <- c(stats[[field]],list(data))
    }

    allstats[[lstnames[k]]] <- stats

  }
  close(thisfile)
}

datemin <- as.POSIXlt(format(alldates[[1]][1],"%Y-%m-%d"))
nhours <- fcst_length - 24/ncycles
datemax <- datemin+(24+nhours)*3600

datesplot <- seq(from=datemin,to=datemax,by=3600)

times_plot <- seq(from=datemin,to=datemax,by=6*3600)

for (field in fields) {

    picname <- paste("./pics/",field,'_',statnamepic,
    '_sfc_ave_tseries_alltests.png',sep="")
    png(picname,width=600,height=400,bg="white")

    statmin <- 999
    statmax <- -999

    for (k in 1:ntests) {
      test <- tests[k]
      statmin <- min(statmin,
                 unlist(lapply(allstats[[lstnames[k]]][[field]][],
                        min)))
      statmax <- max(statmax,
       	       	 unlist(lapply(allstats[[lstnames[k]]][[field]][],
                        max)))
   }

   plot(datesplot,
   seq(from=statmin,to=statmax,length.out=length(datesplot)),
   ylim=c(statmin,statmax),
   xlab="UTC",ylab=statnamepic[1],xaxt='n',xaxs="i",
   cex.axis=1.,cex.lab=1.,type="n",lwd=2,cex=1.)
   axis.POSIXct(1,datesplot,format="%H",at=times_plot)

   for (k in 1:ntests) {
     test <- tests[k]
     for (j in 1:ncycles) {
       lines(alldates[[j]],allstats[[lstnames[k]]][[field]][[j]],
       col=tcolors[k],lty=1,lwd=2)
       points(alldates[[j]],allstats[[lstnames[k]]][[field]][[j]],
       col=tcolors[k],pch=19,cex=1)
     }
   }

   xmin <- min(alldates[[1]])
   ymax <- statmax
   ymin <- statmin

#   legend(x=xmin,y=ymax,xjust=0,yjust=1,col=tcolors, #rmse
   legend(x=xmax,y=ymax,xjust=1,yjust=1,col=tcolors, #no legend
   lwd=4,legend=danames,cex=1)


   dev.off()
}


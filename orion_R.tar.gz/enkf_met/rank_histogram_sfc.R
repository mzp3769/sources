test <- "test_510"

fields2d <- c("T2","Q2","U10","V10")
starthours <- c("00","06","12","18")
fcst_length <- 9
suffix <- "rhist.txt"

indir=paste("./indata/",test,"/ensemble_stats_sfc",sep='')

for (field in fields2d) {
    print(field)
    for (starthour in starthours) {
        hour <- 1
	picname <-  paste("./pics/",field,'_',
	starthour,'_',test,'_rhist.png',sep='')
	png(picname,width=900, height=900.,bg="white")
	par(mfrow=c(3,3))
	par(omi=c(0,0,.5,0))

    	while (hour <= fcst_length) {    
	      chour <- sprintf("%02i",hour)
	      fname <- paste(indir,'/',field,'_',
	      	    starthour,'_',chour,'_',suffix,sep="")
	      print(fname)
	      hour <- hour + 1
	      thisfile <- file(fname,"ra")
	      names <- scan(thisfile,what='a',sep=',',nlines=1)
	      vartable <- read.table(thisfile,header=FALSE,skip=0,sep=',')	
	      close(thisfile)
	      ntotal <-  which(names=="TOTAL")
	      n1 <- which(names=="N_RANK")+1
	      n2 <- length(names)
	      nranks <- n2-n1+1
	      nens <- nranks-1
	      total <- sum(vartable[,ntotal])
	      rank_diag <- colSums(vartable[,n1:n2])/total
#	rank_diag <- apply(data.matrix(vartable[,n1:n2]),2,sum)
	      barplot(rank_diag,space=0,names.arg=chour,col="skyblue")
}
	par(mfrow=c(1,1))
	par(omi=c(0,0,0,0))
	title(main=paste(field,' ',starthour,' UTC ',as.character(nens),
	' members',sep=''))

dev.off()
}}


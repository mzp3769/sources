#generate series of random numbers for the ensmble

series_length <- 48*3600

RNGkind("Mersen")

nens <- 50

nfcst <- 999

for (iens in 1:nens) {

    print(iens)

    set.seed(iens)
    vect <- runif(series_length)

    fname <- paste('./outdata/random.',
    sprintf("%03d",iens),sep='')

    write(c(series_length,vect),file=fname,ncolumns=1,
    append=FALSE)

}

for (ifcst in 0:nfcst) {

    print(ifcst)

    fname <- paste('./outdata/sample.',
    sprintf("%03d",ifcst),sep='')

    vect <- sample((1:nens),replace=FALSE)
    write(sprintf("%03d",vect),
    file=fname,ncolumns=nfcst,append=FALSE)

}

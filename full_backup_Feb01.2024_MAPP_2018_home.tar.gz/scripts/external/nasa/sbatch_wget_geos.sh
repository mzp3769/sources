#!/bin/ksh
#SBATCH -n 1
#SBATCH -t 08:00:00
#SBATCH -q batch
#SBATCH -p service
##SBATCH -p orion
#SBATCH -A chem-var
#SBATCH -J get_geos
#SBATCH -D /home/mpagowsk/mapp_2018/scripts/external/nasa
#SBATCH -o /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.o%j
#SBATCH -e /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.e%j

#sbatch --export=ALL sbatch_wget_geos.sh

. ./wget_geos.sh


#!/bin/ksh

#date -d 2016-06-01 +%j
#153
#date -d 2016-06-30 +%j
#182

istart=153
iend=182

i=istart
while [[ $i -le $iend ]]
do
    ic="`printf %03i $i`"
    echo $ic
    wget -e robots=off -m -np -R .html,.tmp -nH --cut-dirs=3 "https://ladsweb.modaps.eosdis.nasa.gov/archive/allData/5110/AERDT_L2_VIIRS_SNPP/2016/${ic}/" --header "Authorization: Bearer 405E6FDE-649F-11EA-B2BB-EB080380055A" -P /work/noaa/gsd-fv3-dev/pagowski/OBS
    ((i=i+1))
done


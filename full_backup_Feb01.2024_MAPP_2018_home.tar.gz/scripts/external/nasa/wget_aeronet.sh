#!/bin/ksh
cd /work/noaa/gsd-fv3-dev/pagowski/OBS/aeronet

wget --no-check-certificate  -q  -O AERONET_NA_2016.lev20 "https://aeronet.gsfc.nasa.gov/cgi-bin/print_web_data_v3?year=2016&month=6&day=1&year2=2016&month2=6&day2=30&AOD20=1&AVG=10&lat1=-90..&lon1=-180.&lat2=90.&lon2=180."


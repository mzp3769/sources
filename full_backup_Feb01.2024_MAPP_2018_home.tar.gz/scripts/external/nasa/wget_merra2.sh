#!/bin/ksh

#see examples for whole directories at
#https://disc.gsfc.nasa.gov/information/howto?title=How%20to%20Download%20Data%20Files%20from%20HTTPS%20Service%20with%20wget

#data description https://gmao.gsfc.nasa.gov/pubs/docs/Bosilovich785.pdf

touch ~/.urs_cookies

start_date=2021080100
end_date=2021080118
cycle_frequency=24

http_merra2_aod="https://goldsmr4.gesdisc.eosdis.nasa.gov/data/MERRA2/M2I3NXGAS.5.12.4"
prefix_merra2_aod="MERRA2_400.inst3_2d_gas_Nx"
http_merra2_aero="https://goldsmr5.gesdisc.eosdis.nasa.gov/data/MERRA2/M2I3NVAER.5.12.4"
prefix_merra2_aero="MERRA2_400.inst3_3d_aer_Nv"

filelist="filelist.txt"

cd /scratch1/BMC/gsd-fv3-dev/MAPP_2018/pagowski/DATA/MODEL/m2/akbkll

/bin/rm -f $filelist

ndate=~/bin/ndate

ident=$start_date

while [[ $ident -le $end_date ]]
do

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hr=`echo "${ident}" | cut -c9-10`

cat << EOF >> $filelist 
${http_merra2_aod}/${year}/${month}/${prefix_merra2_aod}.${year}${month}${day}.nc4
${http_merra2_aero}/${year}/${month}/${prefix_merra2_aero}.${year}${month}${day}.nc4
EOF

    ident=`$ndate $cycle_frequency $ident`

done
    
wget --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --keep-session-cookies --content-disposition -i $filelist


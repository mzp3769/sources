#!/bin/ksh

. /etc/profile

. ../.environ.ksh

satellite='MYD04' #aqua
satellite='MOD04' # terra

if [[ $satellite == 'MYD04' ]]
then
    satid='aqua'
else
    satid='terra'
fi

grid=C192
cycle_frequency=6

typeset -A obstypes 
obstypes[ocean]="ocean"
obstypes[land]="land"
obstypes[deep]="deep"

start_date=2016060100
end_date=2016070100

maindir=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/pagowski

maindir_obs=${maindir}/OBS/NNR_003_6Targets
outdir=${maindir_obs}/${satellite}/Y${year}/M${month}_thinned_${grid}

#from nnr2ioda.sh 
workdir=${maindir}/tmpdir/workdir_nnr2ioda 


cd $workdir

ndate=~/bin/ndate

((halfcycle=cycle_frequency / 2))

ident=$start_date

while [[ $ident -le $end_date ]]
do

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hr=`echo "${ident}" | cut -c9-10`

    set -A listback \
        ./nnr_${satid}_${obstypes[ocean]}.${ident}-.nc \
        ./nnr_${satid}_${obstypes[land]}.${ident}-.nc \
        ./nnr_${satid}_${obstypes[deep]}.${ident}-.nc \

    set -A listcenter \
	./nnr_${satid}_${obstypes[ocean]}.${ident}.nc \
        ./nnr_${satid}_${obstypes[land]}.${ident}.nc \
        ./nnr_${satid}_${obstypes[deep]}.${ident}.nc 

    set -A listfor \
        ./nnr_${satid}_${obstypes[ocean]}.${ident}+.nc \
        ./nnr_${satid}_${obstypes[land]}.${ident}+.nc \
        ./nnr_${satid}_${obstypes[deep]}.${ident}+.nc \

    set -A filelist ${listback[*]} ${listcenter[*]} ${listfor[*]}

#    if [[ $ident == $start_date ]]
#    then
#	set -A filelist ${listcenter[*]} ${listfor[*]}
#    elif [[ $ident == $end_date ]]
#    then
#	set -A filelist ${listback[*]} ${listcenter[*]}
#    else
#	set -A filelist ${listback[*]} ${listcenter[*]} ${listfor[*]}
#    fi
    
    ncrcat -O ${filelist[*]} ${outdir}/nnr_${satid}.${ident}.nc
    if [[ $? -ne 0 ]]
    then
	echo "ncrcat failed - files missing"
	exit 1
    fi

    
    echo $ident

    ident=`$ndate $cycle_frequency $ident`

done

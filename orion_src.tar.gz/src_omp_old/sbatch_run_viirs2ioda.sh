#!/bin/ksh 
#SBATCH -n 1
#SBATCH -t 08:00:00
#SBATCH -q batch
##SBATCH -A wrf-chem
#SBATCH -A chem-var
#SBATCH -J viirs2ioda
#SBATCH -D /home/Mariusz.Pagowski/mapp_2018/src_omp
#SBATCH -o /scratch1/BMC/gsd-fv3-dev/MAPP_2018/pagowski/jedi/qslogs/%x.o%j
#SBATCH -e /scratch1/BMC/gsd-fv3-dev/MAPP_2018/pagowski/jedi/qslogs/%x.e%j

#sbatch --export=ALL sbatch_run_viirs2ioda.sh

. /etc/profile

. ~/MAPP_2018/.environ.ksh

module load contrib
module load anaconda/latest

set -x

python run_viirs2ioda.py



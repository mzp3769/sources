#!/bin/bash
#SBATCH -J recenter
#SBATCH -A chem-var
#SBATCH -n 1
#SBATCH -o /scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/misc/replaceVar-test/enkfgdas.20160606/12-recenterMPI/log.out
#SBATCH -e /scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/misc/replaceVar-test/enkfgdas.20160606/12-recenterMPI/log.out
#SBATCH -q debug
#SBATCH -t 00:10:00

cntldir=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/misc/replaceVar-test/enkfgdas.20160606/12-cntl/
ensmdir=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/misc/replaceVar-test/enkfgdas.20160606/12-recenterMPI/
tracer_prefix=20160606.180000.fv_tracer.res
RECENTEREXEC=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/expCodes/miscScripts/JEDI-Support/src_mpi/exec/recenter_aeros_mpi.x


ENS="1 2"

for mem0 in ${ENS}; do
    memstr=mem`printf %03d $mem0`  
    memdir=${ensmdir}/${memstr}/RESTART
    # need to generate files for each tile 1-6
    for n in $(seq 1 6); do
        export itile=$n
        
	mem_tracer=${memdir}/${tracer_prefix}.tile${itile}.nc
	mem_tracer1=${memdir}/${tracer_prefix}.tile${itile}.nc_beforeRecenter

        /bin/cp -r ${mem_tracer} ${mem_tracer1}
   done
done

cat << EOF > recenter_aeros_mpi.nl
&recenter_aeros_mpi_nml
 nens = 2
 dircntl = "${cntldir}"
 dirmem = "${ensmdir}"
 filecntl = "${tracer_prefix}.tile?.nc"
 filemem = "${tracer_prefix}.tile?.nc"
 varnames =  "sulf","bc1","bc2","oc1","oc2","dust1","dust2","dust3","dust4","dust5","seas1","seas2","seas3","seas4","seas5"
/ 
EOF

mpirun -np 10 ${RECENTEREXEC}
err=$?

exit $err

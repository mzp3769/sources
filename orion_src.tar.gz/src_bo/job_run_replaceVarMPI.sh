#!/bin/bash
#SBATCH -J replaceVar
#SBATCH -A chem-var
#SBATCH -n 10
#SBATCH -o /scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/misc/replaceVar-test/enkfgdas.20160601/00-replaceVarMPI/log.out
#SBATCH -e /scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/misc/replaceVar-test/enkfgdas.20160601/00-replaceVarMPI/log.out
#SBATCH -q debug
#SBATCH -t 00:10:00


#HOMEjedi=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/expCodes/fv3-bundle/V20201202/build
#. ${HOMEjedi}/jedi_module_base.hera
module load nco ncview ncl
module list
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${HOMEjedi}/lib/"

nmem=2
VARSREPLACEEXEC=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/expCodes/miscScripts/JEDI-Support/src_mpi/exec/replace_vars_mpi.x
datadir=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/misc/replaceVar-test/enkfgdas.20160606/12-replaceVarMPI
timeprefix=20160606.180000

cd ${datadir}
ln -sf ${VARSREPLACEEXEC} ${datadir}/



# we need to now do some ncks things on the deterministic run

imem=0
while [ ${imem} -le ${nmem} ]; do
    if [ ${imem} -eq 0 ]; then
       memstr="ensmean"
    else
       memstr="mem`printf %03d ${imem}`"
    fi

    memdir=${datadir}/${memstr}/RESTART/

    itile=1
    while [[ $itile -le 6 ]]; do
        gesfile_trcr=${memdir}/${timeprefix}.fv_tracer.res.tile${itile}.nc.ges
        anlfile_trcr=${memdir}/${timeprefix}.fv_tracer.res.tile${itile}.nc
        anlfile_trcr_jedi=${memdir}/${timeprefix}.fv_tracer.res.tile${itile}.nc.anl_jedi
	/bin/mv ${anlfile_trcr} ${anlfile_trcr_jedi}
	/bin/cp ${gesfile_trcr} ${anlfile_trcr}
  ((itile=itile+1))
done
((imem=imem+1))
done

anlfile_trcr_jedi=${timeprefix}.fv_tracer.res.tile?.nc.anl_jedi
anlfile_trcr=${timeprefix}.fv_tracer.res.tile?.nc

/bin/rm -rf replace_vars_mpi.nl
cat << EOF > replace_vars_mpi.nl
&replace_vars_mpi_nml
nens = ${nmem}
dirin = "./"
filein = "${anlfile_trcr_jedi}"
dirout = "./"
fileout = "${anlfile_trcr}"
varnames =  "sulf","bc1","bc2","oc1","oc2","dust1","dust2","dust3","dust4","dust5","seas1","seas2","seas3","seas4","seas5"
/
EOF

mpirun -np 10 ./replace_vars_mpi.x
err=$?
if  [ $err -ne 0 ]; then
    echo "ReplaceVars run failed and exit the program!!!"
    exit $err
else
    #/bin/rm -rf ${anlfile_trcr_jedi}
    echo ${anlfile_trcr_jedi}
fi

################################################################################
exit $err

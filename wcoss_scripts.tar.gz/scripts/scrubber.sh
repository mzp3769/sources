#!/bin/ksh

self=`whoami`

TMPDIR=/lfs/h2/oar/ptmp/${self}/w2h

ndate=~/bin/ndate

today=`$ndate | cut -c1-8`00


scrub_date=`$ndate -96 ${today}`
scrub_day=`echo $scrub_date | cut -c1-8`

echo "scrubbing $scrub_day"

rm -f ${TMPDIR}/enkfgdas.${scrub_day}??_grp??.tar 


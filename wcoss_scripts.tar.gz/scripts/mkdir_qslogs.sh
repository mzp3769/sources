#!/bin/ksh -l

if [[ ! -r /lfs/h2/oar/ptmp/mariusz.pagowski/w2h/qslogs ]]
then
    mkdir -p /lfs/h2/oar/ptmp/mariusz.pagowski/w2h/qslogs
fi

if [[ ! -r /lfs/h2/oar/ptmp/mariusz.pagowski/w2h/logs ]]
then
    mkdir -p /lfs/h2/oar/ptmp/mariusz.pagowski/w2h/logs
fi


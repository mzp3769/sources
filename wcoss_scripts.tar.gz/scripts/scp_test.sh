#!/bin/ksh

HERA=Mariusz.Pagowski@dtn-hera.fairmont.rdhpcs.noaa.gov:/scratch1/BMC/chem-var/pagowski/junk_scp/wcoss2

cd /u/mariusz.pagowski
scp w2h_ens_cron.sh $HERA

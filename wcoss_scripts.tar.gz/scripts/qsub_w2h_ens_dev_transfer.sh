#!/bin/ksh --login
#PBS -N w2h
#PBS -A ESRL-DEV
##PBS -l place=shared,select=1:ncpus=1:mem=4GB
#PBS -l select=1:ncpus=1:mem=100MB
#PBS -l walltime=00:05:00
#PBS -q dev_transfer
#PBS -o /lfs/h2/oar/ptmp/mariusz.pagowski/w2h/qslogs
#PBS -e /lfs/h2/oar/ptmp/mariusz.pagowski/w2h/qslogs


cd /u/mariusz.pagowski/w2h

. ./w2h_ens.sh



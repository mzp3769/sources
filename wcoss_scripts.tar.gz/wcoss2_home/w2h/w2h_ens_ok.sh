#!/bin/ksh 

self=`whoami`

PRODDIR=/lfs/h1/ops/prod/com/gfs/v16.2
STOREDIR_W=/dfs/write/oar/esrl/${self}/w2h
STOREDIR_R=/dfs/read/oar/esrl/${self}/w2h
TMPDIR_W=/lfs/h2/oar/ptmp/${self}/w2h_w
TMPDIR_R=/lfs/h2/oar/ptmp/${self}/w2h_r
TMPDIR=/lfs/h2/oar/ptmp/${self}/w2h
RECORDDIR_SW=${STOREDIR_W}/records
RECORDDIR_SR=${STOREDIR_R}/records
RECORDDIR_TW=${TMPDIR_W}/records
RECORDDIR_TR=${TMPDIR_R}/records
RECORDDIR_T=${TMPDIR}/records
LOGDIR_SW=${STOREDIR_W}/logs
LOGDIR_RW=${STOREDIR_R}/logs
LOGDIR_T=${TMPDIR}/logs
HERADTN=dtn-hera.fairmont.rdhpcs.noaa.gov
HERA="Mariusz.Pagowski@${HERADTN}:/scratch1/BMC/chem-var/pagowski/junk_scp/wcoss2"

ping -c 1 ${HERADTN}
if [[ $? -ne 0 ]]
then
    current_date=`date`
    echo "${HERADTN} not available at $current_date"
    exit 1
fi

nanals=20
ngroups=5
ntiles=6

if [[ ! -r ${TMPDIR} ]]
then
    mkdir -p ${TMPDIR}
fi

if [[ -r ${LOGDIR_SW} ]]
then
    rsync -azv ${LOGDIR_SW} ${TMPDIR_W}
fi

if [[ -r ${RECORDDIR_SW} ]]
then    
    rsync -azv ${RECORDDIR_SW} ${TMPDIR_W}
    record_date_w=`head -1 ${RECORDDIR_TW}/record.txt`
else
    record_date_w=0
fi
    
if [[ -r ${LOGDIR_SR} ]]
then
    rsync -azv ${LOGDIR_SR} ${TMPDIR_R}
fi

if [[ -r ${RECORDDIR_SR} ]]
then
    rsync -azv ${RECORDDIR_SR} ${TMPDIR_R}
    record_date_r=`head -1 ${RECORDDIR_TR}/record.txt`
else
    record_date_r=0
fi

cycle_frequency=6
((cycle_frequency_half=cycle_frequency/2))
((clean_frequency=cycle_frequency*2))

ENSDIR=${PRODDIR}

ndate=~/bin/ndate

if [[ $record_date_r < $record_date_w ]]
then
    /bin/cp -rP ${RECORDDIR_TW} ${TMPDIR}
else
    /bin/cp -rP ${RECORDDIR_RW} ${TMPDIR}
fi
    
record_date=`head -1 ${RECORDDIR_T}/record.txt`

echo "start_date=$record_date"

cycle_date=`$ndate +${cycle_frequency} ${record_date}`
cycle_datem=`$ndate -${cycle_frequency} ${cycle_date}`
restart_date_ctrl=`$ndate +${cycle_frequency} ${cycle_date}`
restart_date_ens=`$ndate +${cycle_frequency_half} ${cycle_date}`
restart_date_ensm=`$ndate -${cycle_frequency_half} ${cycle_date}`

yyyymmdd_c=`echo $cycle_date | cut -c1-8`
hh_c=`echo $cycle_date | cut -c9-10`

yyyymmdd_cm=`echo $cycle_datem | cut -c1-8`
hh_cm=`echo $cycle_datem | cut -c9-10`

yyyymmdd_r_ctrl=`echo $restart_date_ctrl | cut -c1-8`
hh_r_ctrl=`echo $restart_date_ctrl | cut -c9-10`

yyyymmdd_r_ens=`echo $restart_date_ens | cut -c1-8`
hh_r_ens=`echo $restart_date_ens | cut -c9-10`

yyyymmdd_r_ensm=`echo $restart_date_ensm | cut -c1-8`
hh_r_ensm=`echo $restart_date_ensm | cut -c9-10`

cd ${ENSDIR}

ensdir=enkfgdas.${yyyymmdd_c}/${hh_c}/atmos
ensdirm=enkfgdas.${yyyymmdd_cm}/${hh_cm}/atmos

ianal=1

while [[ $ianal -le $nanals ]]
do
    canal=mem`printf %03i $ianal`
    if [[ ! -r ${ENSDIR}/${ensdir}/${canal}/gdas.t${hh_c}z.sfcf006.nc ]]
    then
	echo "member $canal not found at ${yyyymmdd_c}${hh_c}"
	exit 1
    fi
    ((ianal=ianal+1))
done

if [[ ! -r ${LOGDIR_T} ]]
then
    mkdir -p ${LOGDIR_T}
fi

cd $ensdir

if [[ ! -r ${TMPDIR}/enkfgdas.${cycle_date}_grp01.tar || -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp01.log ]]
then
    tar -cf ${TMPDIR}/enkfgdas.${cycle_date}_grp01.tar mem00[1-4]/gdas.t${hh_c}z.sfcf006.nc > ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp01.log 2>&1 && scp ${TMPDIR}/enkfgdas.${cycle_date}_grp01.tar > ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp01.log 2>&1 ${HERA} &
fi

if [[ ! -r ${TMPDIR}/enkfgdas.${cycle_date}_grp02.tar || -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp02.log ]]
then
    tar -cf ${TMPDIR}/enkfgdas.${cycle_date}_grp02.tar mem00[5-8]/gdas.t${hh_c}z.sfcf006.nc > ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp02.log 2>&1 && scp ${TMPDIR}/enkfgdas.${cycle_date}_grp02.tar > ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp02.log 2>&1 ${HERA} &
fi

if [[ ! -r ${TMPDIR}/enkfgdas.${cycle_date}_grp03.tar || -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp03.log ]]
then
    tar -cf ${TMPDIR}/enkfgdas.${cycle_date}_grp03.tar mem009/gdas.t${hh_c}z.sfcf006.nc mem01[0-2]/gdas.t${hh_c}z.sfcf006.nc > ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp03.log 2>&1 && scp ${TMPDIR}/enkfgdas.${cycle_date}_grp03.tar > ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp03.log 2>&1 ${HERA} &
fi

if [[ ! -r ${TMPDIR}/enkfgdas.${cycle_date}_grp04.tar || -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp04.log ]]
then
    tar -cf ${TMPDIR}/enkfgdas.${cycle_date}_grp04.tar mem01[3-6]/gdas.t${hh_c}z.sfcf006.nc > ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp04.log 2>&1 && scp ${TMPDIR}/enkfgdas.${cycle_date}_grp04.tar > ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp04.log 2>&1 ${HERA} &
fi

if [[ ! -r ${TMPDIR}/enkfgdas.${cycle_date}_grp05.tar || -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp05.log ]]
then
    tar -cf ${TMPDIR}/enkfgdas.${cycle_date}_grp05.tar mem01[7-9]/gdas.t${hh_c}z.sfcf006.nc mem020/gdas.t${hh_c}z.sfcf006.nc > ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp05.log 2>&1 && scp ${TMPDIR}/enkfgdas.${cycle_date}_grp05.tar > ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp05.log 2>&1 ${HERA} &
fi

wait

for i in $(seq 1 $ngroups)
do
    ci=`printf %02i $i`
    if [[ -f ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp${ci}.log && ! -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp${ci}.log && -s ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp${ci}.log ]]
    then
	scp ${TMPDIR}/enkfgdas.${cycle_date}_grp${ci}.tar > ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp${ci}.log 2>&1 ${HERA} &
    fi
done

wait

if [[ -f ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp01.log && ! -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp01.log && -f ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp01.log && ! -s ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp01.log && -f ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp02.log && ! -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp02.log && -f ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp02.log && ! -s ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp02.log && -f ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp03.log && ! -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp03.log && -f ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp03.log && ! -s ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp03.log && -f ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp04.log && ! -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp04.log && -f ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp04.log && ! -s ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp04.log && -f ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp05.log && ! -s ${LOGDIR_T}/tar_enkfgdas.${cycle_date}_grp05.log && -f ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp05.log && ! -s ${LOGDIR_T}/scp_enkfgdas.${cycle_date}_grp05.log ]] 
then
    sed -i 1i\ ${cycle_date} ${RECORDDIR_T}/record.txt
    scp ${RECORDDIR_T}/record.txt ${HERA}
    record_date_clean=`$ndate -${clean_frequency} ${record_date}`
    rm -f ${LOGDIR_T}/*${record_date_clean}*
    rsync -azv ${RECORDDIR_T} ${STOREDIR_W}
    rsync -azv ${LOGDIR_T} ${STOREDIR_W}
fi

end_date=`head -1 ${RECORDDIR_T}/record.txt`

echo "end_date=$end_date"

exit 0


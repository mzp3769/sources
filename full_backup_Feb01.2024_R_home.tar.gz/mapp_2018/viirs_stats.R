#to figure VIIRS biases from Shobha, Dec 2021

aod_bracket <- c(0.,0.1,0.8)

#global spring 
bs <- c(0.5358,-0.0934,0.1691)
bo <- c(-0.0541,0.0046,-0.1638)
us <- c(0.2688,0.2520,0.2005)
uo <- c(0.0232,0.0428,0.0635)

#global summer
bs <- c(0.4839,0.0497,-0.0158)
bo <- c(-0.0516,-0.0130,0.1881)
us <- c(0.2418,0.2575,0.2784)
uo <- c(0.0251,0.0252,-0.0188)

#global fall
bs <- c(0.4212,-0.1037,0.3002)
bo <- c(-0.0423,0.0012,-0.2559)
us <- c(0.3023,0.2579,0.1193)
uo <- c(0.0217,0.0289,0.1646)

#global winter
bs <- c(0.4798,-0.2000,0.1540)
bo <- c(-0.0384,0.0185,-0.2790)
us <- c(0.2945,0.3042,0.3106)
uo <- c(0.0225,0.0386,-0.0198)

#global all seasons
bs <- c(0.4489,-0.0865,0.1395)
bo <- c(-0.0446,0.0040,-0.1195)
us <- c(0.2761,0.2858,0.2262)
uo <- c(0.0235,0.0306,0.0639)

stats <- function(value,bracket,slope,offset) {
      if (value >= bracket[1] && value < bracket[2] ) {
      	 stat <- slope[1]*value+offset[1] 
      } else if (value >= bracket[2] && value <= bracket[3] ) {
      	 stat <- slope[2]*value+offset[2]       	 
      }	else {
         stat <-  slope[3]*value+offset[3]
      }
      return(stat)
}

aod_min <- 0.
aod_max <- 5.

aods <- seq(aod_min,aod_max,by=0.05)

aod_bias <- sapply(aods,stats,bracket=aod_bracket,slope=bs,offset=bo)
aod_uncert <- sapply(aods,stats,bracket=aod_bracket,slope=us,offset=uo)

picname <- "./pics/viirs_bias.png"
png(picname,width = 900, height = 500,bg="white")
plot(aods,aod_bias,type="p",pch=20,cex=0.5,col="blue")
x <- aods
y <- aod_bias
regression <- lm(y ~ poly(x, 2, raw=TRUE))
coeffs_bias <- as.numeric(coefficients(regression))
bias_fit <- coeffs_bias[1]+coeffs_bias[2]*x+coeffs_bias[3]*x^2       
points(aods,bias_fit,pch=20,cex=0.5,col="red")
dev.off()

picname <- "./pics/viirs_debiased.png"
png(picname,width = 500, height = 500,bg="white")
plot(aods,aods-aod_bias,type="p",pch=20,cex=0.5,col="blue")
points(aods,aods-bias_fit,type="p",pch=20,cex=0.5,col="red")
dev.off()

picname <- "./pics/viirs_error.png"
png(picname,width = 900, height = 500,bg="white")
plot(aods,aod_uncert,type="p",pch=20,cex=0.5,col="blue")
x <- aods
y <- aod_uncert
regression <- lm(y ~ poly(x, 2, raw=TRUE))
coeffs_uncert <- as.numeric(coefficients(regression))
uncert_fit <- coeffs_uncert[1]+coeffs_uncert[2]*x+coeffs_uncert[3]*x^2
points(aods,uncert_fit,pch=20,cex=0.5,col="red")
dev.off()


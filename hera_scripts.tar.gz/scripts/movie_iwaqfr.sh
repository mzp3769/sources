#!/bin/sh

cd /scratch1/BMC/gsd-fv3-dev/MAPP_2018/pagowski/ncl/process

convert -set delay 60 -loop 5 fig_*png  movie_iwaqfr.gif


#!/bin/ksh

#see examples for whole directories at
#https://disc.gsfc.nasa.gov/information/howto?title=How%20to%20Download%20Data%20Files%20from%20HTTPS%20Service%20with%20wget

#https://portal.nccs.nasa.gov/datashare/gmao/geos-fp/das/Y2021/M08/D16/

#data description https://gmao.gsfc.nasa.gov/pubs/docs/Bosilovich785.pdf

#AOD at 550nm is TOTEXTTAU averged over 3 hours 
#(e.g. 1:30 is average 00:00 to 3:00 UTC) 

touch ~/.urs_cookies

start_date=2022042700
end_date=2022042700
cycle_frequency=6

http_geos="https://portal.nccs.nasa.gov/datashare/gmao/geos-fp/das"
prefix_geos_aod="GEOS.fp.asm.tavg3_2d_aer_Nx"
prefix_geos_aero="GEOS.fp.asm.inst3_3d_aer_Nv"

filelist="filelist.txt"

cd /scratch1/BMC/gsd-fv3-dev/MAPP_2018/pagowski/DATA/MODEL/geos/akbkll

/bin/rm -f $filelist

ndate=~/bin/ndate

ident=$start_date

while [[ $ident -le $end_date ]]
do

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hour=`echo "${ident}" | cut -c9-10`

    ident_m=`$ndate -2 $ident`
    ident_p=`$ndate +1 $ident`

    year_m=`echo "${ident_m}" | cut -c1-4`
    month_m=`echo "${ident_m}" | cut -c5-6`
    day_m=`echo "${ident_m}" | cut -c7-8`
    hour_m=`echo "${ident_m}" | cut -c9-10`

    year_p=`echo "${ident_p}" | cut -c1-4`
    month_p=`echo "${ident_p}" | cut -c5-6`
    day_p=`echo "${ident_p}" | cut -c7-8`
    hour_p=`echo "${ident_p}" | cut -c9-10`


cat << EOF >> $filelist 
${http_geos}/Y${year}/M${month}/D${day}/${prefix_geos_aero}.${year}${month}${day}_${hour}00.V01.nc4
${http_geos}/Y${year_m}/M${month_m}/D${day_m}/${prefix_geos_aod}.${year_m}${month_m}${day_m}_${hour_m}30.V01.nc4
${http_geos}/Y${year_p}/M${month_p}/D${day_p}/${prefix_geos_aod}.${year_p}${month_p}${day_p}_${hour_p}30.V01.nc4
EOF
    ident=`$ndate $cycle_frequency $ident`
done
    
wget --load-cookies ~/.urs_cookies --save-cookies ~/.urs_cookies --keep-session-cookies --content-disposition -i $filelist


#!/usr/bin/env python
from datetime import datetime
from datetime import timedelta
from ecmwfapi import ECMWFDataServer
import cdsapi

server = ECMWFDataServer(url="https://api.ecmwf.int/v1",
                         key="81bc290717a0bf7ecfd45e1ece98fd1b",
                         email="mariusz.pagowski@noaa.gov")

sdate=2022042700
edate=2022042700

hint=24

def ndate(cdate,hinc):
    yy=int(str(cdate)[:4])
    mm=int(str(cdate)[4:6])
    dd=int(str(cdate)[6:8])
    hh=int(str(cdate)[8:10])
    dstart=datetime(yy,mm,dd,hh)
    dnew=dstart+timedelta(hours=hinc)
    dnewint=int(str('%4.4d' % dnew.year)+str('%2.2d' % dnew.month)+
                str('%2.2d' %dnew.day)+str('%2.2d' % dnew.hour))
    return dnewint

cdate=sdate
while (cdate<=edate):
  yy=str(cdate)[:4]
  mm=str(cdate)[4:6]
  dd=str(cdate)[6:8]
  hh=str(cdate)[8:10]
  datestr="%s-%s-%s" %(yy,mm,dd)
  output_aods="/scratch1/BMC/gsd-fv3-dev/MAPP_2018/pagowski/DATA/MODEL/cams/pll_orig/cams_aods_%s.nc" %str(cdate)[:8]
  output_aeros="/scratch1/BMC/gsd-fv3-dev/MAPP_2018/pagowski/DATA/MODEL/cams/pll_orig/cams_aeros_%s.nc" %str(cdate)[:8]
  print('%s'%(datestr))

  c = cdsapi.Client()

  c.retrieve(
      'cams-global-atmospheric-composition-forecasts',
      {
          'date': datestr,
          'format': 'netcdf',
          'variable': [
              'sea_salt_aerosol_0.03-0.5um_mixing_ratio',
              'sea_salt_aerosol_0.5-5um_mixing_ratio',
              'sea_salt_aerosol_5-20um_mixing_ratio',
              'dust_aerosol_0.03-0.55um_mixing_ratio',
              'dust_aerosol_0.55-0.9um_mixing_ratio',
              'dust_aerosol_0.9-20um_mixing_ratio',
              'hydrophilic_organic_matter_aerosol_mixing_ratio',
              'hydrophobic_organic_matter_aerosol_mixing_ratio',
              'hydrophilic_black_carbon_aerosol_mixing_ratio',
              'hydrophobic_black_carbon_aerosol_mixing_ratio',
              'sulphate_aerosol_mixing_ratio',
          ],
          'pressure_level': [
              '100', '250', '400', '500',
              '600', '700', '850', '925', '1000',
          ],
          'leadtime_hour': '0',
          'time': [
              '00:00', '06:00', '12:00', '18:00',
          ],
          'type': 'analysis',
          'area': [
              '90', '-180', '-90', '180',
          ]
      },
      output_aeros)

  c.retrieve(
      'cams-global-atmospheric-composition-forecasts',
      {
          'date': datestr,
          'format': 'netcdf',
          'variable': [
              'total_aerosol_optical_depth_469nm',
              'total_aerosol_optical_depth_550nm',
              'total_aerosol_optical_depth_670nm',
              'total_aerosol_optical_depth_865nm',
              'total_aerosol_optical_depth_1240nm',
          ],
          'leadtime_hour': '0',
          'time': [
              '00:00', '06:00', '12:00', '18:00',
          ],
          'type':'analysis',
          'area': [
              '90', '-180', '-90', '180',
          ]
      },
      output_aods)

  cdate=ndate(cdate,hint)


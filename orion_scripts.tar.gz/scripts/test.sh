#!/bin/bash
#SBATCH -J sig2nc_run 
#SBATCH -q batch
#SBATCH -p bigmem
#SBATCH -A gsd-fv3-dev
##SBATCH -A chem-var
#SBATCH -N 8
#SBATCH -D /home/mpagowsk/mapp_2018/scripts
#SBATCH -n 20
#SBATCH -t 7:59:00
##SBATCH --open-mode=truncate
#SBATCH -o /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.o%j
#SBATCH -e /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.e%j

#sbatch --export=ALL,start=2015121300 sbatch_nems2nc_jediaero_met.sh

set -x

start=2015121800
end=2015121800
export yyyymmddhh_start=$start
export yyyymmddhh_end=$end

#try skipping source below
#source /home/mpagowsk/mapp_2018/scripts/machine-setup.sh

python /home/mpagowsk/mapp_2018/scripts/nems2nc_jediaero_met.py


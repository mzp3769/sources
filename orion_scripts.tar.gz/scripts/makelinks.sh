#!/bin/ksh

INDIR=/work/noaa/gsd-fv3-dev/pagowski/DATA/MET_ANALYSES/nemsio
#set -A dirs 2016050418 2016050500 2016050506 2016050512 2016050600 2016050606 2016050612 2016050618 2016050700 2016050706 2016050712 2016050718 2016050800 2016050806 2016050818 2016050900 2016050906 2016050912 2016050918 2016051000 2016051006

#set -A dirs 2016050412 2016050518
set -A dirs 2016050212

for dir in ${dirs[*]}
do
    indir=${INDIR}/${dir}
    echo $dir
    cd $indir
    for file in sanl_${dir}_mem???
    do
	newfile=`echo $file | sed -e "s/sanl/siganl/g"`
	ln -sf $file $newfile
    done
done


#!/bin/ksh

. /etc/profile

. ~/.python

start_date=2016090100
end_date=2016093018


ndate=~/bin/ndate

cycle_frequency=6

maindir=/work/noaa/gsd-fv3-dev/pagowski/DATA/MODEL/fv3/ll_reanalysis
indir=${maindir}/201609
manifestdir=/work/noaa/gsd-fv3-dev/pagowski/nceimanifest/make_manifest

cd $indir

ident=$start_date

while [[ $ident -le $end_date ]]
do

    python ${manifestdir}/make_manifest.py NARA-1.0_aero_${ident}.nc4

    python ${manifestdir}/make_manifest.py NARA-1.0_AOD_${ident}.nc4

    echo $ident

    ident=`$ndate +${cycle_frequency} $ident`

done


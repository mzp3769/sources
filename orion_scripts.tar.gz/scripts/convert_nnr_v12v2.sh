#!/bin/ksh

NNRDIR_v1=/work/noaa/gsd-fv3-dev/pagowski/DATA/OBS/NNR/thinned_debiased_C192_v1

NNRDIR_v2=/work/noaa/gsd-fv3-dev/pagowski/DATA/OBS/NNR/thinned_debiased_C192_v2

exec=/work/noaa/gsd-fv3-dev/pagowski/jedi/build/fv3-bundle_updated/bin/ioda-upgrade.x

cd $NNRDIR_v1

for file in *.nc
do 
    echo $file
    . ~/.nc
    ncks -O -4 --fix_rec_dmn all $file ${NNRDIR_v2}/${file}_v1
    . ~/.jedi
    ${exec} ${NNRDIR_v2}/${file}_v1 ${NNRDIR_v2}/${file}
    /bin/rm ${NNRDIR_v2}/${file}_v1
done


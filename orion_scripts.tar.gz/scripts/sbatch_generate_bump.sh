#!/bin/ksh
#SBATCH -J bump
##SBATCH -q batch
##SBATCH -q debug
#SBATCH -q urgent
#SBATCH -p orion
##SBATCH -p bigmem
##SBATCH -A gsd-fv3-dev
##SBATCH -A chem-var
#SBATCH -A ap-fc
##SBATCH -A wrf-chem
#SBATCH -D /home/mpagowsk/mapp_2018/scripts
#SBATCH -n 48
#SBATCH -t 0:10:00
#SBATCH -o /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.o%j
#SBATCH -e /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.e%j

#sbatch --export=ALL sbatch_generate_bump.sh

. /etc/profile
. /apps/lmod/lmod/init/sh
. ~/.jedi

#ulimit -s unlimited
#ulimit -v unlimited

start_date=2016010100
end_date=2016010100

ndate=~/bin/ndate

cycle_frequency=6

export JEDI=/work/noaa/gsd-fv3-dev/pagowski/jedi
export JEDIYAML=${JEDI}/yamls
export JEDIBUILD=${JEDI}/build/fv3-bundle_updated

export JEDIBIN=${JEDIBUILD}/bin
export JEDICODE=${JEDI}/code/fv3-bundle_stable/fv3-jedi
export JEDIDATA=${JEDICODE}/test/Data
export JEDIFIELDS=${JEDI}/fieldsets

MAINDIR=/work/noaa/gsd-fv3-dev/pagowski

TMPDIR=${MAINDIR}/tmpdir/workdir_bump

# Run time debugging options
# --------------------------
export OOPS_TRACE=0
export OOPS_DEBUG=0
export OOPS_LOG=0

rm -rf $TMPDIR
mkdir -p $TMPDIR

cd $TMPDIR

ln -sf ${JEDIFIELDS} .
ln -sf ${JEDIDATA}/fv3files .

/bin/cp ${JEDIYAML}/bumpparameters_nicas_gfs_aero_logp_2x4.yaml bumpparameters_nicas_gfs_aero_logp.yaml

#/bin/cp ${JEDIYAML}/bumpparameters_nicas_gfs_aero_logp_4x4.yaml bumpparameters_nicas_gfs_aero_logp.yaml

INDIR=${MAINDIR}/jedi_convert/inputs
OUTDIR=${MAINDIR}/jedi_bump/outputs

if [[ ! -r ${OUTDIR} ]]
then
    mkdir -p ${OUTDIR}
fi

rm -rf inputs outputs

ln -sf ${INDIR} inputs
ln -sf ${OUTDIR} outputs

ident=$start_date

while [[ $ident -le $end_date ]]
do

    echo $ident

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hr=`echo "${ident}" | cut -c9-10`

    cd $TMPDIR

    export jobtype=bumpparameters_nicas_gfs_aero_logp

    echo "srun -n $SLURM_NTASKS  $JEDIBIN/fv3jedi_parameters.x ${jobtype}.yaml"

    srun -n $SLURM_NTASKS  $JEDIBIN/fv3jedi_parameters.x ${jobtype}.yaml

    /bin/cp fv3jedi_bumpparameters_* ${OUTDIR}

    ident=`$ndate +${cycle_frequency} $ident`

done




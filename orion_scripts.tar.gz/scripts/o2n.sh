#!/bin/bash -l

ident=2015121018

. /etc/profile

module load python/3.7.5

set -x

globus login

checkFile=test2.txt

orionEP=84bad22e-cb80-11ea-9a44-0255d23c44ef
#niagEP=21467dd0-afd6-11ea-8f12-0a21f750d19b
niagEP=1bfd8a79-52b2-4589-88b2-0648e0c0b35d

orionDir=/home/mpagowsk/mapp_2018/scripts
orionLogDir=/work/noaa/gsd-fv3-dev/pagowski/o2nlogs
niagDir=/collab1/data/Mariusz.Pagowski/from_orion/${ident}
cd ${orionDir}

ls -l ${orionDir}/${checkFile} > ${orionLogDir}/tmp1_${ident}.log 
size1=`tail -n 1 ${orionLogDir}/tmp1_${ident}.log | awk '{print $5}'`

globus ls -l ${niagEP}:${niagDir} --filter "${checkFile}" > ${orionLogDir}/tmp2_${ident}.log 2>&1 

size2=`tail -n 1 ${orionLogDir}/tmp2_${ident}.log | awk '{print $7}'`

if echo "$size2" | grep -qE '^[0-9]+$'; then
    if [[ ${size1} -eq ${size2} ]];then
	rc=0
    else
	rc=1
    fi
    echo ${size1}
    echo ${size2}
else
    rc=1
fi

if [[ $rc -eq 0 ]]; then
    echo "Backup is already done on Niagara !!!!!!!!"
    exit $rc
else
    echo "Start Niagara backup !!!!!!!!"
    
    globus mkdir ${niagEP}:${niagDir} > ${orionLogDir}/tmp3_${ident}.log 2>&1 
    globus transfer ${orionEP}:${orionDir}/ ${niagEP}:${niagDir}/ --batch --label "CLI batch" < ${orionDir}/gtInputFiles.in >& ${orionLogDir}/gtInputFiles_ID_${ident}.log

    gID=`tail -n 1 ${orionLogDir}/gtInputFiles_ID_${ident}.log | awk '{print $3}'`
    echo ${gID}

    echo "Waiting on 'gt transfer' task '$gID'"
    globus task wait "${gID}"
    rc=$?
    echo $rc
    if [[ $rc -eq 0 ]];then
       echo "Niagara backup was done successfully!!!!!!"
       exit $rc
    else
       echo "Niagara backup  failed for $rc at "`date`
       exit $rc
    fi
fi


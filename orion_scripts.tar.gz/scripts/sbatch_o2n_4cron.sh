#!/bin/ksh -l
#SBATCH -J 4cron
##SBATCH -q debug
#SBATCH -p service
#SBATCH -A gsd-fv3-dev
#SBATCH -n 1
#SBATCH -D /home/mpagowsk/mapp_2018/scripts
##SBATCH --ntasks-per-node=1
#SBATCH -t 0:29:00
#SBATCH -e /work/noaa/gsd-fv3-dev/pagowski/o2nlogs/qslogs/%x.e%j
#SBATCH -o /work/noaa/gsd-fv3-dev/pagowski/o2nlogs/qslogs/%x.o%j

#sbatch --export=ALL sbatch_o2n_4cron.sh

crondir=/work/noaa/gsd-fv3-dev/pagowski/4cron

orionEP=2cf2c281-cafc-4b20-900b-45abeb042854
#herculesEP=869912fe-f6de-46c0-af10-b22efd84a022

orionDir=${crondir}
orionLogDir=/work/noaa/gsd-fv3-dev/pagowski/o2nlogs

#niagEP=21467dd0-afd6-11ea-8f12-0a21f750d19b
niagEP=1bfd8a79-52b2-4589-88b2-0648e0c0b35d
niagDir=/collab1/data/Mariusz.Pagowski/from_orion/4cron

heraEP=8417f291-7633-4b36-b653-5bfcbf8b2800

. /etc/profile

module load python/3.7.5


cfile=4cron.txt

cd $crondir
echo `date` >> $cfile
ident=`date +%Y_%j`

ls -1 $cfile > /dev/null 2>&1 
rcc=$?

if [[ $rcc -eq 0 ]]
then
    header=`head $cfile`
    echo $header
else
    string="${cfile}_no_created"
    mailx -s $string mariusz.pagowski@noaa.gov < /dev/null > /dev/null
    exit 1
fi


echo "Transfering $cfile"
globus transfer ${orionEP}:${orionDir}/${cfile} ${niagEP}:${niagDir}/${cfile} > ${orionLogDir}/4cron_${ident}.log

gID=`tail -n 1 ${orionLogDir}/4cron_${ident}.log | awk '{print $3}'`
echo ${gID}

echo "Waiting on 'globus transfer' task '$gID'"
globus task wait "${gID}"
rcc=$?

if [[ $rcc -eq 0 ]];then
    echo "Niagara backup of $cfile was done successfully!!!!!!"
else
    string="o2n_transfer_failed"
    mailx -s $string mariusz.pagowski@noaa.gov < /dev/null > /dev/null
fi




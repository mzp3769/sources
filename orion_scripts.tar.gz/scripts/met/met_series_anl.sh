#!/bin/ksh

set -x

SDATE=2016060100
EDATE=2016060218
INC_H=6

. /etc/profile
. ~/mapp_2018/.environ_met.ksh

BASE=~/mapp_2018/scripts/met

INPUTBASE="/work/noaa/gsd-fv3-dev/pagowski/MODEL"
OUTPUTBASE="${INPUTBASE}/metstats"

GRID_NAME="G003"

PLEV="100 250 400 500 600 700 850 925 1000"

MODELNAME="fv3"
FCSTDIR=$INPUTBASE/${MODELNAME}/pll
FCSTINPUTTMP=${MODELNAME}"_aeros_{init?fmt=%Y%m%d%H}_pll.nc"

OBSNAME="cams"
#OBSNAME="m2"
OBSDIR=$INPUTBASE/${OBSNAME}/pll
OBSINPUTTMP=${OBSNAME}"_aeros_{init?fmt=%Y%m%d}_pll.nc"

WRKD=/work/noaa/gsd-fv3-dev/pagowski/tmpdir/workdir_SeriesAnalysis
NDATE=~/bin/ndate
CONFIG_DIR=$BASE/config
MAINCONF=$CONFIG_DIR/main.conf.IN
MASKS_DIR=${INPUTBASE}/masks/nc_mask
PY_DIR=$BASE/python
MASTER=$METPLUS_PATH/ush/master_metplus.py




FCSTPATH=$INPUTBASE/FV3/VIIRS/pll
FCST_Head="fv3_aeros_"
FCSTSUFF="_pll.nc"
FCSTFILETMP="${FCST_Head}*${FCSTSUFF}"
FCST_NAME="FV3"
FCSTVARS="SEASFINE SEASMEDIUM SEASCOARSE DUSTFINE DUSTMEDIUM DUSTCOARSE OCPHILIC OCPHOBIC BCPHILIC BCPHOBIC SO4"
#FCSTVARS="aermr01 aermr02 aermr03 aermr04 aermr05 aermr06 aermr07 aermr08 aermr09 aermr10 aermr11"

OBSPATH=$INPUTBASE/MERRA2/pll
OBS_Head="m2_aeros_"
OBSSUFF="_pll.nc"
OBSFILETMP="${OBS_Head}*${OBSSUFF}"
OBS_NAME="MERRA2"
OBSVARS="SEASFINE SEASMEDIUM SEASCOARSE DUSTFINE DUSTMEDIUM DUSTCOARSE OCPHILIC OCPHOBIC BCPHILIC BCPHOBIC SO4"


typeset -a FCSTVARLIST
vidx=0
for FVAR in $FCSTVARS
do 
   FCSTVARLIST[$vidx]=$FVAR
   let vidx=vidx+1
done
typeset -a OBSVARLIST
vidx=0
for OVAR in $OBSVARS
do
   OBSVARLIST[$vidx]=$OVAR
   let vidx=vidx+1
done
nvar=${#FCSTVARLIST[*]}
echo $nvar
# plev 100, 250, 400, 500, 600, 700, 850, 925, 1000
#typeset -a PLEVLIST=(100 250 400 500 600 700 800 850 900 925 950 1000)

nl=0
typeset -a PLEVLIST
typeset -a NCLVIDXLIS
for PRES in $PLEV
do
  PLEVLIST[$nl]=${PRES}
  NCLVIDXLIST[$nl]=$nl
  let nl=nl+1
done
nplv=${#PLEVLIST[*]}

cd $WRKD
mkdir -p $WRKD/fcst $WRKD/obs

FCSTDIR=$WRKD/fcst
OBSDIR=$WRKD/obs

CDATE=$SDATE
while [ $CDATE -le $EDATE ];
do
  ln -sf $FCSTPATH/${FCST_Head}${CDATE}${FCSTSUFF} ./fcst
  ln -sf $OBSPATH/${OBS_Head}${CDATE}${OBSSUFF} ./obs
  CDATE=`$NDATE $CDATE $INC_H`
done

nv=5
while [[ $nv == 5 ]]; #-lt $nvar ]];
do
np=6
while [[ $np == 6 ]]; #-lt $nplv ]];
do

PLEV="${PLEVLIST[$np]}"
FCST_VAR="${FCSTVARLIST[$nv]}"
case $FCSTSUFF in 
.nc)
   FCST_VARLEV="\"(0,${NCLVIDXLIST[$np]},*,*)\""
;;
*)
FCST_VARLEV="P${PLEVLIST[$np]}"
;;
esac

OBS_VAR="${OBSVARLIST[$nv]}"
OBS_VARLEV="\"(0,${NCLVIDXLIST[$np]},*,*)\""
FCST_VARLEV=${OBS_VARLEV}

OUTPUTTMP="${OBS_VAR}_${PLEV}hPa.nc"

echo $FCST_VAR $FCST_VARLEV
echo $OBS_VAR $OBS_VARLEV
echo $OUTPUTTMP

cat $MAINCONF | sed s:_MET_PATH_:${MET_PATH}:g \
              | sed s:_INPUTBASE_:${INPUTBASE}:g \
              | sed s:_OUTPUTBASE_:${OUTPUTBASE}:g \
              > ./main.conf 

cat $INCONFIG | sed s:_SDATE_:${SDATE}:g \
              | sed s:_EDATE_:${EDATE}:g \
              | sed s:_INC_H_:${INC_H}:g \
              | sed s:_BASE_:${BASE}:g \
              | sed s:_GRID_NAME_:${GRID_NAME}:g \
              | sed s:_FCST_NAME_:${FCST_NAME}:g \
              | sed s:_OBS_NAME_:${OBS_NAME}:g \
              | sed s:_FCST_VAR_:${FCST_VAR}:g \
              | sed s:_FCST_VARLEV_:${FCST_VARLEV}:g \
              | sed s:_OBS_VAR_:${OBS_VAR}:g \
              | sed s:_OBS_VARLEV_:${OBS_VARLEV}:g \
              | sed s:_FCSTDIR_:${FCSTDIR}:g \
              | sed s:_OBSDIR_:${OBSDIR}:g \
              | sed s:_FCSTFILETMP_:"${FCSTFILETMP}":g \
              | sed s:_OBSFILETMP_:"${OBSFILETMP}":g \
              | sed s:_OUTPUTTMP_:${OUTPUTTMP}:g \
              > ./SeriesAnalysis.${OBS_VAR}_${PLEV}hPa.conf


$MASTER -c ./SeriesAnalysis.${OBS_VAR}_${PLEV}hPa.conf -c ./main.conf

let np=np+1
done
let nv=nv+1
done

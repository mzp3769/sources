#!/bin/sh
#
# Usage: ./runmet_series_anl_fv3-cams.sh
# BASE: The path
# INPUTBASE: the path saved dataset files.

set -x 

proj_account="chem-var"
popts="1/1"

metrun=met_series_anl
outdir=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/expCodes/METplus-diag/diagOutput/

# BASE: The path to METplus package
# INPUTBASE: the path saved dataset files.
export BASE=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/expCodes/METplus-diag/METplus_pkg/
export INPUTBASE=/scratch1/BMC/gsd-fv3-dev/MAPP_2018/bhuang/JEDI-2020/JEDI-FV3/expCodes/METplus-diag/data/

export SDATE=2016060100
export EDATE=2016063018
export INC_H=6

#define model resolution for stat
export GRID_NAME="G003"
GRID_DEG="1.0deg"
#export GRID_NAME="G002"
#GRID_DEG="2.5deg"

# set fcst and obs varibales
# need to further set fcst and obs model levels in met_series_anl.sh
export FCST_NAME="FV3"
export FCSTPATH=$INPUTBASE/FV3/VIIRS/pll
export FCST_HEAD_aeros="fv3_aeros_"
export FCST_SUFF_aeros="_pll.nc"

export FCST_HEAD_aods="fv3_aods_"
export FCST_SUFF_aods="_ll.nc"

export FCST_HEAD_int="fv3_aeros_int_"
export FCST_SUFF_int="_pll.nc"

#export OBS_NAME="CAMS"
#export OBSPATH=$INPUTBASE/CAMS/pll
#export OBS_HEAD_aeros="cams_aeros_"
#export OBS_SUFF_aeros="_sdtotals.nc"
#export OBS_HEAD_aods="cams_aods_"
#export OBS_SUFF_aods=".nc"

export OBS_NAME="MERRA2"
export OBSPATH=$INPUTBASE/MERRA2/pll
export OBS_HEAD_aeros="m2_aeros_"
export OBS_SUFF_aeros="_pll.nc"

export OBS_HEAD_aods="m2_aods_"
export OBS_SUFF_aods="_ll.nc"

export OBS_HEAD_int="m2_aeros_int_"
export OBS_SUFF_int="_pll.nc"

WRKDTOP=$outdir/wrk-${FCST_NAME}-${OBS_NAME}-${SDATE}-${EDATE}-${GRID_DEG}/${metrun}/

# set aerosol varibales to be evaluated
#CAMSiRA (EAC4)		MERRA2/GSDChem
#DUSTTOTAL		DUSTTOTAL
#SEASTOTAL		SEASTOTAL
#aermr01		SEASFINE
#aermr02		SEASMEDIUM
#aermr03		SEASCOARSE
#aermr04		DUSTFINE
#aermr05		DUSTMEDIUM
#aermr06		DUSTCOARSE
#aermr07		OCPHILIC
#aermr08		OCPHOBIC
#aermr09		BCPHILIC
#aermr10		BCPHOBIC
#aermr11		SO4
#aod550			AODANA/aod

#nvars=7
#FCSTVARS=(DUSTTOTAL SEASTOTAL OCPHILIC OCPHOBIC BCPHILIC BCPHOBIC SO4)
#OBSVARS=(DUSTTOTAL SEASTOTAL OCPHILIC OCPHOBIC BCPHILIC BCPHOBIC SO4)
nvars=3
FCSTVARS=(CPHOBIC CPHILIC CTOTAL)
OBSVARS=(CPHOBIC CPHILIC CTOTAL)

#FCSTVARS_int=(DUSTTOTAL_INTEGRAL SEASTOTAL_INTEGRAL OCPHILIC_INTEGRAL OCPHOBIC_INTEGRAL BCPHILIC_INTEGRAL BCPHOBIC_INTEGRAL SO4_INTEGRAL)
#OBSVARS_int=(DUSTTOTAL_INTEGRAL SEASTOTAL_INTEGRAL OCPHILIC_INTEGRAL OCPHOBIC_INTEGRAL BCPHILIC_INTEGRAL BCPHOBIC_INTEGRAL SO4_INTEGRAL)

nvars=3
FCSTVARS_int=(CPHOBIC_INTEGRAL CPHILIC_INTEGRAL CTOTAL_INTEGRAL)
OBSVARS_int=(CPHOBIC_INTEGRAL CPHILIC_INTEGRAL CTOTAL_INTEGRAL)


if [ -d /glade/scratch ]; then
   export machine=Cheyenne
   export subcmd=$BASE/ush/sub_ncar
elif [ -d /scratch1/NCEPDEV/da ]; then
   export machine=Hera
   export subcmd=$BASE/ush/sub_hera
fi


#Process aerosol species
for ((ivar=0;ivar<${nvars};ivar++))
do
    export FCST_VAR=${FCSTVARS[ivar]}
    export FCST_HEAD=${FCST_HEAD_aeros}
    export FCST_SUFF=${FCST_SUFF_aeros}
    export OBS_VAR=${OBSVARS[ivar]}
    export OBS_HEAD=${OBS_HEAD_aeros}
    export OBS_SUFF=${OBS_SUFF_aeros}
    export WRKD=${WRKDTOP}/${FCST_VAR}-${OBS_VAR}
    export DATA=$WRKD/tmp
    export OUTPUTBASE=${WRKD}
    export SIGLEV="FALSE"
    export VAR_AOD="FALSE"

    cd $WRKD
    #rm -rf $WRKD/*
    /bin/sh $subcmd -a $proj_account -p $popts -j $metrun-${FCST_NAME}.${FCST_VAR}-${OBS_NAME}.${OBS_VAR} -o ${WRKD}/$metrun-${FCST_NAME}.${FCST_VAR}-${OBS_NAME}.${OBS_VAR}.out -q batch -t 02:19:00 -r /1 $BASE/scripts/${metrun}.sh
    sleep 2

#    export FCST_VAR=${FCSTVARS_int[ivar]}
#    export FCST_HEAD=${FCST_HEAD_int}
#    export FCST_SUFF=${FCST_SUFF_int}
#    export OBS_VAR=${OBSVARS_int[ivar]}
#    export OBS_HEAD=${OBS_HEAD_int}
#    export OBS_SUFF=${OBS_SUFF_int}
#    export WRKD=${WRKDTOP}/${FCST_VAR}-${OBS_VAR}-INTEGRAL
#    export DATA=$WRKD/tmp
#    export OUTPUTBASE=${WRKD}
#    export SIGLEV="TRUE"
#    export VAR_AOD="FALSE"
#
#    cd $WRKD
#    #rm -rf $WRKD/*
#    /bin/sh $subcmd -a $proj_account -p $popts -j $metrun-${FCST_NAME}.${FCST_VAR}-${OBS_NAME}.${OBS_VAR} -o ${WRKD}/$metrun-${FCST_NAME}.${FCST_VAR}-${OBS_NAME}.${OBS_VAR}.out -q batch -t 02:29:00 -r /1 $BASE/scripts/${metrun}.sh
#    sleep 2
done

exit

#Process aod
export FCST_VAR=aod
export FCST_HEAD=${FCST_HEAD_aods}
export FCST_SUFF=${FCST_SUFF_aods}
export OBS_VAR=AODANA
export OBS_HEAD=${OBS_HEAD_aods}
export OBS_SUFF=${OBS_SUFF_aods}
export WRKD=${WRKDTOP}/${FCST_VAR}-${OBS_VAR}
export DATA=$WRKD/tmp
export OUTPUTBASE=${WRKD}
export SIGLEV="TRUE"
export VAR_AOD="TRUE"

cd $WRKD
#rm -rf $WRKD/*
#/bin/sh $subcmd -a $proj_account -p $popts -j $metrun-${FCST_NAME}.${FCST_VAR}-${OBS_NAME}.${OBS_VAR} -o ${WRKD}/$metrun-${FCST_NAME}.${FCST_VAR}-${OBS_NAME}.${OBS_VAR}.out -q batch -t 02:19:00 -r /1 $BASE/scripts/${metrun}.sh

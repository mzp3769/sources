#!/bin/bash
#SBATCH -J sig2nc
##SBATCH -q debug
#SBATCH -q batch
##SBATCH -p bigmem
#SBATCH -p orion
##SBATCH -A ap-fc
##SBATCH -A gsd-fv3-dev
##SBATCH -A chem-var
#SBATCH -A wrf-chem
#SBATCH -N 4
#SBATCH -D /home/mpagowsk/mapp_2018/scripts
#SBATCH -n 20
##SBATCH -t 0:30:00
#SBATCH -t 7:59:00
##SBATCH --open-mode=truncate
#SBATCH -o /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.o%j
#SBATCH -e /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.e%j

#sbatch --export=ALL,start=2016020900 sbatch_nems2nc_jediaero_met.sh

set -x

ndate=~/bin/ndate
dhour=23

end=`$ndate +$dhour $start`

export yyyymmddhh_start=$start
export yyyymmddhh_end=$end

source /home/mpagowsk/mapp_2018/scripts/machine-setup.sh

python /home/mpagowsk/mapp_2018/scripts/nems2nc_jediaero_met.py

wait

sbatch --export=ALL,start_date=$start sbatch_chgres.sh

#!/bin/ksh

ndate=~/bin/ndate

cycle_frequency=24

start_date=2016121600
end_date=2016122318

ident=$start_date

while [[ $ident -le $end_date ]]
do
    echo $ident
    sbatch --export=ALL,start=$ident sbatch_nems2nc_jediaero_met.sh
    ident=`$ndate +${cycle_frequency} $ident`
done


#!/bin/ksh
#SBATCH -J chgres
#SBATCH -q batch
##SBATCH -q debug
#SBATCH -p orion
##SBATCH -p bigmem
##SBATCH -A gsd-fv3-dev
##SBATCH -A chem-var
#SBATCH -A ap-fc
##SBATCH -A wrf-chem
#SBATCH -D /home/mpagowsk/mapp_2018/scripts
#SBATCH -n 1
#SBATCH -t 1:59:00
#SBATCH -o /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.o%j
#SBATCH -e /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.e%j

#sbatch --export=ALL,start_date=2016022900 sbatch_chgres.sh

WORKFLOWDIR="/work/noaa/gsd-fv3-dev/pagowski/workflows/global-workflow"

export machine=ORION
export machine_lc=orion
export CASE=C96

. /etc/profile

. ${WORKFLOWDIR}/parm/config/config.resources ecen

. ${WORKFLOWDIR}/env/${machine}.env ecen

. ${WORKFLOWDIR}/modulefiles/module_base.${machine_lc}

ulimit  -s unlimited

METDIR=/work2/noaa/gsd-fv3-dev/pagowski/DATA/MET_ANALYSES/ncdf

ndate=~/bin/ndate

end_date=`$ndate +18 $start_date`

cycle_frequency=6

nanals=40

ndate=~/bin/ndate

lon_s=${LONB:-$((`echo $CASE | cut -c 2-`*4))}
lat_s=${LATB:-$((`echo $CASE | cut -c 2-`*2))}

export OMP_NUM_THREADS=1

ident=$start_date

while [[ $ident -le $end_date ]]
do

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hour=`echo "${ident}" | cut -c9-10`

    nanal=1    
    
    while [[ $nanal -le $nanals ]]
    do
	charnanal=mem`printf %03i $nanal`

	echo "ident = $ident" $charnanal

	cd ${METDIR}/${ident}/${charnanal}
	
	if [[ -r gdas.t${hour}z.atmanl.nc ]]
	then
	    /bin/mv gdas.t${hour}z.atmanl.nc gdas.t${hour}z.orig.atmanl.nc
	fi

cat > enkf_chgres_recenter_nc.nl <<EOF
&chgres_setup
 i_output=$lon_s
 j_output=$lat_s
 input_file="gdas.t${hour}z.orig.atmanl.nc"
 output_file="gdas.t${hour}z.atmanl.nc"
 terrain_file="../../atmanl_terrain"
 ref_file="../../atmanl_terrain"
/
EOF

        srun -n 1 ${WORKFLOWDIR}/exec/enkf_chgres_recenter_nc.x enkf_chgres_recenter_nc.nl


        /bin/rm -f enkf_chgres_recenter_nc.nl

	((nanal=nanal+1))    

    done

    ident=`$ndate +${cycle_frequency} $ident`

done

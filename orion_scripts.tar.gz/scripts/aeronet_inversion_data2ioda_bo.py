#!/usr/bin/env python3
# read/interpolate online aeronet AOD data and convert to netcdf
import netCDF4 as nc
import numpy as np
import inspect, sys, os, argparse
import pandas as pd
from datetime import datetime, timedelta
from builtins import object, str
from numpy import NaN
from pathlib import Path

#IODA_CONV_PATH = Path(__file__).parent/"@SCRIPT_LIB_PATH@"
#if not IODA_CONV_PATH.is_dir():
#    IODA_CONV_PATH = Path(__file__).parent/'..'/'lib-python'
#sys.path.append(str(IODA_CONV_PATH.resolve()))
sys.path.append('/work/noaa/gsd-fv3-dev/pagowski/lib-python')
import pytspack as pts
import meteo_utils
import ioda_conv_ncio as iconv
from collections import defaultdict, OrderedDict
from orddicts import DefaultOrderedDict

def dateparse(x):
    return datetime.strptime(x, '%d:%m:%Y %H:%M:%S')

def add_data(dates=None,
             product=None,
             latlonbox=None,
             daily=False,
             interp_to_aod_values=None,
             inv_type=None,
             freq=None,
             siteid=None,
             detect_dust=False, n_procs=1, verbose=10):
    a = AERONET()
    df = a.add_data(dates=dates,
                    product=product,
                    latlonbox=latlonbox,
                    daily=daily,
                    interp_to_aod_values=interp_to_aod_values,
                    inv_type=inv_type,
                    siteid=siteid,
                    freq=freq,
                    detect_dust=detect_dust)
    return df.reset_index(drop=True)


class AERONET(object):
    def __init__(self):
        from numpy import concatenate, arange
        self.baseurl = 'https://aeronet.gsfc.nasa.gov/cgi-bin/print_web_data_v3?'
        self.dates = [
            datetime.strptime('2016-06-06 12:00:00', '%Y-%m-%d %H:%M:%S'),
            datetime.strptime('2016-06-10 13:00:00', '%Y-%m-%d %H:%M:%S')
        ]
        self.datestr = []
        self.df = pd.DataFrame()
        self.daily = None
        self.prod = None
        self.inv_type = None
        self.siteid = None
        self.objtype = 'AERONET'
        self.usecols = concatenate((arange(30), arange(65, 83)))
        self.latlonbox = None
        self.url = None
        self.new_aod_values = None

    def build_url(self):
        sy = self.dates.min().strftime('%Y')
        sm = self.dates.min().strftime('%m').zfill(2)
        sd = self.dates.min().strftime('%d').zfill(2)
        sh = self.dates.min().strftime('%H').zfill(2)
        ey = self.dates.max().strftime('%Y').zfill(2)
        em = self.dates.max().strftime('%m').zfill(2)
        ed = self.dates.max().strftime('%d').zfill(2)
        eh = self.dates.max().strftime('%H').zfill(2)
        if self.prod in [
                'AOD10', 'AOD15', 'AOD20', 'SDA10', 'SDA15', 'SDA20', 'TOT10',
                'TOT15', 'TOT20'
        ]:
            base_url = 'https://aeronet.gsfc.nasa.gov/cgi-bin/print_web_data_v3?'
            inv_type = None
        else:
            base_url = 'https://aeronet.gsfc.nasa.gov/cgi-bin/print_web_data_inv_v3?'
            if self.inv_type == 'ALM15':
                inv_type = '&ALM15=1'
            else:
                inv_type = '&ALM20=1'
        date_portion = 'year=' + sy + '&month=' + sm + '&day=' + sd + \
            '&hour=' + sh + '&year2=' + ey + '&month2=' + em + '&day2=' + ed +\
            '&hour2=' + eh
        if self.inv_type is not None:
            product = '&product=' + self.prod
        else:
            product = '&' + self.prod + '=1'
            self.inv_type = ''
        time = '&AVG=' + str(self.daily)
        if self.siteid is not None:
            latlonbox = '&site={}'.format(self.siteid)
        elif self.latlonbox is None:
            latlonbox = ''
        else:
            lat1 = str(float(self.latlonbox[0]))
            lon1 = str(float(self.latlonbox[1]))
            lat2 = str(float(self.latlonbox[2]))
            lon2 = str(float(self.latlonbox[3]))
            latlonbox = '&lat1=' + lat1 + '&lat2=' + \
                lat2 + '&lon1=' + lon1 + '&lon2=' + lon2
        print(base_url)
        print(date_portion)
        print(product)
        print(inv_type)
        print(time)
        print(latlonbox)
        if inv_type is None:
            inv_type = ''
        self.url = base_url + date_portion + product + \
            inv_type + time + latlonbox + '&if_no_html=1'

    def read_aeronet(self):
        print('Reading Aeronet Data...')
        df = pd.read_csv(self.url,
                         engine='python',
                         header=None,
                         skiprows=7,
			 parse_dates={'time': [1, 2]},
                         date_parser=dateparse,
                         na_values=-999)
        columns = self.get_columns()
        df.columns = columns
        df.index = df.time
        df.rename(columns={
            'latitude(degrees)': 'latitude',
            'longitude(degrees)': 'longitude',
            'elevation(m)': 'elevation',
            'aeronet_site': 'siteid'
        },
            inplace=True)
        #df.dropna(subset=['latitude', 'longitude'], inplace=True)
        #df.dropna(axis=1, how='all', inplace=True)
        self.df = df

    def get_columns(self):
        header = pd.read_csv(self.url, skiprows=6, header=None,
                             nrows=1).values.flatten()
        final = ['time']
        for i in header:
            if "Date(" in i or 'Time(' in i:
                if "Last_Processing_Date(" in i or "Last_Processing_Time(" in i:
                    final.append(i.lower())
                else:
                    pass
            else:
                final.append(i.lower())
        return final

    def add_data(self,
                 dates=None,
                 product=None,
                 latlonbox=None,
                 daily=False,
                 interp_to_aod_values=None,
                 inv_type=None,
                 freq=None,
                 siteid=None,
                 detect_dust=False):
        self.latlonbox = latlonbox
        self.siteid = siteid
        if dates is None:  # get the current day
            self.dates = pd.date_range(start=pd.to_datetime('today'),
                                       end=pd.to_datetime('now'),
                                       freq='H')
        else:
            self.dates = dates
        self.prod = product.upper()
        if daily:
            self.daily = 20  # daily data
        else:
            self.daily = 10  # all points
        #if inv_type is not None:
        #    self.inv_type = 'ALM15'
        #else:
        self.inv_type = inv_type
        self.build_url()
        try:
            self.read_aeronet()
            print(self.url)
        except:
            print(self.url)
        if freq is not None:
            self.df = self.df.groupby('siteid').resample(
                freq).mean().reset_index()
        return self.df


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
	     description=(
		          'Reads online AERONET inversion data from NASA website '
			  ' and converts into IODA formatted output files')
    )

    required = parser.add_argument_group(title='required arguments')
    required.add_argument(
		    '-l', '--level',
		    help="AERONET inversion data levels ('ALM15 or ALM20') to be downloaded from NASA website",
		    type=str, required=True)
    required.add_argument(
		    '-t', '--time',
		    help="time (YYYYMMDDTHH) of AERONET inversion data files to be downloaded from NASA website",
		    type=str, required=True)
    required.add_argument(
		    '-w', '--window',
		    help="An integer/float number defines a time window centered at time argument in hours within which AERONET inversion data will be downloaded",
		    type=float, required=True)
    required.add_argument(
		    '-o', '--output',
		    help="path of AERONET inversion data IODA file",
		    type=str, required=True)

    args = parser.parse_args()
    aeronetlev = args.level
    date_center1 = args.time
    hwindow=args.window
    hwindow=hwindow/2.0
    outfile = args.output
    date_center = datetime.strptime(date_center1, '%Y%m%d%H') 
    date_start = date_center + timedelta(hours=-1.*hwindow)
    date_end = date_center + timedelta(hours=hwindow)

    print('Download AERONET inversion data within +/- ' + str(hwindow) + ' hours at: ')
    print(date_center)

    dates = pd.date_range(start=date_start,end=date_end,freq='H')

    # Define AOD wavelengths, channels and frequencies
    aod_wav = np.array([440., 675, 870., 1020.], dtype=np.float32)
    aod_chan = np.array([3,   5,    6,    7], dtype=np.intc)

    speed_light = 2.99792458E8
    frequency = speed_light*1.0E9/aod_wav
    print('Calculate AERONET inverion data at wavelengths/channels/frequencies: ')
    print(aod_wav)
    print(aod_chan)
    print(frequency)

    # Read and extract online AERONET inversion data
    print('Read and extract online AERONET inversion data: AOD, SST, TAB, CAD')
    f3_aod_all = add_data(dates=dates, product='AOD', inv_type=aeronetlev)
    f3_ssa_all = add_data(dates=dates, product='SSA', inv_type=aeronetlev)
    f3_tab_all = add_data(dates=dates, product='TAB', inv_type=aeronetlev)
    f3_cad_all = add_data(dates=dates, product='CAD', inv_type=aeronetlev)
    f3_aod=f3_aod_all[['time', 'siteid', 'longitude', 'latitude', 'elevation',
                       'if_retrieval_is_l2(without_l2_0.4_aod_440_threshold)', 'if_aod_is_l2', 'inversion_data_quality_level',
                      'aod_extinction-total[440nm]', 'aod_extinction-total[675nm]', 'aod_extinction-total[870nm]', 'aod_extinction-total[1020nm]']]
    f3_ssa=f3_ssa_all[['time', 'siteid', 'longitude', 'latitude', 'elevation',
                       'if_retrieval_is_l2(without_l2_0.4_aod_440_threshold)', 'if_aod_is_l2', 'inversion_data_quality_level',
		      'single_scattering_albedo[440nm]','single_scattering_albedo[675nm]','single_scattering_albedo[870nm]','single_scattering_albedo[1020nm]']]
    f3_tab=f3_tab_all[['time', 'siteid', 'longitude', 'latitude', 'elevation',
                       'if_retrieval_is_l2(without_l2_0.4_aod_440_threshold)', 'if_aod_is_l2', 'inversion_data_quality_level',
                      'absorption_aod[440nm]', 'absorption_aod[675nm]', 'absorption_aod[870nm]', 'absorption_aod[1020nm]']]
    f3_cad=f3_cad_all[['time', 'siteid', 'longitude', 'latitude', 'elevation',
                       'if_retrieval_is_l2(without_l2_0.4_aod_440_threshold)', 'if_aod_is_l2', 'inversion_data_quality_level',
                      'aod_coincident_input[440nm]', 'aod_coincident_input[675nm]','aod_coincident_input[870nm]','aod_coincident_input[1020nm]']]
    f3=pd.concat([f3_aod, 
    	         f3_ssa[['single_scattering_albedo[440nm]','single_scattering_albedo[675nm]',
    			 'single_scattering_albedo[870nm]','single_scattering_albedo[1020nm]']],
    		 f3_tab[['absorption_aod[440nm]', 'absorption_aod[675nm]', 
    			'absorption_aod[870nm]', 'absorption_aod[1020nm]']], 
    		 f3_cad[['aod_coincident_input[440nm]', 'aod_coincident_input[675nm]',
    			'aod_coincident_input[870nm]','aod_coincident_input[1020nm]']]],axis=1, join='inner')
    # Write data into ASCII txt file for sanity check. 
    #cols=['time', 'siteid', 'longitude', 'latitude', 'elevation', 'if_retrieval_is_l2(without_l2_0.4_aod_440_threshold)', 'if_aod_is_l2', 'inversion_data_quality_level']
    #f3_ssa.to_csv('df_ssa_all.txt', sep=' ', index=False, columns=cols)
    #f3_aod.to_csv('df_aod_all.txt', sep=' ', index=False, columns=cols)
    #f3_tab.to_csv('df_tab_all.txt', sep=' ', index=False, columns=cols)
    #f3_cad.to_csv('df_cad_all.txt', sep=' ', index=False, columns=cols)
    #f3.to_csv('df_f3_all.txt', sep=' ', index=False)

    # Define AO D varname that match with those in f3
    nlocs, columns = f3.shape
    if nlocs==0:
        print('No avaiable AERONET inversion data at ' + date_center1 + '  and exit')
        exit(0)
    obsvars = { 'aod_extinction_total_3': 'aod_extinction-total[440nm]',
		'aod_extinction_total_5': 'aod_extinction-total[675nm]',
		'aod_extinction_total_6': 'aod_extinction-total[870nm]',
		'aod_extinction_total_7': 'aod_extinction-total[1020nm]',
		'single_scattering_albedo_3': 'single_scattering_albedo[440nm]',
		'single_scattering_albedo_5': 'single_scattering_albedo[675nm]',
		'single_scattering_albedo_6': 'single_scattering_albedo[870nm]',
		'single_scattering_albedo_7': 'single_scattering_albedo[1020nm]',
		'absorption_aod_3': 'absorption_aod[440nm]',
		'absorption_aod_5': 'absorption_aod[675nm]',
		'absorption_aod_6': 'absorption_aod[870nm]',
		'absorption_aod_7': 'absorption_aod[1020nm]',
		'aod_coincident_input_3': 'aod_coincident_input[440nm]',
		'aod_coincident_input_5': 'aod_coincident_input[675nm]',
		'aod_coincident_input_6': 'aod_coincident_input[870nm]',
		'aod_coincident_input_7': 'aod_coincident_input[1020nm]',}

    locationKeyList = [("latitude", "float"), ("longitude", "float"), ("datetime", "string"),] 
    writer = iconv.NcWriter(outfile, locationKeyList)
    varDict = defaultdict(lambda: defaultdict(dict))
    outdata = defaultdict(lambda: DefaultOrderedDict(OrderedDict))
    loc_mdata = defaultdict(lambda: DefaultOrderedDict(OrderedDict))
    var_mdata = defaultdict(lambda: DefaultOrderedDict(OrderedDict))
    units = {}
    units['latitude'] = 'degree'
    units['longitude'] = 'degree'
    units['station_elevation'] = 'm'
    
    # Define varDict variables
    print('Define varDict variables')
    for key, value in obsvars.items():
        print(key, value)
        varDict[key]['valKey'] = key, writer.OvalName()
        varDict[key]['errKey'] = key, writer.OerrName()
        varDict[key]['qcKey'] = key, writer.OqcName()

    # Define loc_mdata
    print('Define loc_mdata')
    loc_mdata['latitude'] = np.array(f3['latitude'])
    loc_mdata['longitude'] = np.array(f3['longitude'])
    loc_mdata['station_elevation'] = np.array(f3['elevation'])
    loc_mdata['surface_type'] = np.full((nlocs), 1)
    # 0 for pass and 1 for not pass whetehr AERONET inversion data reach Level 2.0
    loc_mdata['l20_without_aod440_0.4_threshold_qc'] = np.where(f3['if_retrieval_is_l2(without_l2_0.4_aod_440_threshold)'] == 1, 0, 1)
    loc_mdata['l20_with_aod440_0.4_threshold_qc'] = np.where(f3['if_aod_is_l2'] == 1, 0, 1)
    # 0 for Level 2.0 and 1 for Level 1.5
    loc_mdata['inversion_l20_qc'] = np.where(f3['inversion_data_quality_level'] == 'lev20', 0, 1)

    c = np.empty([nlocs], dtype='S50')
    c[:] = np.array(f3.siteid)
    loc_mdata['station_id'] = writer.FillNcVector(c, 'string')

    #c1 = np.empty([nlocs], dtype='S50')
    #c1[:] = np.array(f3.inversion_data_quality_level)
    #loc_mdata['inversion_data_quality_level'] = writer.FillNcVector(c1, 'string')

     # Define datetime
    d = np.empty([nlocs], 'S20')
    for i in range(nlocs):
        d[i]=f3.time[i].strftime('%Y-%m-%dT%H:%M:%SZ') 
    loc_mdata['datetime'] = writer.FillNcVector(d, 'datetime')

    # Define var_mdata
    print('Define var_mdata')
    var_mdata['frequency'] = writer.FillNcVector(frequency, 'float')
    var_mdata['sensor_channel'] = writer.FillNcVector(aod_chan, 'integer')

    for key, value in obsvars.items():
        outdata[varDict[key]['valKey']] = np.array(f3[value].fillna(nc.default_fillvals['f4']))
        outdata[varDict[key]['qcKey']] = np.where(outdata[varDict[key]['valKey']] == nc.default_fillvals['f4'], 1, 0)
        outdata[varDict[key]['errKey']] = np.where(outdata[varDict[key]['valKey']] == nc.default_fillvals['f4'], nc.default_fillvals['f4'], 0.00)

    # Define global atrributes
    print('Define global atrributes')
    AttrData = {'observation_type': 'AERONET inversion data', 
		'date_time_string': date_center.strftime('%Y-%m-%dT%H:%M:%SZ'),
		'sensor': "aeronet", 
		'surface_type': 'ocean=0,land=1,costal=2',}

    # Write out IODA V1 NC files
    print('Write into IODA format file: ' + outfile)
    writer._nvars = len(aod_wav)
    print('Write into IODA format file0: ' + outfile)
    writer._nlocs = nlocs
    print('Write into IODA format file1: ' + outfile)
    writer.BuildNetcdf(outdata, loc_mdata, var_mdata, AttrData, units)
    print('Write into IODA format file2: ' + outfile)

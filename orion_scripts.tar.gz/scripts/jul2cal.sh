#!/bin/ksh

#convert julian date to calendar date

cd /work/noaa/gsd-fv3-dev/pagowski/junk_scp/viirs_lunar

for infile in npp*.nc
do
    echo $infile
    year=`echo $infile | cut -c6-9`
    jday=`echo $infile | cut -c10-12`
    hhmm=`echo $infile | cut -c14-17`
    newdate=`date -d "${year}-01-01 +$(( ${jday} - 1 ))days" +%Y%m%d`$hhmm

    ln -sf $infile viirs_snpp_${newdate}.nc

done

#!/bin/ksh

. /etc/profile

start_date=2016120100
end_date=2016123118

cycle_frequency=6


indir=/work/noaa/gsd-fv3-dev/pagowski/aeronet_hofx/noda_AOD20
indir=/work/noaa/gsd-fv3-dev/pagowski/aeronet_hofx/anal_AOD20
ndate=~/bin/ndate

cd $indir

ident=$start_date

while [[ $ident -le $end_date ]]
do

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hour=`echo "${ident}" | cut -c9-10`

    echo $ident

    ((newyear=year-1))

    infile=aeronet_aod_hofx.${ident}.nc
    outfile=aeronet_aod_hofx.${newyear}${month}${day}${hour}.nc

    echo $infile 
    echo $outfile

    ln -sf $infile $outfile

    ident=`$ndate +${cycle_frequency} $ident`

done


#!/bin/ksh

. /etc/profile

start_date=2020092306
end_date=2020101018


cycle_frequency=6

maindir=/work/noaa/gsd-fv3-dev/pagowski
jedidir=/work/noaa/gsd-fv3-dev/pagowski/jedi/build/fv3-bundle_stable/bin

workdir=${maindir}/tmpdir/workdir_viirs

indir=${maindir}/DATA/OBS/VIIRS/thinned_debiased_C192
outdir=${indir}

ndate=~/bin/ndate

if [[ ! -r $workdir ]]
then
    mkdir -p $workdir
fi

cd $workdir

ident=$start_date

while [[ $ident -le $end_date ]]
do

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hour=`echo "${ident}" | cut -c9-10`

    echo $ident

    infile_v1=${indir}/viirs_aod_snpp.${ident}_v1.nc
    outfile_v2=${outdir}/viirs_aod_snpp.${ident}.nc

    . ~/.jedi
    
    ${jedidir}/ioda-upgrade.x $infile_v1 $outfile_v2

    ident=`$ndate +${cycle_frequency} $ident`

done


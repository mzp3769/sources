#!/bin/ksh

. /etc/profile

start_date=2016070100
end_date=2016123118

start_date=2020121500
end_date=2020121500


alm="ALM15"
alm="ALM20"

cycle_frequency=6

maindir=/work/noaa/gsd-fv3-dev/pagowski
jedidir=/work/noaa/gsd-fv3-dev/pagowski/jedi/build/fv3-bundle_stable/bin

workdir=${maindir}/tmpdir/workdir_aeronet_alm

outdir=${maindir}/DATA/OBS/aeronet_${alm}

if [[ ! -r $outdir ]]
then
    mkdir -p $outdir
fi


ndate=~/bin/ndate

if [[ ! -r $workdir ]]
then
    mkdir -p $workdir
fi

cd $workdir

/bin/cp ~/mapp_2018/scripts/aeronet_alm2ioda.py .

ident=$start_date

while [[ $ident -le $end_date ]]
do

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hour=`echo "${ident}" | cut -c9-10`

    echo $ident

    outfile_v1=${outdir}/aeronet_alm.${ident}_v1.nc
    outfile_v2=${outdir}/aeronet_alm.${ident}_v2.nc

    module purge
    module load python/3.7.5 nco/4.9.3

    python aeronet_alm2ioda.py -l ${alm} -t $ident -w ${cycle_frequency} -o $outfile_v1

    ncks -O -4 --fix_rec_dmn all $outfile_v1 tmp.nc

    . ~/.jedi

    ${jedidir}/ioda-upgrade.x tmp.nc $outfile_v2

    ident=`$ndate +${cycle_frequency} $ident`

done


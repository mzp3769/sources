#!/bin/ksh

#date -d 2016-06-01 +%j
#153
#date -d 2016-06-30 +%j
#182
#date +%j -d 20151201
#date -d 20151201 +%j

wget -e robots=off -m -np -R .html,.tmp -nH --cut-dirs=3 "https://portal.nccs.nasa.gov/datashare/iesa/aerosol/NNR/061.nnr_003_6" -P /work/noaa/gsd-fv3-dev/pagowski/OBS/nnr



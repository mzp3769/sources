#!/bin/ksh

#date -d 2016-02-15 +%j
#153
#date -d 2016-02-30 +%j
#182
#date +%j -d 20151201
#date -d 20151201 +%j

istart=274
iend=304
year=2020

istart=153
iend=182
year=2020


satellite='MYD04' #aqua
satellite='MOD04' # terra

i=istart
while [[ $i -le $iend ]]
do
    ic="`printf %03i $i`"
    echo $ic
    wget -e robots=off -m -np -R .html,.tmp -nH --cut-dirs=3 "https://ladsweb.modaps.eosdis.nasa.gov/archive/allData/61/${satellite}_L2/${year}/${ic}/" --header "Authorization: Bearer bXBhZ293c2tpOmJXRnlhWFZ6ZWk1d1lXZHZkM05yYVVCdWIyRmhMbWR2ZGc9PToxNjM0MTMzNTUxOjNlNzU4OWVlOGY1NDZjZWE1OGI5NWU0ODU4ODMxOTI4MTAxOWU4MjI" -P /work/noaa/gsd-fv3-dev/pagowski/DATA/OBS/MODIS/modis_10km

    ((i=i+1))
done


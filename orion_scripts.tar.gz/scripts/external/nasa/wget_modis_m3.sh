#!/bin/ksh

#date -d 2016-02-15 +%j
#153
#date -d 2016-02-30 +%j
#182
#date +%j -d 20151201
#date -d 20151201 +%j

istart=2012
iend=2015

satellite='MYD08' #aqua
satellite='MOD08' # terra

i=$istart
while [[ $i -le $iend ]]
do
    echo $i
    wget -e robots=off -m -np -R .html,.tmp -nH --cut-dirs=3 "https://ladsweb.modaps.eosdis.nasa.gov/archive/allData/61/${satellite}_M3/${i}/" --header "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbF9hZGRyZXNzIjoibWFyaXVzei5wYWdvd3NraUBub2FhLmdvdiIsImlzcyI6IkFQUyBPQXV0aDIgQXV0aGVudGljYXRvciIsImlhdCI6MTcwMzEwMTI2NywibmJmIjoxNzAzMTAxMjY3LCJleHAiOjE4NjA3ODEyNjcsInVpZCI6Im1wYWdvd3NraSIsInRva2VuQ3JlYXRvciI6Im1wYWdvd3NraSJ9.aLGGfYdJqPRQ61yVsfhdwduZiOMbHCYMIzjlYdyOstk" -P /work/noaa/gsd-fv3-dev/pagowski/DATA/OBS/MODIS/modis_m3

    cd /work/noaa/gsd-fv3-dev/pagowski/DATA/OBS/modis_m3/${satellite}_M3/${i}
    /bin/mv */*hdf .
    /bin/rm -r [0-3]* 

    ((i=i+1))
done


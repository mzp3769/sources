#!/bin/ksh

#date -d 2016-06-01 +%j
#153
#date -d 2016-06-30 +%j
#182
#date +%j -d 20151201
#date -d 20151201 +%j

istart=335
iend=365

i=istart
while [[ $i -le $iend ]]
do
    ic="`printf %03i $i`"
    echo $ic
    wget -e robots=off -m -np -R .html,.tmp -nH --cut-dirs=3 "https://ladsweb.modaps.eosdis.nasa.gov/archive/allData/61/MOD04_3K/2015/${ic}/" --header "Authorization: Bearer 405E6FDE-649F-11EA-B2BB-EB080380055A" -P /work/noaa/gsd-fv3-dev/pagowski/OBS/modis_3km
    ((i=i+1))
done



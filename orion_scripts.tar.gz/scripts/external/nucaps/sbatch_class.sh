#!/bin/ksh -l
#SBATCH -J nucaps
##SBATCH -q debug
#SBATCH -p service
#SBATCH -A gsd-fv3-dev
#SBATCH -n 1
#SBATCH -D /home/mpagowsk/mapp_2018/scripts/external/nucaps
##SBATCH --ntasks-per-node=1
#SBATCH -t 6:29:00
#SBATCH -e /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.e%j
#SBATCH -o /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.o%j

#sbatch --export=ALL sbatch_class.sh

#does not work

cd /work/noaa/gsd-fv3-dev/pagowski/DATA/OBS/NUCAPS

wget -r "ftp://ftp.avl.class.noaa.gov/191377/8131597352/001" -P .

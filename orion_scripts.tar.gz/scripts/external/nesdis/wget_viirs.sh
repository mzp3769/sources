#!/bin/ksh

wget -r "ftp://tars.umd.edu/hliu/NPP_VIIRS_EPS_AOD/2016-06-2[7-9]" -P /work/noaa/gsd-fv3-dev/pagowski/OBS/viirs



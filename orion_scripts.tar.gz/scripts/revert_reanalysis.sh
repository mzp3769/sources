#!/bin/ksh

. /etc/profile

. ~/.nc

start_date=2016010100
end_date=2016013118

cycle_frequency=6

maindir=/work/noaa/gsd-fv3-dev/pagowski//DATA/MODEL/fv3/ll
ndate=~/bin/ndate

cd $maindir

ident=$start_date

while [[ $ident -le $end_date ]]
do

    infile="GEFS_aero_reanalysis_v1.0_${ident}.nc4"
    outfile="GEFS_aero_reanalysis_v1.0_${ident}_rev.nc4"

    echo $outfile

    ncpdq -O -a -lev ${infile} ${outfile}

    ident=`$ndate +${cycle_frequency} $ident`

done

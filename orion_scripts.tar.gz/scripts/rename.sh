#!/bin/ksh

INDIR=/work/noaa/gsd-fv3-dev/pagowski/DATA/MODEL/fv3/ll

cd $INDIR

for file in *.nc
do
    newfile=`echo $file | sed -e "s/nc/nc4/g"`
    echo $newfile
    /bin/mv $file $newfile
done


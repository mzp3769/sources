#!/bin/ksh

. /etc/profile

start_date=2020092306
end_date=2020101018

cycle_frequency=6

maindir=/work/noaa/gsd-fv3-dev/pagowski
jedidir=/work/noaa/gsd-fv3-dev/pagowski/jedi/build/fv3-bundle_stable/bin

indir=${maindir}/DATA/OBS/VIIRS_lunar/thinned_debiased_C192
outdir=${indir}

. ~/.jedi

ndate=~/bin/ndate

cd $indir

ident=$start_date

while [[ $ident -le $end_date ]]
do
    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hour=`echo "${ident}" | cut -c9-10`

    echo $ident

    infile_l_v1=${indir}/viirs_aod_lunar_snpp.${ident}_v1.nc
    outfile_l_v2=${outdir}/viirs_aod_lunar_snpp.${ident}.nc

    infile_sl_v1=${indir}/viirs_aod_snpp.${ident}_v1.nc
    outfile_sl_v2=${outdir}/viirs_aod_snpp.${ident}.nc

    if [[ -r $infile_l_v1 ]]
    then
	${jedidir}/ioda-upgrade.x $infile_l_v1 $outfile_l_v2
	${jedidir}/ioda-upgrade.x $infile_sl_v1 $outfile_sl_v2
    fi
    
    ident=`$ndate +${cycle_frequency} $ident`

done


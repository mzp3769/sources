#!/usr/bin/env python3

# Description:
#        This code reads ASCII files of AERONET inversion products 
#        downloaded from from NASA website and converts to IODA format. 
#        Inversion products include conicident AOT data with almucantar
#        retrieval (CAD), single scattering albedo (SSA), 
#        AOD aborption (TAB) for inversion types of ALM15 and ALM20 and
#        at wavelengths of 440/675/870/1020nm)
#
# Usage:
#        python aeronet_alm2ioda.py -i "aeronet_alm_.dat -l ALM15 
#                              -t 2018041500 -w 6 -o aeronet_alm.nc
#        -i: three input AERONET inversion files for (CAD, SSA. TAN)
#             that are separated by comma   
#        -l: inversion type of input files (ALM15 or ALM20)
#        -t: date in format YYYYMMDDHH
#        -w: time window in hours
#        -o: output inversion file with IODA format
#
# Contact:
#        Bo Huang (bo.huang@noaa.gov) from CU/CIRES and NOAA/ESRL/GSL
#        (August 9, 2021)
#
# Acknowledgement:
#        Barry Baker from ARL for his initial preparation for this code.
#


import netCDF4 as nc
import numpy as np
import inspect, sys, os, argparse
import pandas as pd
from datetime import datetime, timedelta
from builtins import object, str
from numpy import NaN
from pathlib import Path

#IODA_CONV_PATH = Path(__file__).parent/"@SCRIPT_LIB_PATH@"
#if not IODA_CONV_PATH.is_dir():
#    IODA_CONV_PATH = Path(__file__).parent/'..'/'lib-python'
#sys.path.append(str(IODA_CONV_PATH.resolve()))
sys.path.append('/work/noaa/gsd-fv3-dev/pagowski/lib-python')
#sys.path.append('/home/Bo.Huang/JEDI-2020/miscScripts-home/JEDI-Support/aeronetScript/readAeronet/lib-python/')
import meteo_utils
import ioda_conv_ncio as iconv
from collections import defaultdict, OrderedDict
from orddicts import DefaultOrderedDict

def dateparse(x):
    return datetime.strptime(x, '%d:%m:%Y %H:%M:%S')

def add_data(dates=None,
             product=None,
             latlonbox=None,
             daily=False,
             inv_type=None,
             freq=None,
	     siteid=None):
    a = AERONET()
    df = a.add_data(dates=dates,
                    product=product,
                    latlonbox=latlonbox,
                    daily=daily,
                    inv_type=inv_type,
                    siteid=siteid,
                    freq=freq)
    return df.reset_index(drop=True)


class AERONET(object):
    def __init__(self):
        from numpy import concatenate, arange
        self.baseurl = 'https://aeronet.gsfc.nasa.gov/cgi-bin/print_web_data_v3?'
        self.dates = [
            datetime.strptime('2016-06-06 12:00:00', '%Y-%m-%d %H:%M:%S'),
            datetime.strptime('2016-06-10 13:00:00', '%Y-%m-%d %H:%M:%S')
        ]
        self.datestr = []
        self.df = pd.DataFrame()
        self.daily = None
        self.prod = None
        self.inv_type = None
        self.siteid = None
        self.objtype = 'AERONET'
        self.usecols = concatenate((arange(30), arange(65, 83)))
        self.latlonbox = None
        self.url = None
        self.new_aod_values = None

    def build_url(self):
        sy = self.dates.min().strftime('%Y')
        sm = self.dates.min().strftime('%m').zfill(2)
        sd = self.dates.min().strftime('%d').zfill(2)
        sh = self.dates.min().strftime('%H').zfill(2)
        ey = self.dates.max().strftime('%Y').zfill(2)
        em = self.dates.max().strftime('%m').zfill(2)
        ed = self.dates.max().strftime('%d').zfill(2)
        eh = self.dates.max().strftime('%H').zfill(2)
        if self.prod in [
                'AOD10', 'AOD15', 'AOD20', 'SDA10', 'SDA15', 'SDA20', 'TOT10',
                'TOT15', 'TOT20'
        ]:
            base_url = 'https://aeronet.gsfc.nasa.gov/cgi-bin/print_web_data_v3?'
            inv_type = None
        else:
            base_url = 'https://aeronet.gsfc.nasa.gov/cgi-bin/print_web_data_inv_v3?'
            if self.inv_type == 'ALM15':
                inv_type = '&ALM15=1'
            else:
                inv_type = '&ALM20=1'
        date_portion = 'year=' + sy + '&month=' + sm + '&day=' + sd + \
            '&hour=' + sh + '&year2=' + ey + '&month2=' + em + '&day2=' + ed +\
            '&hour2=' + eh
        if self.inv_type is not None:
            product = '&product=' + self.prod
        else:
            product = '&' + self.prod + '=1'
            self.inv_type = ''
        time = '&AVG=' + str(self.daily)
        if self.siteid is not None:
            latlonbox = '&site={}'.format(self.siteid)
        elif self.latlonbox is None:
            latlonbox = ''
        else:
            lat1 = str(float(self.latlonbox[0]))
            lon1 = str(float(self.latlonbox[1]))
            lat2 = str(float(self.latlonbox[2]))
            lon2 = str(float(self.latlonbox[3]))
            latlonbox = '&lat1=' + lat1 + '&lat2=' + \
                lat2 + '&lon1=' + lon1 + '&lon2=' + lon2
        print(base_url)
        print(date_portion)
        print(product)
        print(inv_type)
        print(time)
        print(latlonbox)
        if inv_type is None:
            inv_type = ''
        self.url = base_url + date_portion + product + \
            inv_type + time + latlonbox + '&if_no_html=1'

    def read_aeronet(self):
        print('Reading Aeronet Inversion Data...')
        df = pd.read_csv(self.url,
                         engine='python',
                         header=None,
                         skiprows=7,
			 parse_dates={'time': [1, 2]},
                         date_parser=dateparse,
                         na_values=-999)
        columns = self.get_columns()
        df.columns = columns
        df.index = df.time
        df.rename(columns={
            'latitude(degrees)': 'latitude',
            'longitude(degrees)': 'longitude',
            'elevation(m)': 'elevation',
            'aeronet_site': 'siteid'
        },
            inplace=True)
        self.df = df

    def get_columns(self):
        header = pd.read_csv(self.url, skiprows=6, header=None,
                             nrows=1).values.flatten()
        final = ['time']
        for i in header:
            if "Date(" in i or 'Time(' in i:
                if "Last_Processing_Date(" in i or "Last_Processing_Time(" in i:
                    final.append(i.lower())
                else:
                    pass
            else:
                final.append(i.lower())
        return final

    def add_data(self,
                 dates=None,
                 product=None,
                 latlonbox=None,
                 daily=False,
                 inv_type=None,
                 freq=None,
		 siteid=None):
        self.latlonbox = latlonbox
        self.siteid = siteid
        if dates is None:  # get the current day
            self.dates = pd.date_range(start=pd.to_datetime('today'),
                                       end=pd.to_datetime('now'),
                                       freq='H')
        else:
            self.dates = dates
        self.prod = product.upper()
        if daily:
            self.daily = 20  # daily data
        else:
            self.daily = 10  # all points
        self.inv_type = inv_type
        self.build_url()
        try:
            self.read_aeronet()
            print(self.url)
        except:
            print(self.url)
        if freq is not None:
            self.df = self.df.groupby('siteid').resample(
                freq).mean().reset_index()
        return self.df


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
	     description=(
		          'Reads online AERONET inversion data from NASA website '
			  ' and converts into IODA formatted output files')
    )

    required = parser.add_argument_group(title='required arguments')
    required.add_argument(
		    '-l', '--level',
		    help="AERONET inversion data levels ('ALM15 or ALM20') to be downloaded from NASA website",
		    type=str, required=True)
    required.add_argument(
		    '-t', '--time',
		    help="time (YYYYMMDDTHH) of AERONET inversion data files to be downloaded from NASA website",
		    type=str, required=True)
    required.add_argument(
		    '-w', '--window',
		    help="An integer/float number defines a time window centered at time argument in hours within which AERONET inversion data will be downloaded",
		    type=float, required=True)
    required.add_argument(
		    '-o', '--output',
		    help="path of AERONET inversion data IODA file",
		    type=str, required=True)

    args = parser.parse_args()
    aeronetlev = args.level
    date_center1 = args.time
    hwindow=args.window
    hwindow=hwindow/2.0
    outfile = args.output
    date_center = datetime.strptime(date_center1, '%Y%m%d%H') 
    date_start = date_center + timedelta(hours=-1.*hwindow)
    date_end = date_center + timedelta(hours=hwindow)

    print('Download AERONET inversion data within +/- ' + str(hwindow) + ' hours at: ')
    print(date_center)

    dates = pd.date_range(start=date_start,end=date_end,freq='H')

    # Define AOD wavelengths, channels and frequencies
    aod_wav = np.array([440., 675, 870., 1020.], dtype=np.float32)
    aod_chan = np.array([3,   5,    6,    7], dtype=np.intc)

    speed_light = 2.99792458E8
    frequency = speed_light*1.0E9/aod_wav
    print('Calculate AERONET inverion data at wavelengths/channels/frequencies: ')
    print(aod_wav)
    print(aod_chan)
    print(frequency)

    # Read and extract online AERONET inversion data
    print('Read and extract online AERONET inversion data: AOD, SST, TAB, CAD')
    f3_ssa_all = add_data(dates=dates, product='SSA', inv_type=aeronetlev)
    f3_tab_all = add_data(dates=dates, product='TAB', inv_type=aeronetlev)
    f3_cad_all = add_data(dates=dates, product='CAD', inv_type=aeronetlev)
    f3_cad=f3_cad_all[['time', 'siteid', 'longitude', 'latitude', 'elevation',
                       'if_retrieval_is_l2(without_l2_0.4_aod_440_threshold)', 'if_aod_is_l2', 'inversion_data_quality_level',
                      'aod_coincident_input[440nm]', 'aod_coincident_input[675nm]','aod_coincident_input[870nm]','aod_coincident_input[1020nm]']]
    f3_ssa=f3_ssa_all[['single_scattering_albedo[440nm]','single_scattering_albedo[675nm]','single_scattering_albedo[870nm]','single_scattering_albedo[1020nm]']]
    f3_tab=f3_tab_all[['absorption_aod[440nm]', 'absorption_aod[675nm]', 'absorption_aod[870nm]', 'absorption_aod[1020nm]']]
    f3=pd.concat([f3_cad,f3_ssa,f3_tab], axis=1, join='inner') 
    # Write data into ASCII txt file for sanity check. 
    #cols=['time', 'siteid', 'longitude', 'latitude', 'elevation', 'if_retrieval_is_l2(without_l2_0.4_aod_440_threshold)', 'if_aod_is_l2', 'inversion_data_quality_level']
    #f3_ssa.to_csv('df_ssa_all.txt', sep=' ', index=False, columns=cols)
    #f3_aod.to_csv('df_aod_all.txt', sep=' ', index=False, columns=cols)
    #f3_tab.to_csv('df_tab_all.txt', sep=' ', index=False, columns=cols)
    #f3_cad.to_csv('df_cad_all.txt', sep=' ', index=False, columns=cols)
    #f3.to_csv('df_f3_all.txt', sep=' ', index=False)

    # Define AO D varname that match with those in f3
    nlocs, columns = f3.shape
    if nlocs==0:
        print('No avaiable AERONET inversion data at ' + date_center1 + '  and exit')
        exit(0)
    obsvars = { 'aerosol_optical_depth_3': 'aod_coincident_input[440nm]',
		'aerosol_optical_depth_5': 'aod_coincident_input[675nm]',
		'aerosol_optical_depth_6': 'aod_coincident_input[870nm]',
		'aerosol_optical_depth_7': 'aod_coincident_input[1020nm]',
                'single_scattering_albedo_3': 'single_scattering_albedo[440nm]',
		'single_scattering_albedo_5': 'single_scattering_albedo[675nm]',
		'single_scattering_albedo_6': 'single_scattering_albedo[870nm]',
		'single_scattering_albedo_7': 'single_scattering_albedo[1020nm]',
		'absorption_aerosol_optical_depth_3': 'absorption_aod[440nm]',
		'absorption_aerosol_optical_depth_5': 'absorption_aod[675nm]',
		'absorption_aerosol_optical_depth_6': 'absorption_aod[870nm]',
		'absorption_aerosol_optical_depth_7': 'absorption_aod[1020nm]'}

    locationKeyList = [("latitude", "float"), ("longitude", "float"), ("datetime", "string"),] 
    writer = iconv.NcWriter(outfile, locationKeyList)
    varDict = defaultdict(lambda: defaultdict(dict))
    outdata = defaultdict(lambda: DefaultOrderedDict(OrderedDict))
    loc_mdata = defaultdict(lambda: DefaultOrderedDict(OrderedDict))
    var_mdata = defaultdict(lambda: DefaultOrderedDict(OrderedDict))
    units = {}
    units['latitude'] = 'degree'
    units['longitude'] = 'degree'
    units['station_elevation'] = 'm'
    
    # Define varDict variables
    print('Define varDict variables')
    for key, value in obsvars.items():
        print(key, value)
        varDict[key]['valKey'] = key, writer.OvalName()
        varDict[key]['errKey'] = key, writer.OerrName()
        varDict[key]['qcKey'] = key, writer.OqcName()

    # Define loc_mdata
    print('Define loc_mdata')
    loc_mdata['latitude'] = np.array(f3['latitude'])
    loc_mdata['longitude'] = np.array(f3['longitude'])
    loc_mdata['station_elevation'] = np.array(f3['elevation'])
    loc_mdata['surface_type'] = np.full((nlocs), 1)

    # Whether aaod reaches Level 2.0 without the threshold of aod440 >= 0.4 (0: yes, 1: no)
    loc_mdata['aaod_l2_qc_without_aod440_le_0.4_threshold'] = np.where(f3['if_retrieval_is_l2(without_l2_0.4_aod_440_threshold)'] == 1, 0, 1)

    # Whether Coincident_AOD440nm in aeronet_cad.txt reaches Level 2.0 (0: yes, 1: no)
    loc_mdata['aod_l2_qc'] = np.where(f3['if_aod_is_l2'] == 1, 0, 1)

    # aaod inversion type: 0 for ALM20 and 1 for ALM15
    loc_mdata['aaod_l2_qc'] = np.where(f3['inversion_data_quality_level'] == 'lev20', 0, 1)

    c = np.empty([nlocs], dtype='S50')
    c[:] = np.array(f3.siteid)
    loc_mdata['station_id'] = writer.FillNcVector(c, 'string')

    #c1 = np.empty([nlocs], dtype='S50')
    #c1[:] = np.array(f3.inversion_data_quality_level)
    #loc_mdata['inversion_data_quality_level'] = writer.FillNcVector(c1, 'string')

     # Define datetime
    d = np.empty([nlocs], 'S20')
    for i in range(nlocs):
        d[i]=f3.time[i].strftime('%Y-%m-%dT%H:%M:%SZ') 
    loc_mdata['datetime'] = writer.FillNcVector(d, 'datetime')

    # Define var_mdata
    print('Define var_mdata')
    var_mdata['frequency'] = writer.FillNcVector(frequency, 'float')
    var_mdata['sensor_channel'] = writer.FillNcVector(aod_chan, 'integer')

    for key, value in obsvars.items():
        outdata[varDict[key]['valKey']] = np.array(f3[value].fillna(nc.default_fillvals['f4']))
        outdata[varDict[key]['qcKey']] = np.where(outdata[varDict[key]['valKey']] == nc.default_fillvals['f4'], 1, 0)
        if key in ["aerosol_optical_depth_3", "aerosol_optical_depth_5","aerosol_optical_depth_6","aerosol_optical_depth_7"]:
            outdata[varDict[key]['errKey']] = np.where(outdata[varDict[key]['valKey']] == nc.default_fillvals['f4'], nc.default_fillvals['f4'], 0.02)
        if key in ["single_scattering_albedo_3", "single_scattering_albedo_5","single_scattering_albedo_6","single_scattering_albedo_7"]: 
            outdata[varDict[key]['errKey']] = np.where(f3['aod_coincident_input[440nm]'] >= 0.4, 0.03, 10.0)
        if key in ["absorption_aerosol_optical_depth_3", "absorption_aerosol_optical_depth_5","absorption_aerosol_optical_depth_6","absorption_aerosol_optical_depth_7"]:
            outdata[varDict[key]['errKey']] = np.where(outdata[varDict[key]['valKey']] == nc.default_fillvals['f4'], nc.default_fillvals['f4'], 10.0)
    # Define global atrributes
    print('Define global atrributes')
    AttrData = {'observation_type': 'AERONET AAOD', 
		'date_time_string': date_center.strftime('%Y-%m-%dT%H:%M:%SZ'),
		'sensor': "aeronet", 
		'surface_type': 'ocean=0, land=1, costal=2'}

    # Write out IODA V1 NC files
    print('Write into IODA format file: ' + outfile)
    writer._nvars = len(aod_wav)
    print('Write into IODA format file0: ' + outfile)
    writer._nlocs = nlocs
    print('Write into IODA format file1: ' + outfile)
    writer.BuildNetcdf(outdata, loc_mdata, var_mdata, AttrData, units)
    print('Write into IODA format file2: ' + outfile)

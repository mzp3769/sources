#!/bin/ksh

. /etc/profile

start_date=2021090500
end_date=2021092718

sim=anal
#sim=noda

aeronet_data="AOD15"

cycle_frequency=6
ndate=~/bin/ndate
maindir=/work/noaa/gsd-fv3-dev/pagowski

bodir=/work/noaa/gsd-fv3-dev/bhuang/JEDI-FV3/expRuns/MISC/toOrion-nrtDA

scriptdir=~/mapp_2018/scripts

workdir=${maindir}/tmpdir/workdir_aeronet_hofx

outdir=${maindir}/aeronet_hofx_from_bo/${sim}_${aeronet_data}

if [[ ! -r $outdir ]]
then
    mkdir -p $outdir
fi

ndate=~/bin/ndate

((cycle_frequency_half=cycle_frequency/2))

if [[ ! -r $workdir ]]
then
    mkdir -p $workdir
fi

cd $workdir

. ~/.nc

ident=$start_date

while [[ $ident -le $end_date ]]
do

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hour=`echo "${ident}" | cut -c9-10`

    datestd=$ident

    obsdir=${bodir}/gdas.${year}${month}${day}/${hour}/obs

    if [[ $sim == 'anal' ]] 
    then
	ncrcat -O ${obsdir}/aod_aeronet_hofx_3dvar_LUTs_${ident}_????.nc4 ${outdir}/aeronet_aod_hofx.${datestd}.nc
    else
	ncrcat -O ${obsdir}/aod_aeronet_hofx_3dvar_LUTs_${ident}_????.nc4.ges ${outdir}/aeronet_aod_hofx.${datestd}.nc
    fi	

    echo $ident

    ident=`$ndate +${cycle_frequency} $ident`

done


#!/bin/ksh
#SBATCH -J convert
##SBATCH -q batch
##SBATCH -q debug
#SBATCH -q urgent
#SBATCH -p orion
##SBATCH -p bigmem
##SBATCH -A gsd-fv3-dev
##SBATCH -A chem-var
#SBATCH -A ap-fc
##SBATCH -A wrf-chem
#SBATCH -D /home/mpagowsk/mapp_2018/scripts
#SBATCH -n 6
#SBATCH -t 0:10:00
#SBATCH -o /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.o%j
#SBATCH -e /work/noaa/gsd-fv3-dev/pagowski/qslogs/%x.e%j

#sbatch --export=ALL sbatch_convert_c96_c192.sh

. /etc/profile
. /apps/lmod/lmod/init/sh
. ~/.jedi

ulimit -s unlimited
ulimit -v unlimited

start_date=2015123106
end_date=2016010100

ndate=~/bin/ndate

cycle_frequency=6

export JEDI=/work/noaa/gsd-fv3-dev/pagowski/jedi
export JEDIYAML=${JEDI}/yamls
export JEDIBUILD=${JEDI}/build/fv3-bundle_stable

export JEDIBIN=${JEDIBUILD}/bin
export JEDICODE=${JEDI}/code/fv3-bundle_stable/fv3-jedi
export JEDIDATA=${JEDICODE}/test/Data
export JEDIFIELDS=${JEDI}/fieldsets

MAINDIR=/work/noaa/gsd-fv3-dev/pagowski

TMPDIR=${MAINDIR}/tmpdir/workdir_convert

# Run time debugging options
# --------------------------
export OOPS_TRACE=0
export OOPS_DEBUG=0
export OOPS_LOG=0

rm -rf $TMPDIR
mkdir -p $TMPDIR

cd $TMPDIR

ln -sf ${JEDIFIELDS} .
ln -sf ${JEDIDATA}/fv3files .

/bin/cp ${JEDIYAML}/convertstate_gfs_aero_c96_c192_template.yaml .

INDIR=${MAINDIR}/jedi_convert/inputs
OUTDIR=${MAINDIR}/jedi_convert/outputs

if [[ ! -r ${OUTDIR} ]]
then
    mkdir -p ${OUTDIR}
fi

rm -rf inputs outputs

ln -sf ${INDIR} inputs
ln -sf ${OUTDIR} outputs

ident=$start_date

while [[ $ident -le $end_date ]]
do

    echo $ident

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hr=`echo "${ident}" | cut -c9-10`

    analdate=${year}${month}${day}.${hr}0000    

    cd ${INDIR}

    itile=1

    while [[ $itile -le 6 ]]
    do
	ln -sf ${analdate}.fv_core.res.tile${itile}.nc.ges ${analdate}.fv_core.res.tile${itile}.nc
	ln -sf ${analdate}.sfc_data.tile${itile}.nc.ges ${analdate}.sfc_data.tile${itile}.nc
	ln -sf ${analdate}.fv_srf_wnd.res.tile${itile}.nc.ges ${analdate}.fv_srf_wnd.res.tile${itile}.nc

	((itile=itile+1))

    done

    ln -sf ${analdate}.coupler.res.ges ${analdate}.coupler.res

    cd $TMPDIR

    sed -e "s/analdate/${analdate}/g" convertstate_gfs_aero_c96_c192_template.yaml > convertstate_gfs_aero_c96_c192.yaml
	
    export jobtype=convertstate_gfs_aero_c96_c192

    echo "srun -n $SLURM_NTASKS  $JEDIBIN/fv3jedi_convertstate.x ${jobtype}.yaml"

    srun -n $SLURM_NTASKS  $JEDIBIN/fv3jedi_convertstate.x ${jobtype}.yaml

    cd $OUTDIR

    itile=1

    while [[ $itile -le 6 ]]
    do
	ln -sf ${analdate}.fv_core.res.tile${itile}.nc ${analdate}.fv_core.res.tile${itile}.nc.ges
	ln -sf ${analdate}.fv_tracer.res.tile${itile}.nc ${analdate}.fv_tracer.res.tile${itile}.nc.ges
	ln -sf ${analdate}.sfc_data.tile${itile}.nc ${analdate}.sfc_data.tile${itile}.nc.ges
	ln -sf ${analdate}.fv_srf_wnd.res.tile${itile}.nc ${analdate}.fv_srf_wnd.res.tile${itile}.nc.ges

	((itile=itile+1))

    done

    ln -sf ${analdate}.coupler.res ${analdate}.coupler.res.ges

    ident=`$ndate +${cycle_frequency} $ident`

done




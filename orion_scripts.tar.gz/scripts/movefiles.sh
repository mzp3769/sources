#!/bin/ksh
#to move control files to final destinations

MAINDIR=/work/noaa/gsd-fv3-dev/pagowski/DATA/MET_ANALYSES/ncdf

grid=C192

INDIR=${MAINDIR}/control_${grid}

cycle_frequency=6

ndate=~/bin/ndate

date_start=2015120100
date_end=2016011718

ident=$date_start

while [[ $ident -le $date_end ]]
do
    echo $ident

    indir=${INDIR}/${ident}
    outdir=${MAINDIR}/${ident}/control_${grid}
    if [[ ! -r $outdir ]]
    then
	mkdir -p $outdir
    fi

    /bin/mv ${indir}/gdas* $outdir
    ident=`$ndate +${cycle_frequency} $ident`
done

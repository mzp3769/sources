void c_ncdf_w ( );

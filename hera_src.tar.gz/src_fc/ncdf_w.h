void ncdf_w ( );

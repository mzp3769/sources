void abwe1 ( int n, int m, double eps, double coef2, int even, double b[], 
  double *x, double *w );
void abwe2 ( int n, int m, double eps, double coef2, int even, double b[], 
  double *x, double *w1, double *w2 );
void kronrod ( int n, double eps, double x[], double w1[], double w2[] );
double r8_abs ( double x );
void timestamp ( void );

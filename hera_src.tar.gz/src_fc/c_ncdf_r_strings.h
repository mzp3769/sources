void c_ncdf_r_strings ( int grpid, int varid, int nlocs, int length );

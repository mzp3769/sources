library(ncdf)
library(spatial)
library(nlme)
require(stats)

emismin <- 1.e-8

varname <- "E_PM25J"
varname <- "E_ECJ"
varname <- "E_ORGJ"
#varname <- "E_SO4J"
varname <- "E_NO3J"
source("gaspari.R")

ncname <- "./indata/wrfchemi_00z_d01"
nc <- open.ncdf(ncname, readunlim=FALSE )
x <- get.var.ncdf(nc,"west_east")
y <- get.var.ncdf(nc,"south_north")
z <- get.var.ncdf(nc,"emissions_zdim")
nx <- length(x)
ny <- length(y)
nz <- length(z)

nxy=nx*ny
varin <- get.var.ncdf(nc,varname)

close.ncdf(nc)

xx <- array(NA,c(nxy))
yy <- array(NA,c(nxy))
varvec <- array(NA,c(nxy))

scales <- array(NA,c(nx,ny))	

var <- varin[,,1,1]

tilesize <- 10

minpoints <- 100
nbins <- minpoints

for (jj in 1:ny) {
for (ii in 1:nx) {

k <- 1

jmin <- max(1,jj-tilesize)
jmax <- min(ny,jj+tilesize)

imin <- max(1,ii-tilesize)
imax <- min(nx,ii+tilesize)


for (j in (jmin:jmax)) {
for (i in (imin:imax)) {
    if (var[i,j] > emismin) {
       	xx[k] <- x[i]
        yy[k] <- y[j] 
    	varvec[k] <- log(var[i,j])
#    	varvec[k] <- var[i,j]
	k <- k+1
     }
}}

npoints <- k-1

if (npoints < 100) next 

varframe <- data.frame(y=yy[1:npoints],x=xx[1:npoints],
z=varvec[1:npoints])

surface <- surf.ls(2,varframe)

#correlogram(surface,nbins,lty=1,pch=19,cex=0.75,col="blue")

corr <- correlogram(surface,nbins,plotit=FALSE)

ind <- which(corr$y < 0.)
ind1 <- ind[1]

dx <- corr$x[ind1] - corr$x[ind1-1]
y1 <- corr$y[ind1-1]
y2 <- corr$y[ind1]

scales[ii,jj] <- corr$x[ind1-1]+y1*dx/(y1-y2)

#print(c(ii,jj,scales[ii,jj]))
#locator()

print(c(ii,jj))

}}

x <- 1:nx
y <- 1:ny

x11(width=6,height=6)

filled.contour(x,y,scales,xlim=range(x),ylim=range(y),
nlevels=10,color.palette=rainbow)


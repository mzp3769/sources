#!/bin/ksh --login
#PBS -N R_scales
#PBS -A chem-var
#PBS -l procs=12
##PBS -q debug
#PBS -l walltime=01:00:00
#PBS -d /home/Mariusz.Pagowski/R/enkf_chem
#PBS -o /home/Mariusz.Pagowski/R/enkf_chem/qslogs
#PBS -e /home/Mariusz.Pagowski/R/enkf_chem/qslogs

#. /usr/share/Modules/init/ksh

#module purge

#module load R/3.1.0

R CMD BATCH emission_local_scales_ncdf4.R emission_local_scales_ncdf4.log

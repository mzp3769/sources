#to plot a profile of increment
test <- 'test_137'

library(ncdf)

ncname <- paste('../indata/',test,'/pm2_5_prof_series.nc',
sep='')
nc <- open.ncdf(ncname, readunlim=FALSE )
pottemp <- get.var.ncdf(nc,"T")
pm25 <- get.var.ncdf(nc,"PM2_5_DRY")
pb <- get.var.ncdf(nc,"PB")
pp <- get.var.ncdf(nc,"P")
close.ncdf(nc)
logp <- -log(pb[,1]/pb[1,1])

ntimes <- dim(pm25)[2]

year_start <- "2010"
month_start <- "06"
day_start <- "01"
hour_start <- "00"
minute_start <- "00"
secont_start <- "00"

plotdates <- c("2010/06/01 UTC","2010/07/01 UTC")
yyyymmdd_start <- paste(year_start,month_start,day_start,
sep="-")
time_start <- paste(hour_start,minute_start,secont_start,
sep=":")
date_start <- as.POSIXlt(paste(yyyymmdd_start,time_start),"UTC")

alldates <- seq(date_start,by=6*3600,length=ntimes)
xlabstring <- expression("Days")
keystring <- expression(paste("[",mu,"g","  ",m^{-3},"]"))
plotstring <- expression(paste(PM[2.5]))
ylabstring <- expression(paste(-log,"(p/",p[s],")"))

xmin <- 1
xmax <- ntimes

xx <- seq(0,(ntimes-1)/4,by=.25)

picname <- paste("./pics/pm25_tseries_",test,".tiff",sep='')

tiff(picname,width = 700, height = 400,bg="white")
filled.contour(xx,logp,t(pm25),
nlevels=6,col=c("lightskyblue","limegreen","yellow",
"orange","red","violet"),
#nlevels=6,col=rainbow(5,start=.7,end=.1),
ylab=ylabstring,ylim=c(0,1.),xlab=xlabstring,
xaxs="i",xlim=c(min(xx),max(xx)),
#plot.title = plotstring,
key.title = title(main=keystring))
plot.title= 
dev.off()


#to plot scatter and output logs for plotting stats for multiple tests
#if crashes track the line number and correct fcst* file at
#line number is (j-nvals[1] - nvals[2])*4 
#not implemented since requires high AOD values
stop("STOP")

df <- data.frame(x= vars[,2],y= vars[,1])
looks better with log

k <- with(df,MASS:::kde2d(x,y))
filled.contour(k)

test <- "test_822"
indir <- paste('./indata/',test,'/modis',sep='')
outdir <- './pics/modis/'

picratio <- 1.07

fcsts <- as.character(seq(from=0,to=9,by=1))
nfcsts <- length(fcsts)

year <- "2012"
months <- c("06","07","08")
nmonths <- length(months)

nvals <-  array(0,nmonths)
ncols <- 3

varriances <- array(NA,c(2,nfcsts))
correls <-  array(NA,nfcsts) 
rmses <-  array(NA,nfcsts) 
ndatas <- array(NA,nfcsts)
bias <- array(NA,nfcsts)

n <- 0	

for (fcst in fcsts) {

    fnames <- paste(indir,'/fcst_',year,months,'_',fcst,'.txt',sep='')

    i <- 0

    for (fname in fnames) {
        infile <- file(fname,"ra")
    	a <- readLines(infile)       
    	close(infile)
    	i <- i+1
    	nvals[i] <- (length(a)-1)/4
    }

    allnvals <- sum(nvals)

    vars <- array(NA,c(allnvals,2))
    sat <- array(NA,allnvals)
    coords <- array(NA,c(allnvals,3))

    j <- 0

    i <- 0

    for (fname in fnames) {
    infile <- file(fname,"ra")
    date <-  scan(infile,what='a',nlines=1,quiet=TRUE)
    print(date)

    i <- i+1

    for (k in 1:nvals[i]) {
    	j <- j+1
    	sat[j] <- scan(infile,what='a',nlines=1,quiet=TRUE)
	       coords[j,] <- array(scan(infile,what=0,n=ncols,nlines=1,
	       quiet=TRUE))
        vars[j,1] <- array(scan(infile,what=0,nlines=1,quiet=TRUE))
 	vars[j,2] <- array(scan(infile,what=0,nlines=1,quiet=TRUE))
    }

    close(infile)

    }

    xmin <- 0
    xmax <- max(vars)
    xmax <- 1.5
    xlabstring <- "obs"
    ylabstring <- "model"




    pngname <- paste(outdir,'fcst_',fcst,'_',test,'.png',sep="")

    png(pngname,width=600, height=600*picratio,bg="white")

    plot(vars[,2],vars[,1],xlim=c(xmin,xmax),ylim=c(xmin,xmax),
	type="p",pch=20,cex=.5,
    	cex.axis=1.,cex.lab=1.,
    	xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

    x <- seq(0,xmax,by=xmax/10)

    lines(x,x,type='l',col='red',lwd=2)

    dev.off()

    n <- n+1 

    varriances[1,n] <- var(vars[,1])
    varriances[2,n] <- var(vars[,2])
    correls[n] <-  cor(vars[,1],vars[,2])
    rmses[n] <-  sqrt(sum((vars[,1]-vars[,2])^2)/length(vars[,1]))
    ndatas[n] <- length(vars[,1])
    bias[n] <- mean(vars[,1]-vars[,2])

}

pngname <- paste(outdir,'correl_',test,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- 'Forecast hour'
ylabstring <- 'Correlation'

plot(as.numeric(fcsts),correls,xlim=c(0,nfcsts-1),ylim=c(0,1),
        type="l",lwd=4,
        cex.axis=1.,cex.lab=1.,
        xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

dev.off()

pngname <- paste(outdir,'variances_',test,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- 'Forecast hour'
ylabstring <- 'Variance'

ymax <- max(varriances)+0.01

plot(as.numeric(fcsts),varriances[2,],xlim=c(0,nfcsts-1),ylim=c(0,ymax),
        type="l",lwd=4,
        cex.axis=1.,cex.lab=1.,col="black",
        xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

lines(as.numeric(fcsts),varriances[1,],type="l",lwd=4,col="red")

dev.off()

pngname <- paste(outdir,'bias_',test,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- 'Forecast hour'
ylabstring <- 'Bias'

ymax <- max(bias)
ymin <- min(bias)

plot(as.numeric(fcsts),bias,xlim=c(0,nfcsts-1),ylim=c(ymin,ymax),
        type="l",lwd=4,
        cex.axis=1.,cex.lab=1.,
        xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

dev.off()

pngname <- paste(outdir,'rmse_',test,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

ymax <- max(rmses)
ymin <- min(rmses)


xlabstring <- 'Forecast hour'
ylabstring <- 'RMSE'

plot(as.numeric(fcsts),rmses,xlim=c(0,nfcsts-1),ylim=c(ymin,ymax),
        type="l",lwd=4,
        cex.axis=1.,cex.lab=1.,
        xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

dev.off()

pngname <- paste(outdir,'ndatas_',test,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

xlabstring <- 'Forecast hour'
ylabstring <- 'Number of observations'

ymax <- max(ndatas)
ymin <- min(ndatas)

plot(as.numeric(fcsts),ndatas,xlim=c(0,nfcsts-1),ylim=c(ymin,ymax),
        type="l",lwd=4,
        cex.axis=1.,cex.lab=1.,
        xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

dev.off()

outfile <- paste('./outdata/modis_',test,'.txt',sep='')

system(paste('rm -f',outfile))

write('fcst_hour ndatas bias correlation variance_obs variance_model rmse',
      file=outfile,append=TRUE,sep='   ')

i <- 0
for (fcst in fcsts) {
    i <- i+1
    write(c(i-1,ndatas[i],bias[i],correls[i],
	    varriances[2,i],varriances[1,i],rmses[i]),
	    file=outfile,append=TRUE,sep=',   ',ncolumns=7)
}


#to plot a profile of increment
library(ncdf)

coords <- c(68,50) #ok 00z
coords <- c(78,73) #00z
#coords <- c(75,51) #00z
#coords <- c(67,50) #00z

#coords <- c(39,8) #12z
#coords <- c(52,14) #12z
#coords <- c(44,33)
#coords <- c(43,34)
#coords <- c(44,34)

ncname <- './indata/increment/wrf_post.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
t <- get.var.ncdf(nc,"T")
pb <- get.var.ncdf(nc,"PB")
pp <- get.var.ncdf(nc,"P")
close.ncdf(nc)

ncname <- './indata/increment/diff_enkf.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
gsi <- get.var.ncdf(nc,"PM2_5_DRY")
close.ncdf(nc)
 
ncname <- './indata/increment/diff_enkf.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
enkf <- get.var.ncdf(nc,"PM2_5_DRY")
close.ncdf(nc)

top <- 30
levels <- 1:top

pprof <- -log((pp[coords[1],coords[2],]
              +pb[coords[1],coords[2],])/
              (pp[coords[1],coords[2],1]+pb[coords[1],coords[2],1]))


enkfprof <- enkf[coords[1],coords[2],]
gsiprof <- gsi[coords[1],coords[2],]
tprof <- t[coords[1],coords[2],] 


ymin <- min(pprof[1:top])
ymax <- max(pprof[1:top])
xmin <- min(enkfprof,gsiprof)
xmax <- max(enkfprof,gsiprof)+0.1*max(enkfprof,gsiprof)

xlabstring <- expression(
paste("PM2.5 ","[",mu,"g","  ",m^{-3},"]",sep=""))
ylabstring <- expression(paste(-log,"(p/",p[s],")"))

width <- 400
height <- 600

ylabstring <- expression(paste(-log,"(p/",p[s],")"))

png("./pics/increment_gsi.png",width = width, height = height,
bg="white")

par(mar=c(5, 4.5, 4, 2)+0.1)


plot(gsiprof[1:top],pprof[1:top],type="l",col="black",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.5,cex.lab=1.5,lwd=3,cex=1.5,
xlim=c(xmin,xmax),ylim=c(ymin,ymax))
#lines(enkfprof[1:top],pprof[1:top],col="violet",lwd=3)
#legend(x=xmax,y=ymax,xjust=1,yjust=1,
#col=c("green","violet"),legend=c("GSI","EnKF_TOT"),
#lwd=3,cex=0.9)

dev.off()


png("./pics/increment_enkf.png",width = width, height = height,
bg="white")

par(mar=c(5, 4.5, 4, 2)+0.1)

plot(enkfprof[1:top],pprof[1:top],type="l",col="black",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.5,cex.lab=1.5,lwd=3,cex=1.5,
xlim=c(xmin,xmax),ylim=c(ymin,ymax))
#lines(enkfprof[1:top],pprof[1:top],col="violet",lwd=3)
#legend(x=xmax,y=ymax,xjust=1,yjust=1,
#col=c("green","violet"),legend=c("GSI","EnKF_TOT"),
#lwd=3,cex=0.9)

dev.off()

png("./pics/t_profile.png",width = width, height = height,
bg="white")

xlabstring <- expression(
paste(Theta," [K]",sep=""))

par(mar=c(5, 4.5, 4, 2)+0.1)

plot((tprof+300)[1:top],pprof[1:top],type="l",col="red",
xlab=xlabstring,ylab=ylabstring,yaxs="i",
cex.axis=1.5,cex.lab=1.5,lwd=3,cex=1.5)
dev.off()



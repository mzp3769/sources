#to calculate dust and sea salt fractions from macc to wrf-chem

library(MASS)

#from zender 2003 split function

erf <- function(x) {
    2 * pnorm(x*sqrt(2)) - 1
}

split_function <- function(dmin_j,dmax_j,stdev_i,dv_i) {

    xmin <- log(dmin_j/dv_i)/(sqrt(2)*log(stdev_i))
    xmax <- log(dmax_j/dv_i)/(sqrt(2)*log(stdev_i))
    split_function <- 0.5*(erf(xmax)-erf(xmin))

}

#dust 

n_dust_bins_gocart <- 5
n_dust_bins_macc <- 3

#gocart dust bins
#0.2 - 2.0 micron diameter  = 0.11
#2.0-3.6 micron diameter = 0.22
#3.6-6.0 micron diameter = 0.27
#6.0-12.0 micron diameter = 0.30
#12.0 - 20.0 micron diameter = 0.11

diameter_dust_bins_gocart <- c(0.2,2.0,3.6,6.0,12.0,20.0)
diameter_dust_bins_macc <- c(0.03,0.55,0.9,20.)*2 # from radius to diameter

#dust bins have a tri-lognormal distribution
#after Zander (2003) from d'Almeida (1987) background distribution
#Zander has second bin 3.19 wrong - should be 1.4

#for background dust aerosol

n_dust_distrib <- 3
stdevs_dust_distrib <- c(2.1,1.9,1.6)
diameters_dust_distrib <- c(0.16,1.4,10.0)
#diameters_dust_distrib <- c(0.02,0.116,1.8)
diameters_v_dust_distrib <- exp(log(diameters_dust_distrib)+
		       3.*(log(stdevs_dust_distrib))^2)

#should be overdetermined for SVD
matrix_macc <- array(NA,c(n_dust_distrib,n_dust_bins_macc))
splits_dust_macc <- array(c(0.1,0.2,0.7),c(1,n_dust_bins_macc))

for (i in 1:n_dust_distrib) {
    for (j in 1:n_dust_bins_macc) {
    	matrix_macc[i,j] <- split_function(
		     	diameter_dust_bins_macc[j],
		     	diameter_dust_bins_macc[j+1],
			stdevs_dust_distrib[i],
			diameters_v_dust_distrib[i])			
}}

number_conc_distrib <- splits_dust_macc %*% ginv(matrix_macc)

matrix_gocart <- array(NA,c(n_dust_distrib,n_dust_bins_gocart))

for (i in 1:n_dust_distrib) {
    for (j in 1:n_dust_bins_gocart) {
    	matrix_gocart[i,j] <- split_function(
		     	diameter_dust_bins_gocart[j],
		     	diameter_dust_bins_gocart[j+1],
			stdevs_dust_distrib[i],
			diameters_v_dust_distrib[i])			
}}

for (i in 1:n_dust_distrib)
matrix_gocart[i,j]


splits_dust_gocart<- number_conc_distrib %*% matrix_gocart



splits_dust_gocart <- array(0.,n_dust_bins_gocart)

for (j in 1:(n_dust_bins_gocart)) {
    for (i in 1:n_dust_distrib) {    
        splits_dust_gocart[j] <- splits_dust_gocart[j] + 
    	split_function(diameter_dust_bins_gocart[j],
		       diameter_dust_bins_gocart[j+1],
                       stdevs_dust_distrib[i],diameters_v_dust_distrib[i])

}}

splits_dust_gocart <- splits_dust_gocart/sum(splits_dust_gocart)




#seas 

n_seas_bins_gocart <- 4
n_seas_bins_macc <- 3

#gocart seas salt
#0.2 - 1.0 micron diameter  
#1.0 - 3.0 micron diameter 
#3.0 - 10.0 micron diameter 
#10.0 - 20.0 micron diameter 

gocart_seas_diameter_bins <- c(0.2,1.0,3.0,10.0,20.0)
macc_seas_diameter_bins <- c(0.03,0.5,5.,20.)*2 # from radius to diameter
 
#seas bins have a tri-lognormal distribution
#after Seinfeld and Pandis book from Jaenicke(1993)
#for seas aerosol

n_seas_bins_distrib <- 3
distrib_stdevs <- c(1.92,1.23,1.49)
distrib_diameters_n <- c(0.008,0.266,0.58)
distrib_diameters_v <- exp(log(distrib_diameters_n)+
		       3.*(log(distrib_stdevs))^2)


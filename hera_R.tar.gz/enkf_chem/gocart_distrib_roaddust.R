#in ums
nbins <- 5
gocart_radius_lower <- c(0.1,1.0,1.8,3.0,6.0)
gocart_radius_upper <- c(1.0,1.8,3.0,6.0,10.0)
gocart_radius_effective <- c(0.73,1.4,2.4,4.5,8.0)

#http://cafoaq.tamu.edu/files/2012/01/PU01207_6.pdf

stdev <- 2.2
mean <- 11.6
rho <- 2.5e3 #kg/m3

#http://www.hapman.com/support/bulk-material-density-guide.html
#for sand 
#rho <- 2.0e3

#after Liu JGR assume
#rho <- 2.6
#stdev <- 2.


mu <- log(mean)
sigma <- log(stdev)
x11(width=5,height=5)
plot(function(x) {dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
xlim=c(0,2*mean))

x11(width=5,height=5)
plot(function(x) {plnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
xlim=c(0,2*mean))

ibin <- nbins

prob <- array(NA,nbins)
mass_fraction <- array(NA,nbins)

for (ibin in 1:nbins) {

    xlow <- gocart_radius_lower[ibin]*2 #for diameter
    xup <- gocart_radius_upper[ibin]*2

    prob[ibin] <- plnorm(xup ,meanlog=mu,sdlog=sigma, log = FALSE)-
                  plnorm(xlow,meanlog=mu,sdlog=sigma, log = FALSE)
}

#scale probabilities based on emissions of PM10

probpm10 <- plnorm(10.,meanlog=mu,sdlog=sigma, log = FALSE)




#to plot a profile of increment
library(ncdf)

ncname <- './indata/ming_incr.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
p25 <- get.var.ncdf(nc,"P25")
seas1 <- get.var.ncdf(nc,"SEAS_1")
bc1 <- get.var.ncdf(nc,"BC1")
oc1 <- get.var.ncdf(nc,"OC1")
dust1 <- get.var.ncdf(nc,"DUST_1")
close.ncdf(nc)

lev <- 1

nx <- dim(p25)[1]
ny <- dim(p25)[2]

keystring <- expression(paste("[",mu,"g","  ",m^{-3},"]"))

species <- "p25"
zlims <- c(-10,30)
data <- p25[,,lev]

species <- "seas1"
zlims <- c(-0.5,3.0)
data <- seas1[,,lev]

species <- "bc1"
zlims <- c(-2.5,0.)
data <- bc1[,,lev]

species <- "oc1"
zlims <- c(-6.,0.)
data <- oc1[,,lev]

species <- "dust1"
zlims <- c(-3.,1.)
data <- dust1[,,lev]

picname <- paste("./pics/",species,"_contour.tiff",sep='')
tiff(picname,width = 800, height = 500,bg="white")
filled.contour(1:nx,1:ny,data,
nlevels=6,col=c("lightskyblue","limegreen","yellow",
"orange","red","purple","violet"),zlim=zlims,
xaxs="i",yaxs="i",
key.title = title(main=keystring))
dev.off()


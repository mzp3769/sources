#to plot two pm25 profiles
library(ncdf)
source("gaspari.R")

ncname <- './indata/test_829/dust_1_prof.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
pb <- get.var.ncdf(nc,"PB")
pp <- get.var.ncdf(nc,"P")
close.ncdf(nc)

top <- 40
levels <- 1:top

pprof <- -log((pp+pb)/(pp[1]+pb[1]))

gasparlogp <- array(0,top)

for (k in levels) {
    gasparlogp[k] <- gaspari(pprof[k])
}

enkfprof1 <- gasparlogp
enkfprof2 <- gasparlogp


ymin <- min(pprof[1:top])
ymax <- max(pprof[1:top])
xmin <- min(enkfprof1,enkfprof2)
xmax <- max(enkfprof1,enkfprof2)


xlabstring <- expression(
paste("Cut-off",sep=""))
ylabstring <- expression(paste(-log,"(p/",p[s],")"))

#pdf("./pics/profile_dust.pdf",width = 3.5, height = 7,
#bg="white")

width <- 400
height <- 600

ylabstring <- expression(paste(-log,"(p/",p[s],")"))

png(paste("./pics/gaspari_prof.png",sep=''),
    width = width, height = height ,bg="white")

par(mar=c(5, 4.5, 4, 2)+0.1)

plot(enkfprof1[1:top],pprof[1:top],type="l",col="black",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.5,cex.lab=1.5,lwd=3,cex=1.5,
xlim=c(xmin,xmax),ylim=c(ymin,ymax))
#lines(enkfprof2[1:top],pprof[1:top],col="orange",lwd=3)
#legend(x=xmax,y=ymax,xjust=1,yjust=1,
#col=c("violet","orange"),legend=c("No_Met","Met"),
#lwd=3,cex=0.9)

dev.off()



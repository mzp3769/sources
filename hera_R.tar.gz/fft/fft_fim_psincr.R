#to get spectrum for fim pising along a longitude line

fname <- file(paste('./indata/psincr_line.log'),"ra")
tmp <- readLines(fname)
close(fname)	

ntimes <- length(tmp)-1

fname <- file(paste('./indata/psincr_line.log'),"ra")
dims <- array(scan(fname,what=0,n=2))
nx <- dims[1]
myline <- dims[2]

allstats <- array(NA,c(ntimes,nx))

i <- 1
for (i in 1:ntimes) {
      allstats[i,] <- array(scan(fname,what=0,nx,quiet=TRUE))
      print(i)
      i <- i+1
}

close(fname)

magn <- array(NA,c(ntimes,nx/2+1))

for (i in 1:ntimes) {
    test <- fft(allstats[i,])
    magn[i,] <- Mod(test[1:(length(test)/2+1)])
}
xx <- 0:(length(magn[1,])-1)

width <- 600
height <- 400

limit1 <- 50
limit2 <- 200

xxlength <- length(xx)

xmin <- min(xx)
xmax <- max(xx)

ymin <- 0.
ymax <- max(magn)

for (i in 1:ntimes) {
    print(c(i,1))
    picname <- paste("./pics/fft_fim_psincr_1_",sprintf("%03i",i),".png",
    sep='')
    png(picname,width=width, height=height,bg="white")
    plot(x=xx,y=magn[i,],xlim=c(xmin,xmax),
    ylim=c(ymin,ymax),
    type='l',xlab="Frequency",ylab="Magnitude",xaxs="i",col="red",lwd=3)
    ymean <- mean(magn[i,1:limit1])
    yarray <- array(ymean,xxlength)
    yarray[(limit1+1):xxlength] <- NA
    lines(x=xx,y=yarray,col="black",lwd=4)
    dev.off()
}


xmin <- min(xx[limit1:xxlength])
xmax <- max(xx[limit1:xxlength])

ymin <- 0.
ymax <- max(magn[,limit1:limit2])

for (i in 1:ntimes) {
    print(c(i,2))
    picname <- paste("./pics/fft_fim_psincr_2_",sprintf("%03i",i),".png",
    sep='')
    png(picname,width=width, height=height,bg="white")
    plot(x=xx[limit1:xxlength],y=magn[i,limit1:xxlength],
    xlim=c(xmin,xmax),ylim=c(ymin,ymax),
    type='l',xlab="Frequency",ylab="Magnitude",xaxs="i",col="red",lwd=3)
    ymean <- mean(magn[i,limit1:limit2])
    yarray <- array(ymean,length(limit1:xxlength))
    yarray[(limit2+1):xxlength] <- NA
    lines(x=xx,y=yarray,col="black",lwd=4)
    dev.off()
}

xmin <- min(xx[limit2:xxlength])
xmax <- max(xx[limit2:xxlength])

ymin <- 0.
ymax <- max(magn[,limit2:xxlength])

for (i in 1:ntimes) {
    print(c(i,3))
    picname <- paste("./pics/fft_fim_psincr_3_",sprintf("%03i",i),".png",
    sep='')
    png(picname,width=width, height=height,bg="white")
    plot(x=xx[limit2:xxlength],y=magn[i,limit2:xxlength],
    xlim=c(xmin,xmax),ylim=c(ymin,ymax),
    type='l',xlab="Frequency",ylab="Magnitude",xaxs="i",col="red",lwd=3)
    ymean <- mean(magn[i,limit2:xxlength])
    yarray <- array(ymean,length(limit2:xxlength))
    lines(x=xx[limit2:xxlength],y=yarray,col="black",lwd=4)
    dev.off()
}

#to plot timeseries from surfrad and  aeronet for same locations
#Sioux_Fal  43.736  -96.626
#Table_Mou  40.125 -105.237
#BONDVILLE  40.053  -88.372
#Bondville   40.05  -88.37
#SiouxFalls  43.73  -96.62
#TableMounta 40.12 -105.24

library(ncdf4)

infile_surfrad <- "./indata/surfrad.nc"
infile_aeronet <- "./indata/aeronet.nc"

nc <- nc_open(infile_surfrad,readunlim=FALSE, write=FALSE )
hdr_arr_len_surfrad <- nc$dim[["hdr_arr_len"]]$len
obs_arr_len_surfrad <- nc$dim[["obs_arr_len"]]$len
nobs_surfrad <- nc$dim[["nobs"]]$len
hdr_sid_surfrad <- ncvar_get(varid="hdr_sid",nc)
obs_arr_surfrad <- ncvar_get(varid="obs_arr",nc)
hdr_vld_surfrad <- ncvar_get(varid="hdr_vld",nc)
nc_close(nc)

nc <- nc_open(infile_aeronet,readunlim=FALSE, write=FALSE )
hdr_arr_len_aeronet <- nc$dim[["hdr_arr_len"]]$len
obs_arr_len_aeronet <- nc$dim[["obs_arr_len"]]$len
nobs_aeronet <- nc$dim[["nobs"]]$len
hdr_sid_aeronet <- ncvar_get(varid="hdr_sid",nc)
obs_arr_aeronet <- ncvar_get(varid="obs_arr",nc)
hdr_vld_aeronet <- ncvar_get(varid="hdr_vld",nc)
nc_close(nc)

i_surfrad_b <- which(hdr_sid_surfrad=="Bondville")
i_surfrad_s <- which(hdr_sid_surfrad=="SiouxFalls")
i_surfrad_t <- which(hdr_sid_surfrad=="TableMount")

i_aeronet_b <- which(hdr_sid_aeronet=="BONDVILLE")
i_aeronet_s <- which(hdr_sid_aeronet=="Sioux_Fall")
i_aeronet_t <- which(hdr_sid_aeronet=="Table_Moun")

aod_surfrad_b <- obs_arr_surfrad[obs_arr_len_surfrad,i_surfrad_b]
time_surfrad_b <- hdr_vld_surfrad[i_surfrad_b]
dates_surfrad_b <- as.POSIXlt(paste(substr(time_surfrad_b,start=1,stop=4),"-",
                          substr(time_surfrad_b,start=5,stop=6),"-",
                          substr(time_surfrad_b,start=7,stop=8)," ",
                          substr(time_surfrad_b,start=10,stop=11),":",
                          substr(time_surfrad_b,start=12,stop=13),":",
                          substr(time_surfrad_b,start=14,stop=15),sep=""))


aod_surfrad_s <- obs_arr_surfrad[obs_arr_len_surfrad,i_surfrad_s]
time_surfrad_s <- hdr_vld_surfrad[i_surfrad_s]
dates_surfrad_s <- as.POSIXlt(paste(substr(time_surfrad_s,start=1,stop=4),"-",
                          substr(time_surfrad_s,start=5,stop=6),"-",
                          substr(time_surfrad_s,start=7,stop=8)," ",
                          substr(time_surfrad_s,start=10,stop=11),":",
                          substr(time_surfrad_s,start=12,stop=13),":",
                          substr(time_surfrad_s,start=14,stop=15),sep=""))

aod_surfrad_t <- obs_arr_surfrad[obs_arr_len_surfrad,i_surfrad_t]
time_surfrad_t <- hdr_vld_surfrad[i_surfrad_t]
dates_surfrad_t <- as.POSIXlt(paste(substr(time_surfrad_t,start=1,stop=4),"-",
                          substr(time_surfrad_t,start=5,stop=6),"-",
                          substr(time_surfrad_t,start=7,stop=8)," ",
                          substr(time_surfrad_t,start=10,stop=11),":",
                          substr(time_surfrad_t,start=12,stop=13),":",
                          substr(time_surfrad_t,start=14,stop=15),sep=""))

aod_aeronet_b <- obs_arr_aeronet[obs_arr_len_aeronet,i_aeronet_b]
time_aeronet_b <- hdr_vld_aeronet[i_aeronet_b]
dates_aeronet_b <- as.POSIXlt(paste(substr(time_aeronet_b,start=1,stop=4),"-",
                          substr(time_aeronet_b,start=5,stop=6),"-",
                          substr(time_aeronet_b,start=7,stop=8)," ",
                          substr(time_aeronet_b,start=10,stop=11),":",
                          substr(time_aeronet_b,start=12,stop=13),":",
                          substr(time_aeronet_b,start=14,stop=15),sep=""))

aod_aeronet_s <- obs_arr_aeronet[obs_arr_len_aeronet,i_aeronet_s]
time_aeronet_s <- hdr_vld_aeronet[i_aeronet_s]
dates_aeronet_s <- as.POSIXlt(paste(substr(time_aeronet_s,start=1,stop=4),"-",
                          substr(time_aeronet_s,start=5,stop=6),"-",
                          substr(time_aeronet_s,start=7,stop=8)," ",
                          substr(time_aeronet_s,start=10,stop=11),":",
                          substr(time_aeronet_s,start=12,stop=13),":",
                          substr(time_aeronet_s,start=14,stop=15),sep=""))

aod_aeronet_t <- obs_arr_aeronet[obs_arr_len_aeronet,i_aeronet_t]
time_aeronet_t <- hdr_vld_aeronet[i_aeronet_t]
dates_aeronet_t <- as.POSIXlt(paste(substr(time_aeronet_t,start=1,stop=4),"-",
                          substr(time_aeronet_t,start=5,stop=6),"-",
                          substr(time_aeronet_t,start=7,stop=8)," ",
                          substr(time_aeronet_t,start=10,stop=11),":",
                          substr(time_aeronet_t,start=12,stop=13),":",
                          substr(time_aeronet_t,start=14,stop=15),sep=""))


timesplot <- c("2015/08/01","2015/08/10","2015/08/20","2015/08/30")
tcolors <- c("red","blue")

pngname <- "./outdata/bondville_tseries.png"
png(pngname,width=600,height=400,bg="white")

plot(dates_surfrad_b,aod_surfrad_b,xlab="Bondville",ylab="AOD 550nm",xaxt='n',xaxs="i",
cex.axis=1.,cex.lab=1.,type="n",lwd=2,cex=1.)
axis.POSIXct(1,dates_surfrad_b,format="%D",at=timesplot)

points(dates_surfrad_b,aod_surfrad_b,
       col=tcolors[1],pch=19,cex=0.85)
points(dates_aeronet_b,aod_aeronet_b,
       col=tcolors[2],pch=15,cex=0.75)

dev.off()

pngname <- "./outdata/siouxfalls_tseries.png"
png(pngname,width=600,height=400,bg="white")

plot(dates_surfrad_s,aod_surfrad_s,xlab="Sioux Falls",ylab="AOD 550nm",xaxt='n',xaxs="i",
cex.axis=1.,cex.lab=1.,type="n",lwd=2,cex=1.)
axis.POSIXct(1,dates_surfrad_s,format="%D",at=timesplot)
tcolors <- c("red","blue")
points(dates_surfrad_s,aod_surfrad_s,
       col=tcolors[1],pch=19,cex=0.85)
points(dates_aeronet_s,aod_aeronet_s,
       col=tcolors[2],pch=15,cex=0.75)

dev.off()

pngname <- "./outdata/tablemountain_tseries.png"
png(pngname,width=600,height=400,bg="white")

plot(dates_surfrad_t,aod_surfrad_t,xlab="Table Mountain",ylab="AOD 550nm",xaxt='n',xaxs="i",
cex.axis=1.,cex.lab=1.,type="n",lwd=2,cex=1.)
axis.POSIXct(1,dates_surfrad_t,format="%D",at=timesplot)
tcolors <- c("red","blue")
points(dates_surfrad_t,aod_surfrad_t,
       col=tcolors[1],pch=19,cex=0.85)
points(dates_aeronet_t,aod_aeronet_t,
       col=tcolors[2],pch=15,cex=0.75)

dev.off()


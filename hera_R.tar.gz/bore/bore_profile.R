#name <- "TH_adv_dy_prof.ascii"
#name <- "TH_pbl_prof.ascii"
name <- "CLW_prof.ascii"
#name <- "TH_pbl_prof.ascii"
#x11()
#margin=c(1.,1,1,0)

#png("q_prof.png",width = 380, height = 360,bg="lightblue")
png("clw_prof.png",bg="lightblue")
#par(font=4)
#par(mai=margin,lab=c(5,5,1))

ylabstring <- expression("Z(m)")
xlabstring <- expression("UTC")

#dev.set(3)
infile <- file(name,"ra")
header <- list(varname="A",date="A",npoints=1)
header <- scan(infile,what=header,nmax=1)
a <- readLines(infile)
ntimes <- (length(a)+1)/(header$npoints+1)
close(infile)
infile <- file(name,"ra")
var <-array(0,c(2,ntimes,header$npoints))
for (i in 1:ntimes) {
    	header <- scan(infile,what=header,nmax=1) 
	var[,i,] <- array(scan(infile,what=0.,n=2*header$npoints))
}
close(infile)

#par(ticks=FALSE)
filled.contour(seq(0,ntimes-1,1),var[2,1,],var[1,,]*1.e3,nlevels=11,
color.palette=rainbow,plot.axes=TRUE,
xlab=xlabstring,ylab=ylabstring,cex.lab=1.2,cex.axis=1.2)


val<-35.35
par(las=0)
axis(1,at=c(.0,val*.25,val*.5,val*.75,,val),labels=c("0600","0700","0800","0900","1000"),rnorm(7))

#axis(2,at=c(0,500,1000,1500,2000,2500,3000,3500),
#labels=c("0","500","1000","1500","2000","2500","3000","3500"),xa)
par(las=2)
axis(2,outer=FALSE)
#text(-0.75,3600,labels="zo = 0.5 m",cex=1.6)

#col=c("blue","skyblue1","violet","yellow2"))
#color.palette=terrain.colors)
#color.palette=topo.colors)
#color.palette=cm.colors)
#col = topo.colors(20))
#color.palette=rainbow,col = rainbow(10))
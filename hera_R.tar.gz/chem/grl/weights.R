namea <- "./data/weights_ave_8hrmx_2d.ascii"
ncolsa <- 11


xlabstring=expression("days ")
ylabstring=expression("weights")

postscript("weights.eps",width=3.32, height=2.75,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
#png("C_H.png",width = 380, height = 360,bg="lightblue")
#x11()
onefile <- TRUE
#pdf(file=ifelse(onefile,"C_H.5m.pdf"))
#pdf(file=ifelse(onefile,"t_ground.pdf"))

infile <- file(namea,"ra")
varlist <- scan(infile,list("",0,0.,0.,0.,0.,0.,0.,0.,0.))
nrows <- length(varlist[[1]])
close(infile)

#layout(matrix(c(1,2), 1, 1, byrow = TRUE), respect=TRUE)
#par(mfrow=c(1,1))



#########1st fig

xmin <- 1.
xmax <- nrows
ymin <- 0.0
ymax <- 0.4
margin=c(.4,.3,.2,.1)
par(tcl=.2)
par(font=1)
par(mai=margin)
#par(plt=c(0.2,.8,0.2,.5))
#par(fin=c(3,2))
plot(varlist[[2]],varlist[[3]],"l",col="blue",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=2,
xlab=xlabstring,ylab=ylabstring,
xaxs="i",yaxs="i",cex.axis=.1,cex.lab=.1,axes=FALSE)
lines(varlist[[2]],varlist[[4]],"l",col="magenta",lwd=2)
lines(varlist[[2]],varlist[[5]],"l",col="green",lwd=2)
lines(varlist[[2]],varlist[[6]],"l",col="brown",lwd=2)
lines(varlist[[2]],varlist[[7]],"l",col="cyan",lwd=2)
lines(varlist[[2]],varlist[[8]],"l",col="purple",lwd=2)
lines(varlist[[2]],varlist[[9]],"l",col="red",lwd=2)
lines(varlist[[2]],varlist[[10]],"l",col="orange",lwd=2)
legend(25,.4,c("A","B","C","D","E","F","G","bias"),
col=c("blue","magenta","green","brown","cyan","purple","red","orange"),
lwd=2,bty="n",y.intersp=1,cex=.5)
#par(ps=10)
#text(3,0.37,labels="a",cex=.7,vfont=c("serif","plain"))
par(cex.axis=.7)
par(las = 0)
par(tcl=0.)
axis(1,at=c(15),labels=c("length of training period (days)"),lwd=.7)
par(tcl=-0.2)
axis(1,at=c(1,10,20,30),lwd=.7,labels=FALSE)
mtext(c(1,10,20,30),side=1,outer=FALSE,at=c(1,10,20,30),
cex=.6)
par(las = 1)
par(tcl=0)
axis(4,pos=c(30,0.),at=c(0.,.4),lwd=.7,labels=FALSE)
par(tcl=0.0)
axis(3,at=c(1,30),lwd=.7,labels=FALSE)
par(tcl=0.0)
#axis(3,at=c(4,53),lwd=.7,labels=c("Jul 06","Aug 31"))
par(tcl=-.2)
axis(2,pos=c(1,0.),at=c(.0,.1,.2,.3,.4),lwd=.7,labels=FALSE)
mtext(c("0.0   ","0.1   ","0.2   ","0.3   ","0.4   "),side=2,
outer=FALSE,at=c(.005,.105,.205,.305,.405),cex=.6)
#axis(2,pos=c(1,0.0),at=c(.0,.1,.2,.3,.4),lwd=.7)
#legend(-0.1,0.0485,c("ITER","WRF"),col=c("red","blue"),lwd=5,bty="o")
mtext(c(expression(paste(w[i],"  "))),side=2,outer=FALSE,
at=.42,cex=.8)

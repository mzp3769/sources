namea <- "./data/vars_8hrmx_2d.ascii"
nameb <- "./data/varst_8hrmx_2d.ascii"
ncolsa <- 2
col <- 1
cola <- 2

#xlabstring=expression("Date")
#ylabstring=expression("sigmas")

xlabstring=expression(" ")
ylabstring=expression(" ")

postscript("varst.eps",width=4.0, height=2.5,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "ComputerModern")
#png("C_H.png",width = 380, height = 360,bg="lightblue")
#x11()
onefile <- TRUE
#pdf(file=ifelse(onefile,"C_H.5m.pdf"))
#pdf(file=ifelse(onefile,"t_ground.pdf"))

infile <- file(namea,"ra")
a <- readLines(infile)
nrows <- length(a)
close(infile)

infile <- file(namea,"ra")
vara <-array(0,c(nrows,ncolsa))	
for (i in 1:nrows) {
	vara[i,] <- array(scan(infile,what=0.,n=ncolsa))
}
close(infile)

infile <- file(nameb,"ra")
varb <-array(0,c(nrows,ncolsa))	
for (i in 1:nrows) {
	varb[i,] <- array(scan(infile,what=0.,n=ncolsa))
}
close(infile)

layout(matrix(c(1,2), 1, 1, byrow = TRUE), respect=TRUE)
#par(mfrow=c(1,1))

#########1st fig

xmin <- 1.
xmax <- 56.
ymin <- 0.10
ymax <- 0.4
margin=c(.4,.45,.05,.1)
par(tcl=.2)
par(font=2)
par(mai=margin)
#par(plt=c(0.2,.8,0.2,.5))
#par(fin=c(3,2))
plot(vara[,col],vara[,cola],"l",col="black",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=2,
xlab=xlabstring,ylab=ylabstring,
xaxs="i",yaxs="i",cex.axis=1.,cex.lab=1.,axes=TRUE)
par(cex.axis=.7)
par(las = 0)
par(tcl=-.2)
axis(1,at=c(1,10,20,30,40,50),lwd=1)
axis(1,at=c(1,56),lwd=1,labels=FALSE)
par(las = 1)
par(tcl=0)
axis(4,pos=c(56,0.1),at=c(0.1,.4),lwd=1,labels=FALSE)
par(tcl=-.5)
#axis(3,at=c(1,10,20,30,40,50),lwd=1)
par(tcl=0)
axis(3,at=c(1,56),lwd=1,labels=FALSE)
par(tcl=-.5)
axis(2,pos=c(1,0.1),at=c(0.1,.2,.3,.4),lwd=1)
#legend(-0.1,0.0485,c("ITER","WRF"),col=c("red","blue"),lwd=5,bty="o")
#text(-0.75,0.0465,labels="zo = 0.5 m",cex=1.6)

layout(matrix(c(1,2), 2, 1, byrow = TRUE))
#par(mfrow=c(2,1))

########2nd fig
xmin <- 1.
xmax <- 56.
ymin <- 0.10
ymax <- 0.6
#margin=c(.4,.45,.05,.1)
par(tcl=.5)
par(font=2)
par(mai=margin)
#par(plt=c(0.2,.8,0.2,.5))
#par(fin=c(3,2))
plot(vara[,col],vara[,cola],"l",col="black",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=2,
xlab=xlabstring,ylab=ylabstring,
xaxs="i",yaxs="i",cex.axis=1.,cex.lab=1.,axes=FALSE)
plot(varb[,col],varb[,cola],"l",col="black",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=2,
xlab=xlabstring,ylab=ylabstring,
xaxs="i",yaxs="i",cex.axis=1.,cex.lab=1.,axes=FALSE)
par(cex.axis=.7)
par(las = 0)
par(tcl=-.2)
axis(1,at=c(1,10,20,30,40,50),lwd=1)
axis(1,at=c(1,56),lwd=1,labels=FALSE)
par(las = 1)
par(tcl=0)
axis(4,pos=c(56,0.1),at=c(0.1,.6),lwd=1,labels=FALSE)
par(tcl=0)
axis(3,at=c(1,56),lwd=1,labels=FALSE)
par(tcl=-.2)
axis(2,pos=c(1,0.1),at=c(0.1,.2,.3,.4,.5,.6),lwd=1)
#legend(-0.1,0.0485,c("ITER","WRF"),col=c("red","blue"),lwd=5,bty="o")
#text(-0.75,0.0465,labels="zo = 0.5 m",cex=1.6)




namea <- "./data/stats_20_8hrmx_2d.ascii"
nameb <- "./data/stats_01_8hrmx_2d.ascii"
ncolsa <- 5


xlabstring=expression("days")
ylabstring=expression("weights")

postscript("stats_corr.eps",width=3.32, height=1.8,,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
#png("C_H.png",width = 380, height = 360,bg="lightblue")
#x11()
onefile <- TRUE
#pdf(file=ifelse(onefile,"C_H.5m.pdf"))
#pdf(file=ifelse(onefile,"t_ground.pdf"))

infile <- file(namea,"ra")
varlist <- scan(infile,list("",0,0.,0.,0.,0.))
nrows <- length(varlist[[1]])
close(infile)

infile <- file(nameb,"ra")
varlistb <- scan(infile,list("",0,0.,0.,0.,0.))
nrows <- length(varlistb[[1]])
close(infile)

xmin <- 1
xmax <- 7
ymin <- .6
ymax <- .75
margin=c(.4,.35,.15,.05)
par(tcl=.2)
par(font=1)
par(mai=margin)
plot(varlist[[2]],varlist[[6]],col="red",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=2,
xlab=xlabstring,ylab="",
xaxs="i",yaxs="i",cex.axis=.1,cex.lab=.1,axes=FALSE,type="n")
#points(varlist[[2]],varlist[[6]],pch=20,col="blue")
points(varlistb[[2]],varlistb[[6]],pch=20,col="black",cex=0.6)
text(1.3,.735,labels="d",cex=.7,vfont=c("serif","plain"))
par(cex.axis=.7)
par(las = 0)
par(tcl=0.)
par(tcl=-0.2)
axis(1,at=c(1,2,3,4,5,6,7),lwd=.7,labels=FALSE)
par(tcl=-.2)
axis(2,pos=c(1,.55),at=c(.6,.65,.7,.75),lwd=.7,labels=FALSE)
#axis(2,pos=c(1,.55),lwd=.7,labels=FALSE)
par(las = 1)
par(tcl=0)
axis(4,pos=c(7,.6),lwd=.7,labels=FALSE)
par(tcl=0.0)
axis(3,at=c(1,7),lwd=.7,labels=FALSE)
par(tcl=0.0)
par(tcl=-.2)
mtext(c("0.60   ","0.65   ","0.70   ","0.75   "),side=2,
outer=FALSE,at=c(.6025,.6525,.7025,.7525),cex=.6)
mtext("Corr ",side=2,outer=FALSE,at=.765,cex=.7)
par(tcl=0.0)
axis(1,at=c(4),labels=c("number of ensemble members"),lwd=.7)
mtext(c(1,2,3,4,5,6,7),side=1,outer=FALSE,at=c(1,2,3,4,5,6,7),cex=.6)
axis(4,pos=c(7,.55),at=c(.6,.65,.75),lwd=.7,labels=FALSE)

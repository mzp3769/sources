namea <- "./data/merror_01.txt"
ncolsa <- 1
col <- 1
cola <- 1

infile <- file(namea,"ra")
a <- readLines(infile)
nrows <- length(a)
close(infile)

infile <- file(namea,"ra")
vara <-array(0,c(nrows,ncolsa))	
for (i in 1:nrows) {
	vara[i,] <- array(scan(infile,what=0.,n=ncolsa))
}
close(infile)

postscript("quantile.eps",width=5.32, height=5.5,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

qqnorm(vara)

#fitdistr(vara,"normal",list(mean=0.16, sd=10.08)) 
# to fit a distribution to data
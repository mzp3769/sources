namea <- "./data/stats_20_8hrmx_2d.ascii"
nameb <- "./data/stats_01_8hrmx_2d.ascii"
ncolsa <- 5


xlabstring=expression("days")
ylabstring=expression("weights")

postscript("stats_rmse.eps",width=3.32, height=1.5,,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
#png("C_H.png",width = 380, height = 360,bg="lightblue")
#x11()
onefile <- TRUE
#pdf(file=ifelse(onefile,"C_H.5m.pdf"))
#pdf(file=ifelse(onefile,"t_ground.pdf"))

infile <- file(namea,"ra")
varlist <- scan(infile,list("",0,0.,0.,0.,0.))
nrows <- length(varlist[[1]])
close(infile)

infile <- file(nameb,"ra")
varlistb <- scan(infile,list("",0,0.,0.,0.,0.))
nrows <- length(varlistb[[1]])
close(infile)

xmin <- 1
xmax <- 7
ymin <- 9
ymax <- 14
margin=c(.05,.35,.15,.05)
par(tcl=.2)
par(font=1)
par(mai=margin)
plot(varlist[[2]],varlist[[4]],col="red",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=2,
xlab=xlabstring,ylab="",
xaxs="i",yaxs="i",cex.axis=.1,cex.lab=.1,axes=FALSE,type="n")
#points(varlist[[2]],varlist[[4]],pch=20,col="blue")
points(varlistb[[2]],varlistb[[4]],pch=20,col="black",cex=0.6)
text(1.3,13.6,labels="b",cex=.7,vfont=c("serif","plain"))
par(cex.axis=.7)
par(las = 0)
par(tcl=0.)
par(tcl=-0.2)
axis(1,at=c(1,2,3,4,5,6,7),lwd=.7,labels=FALSE)
par(tcl=-.2)
axis(2,pos=c(1,9),at=9:14,lwd=.7,labels=FALSE)
axis(2,pos=c(1,9),lwd=.7,labels=FALSE)
par(las = 1)
par(tcl=0)
axis(4,pos=c(7,9),lwd=.7,labels=FALSE)
par(tcl=0.0)
axis(3,at=c(1,30),lwd=.7,labels=FALSE)
par(tcl=0.0)
par(tcl=-.2)
mtext(c(" 9   ","10   ","11   ","12   ","13   ","14   "),side=2,
outer=FALSE,at=c(9.1,10.1,11.1,12.1,13.1,14.1),cex=.6)
#legend(-0.1,0.0485,c("ITER","WRF"),col=c("red","blue"),lwd=5,bty="o")
par(las = 1)
mtext("RMSE (ppbv)",side=2,outer=FALSE,at=14.45,cex=.7,line=-1.7)


namea <- "./data/stats_20_8hrmx_2d.ascii"
nameb <- "./data/stats_01_8hrmx_2d.ascii"
ncolsa <- 5


xlabstring=expression("days")
ylabstring=expression("weights")

postscript("stats_bias.eps",width=3.32, height=1.5,,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
#png("C_H.png",width = 380, height = 360,bg="lightblue")
#x11()
onefile <- TRUE
#pdf(file=ifelse(onefile,"C_H.5m.pdf"))
#pdf(file=ifelse(onefile,"t_ground.pdf"))

infile <- file(namea,"ra")
varlist <- scan(infile,list("",0,0.,0.,0.,0.))
nrows <- length(varlist[[1]])
close(infile)

infile <- file(nameb,"ra")
varlistb <- scan(infile,list("",0,0.,0.,0.,0.))
nrows <- length(varlistb[[1]])
close(infile)

xmin <- 1
xmax <- 7
ymin <- -2.5
ymax <- 0.5
margin=c(.05,.35,.15,.05)
#par(omd=c(.0,.115,.0,.0))
par(tcl=.2)
par(font=1)
par(mai=margin)
#par(plt=c(0.2,.8,0.2,.5))
#par(fin=c(3,2))
#plot(1:7, -2:1.5, type = "n")
plot(varlist[[2]],varlist[[3]],col="red",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=2,
xlab=xlabstring,ylab="",
xaxs="i",yaxs="i",cex.axis=.1,cex.lab=.1,axes=FALSE,type="n")
#points(varlist[[2]],varlist[[3]],pch=20,col="blue")
points(varlistb[[2]],varlistb[[3]],pch=20,col="black",cex=.6)
#par(ps=10)
text(1.3,0.25,labels="a",cex=.7,vfont=c("serif","plain"))
par(cex.axis=.7)
par(las = 0)
par(tcl=0.)
par(tcl=-0.2)
axis(1,at=c(1,2,3,4,5,6,7),lwd=.7,labels=FALSE)
#mtext(c(1,2,3,4,5,6,7),side=1,outer=FALSE,at=c(1,2,3,4,5,6,7),
#cex=.6)
par(tcl=-.2)
axis(2,pos=c(1,-2),at=c(-2.,-1.5,-1.,-.5,.0,.5,1.,1.5,2),
lwd=.7,labels=FALSE)
axis(2,pos=c(1,-2),lwd=.7,labels=FALSE)
par(las = 1)
par(tcl=0)
axis(4,pos=c(7,-1.5),lwd=.7,labels=FALSE)
par(tcl=0.0)
axis(3,at=c(1,30),lwd=.7,labels=FALSE)
par(tcl=0.0)
par(tcl=-.2)
mtext(c("-2.0   ","-1.0   ","0.0   ","1.0   "),side=2,
outer=FALSE,at=c(-1.95,-.95,.05,1.05),cex=.6)
#legend(-0.1,0.0485,c("ITER","WRF"),col=c("red","blue"),lwd=5,bty="o")
par(las = 1)
mtext("Bias (ppbv) ",side=2,outer=FALSE,at=.69,cex=.7,line=-1.25)


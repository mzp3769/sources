namea <- "rank.txt"
ncolsa <- 2
col <- 1
cola <- 2

xlabstring=expression(rank)
ylabstring=expression(P(rank))

#png("rank_precip.png",width = 360, height = 360,bg="lightblue")
#x11()
onefile <- TRUE
pdf(file=ifelse(onefile,"rank.pdf"))

infile <- file(namea,"ra")
a <- readLines(infile)
nrows <- length(a)
close(infile)

infile <- file(namea,"ra")
vara <-array(0,c(nrows,ncolsa))	
for (i in 1:nrows) {
	vara[i,] <- array(scan(infile,what=0.,n=ncolsa))
}
close(infile)

xmin <- 0
xmax <- nrows
ymin <- 0.
ymax <- 1.
margin=c(.85,.8,.2,.15)
par(font=2)
par(mai=margin,tcl=.0001,las=3)
barplot(vara[,cola],width=1,space=0,col="black",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=2,
xlab=xlabstring,ylab=ylabstring,
axes=FALSE,
#xaxs="i",
#yaxs="i",
cex.axis=0.01,cex.lab=1.2)
par(las = 0)
axis(1,at=c(0.5,nrows-.5),labels=c("1",as.character(nrows)))
par(las = 1)
axis(2,pos=c(0.,1),at=c(0.,1),lwd=2)
axis(4,pos=c(nrows,0),labels=FALSE,lwd=2)
axis(3,at=c(0,nrows),labels=FALSE,lwd=2)
#lines(varb[,col],varb[,colb],"l",col="black",lwd=5)
#legend(-0.1,0.0485,c("ITER","WRF"),col=c("black","black"),lwd=5,bty="o",
#lty=c(3,1))
#text(-0.75,0.0465,labels="zo = 0.5 m",cex=1.6)

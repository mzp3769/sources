#to plot new scales for PM2.5/o3 using new becov program
name <- "./indata/wrf_reg_berror.txt"
infile <- file(name,"ra")

data <- scan(infile,what=1,n=3)

nz <- data[1]
ncat <- data[2]
nspecies <- data[3]

eta <- scan(infile,what=1,n=nz)

lat <- scan(infile,what=1,n=ncat)

species_names <- array("",c(nspecies))
hscale <- array(NA,c(ncat,nz,nspecies))
stdev <- array(NA,c(ncat,nz,nspecies))
vscale <- array(NA,c(nz,nspecies))

for (i in 1:nspecies) {
    species_names[i] <- scan(infile,what='a',nlines=1)
    vscale[,i] <- scan(infile,what=1,n=nz)
    for (j in 1:nz) {
        hscale[,j,i] <- scan(infile,what=1,n=ncat)
	stdev[,j,i] <- scan(infile,what=1,n=ncat)
	}
}

close(infile)


#below should be loop for species

x11(width=5.6,height=5)

x <- lat
y <- 1:nz
nlevs <- 20
zmin <- min(hscale)
zmax <- max(hscale)
filled.contour(x,y,hscale[,,1],
               nlevels=nlevs,zlim=range(zmin,zmax),
               color.palette=rainbow)

x11(width=5,height=5)

hscale_ave <- array(NA,c(nz,nspecies))
for  (i in 1:nz) {
     hscale_ave[i,1] <- mean(hscale[1:ncat,i,1])
}

plot(hscale_ave[,1],1:nz,col="black",,xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=3)


x11(width=5.6,height=5)

x <- lat
y <- 1:nz
nlevs <- 20
zmin <- min(stdev)
zmax <- max(stdev)
filled.contour(x,y,stdev[,,1],
               nlevels=nlevs,zlim=range(zmin,zmax),
               color.palette=rainbow)

x11(width=5,height=5)

stdev_ave <- array(NA,c(nz,nspecies))
for  (i in 1:nz) {
     stdev_ave[i,1] <- mean(stdev[1:ncat,i,1])
}

plot(stdev_ave[,1],1:nz,col="black",,xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=3)



x11(width=5,height=5)
plot(vscale[,1],1:nz,col="black",,xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=3)

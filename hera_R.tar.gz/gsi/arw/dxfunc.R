dx <- 20.
dy <- 20.
dx <- sqrt(dx*dy)

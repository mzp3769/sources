#to plot correlations for gsi
source("dxfunc.R")
name <- "./indata/hdist_cor.txt"
infile <- file(name,"ra")

data <- scan(infile,what=1,n=6,quiet=TRUE)
nz <- data[3]
distmax <- data[4]
nbin <- data[6]
#form <- yy ~ (1 + xx/l) * exp(-xx/l)
b <- 2
form <- yy ~ exp(-xx^b/(l^b))
corrmin <- exp(-9)
dist <- array(NA,nbin)
count <- array(NA,nbin)
correl <- array(NA,c(nbin,nz))
lscale <- array(NA,nz)
exponent <-  array(NA,nz)
binmax <- array(NA,nz)
colors <- rainbow(nz)

for (k in 1:nz) {
   data <- scan(infile,what=1,n=1,quiet=TRUE)
   skip=0
   for (ibin in 1:nbin) {
       data <- scan(infile,what=1,n=4,quiet=TRUE)
       dist[ibin] <- data[2]
       count[ibin] <- round(data[4]/1.e4)
       if (skip==1) next
       if (data[3] < corrmin || count[ibin] == 0) {
           skip=1
	   binmax[k] <- ibin-1
           next
       }
       correl[ibin,k] <- data[3]
   }
} 
close(infile)

sumcount <- sum(count)

print("Calculating function fits")

for (k in 1:nz) {
    icount <- 0
    yy <- array(NA,sumcount)
    xx <- array(NA,sumcount)
    for (ibin in 1:binmax[k]) {
            countplus <- icount+count[ibin]
            xx[icount+1:countplus] <- dist[ibin]
            yy[icount+1:countplus] <- correl[ibin,k]
            icount <- countplus
    }
#    data <- coef(nls(form, start=list(l = 10.,b=1),
    data <- coef(nls(form, start=list(l = 10.),
                      na.action=na.omit))
    lscale[k]  <- abs(data[1])
    print(k)
#    exponent[k] <- data[2]
#    print(exponent[k])
}

exponent <- array(b,nz)

x11(width=5,height=5)

for (k in 1:nz) {  
   print(lscale[k]*dx*1.e3/sqrt(2.))
   plot(dist[1:binmax[k]],correl[1:binmax[k],k],
   col=colors[1],xlim=c(0,dist[binmax[k]]),ylim=c(0,1),
   xlab="Distance",ylab="Correlation",xaxs="i",yaxs="i",
   cex.axis=2,type="l",lwd=2)
   x <- dist[1:binmax[k]]
   y <- exp(-x^exponent[k]/(lscale[k]^exponent[k]))
   lines(x,y,col="blue",lwd=2)
   locator()
}

scales <- array(NA,c(2,nz))
scales[1,1:nz] <- seq(1,nz)
scales[2,1:nz] <- lscale[1:nz]*dx*1.e3/sqrt(2.)

title <- "./indata/h_lscale_R.txt"
write(nz,file=title,ncolumns=1,append=FALSE)
write(scales,file=title,ncolumns=2,append=TRUE)



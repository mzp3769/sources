#to plot vertical covariances for gsi
ncut <- 5

name <- "/export/scratch2/pagowski/stuff/R/gsi/arw/indata/v_eigenv.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1)

eigenval <- array(NA,nz)
eigenvec <- array(NA,c(nz,nz))


for (k in 1:nz) {
    i <- scan(infile,what=1,n=1)
    eigenval[k] <-  scan(infile,what=1,n=1)
    eigenvec[,k] <- scan(infile,what=1,n=nz)
} 

close(infile)

x11(width=5,height=5)
plot(1:nz,eigenval,col=colors[1],ylim=c(0.,max(eigenval)),xlim=c(1,nz),
xlab="Eigenvalue number",ylab="Eigenvalues",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=3)
points(1:nz,eigenval,col=colors[1],pch=20)

xmin <- 1
xmax <- nz
ymin <- 0
ymax <- 1
sumeig <- array(NA,nz)

for (k in 1:nz) {
    sumeig[k] <- sum(eigenval[1:k])
} 

x11(width=5,height=5)
plot(1:nz,sumeig/sumeig[nz],
col=colors[1],ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab="Eigenvalue number",ylab="Cumulative eigenvalues",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=3)
points(1:nz,sumeig/sumeig[nz],col=colors[1],pch=20)

colors <- rainbow(ncut)

xmax <- max(eigenvec)
xmin <- min(eigenvec)
ymin <- 1
ymax <- nz

x11(width=5,height=5)
plot(NA,NA,
col=colors[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="Eigenvector",ylab="Vertical level",xaxs="i",yaxs="i",
cex.axis=2,type="l")
for (k in 1:ncut) {
   lines(eigenvec[,k],1:nz,col=colors[k],lwd=2)
}

legend(xmax-.3,ymax,cex=.7,lwd=2,1:ncut,col=colors[1:ncut])



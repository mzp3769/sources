dx <- 12.
dy <- 12.
dx <- sqrt(dx*dy)

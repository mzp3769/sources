#to plot correlations for gsi

name <- "/export/scratch2/pagowski/stuff/R/gsi/arw/indata/lh_hdist_corbin.txt"
infile <- file(name,"ra")
nbin <- scan(infile,what=1,n=1)

dist <- array(NA,nbin)
correl <- array(NA,nbin)
freq <- array(NA,nbin)
for (k in 1:nbin) {
   data <- scan(infile,what=1,n=4,quiet=TRUE)
   if (data[2] < 0.) break
   dist[k] <- data[2]*dx
   correl[k] <- data[3]
   freq[k] <- data[4]
} 
close(infile)

freq <- freq/sum(freq,na.rm=TRUE)

xmin <- 0.
xmax <- max(dist,na.rm=TRUE)

ymin <- 0
ymax <- 0.015 #max(freq,na.rm=TRUE)

png("./pngs/lh_hcor_distfreq_bin.png",
width = 500, height = 500,bg="white")

plot(dist,freq,col="red",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="Distance [km]",ylab="Frequency",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=2)

dev.off()



#to calculate and plot vertical correlations for gsi from wrfvar
#outputs data in gsi format ie. 1./v_aero(jj-nvars,k,1:ncat)/dsig(k)


varname <- "sulf"
method <- "nmc"

times <- "all"
times <- c("00z","06z","12z","18z")


ntimes <- length(times)

for (i in 1:ntimes) {

    print(times[i])

    name <- paste("./indata/aero_be_vcor_",method,"_",
    	           times[i],".txt",sep='')
    infile <- file(name,"ra")
    data <- scan(infile,what=1,n=2,quiet = TRUE)

    naeros <- data[1]
    nz <- data[2]

    dsig <- array(NA,nz)	
    for (k in 1:nz) {
    	junk <- scan(infile,what=1,n=2,quiet = TRUE)		
	dsig[k] <- junk[2]
    }

    stats <- array(1,c(ntimes,nz,nz))

    while (TRUE) {
      name <- scan(infile,what='a',n=1,quiet = TRUE)
      if ( name != varname ) {
          for (k in 1:(nz-1)) {
      	    for (l in (k+1):nz) {
	        junk <- scan(infile,what=1,n=3,quiet=TRUE)
            }
          } 
      } else {
          for (k in 1:(nz-1)) {
      	    for (l in (k+1):nz) {
	        data <- scan(infile,what=1,n=3,quiet=TRUE)
		stats[i,k,l] <- data[3]
		stats[i,l,k] <- data[3]
            }
          } 
          break
      }
    }
    
    close(infile)

    correl <- stats[i,,]

    nlevs=20
    zmin <- min(correl)
    zmax <- max(correl)	
    x <- 1:(nz-1)
    y <- x


    b <- 2
    form <- yy ~ exp(-xx^b/(l^b))
    vscale <- array(NA,nz)

    for (k in 1:(nz-1)) {
       xx <- x - k 
       yy <- correl[k,1:(nz-1)]
       data <- coef(nls(form, start=list(l = 3.),

#algorithm="port", #virtually same as default
#algorithm="plinear", #slightly shorter than default
                    na.action=na.omit))
       vscale[k] <- data[1]
    }

    vscale[nz] <- vscale[nz-1]

    vscale <- 1./(vscale/sqrt(2.))/dsig

    scales <- array(NA,c(2,nz))
    scales[1,1:nz] <- seq(1,nz)
    scales[2,1:nz] <- vscale

    title <- paste("./outdata/v_lscale_wrfvar_R_4gsi_",method,"_",
		    varname,'_',times[i],".txt",sep='')
    write(nz,file=title,ncolumns=1,append=FALSE)
    write(scales,file=title,ncolumns=2,append=TRUE)

}
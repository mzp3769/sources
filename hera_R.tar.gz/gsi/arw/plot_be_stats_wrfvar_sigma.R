#to plot scales and variances

method <- "nmc"
varname <- "sulf"
stdevlabel <- expression(paste("Stdev [",mu,g," ",m^{-3},"]",,sep="")) 

#times <- "all"
#timesl <- "ALL"
#cols <- "black"
times <- c("00z","06z","12z","18z")
timesl <- c("00 UTC","06 UTC","12 UTC","18 UTC")

cols <- c("orange","black","blue","red")

ntimes <- length(times)
indir <- "./indata"

source("magnitude_func.R")

namep <- paste(indir,'/','eta_pave.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1,quiet = TRUE)
etalevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=2,quiet = TRUE)
   etalevels[k] <- data[1]
}
close(infile)

for (i in 1:ntimes) {
    namefile <- paste('./indata/aero_be_',method,'_',
    	              times[i],'.txt',sep='')
    infile <- file(namefile,"ra")
    data <- scan(infile,what=1,n=4,quiet = TRUE)
    naeros <- data[1]
    nz <- data[2]
    ncats <- data[3]
    nstats <- data[4]

    for (k in 1:nz) {
             junk <- scan(infile,what=1,n=2,quiet = TRUE)
    }


    if ( i == 1) {
        stats <- array(NA,c(ntimes,nz,nstats))
    }

    while (TRUE) {
      name <- scan(infile,what='a',n=1,quiet = TRUE)
      if ( name != varname ) {
         for (k in 1:nz) {
      	     junk <- scan(infile,what=1,n=4,quiet = TRUE)
	 }

      } else {
         print(c(name,timesl[i]))	
         for (k in 1:nz) {
             stats[i,k,] <- scan(infile,what=1,n=4,quiet = TRUE)
         }
         break
      }
    }

    close(infile)

}

stdev <- stats[,,2]
hlscale <- stats[,,3]
vlscale <- stats[,,4]


#bounds <- log10_ceiling(c(xmin,xmax))

xmin <- min(stdev)
xmax <- max(stdev)

#xmin <- bounds[1]
#xmax <- bounds[2]

ymin <- 0
ymax <- 1

png(paste("./pics/stdev_wrfvar_",method,"_",varname,"_sigma.png",sep=''),
    width = 600, height = 600,bg="white")

#etalevels <- seq(1,nz)

if ( is.null(dim(stdev)) ) {
   plot(stdev[1:nz],etalevels[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab=stdevlabel,ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=3,cex=1)
   points(stdev[1:nz],etalevels[1:nz],col=cols[1],pch=22,cex=0.65,
       lwd=3)
} else {

plot(stdev[1,1:nz],etalevels[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab=stdevlabel,ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=3,cex=1)
points(stdev[1,1:nz],etalevels[1:nz],col=cols[1],pch=22,cex=0.65,
       lwd=3)

}

if ( !is.null(dim(stdev)) ) {

for (i in 2:ntimes) {
    lines(stdev[i,1:nz],etalevels[1:nz],lwd=3,col=cols[i])
    points(stdev[i,1:nz],etalevels[1:nz],col=cols[i],pch=22,cex=0.65,
       lwd=3)
}
}

legend(x=xmax,y=ymin,lwd=3,pch=c(22,22,22,22),
legend=timesl,col=cols,xjust=1,cex=1.) 

dev.off()

hlscale <- hlscale/1000.

xmin <-  ((min(hlscale)%/%1)-10)
xmax <- ((max(hlscale)%/%1)+10)


png(paste("./pics/hlscale_wrfvar_",method,"_",varname,"_sigma.png",sep=''),
width = 600, height = 600,bg="white")

#etalevels <- seq(1,nz)

if (is.null(dim(hlscale))) {

plot(hlscale[1:nz],etalevels[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="km",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=3,cex=1)
points(hlscale[1:nz],etalevels[1:nz],col=cols[1],pch=22,cex=0.65,
       lwd=3)
} else {

plot(hlscale[1,1:nz],etalevels[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="km",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=3,cex=1)
points(hlscale[1,1:nz],etalevels[1:nz],col=cols[1],pch=22,cex=0.65,
       lwd=3)

}

if ( !is.null(dim(hlscale)) ) {

for (i in 2:ntimes) {
    lines(hlscale[i,1:nz],etalevels[1:nz],lwd=3,col=cols[i])
    points(hlscale[i,1:nz],etalevels[1:nz],col=cols[i],pch=22,cex=0.65,
       lwd=3)
}
}

legend(x=xmin,y=ymin,lwd=3,pch=c(22,22,22,22),
legend=timesl,col=cols,xjust=0,cex=1.) 

dev.off()

xmin <- 0
xmax <- ((max(vlscale)%/%1)*1+2)


png(paste("./pics/vlscale_wrfvar_",method,"_",varname,"_sigma.png",sep=''),
width = 600, height = 600,bg="white")

#etalevels <- seq(1,nz)

if ( is.null(dim(vlscale))) {

plot(vlscale[1:nz],etalevels[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Grid unit",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=3,cex=1)
points(vlscale[1:nz],etalevels[1:nz],col=cols[1],pch=22,cex=0.65,
       lwd=3)

} else {

plot(vlscale[1,1:nz],etalevels[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Grid unit",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=3,cex=1)
points(vlscale[1,1:nz],etalevels[1:nz],col=cols[1],pch=22,cex=0.65,
       lwd=3)

}

if ( !is.null(dim(vlscale))) {

for (i in 2:ntimes) {
    lines(vlscale[i,1:nz],etalevels[1:nz],lwd=3,col=cols[i])
    points(vlscale[i,1:nz],etalevels[1:nz],col=cols[i],pch=22,cex=0.65,
       lwd=3)
}

}

legend(x=xmax,y=ymin,lwd=3,pch=c(22,22,22,22),
legend=timesl,col=cols,xjust=1,cex=1.) 

dev.off()


log10_ceiling <- function(x) {
    10^(ceiling(log10(x)))
}


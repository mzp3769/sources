#to plot vertical correlations for gsi
name <- "./indata/v_lscale_R.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1)

vscale <- array(1,c(2,nz))

for (k in 1:(nz-1)) {
        data <- scan(infile,what=1,n=2,quiet=TRUE)
	vscale[1,k] <- data[1]
        vscale[2,k] <- data[2]
} 

close(infile)

xmin <- 0
xmax <- max(vscale[2,1:(nz-1)],na.rm=TRUE)
ymin <- 0
ymax <- max(vscale[1,1:(nz-1)],na.rm=TRUE)

png("./pngs/vscale.png",width = 500, height = 500,bg="white")
plot(vscale[2,1:(nz-1)],vscale[1,1:(nz-1)],type="l",col="red",lwd=3,
xlab="Lengthscale",ylab="Model level",xaxs="i",yaxs="i",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),cex.axis=2)
dev.off()

#to plot covariance for gsi

name <- "/export/scratch2/pagowski/stuff/R/gsi/arw/indata/lh_hdist_covbin.txt"
infile <- file(name,"ra")
nbin <- scan(infile,what=1,n=1)
dist <- array(NA,nbin)
correl <- array(NA,nbin)

for (k in 1:nbin) {
   data <- scan(infile,what=1,n=3,quiet=TRUE)
   if (data[2] < 0.) break
   dist[k] <- data[2]*dx
   correl[k] <- data[3]#*1.e-6
} 
close(infile)


xmin <- 0.
xmax <- max(dist,na.rm=TRUE)

ymin <- min(correl,na.rm=TRUE)
ymax <- max(correl,na.rm=TRUE)

png("./pngs/lh_hcov_scales_bin.png",
width = 500, height = 500,bg="white")

plot(dist,correl,col="red",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="Distance",ylab="Covariance",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=2)

points(dist,correl,col="red",pch=20)

dev.off()



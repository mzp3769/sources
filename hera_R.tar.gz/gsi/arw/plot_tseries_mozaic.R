#plot time series for da verification for mozaic

indir <- "./indata/mozaic"
outdir <- "./pngs/mozaic"
utc <- "7"

var <- "o3"
hour <- "18"
ihour <- as.integer(hour)

fname_noda <-  paste(indir,'/noassim/','stats_',var,'_',
hour,'.txt.',utc,sep="")

infile_noda <- file(fname_noda,"ra")
data <- scan(infile_noda,what=1,nlines=1)
ntimes <- data[1]
nstats <- data[2]
allstats_noda <- array(NA,c(ntimes,nstats))
for (i in 1:ntimes) {
    allstats_noda[i,] <- scan(infile,what=1,nlines=1)
}

close(infile_noda)


fname_dasfc <-  paste(indir,'/assim_sfc/','stats_',var,'_',
hour,'.txt.',utc,sep="")
infile_dasfc <- file(fname_dasfc,"ra")
data <- scan(infile_dasfc,what=1,nlines=1)
ntimes <- data[1]
nstats <- data[2]
allstats_dasfc <- array(NA,c(ntimes,nstats))
for (i in 1:ntimes) {
    allstats_dasfc[i,] <- scan(infile,what=1,nlines=1)
}

close(infile_dasfc)

fname_dav <-  paste(indir,'/assim_v/','stats_',var,'_',
hour,'.txt.',utc,sep="")
infile_dav <- file(fname_dav,"ra")
data <- scan(infile_noda,what=1,nlines=1)
ntimes <- data[1]
nstats <- data[2]
allstats_dav <- array(NA,c(ntimes,nstats))
for (i in 1:ntimes) {
    allstats_dav[i,] <- scan(infile,what=1,nlines=1)
}

close(infile_dav)

fname_dasfcv <-  paste(indir,'/assim_sfcv/','stats_',var,'_',
hour,'.txt.',utc,sep="")
infile_dasfcv <- file(fname_dasfcv,"ra")
data <- scan(infile_noda,what=1,nlines=1)
ntimes <- data[1]
nstats <- data[2]
allstats_dasfcv <- array(NA,c(ntimes,nstats))
for (i in 1:ntimes) {
    allstats_dasfcv[i,] <- scan(infile,what=1,nlines=1)
}

close(infile_dasfcv)

tiffname <- paste(outdir,'/tseries_bias.',utc,'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- expression("Time (UTC)")
ylabstring <- "BIAS [ppbv]"


xmin <- 0+ihour
xmax <- 48+ihour

ymin <- min(allstats_noda[,3],allstats_dasfc[,3],allstats_dasfcv[,3],
            allstats_dav[,3])
ymax <- max(allstats_noda[,3],allstats_dasfc[,3],allstats_dasfcv[,3],
            allstats_dav[,3])

zero <- array(0,ntimes)

plot(allstats_noda[,1],allstats_noda[,3],xlim=c(xmin,xmax),
ylim=c(ymin,ymax),col="black",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=4,cex=1.)
lines(allstats_dasfc[,1],allstats_dasfc[,3],col="red",lwd=4)
lines(allstats_dav[,1],allstats_dav[,3],col="blue",lwd=4)
lines(allstats_dasfcv[,1],allstats_dasfcv[,3],col="green",lwd=4)
lines(allstats_dav[,1],zero,lwd=1)
dev.off()


tiffname <- paste(outdir,'/tseries_prmse.',utc,'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- "Time (UTC)"
ylabstring <- "PRMSE [ppbv]"

xmin <- 0+ihour
xmax <- 48+ihour

ymin <- min(allstats_noda[,4],allstats_dasfc[,4],allstats_dasfcv[,4],
            allstats_dav[,4])
ymax <- max(allstats_noda[,4],allstats_dasfc[,4],allstats_dasfcv[,4],
            allstats_dav[,4])

plot(allstats_noda[,1],allstats_noda[,4],xlim=c(xmin,xmax),
ylim=c(ymin,ymax),col="black",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=4,cex=1.)
lines(allstats_dasfc[,1],allstats_dasfc[,4],col="red",lwd=4)
lines(allstats_dav[,1],allstats_dav[,4],col="blue",lwd=4)
lines(allstats_dasfcv[,1],allstats_dasfcv[,4],col="green",lwd=4)
dev.off()


tiffname <- paste(outdir,'/tseries_corr.',utc,'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- expression("Time (UTC)")
ylabstring <- "CORR"

xmin <- 0+ihour
xmax <- 48+ihour

ymin <- min(allstats_noda[,5],allstats_dasfc[,5],allstats_dasfcv[,5],
	    allstats_dav[,5])
ymax <- max(allstats_noda[,5],allstats_dasfc[,5],allstats_dasfcv[,5],
            allstats_dav[,5])

plot(allstats_noda[,1],allstats_noda[,5],xlim=c(xmin,xmax),
ylim=c(ymin,ymax),col="black",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=4,cex=1.)
lines(allstats_dasfc[,1],allstats_dasfc[,5],col="red",lwd=4)
lines(allstats_dav[,1],allstats_dav[,5],col="blue",lwd=4)
lines(allstats_dasfcv[,1],allstats_dasfcv[,5],col="green",lwd=4)
dev.off()


tiffname <- paste(outdir,'/tseries_concave.',utc,'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- "Time (UTC)"
ylabstring <- "CONC [ppbv]"

xmin <- 0+ihour
xmax <- 48+ihour

ymin <- min(allstats_noda[,8],allstats_noda[,9],
            allstats_dasfc[,8],allstats_dasfc[,9],
            allstats_dasfcv[,8],allstats_dasfcv[,9],
            allstats_dav[,8],allstats_dav[,9])-5

ymax <- max(allstats_noda[,8],allstats_noda[,9],
            allstats_dasfc[,8],allstats_dasfc[,9],
            allstats_dasfcv[,8],allstats_dasfcv[,9],
            allstats_dav[,8],allstats_dav[,9])+5

plot(allstats_noda[,1],allstats_noda[,8],xlim=c(xmin,xmax),
ylim=c(ymin,ymax),col="black",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="p",lwd=6,cex=1.)
lines(allstats_noda[,1],allstats_noda[,9],col="black",lwd=4)
lines(allstats_dasfc[,1],allstats_dasfc[,9],col="red",lwd=4)
lines(allstats_dav[,1],allstats_dav[,9],col="blue",lwd=4)
lines(allstats_dasfcv[,1],allstats_dasfcv[,9],col="green",lwd=4)

dev.off()



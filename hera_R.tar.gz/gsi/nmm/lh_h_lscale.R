#to plot correlations for gsi
name <- "./indata/lh_hdist_corbin.txt"
infile <- file(name,"ra")
nbin <- scan(infile,what=1,n=1)

dist <- array(NA,nbin)
correl <- array(NA,nbin)
count <- array(NA,nbin)
a <- .8 #o3
a <- .75 #pm
b <- 2
form <- yy ~ a*exp(-xx^b/(l^b))
corrmin <- exp(-9)

for (k in 1:nbin) {
   data <- scan(infile,what=1,n=4,quiet=TRUE)
   if (data[3] < corrmin) {
       binmax <- k-1
       break
   }
   dist[k] <- data[2]
   correl[k] <- data[3]
   count[k] <- round(data[4]/1e2)
} 
close(infile)

sumcount <- sum(count,na.rm=TRUE)

yy <- array(NA,sumcount)
xx <- array(NA,sumcount)

print("Calculating function fits")

icount <- 0
for (ibin in 1:binmax) {
        countplus <- icount+count[ibin]
        xx[icount+1:countplus] <- dist[ibin]
        yy[icount+1:countplus] <- correl[ibin]
#        print(length(xx)); print(ibin) ; print(count[ibin])  
#        print(countplus)
        icount <- countplus
}

xx <- xx[1:sumcount]
yy <- yy[1:sumcount]

#data <- coef(nls(form, start=list(l = 10.,b=1),na.action=na.omit))
#data <- coef(nls(form, start=list(l = 10.,a=1.),na.action=na.omit))
data <- coef(nls(form, start=list(l = 10.),na.action=na.omit))
hl_lscale <- data[1]
#intercept <- a
intercept <- data[2]
exponent <-  data[2]
exponent <- b
intercept <- a

x11(width=5,height=5)

plot(dist[1:binmax],correl[1:binmax],
   col=colors[1],xlim=c(0,dist[binmax]),ylim=c(0,1),
   xlab="Distance",ylab="Correlation",xaxs="i",yaxs="i",
   cex.axis=2,type="l",lwd=2)
   x <- dist[1:binmax]
   y <- intercept*exp(-x^exponent/(hl_lscale^exponent))
   lines(x,y,col="blue",lwd=2)


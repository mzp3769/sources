dx <- 8.6
dy <- 8.05
dx <- sqrt(dx*dy)

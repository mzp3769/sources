#to plot correlations for gsi

name <- "/export/scratch2/pagowski/stuff/R/gsi/indata/p_ave.txt"
infile <- file(name,"ra")
nzp <- scan(infile,what=1,n=1)
plevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=2)
   plevels[k] <- data[2]*1.e-2
}
close(infile)

name <- "/export/scratch2/pagowski/stuff/R/gsi/indata/h_lscale_R.txt"
infile <- file(name,"ra")
nzl <- scan(infile,what=1,n=1)
if (nzp != nzl)  stop("Levels don't match")
hlscale <- array(NA,nzl)

for (k in 1:nzl) {
   data <- scan(infile,what=1,n=2)
   hlscale[k] <- data[2]*1.e-3
}
close(infile)

xmin <- 0
xmax <- (max(hlscale)%/%100)*100+100
ymin <- 50
ymax <- 1000

x11(width=5,height=5)

plot(hlscale,plevels,
   col=colors[1],xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Lengthscale",ylab="Pressure",xaxs="i",yaxs="i",
   cex.axis=2,type="l",lwd=2)
points(hlscale,plevels,col=colors[1],pch=20)


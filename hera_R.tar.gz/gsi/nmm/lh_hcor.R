#to plot correlations for gsi
name <- "/export/scratch2/pagowski/stuff/R/gsi/indata/lh_hdist_cor.txt"
infile <- file(name,"ra")
ncor <- scan(infile,what=1,n=1)

dist <- array(NA,ncor)
correl <- array(NA,ncor)

i=0
print("Reading input file")
for (k in 1:ncor) {
   data <- scan(infile,what=1,n=2,quiet=TRUE)
   dist[k] <- data[1]
   correl[k] <- data[2]
   if (is.na(dist[k]))  break 
   i <- i+1
} 
close(infile)

nlines <- i

print("Finished reading input file")
print(paste(as.character(nlines),"read"))

xmin <- 0.
xmax <- max(dist,na.rm=TRUE)

ymin <- -1.
ymax <- 1.

x11(width=5,height=5)

plot(NA,NA,col="black",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="Distance",ylab="Correlation",xaxs="i",yaxs="i",
cex.axis=2,type="p")
points(dist[1:nlines],correl[1:nlines],pch=20,cex=0.2,col="black")





#to plot correlations for gsi
name <- "/export/scratch2/pagowski/stuff/R/gsi/indata/lh_hdist_corbin.txt"
infile <- file(name,"ra")
nbin <- scan(infile,what=1,n=1)

dist <- array(NA,nbin)
correl <- array(NA,nbin)

for (k in 1:nbin) {
   data <- scan(infile,what=1,n=4,quiet=TRUE)
   if (data[2] < 0.) break
   dist[k] <- data[2]
   correl[k] <- data[3]
} 
close(infile)


xmin <- 0.
xmax <- max(dist,na.rm=TRUE)

ymin <- min(correl,na.rm=TRUE)
ymax <- 1.

x11(width=5,height=5)

plot(dist,correl,col="red",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="Distance",ylab="Correlation",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=2)





#to plot horizontal covariances for gsi
name <- "/export/scratch2/pagowski/stuff/R/gsi/indata/hdist_cov.txt"
infile <- file(name,"ra")
data <- scan(infile,what=1,n=6)
nz <- data[3]
nbin <- data[6]
distmax <- data[5]

dist <- array(NA,nbin)
covar <- array(NA,c(nbin,nz))
stdev  <- array(NA,nz)

for (k in 1:nz) {
   data <- scan(infile,what=1,n=2)
   stdev[k] <- data[2]
   for (ibin in 1:nbin) {
       data <- scan(infile,what=1,n=3)
       dist[ibin] <- data[2]
       covar[ibin,k] <- data[3]
   }
} 

close(infile)

colors <- rainbow(nz)

xmin <- 0
xmax <- (max(dist)%/%100)*100+100
ymin <- min(covar)
ymax <- max(covar)

#graphics.off()

x11(width=5,height=5)

nzhalf=nz%/%2
nzp=nz-3

par(cex=0.65)

plot(dist,covar[,1],col=colors[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="Distance",ylab="Covariance",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=2)
#axis(1, at=xvec, labels=lxvec,cex.axis=2)
for (k in 2:nzp) {
   lines(dist,covar[,k],col=colors[k],lwd=2)
}

legend(xmax-120,ymax,cex=.7,lwd=2,1:nzhalf,col=colors[1:nzhalf])
legend(xmax-60 ,ymax,cex=.7,lwd=2,(nzhalf+1):nzp,
       col=colors[(nzhalf+1):nzp])

x11(width=5,height=5)
plot(stdev[1:nz],1:nz,
col=colors[1],xlim=c(0.,max(stdev)),ylim=c(1,nz-1),
xlab="Stdev",ylab="Vertical level",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=3)





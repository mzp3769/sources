
infile1 <- file("./indata/fim_stats_test_117_134318.in","ra")
indata1 <- readLines(infile1)
close(infile1)

ndata1 <- length(indata1)

infile2 <- file("./indata/fim_stats_test_118_134318.in","ra")
indata2 <- readLines(infile2)
close(infile2)

ndata2 <- length(indata2)

xlabstring <- "Timesteps over 9 hours"
ylabstring <- "Pressure [hPa]"

xmin <- 0
xmax <- ndata1-1

ymin <- min(as.numeric(indata1),as.numeric(indata2))-0.5
ymax <- max(as.numeric(indata1),as.numeric(indata2))+0.5


pngname <- paste('./pics/diags_ipn.png',sep="")
png(pngname,width=600, height=400.,bg="white")
plot(seq(0,ndata1-1,1),indata1,"l",lwd=3,yaxs="i",xaxs="i",col="blue",
cex=1.,ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab=xlabstring, ylab=ylabstring,)
lines(seq(0,ndata2-1,1),indata2,"l",lwd=3,col="red")
legend(x=xmax,y=ymin,xjust=1,yjust=0,col=c("blue","red"),
lwd=3,legend=c("sigma p", "hybrid sigma p -Theta"),cex=0.9)
dev.off()

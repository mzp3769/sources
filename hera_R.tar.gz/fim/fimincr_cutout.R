#to test if nn_ interpolation works ok

fdata <- file(paste('./indata/incr.txt'),"ra")
dims <- array(scan(fdata,what=0,n=2))
nx <- dims[1]
ny <- dims[2]

gridvals <- array(NA,c(nx,ny))

for (i in 1:ny) {
    print(i)
    gridvals[,ny-i+1] <- array(scan(fdata,what=0.,n=nx))
    
}

#gridvals=log(gridvals/1000.)*100 #for pressure before correction

close(fdata)

north <- 89
south <- -89

left <- 0
right <- 359

xx <- seq(left,right,(right-left)/(nx-1))

yy <- seq(south,north,(north-south)/(ny-1))

#128
nx1 <- 160
nx2 <- 220

ny1 <- 30
ny2 <- 65

#254
nx1 <- 280
nx2 <- 350

ny1 <- 30
ny2 <- 72 

xx <- seq(nx1,nx2,1)

yy <- seq(ny1,ny2,1)

width <- 10*(nx2-nx1)
height <- 10*(ny2-ny1)

picname <- "incr_cutout.png"
png(picname,width=width, height=height,bg="white")
filled.contour(xx,yy-90,gridvals[nx1:nx2,ny1:ny2],color.palette=rainbow)

dev.off()



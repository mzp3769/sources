#to plot differences for enkf

test <- "test_032"

library(ncdf)

ps2d <- "PRES_127_SFC"
ps3d <- "PRES_127_HYBL"
temp <- "TMP_127_HYBL"
ugrd <- "U_GRD_127_HYBL"
vgrd <- "V_GRD_127_HYBL"


ncname <- paste('./indata/',test,'/diff_2_mensmean.nc',sep='')
nc <- open.ncdf(ncname, readunlim=FALSE, write=TRUE )
psfc <- get.var.ncdf(nc,ps2d)
p <- get.var.ncdf(nc,ps3d)
t <- get.var.ncdf(nc,temp)
u <- get.var.ncdf(nc,ugrd)
v <- get.var.ncdf(nc,vgrd)

close.ncdf(nc)

dims <- dim(t)

xdim <- dims[1]
ydim <- dims[2]
zdim <- dims[3]

nx <- xdim
ny <- ydim
nz <- zdim

north <- 90
south <- -90
left <- 0
right <- 359

xx <- seq(left,right,(right-left)/(nx-1))
yy <- seq(south,north,(north-south)/(ny-1))

width <- 800
height <- 600

picname <- paste('./pics/diffs_',test,'.png',sep='')
png(picname,width=width, height=height,bg="white")
zlev <- 20
gridvals <- t[,,zlev] 
gridvals <- u[,,zlev]
#gridvals <- p[,,zlev]
zmin <- -2.5
zmax <- 2.5
#gridvals <- psfc
#zmin <- -500.
#zmax <- 500.
#for individual
filled.contour(xx,yy,gridvals,#zlim=c(zmin,zmax),
nlevels=16,color.palette=rainbow)
dev.off()



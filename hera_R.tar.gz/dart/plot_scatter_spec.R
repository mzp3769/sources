tests <- c("test_141","test_137","test_140","test_300")
tests <- c("test_307","test_308")
tcolors <- c("red","violet","blue","orange","black")
danames <- c("GOCART_noDA","SORGAM_noDA")


colnumber_obs <- 2
colnumber_fcst <- 4
spec <- "OC"
network <- "improve"
maxconc <- 50 #to eliminate stamps for dates in the input file

#name <- names[colnumber]
#ylabstring <- as.character(expression(name,
#" [",mu,"g"," ", m^{-3},"]",sep=""))
#ylabstring <- expression(paste("[",mu,"g","  ",m^{-3},"]",
#sep=""))

ntests <- length(tests)

outdir <- "./pics/"
indir <- "./indata/"

varname <- spec

nmaxtimes <- 1e4

allstats <- array(NA,c(ntests,2,nmaxtimes))

ntimes <- array(NA,ntests)

k <- 1

for (test in tests) {
    fname <-  paste(indir,test,'/',network,'/obs_fcst_',varname,
    '.txt',sep="")
    infile <- file(fname,"ra")
    vartable <- try(
    read.table(infile,header=FALSE,skip=0),silent=TRUE)
    if (class(vartable)=="try-error") {
#    print(c("FILE EMPTY",infile))
    close(infile)
    next }
    ntimes[k] <- length(vartable[,1])
    if (ntimes[k] > nmaxtimes) {
    print("CRY FOUL: INCREASE nmaxtimes")
    stop(paste("nmaxtimes = ",as.character(nmaxtimes),
    " ntimes[",as.character(k),"] =",as.character(ntimes)))
    }
    allstats[k,1,1:ntimes[k]] <- 
    sapply(as.vector(vartable[,colnumber_obs]),
    function(x) {if (x > maxconc) x <- NA else x <- x})
    allstats[k,2,1:ntimes[k]] <- 
    as.vector(vartable[,colnumber_fcst]) 
    close(infile)

    tiffname <- paste(outdir,varname,'_',network,'_scatter_',
    tests[k],'.tiff',sep="")
    tiff(tiffname	,width = 600, height = 600,bg="white")
    maintitle <- paste(toupper(network),varname,sep=' : ')
    xlabstring <- "Observations"
    ylabstring <- "Model"

    xmin <- 0
    xmax <- max(0.,allstats[k,1:2,1:ntimes[k]],na.rm=TRUE)
    xmax <- xmax + 0.1*xmax
    ymin <- xmin
    ymax <- xmax

    plot(allstats[k,1,1:ntimes[k]],allstats[k,2,1:ntimes[k]],
    xlim=c(xmin,xmax),ylim=c(ymin,ymax),main=maintitle,
    col=tcolors,
    xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
    cex.axis=1.,cex.lab=1.,type="p",pch=20,cex=1.)

    k <- k+1

    dev.off()

}







test <- "test_122"

fields3d <- c("TT","UU","VV","GHT","QVAPOR")
levels <- c("P925","P850","P700","P500","P250")
fields2d <- c("T2","Q2","U10","V10")
units <- c("T [K]"
          ,expression(paste("U [m",s^{-1},"]"))
          ,expression(paste("V [m",s^{-1},"]"))
          ,"GHT [m]"
          ,expression(paste("QV [g",kg^{-1},"]"))
          )

fields <- c(fields3d,fields2d)	 

ncols=6

stats <- c("FBAR","OBAR","FSTDEV","OSTDEV","PR_CORR","ME","BCMSE","RMSE")

statname <- "ME"

indir="./outdata/"

fname <- paste(indir,'/',test,'_prior_',statname,'.txt',sep="")

thisfile <- file(fname,"ra")

header <- scan(thisfile,what='a',nlines=1)

allvars_pr <- NULL

while (TRUE) {
  data <- unlist(scan(thisfile,sep=','
               ,what=list("","",1,1,1,1),nlines=1))
  allvars_pr <- unlist(rbind(allvars_pr,c(data[1:2],
                          mean(as.numeric(data[3:6]),na.rm=TRUE))))
  if (data[1] == fields2d[length(fields2d)] ) break
}

close(thisfile)


fname <- paste(indir,'/',test,'_posterior_',statname,'.txt',sep="")

thisfile <- file(fname,"ra")

header <- scan(thisfile,what='a',nlines=1)

allvars_po <- NULL

while (TRUE) {
  data <- unlist(scan(thisfile,sep=','
               ,what=list("","",1,1,1,1),nlines=1))
  allvars_po <- unlist(rbind(allvars_po,c(data[1:2],
                          mean(as.numeric(data[3:6]),na.rm=TRUE))))
  if (data[1] == fields2d[length(fields2d)] ) break
}

close(thisfile)

i <- 1

for (field in fields3d) {
   locs <- which(!is.na(match(allvars_pr[, 1],field)))
   x_pr <- as.numeric(allvars_pr[locs,3])
   if (field == "QVAPOR") x_pr <- x_pr*1.e3
   y_pr <- as.numeric(gsub("P","",allvars_pr[locs,2]))

   unit <- units[i]

   locs <- which(!is.na(match(allvars_po[, 1],field)))
   x_po <- as.numeric(allvars_po[locs,3])
   if (field == "QVAPOR") x_po <- x_po*1.e3
   y_po <- as.numeric(gsub("P","",allvars_po[locs,2]))

   picname <- paste("./pics/pr_po_",field,"_",statname,"_",test,".pdf"
                   ,sep="")

   pdf(picname)  
   plot(x_pr,y_pr
   ,xlim=c(min(x_pr,x_po),max(x_po,x_pr))
   ,ylim=c(max(y_pr,y_po),min(y_pr,y_pr))
   ,xlab=unit,ylab="pressure[hPa]"
   ,cex.axis=2,type="l",lwd=2,col="red")

   lines(x_po,y_po,lwd=2,col="blue")
   dev.off()

   i <- i+1
}


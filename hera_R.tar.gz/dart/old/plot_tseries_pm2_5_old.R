library("chron")
year_start <- "2010"
month_start <- "05"
day_start <- "26"
hour_start <- "00"
minute_start <- "30"
secont_start <- "00"

plotdates <- c("2010/06/01","2010/07/01")

yyyymmdd_start <- paste(year_start,month_start,day_start,sep="-")

time_start <- paste(hour_start,minute_start,secont_start,sep=":")

date_start <- as.POSIXlt(paste(yyyymmdd_start,time_start),"UTC")

#plot time series for da verification for calnex

#WRITE(outunit,'(f7.2,i10,7e15.7)')date,nobsvalid_s,&
#                &bias_s,patrmse_s,corr_s,stdevobs_s,stdevfcst_s,&
#                   3      4        5
#                &obsave_s,fcstave_s

names <- c("BIAS","PRMSE","CORR") # (3,4,5)
colnumber <- 3

#name <- names[colnumber]
#ylabstring <- as.character(expression(name," [",mu,"g"," ", m^{-3},"]",sep=""))
#ylabstring <- expression(paste("[",mu,"g","  ",m^{-3},"]",sep=""))

#tests <- c("test_2","test_3","test_6","test_4")
#tests <- c("test_3","test_10","test_9","test_4")
tests <- c("test_101","test_103","test_102") #,"test_9","test_4")
ntests <- length(tests)
tcolors <- c("green","blue","red") #,"skyblue","red")
#danames <- c("NODA","ENKF_10","ENKF_9","GSI")
danames <- c("ENKF_1","GSI","NODA")

outdir <- "./pics/"
indir <- "./indata/"       

varname <- "PM2_5_DRY"

ntimes <- NULL
allstats <- NULL

for (test in tests) {
    fname <-  paste(indir,test,'/stats_',varname,'.txt',sep="")
    infile <- file(fname,"ra")
    vartable <- try(
    read.table(infile,header=FALSE,skip=0),silent=TRUE)
    if (class(vartable)=="try-error") {
#    print(c("FILE EMPTY",infile))
    close(infile)
    next }
    ntimes <- c(ntimes,length(vartable[,1]))
    nstats <- length(vartable[1,])
    allstats <- rbind(allstats,vartable)
    close(infile)

}

alldates <- seq(date_start,by=3600,length=max(ntimes))
    
tiffname <- paste(outdir,varname,'_',names[colnumber-2],'.tiff',sep="")
tiff(tiffname,width = 600, height = 400,bg="white")

xlabstring <- expression("Time")
ylabstring <- names[colnumber-2]

xmin <- min(alldates)
xmax <- max(alldates)

ymin <- min(allstats[,colnumber],na.rm=TRUE)
ymax <- max(allstats[,colnumber],na.rm=TRUE)

zero <- array(0,max(ntimes))

plot(alldates[1:ntimes[1]],allstats[1:ntimes[1],colnumber],
ylim=c(ymin,ymax),col=tcolors[1],
xlab='',ylab=ylabstring,xaxt='n',yaxs="i",xaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=2,cex=1.)
axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
zero <- array(0,max(ntimes))
lines(alldates[1:ntimes[1]],zero,col="black",lwd=2)

endline <- ntimes[1]

k <- 2
for (test in tests[k:ntests]) {
startline <- endline + 1 
endline <- endline + ntimes[k]
es <- endline - startline +1
lines(alldates[1:es],allstats[startline:endline,colnumber],
col=tcolors[k],lwd=2)
k <- k+1
}

#abline("v"=seq(0,xmax,6))


if (colnumber == 3 || colnumber == 5) {
legend(x=xmax,y=ymin,xjust=1,yjust=0,col=tcolors,
lwd=2,legend=danames,cex=1)
} else {
legend(x=xmax,y=ymax,xjust=1,yjust=1,col=tcolors,
lwd=2,legend=danames,cex=1)
}
dev.off()


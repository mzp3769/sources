#for pm(seed <- ?,black), voc(seed <- ?,red)  nh3(seed <- 18,green)
#bio(seed <- 51)
mu <- -.1
sigma <- .55
plot(function(x) {dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
xlim=c(0,5))
ex <- exp(mu+.5*sigma^2)
varx <- exp(2*mu + sigma^2)*(exp(sigma^2) - 1)


#for no (seed <- 21)
#mu <- -.08
#sigma <- .35
#plot(function(x) {dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
#xlim=c(0,5))
#ex <- exp(mu+.5*sigma^2)
#varx <- exp(2*mu + sigma^2)*(exp(sigma^2) - 1)



nx <- 134
ny <- 110
nxy <- nx*ny
xmin <- 0.1
xmax <- 4

#for pm(seed <- ?,black), voc(seed <- ?,red)  nh3(seed <- 18,green)
#bio(seed <- 51)

#seeds

name <- 'voc'
seed <- 10
seed <- 110

name <- 'nox'
seed <- 20
seed <- 120

name <- 'nh3'
seed <- 30
seed <- 130

name <- 'pm25'
seed <- 40
seed <- 140 

name <- 'bio'
seed <- 50
seed <- 150

set.seed(seed, kind = NULL)
x <- rlnorm(nxy, mean=mu, sd=sigma)

nens <- 20
x <- rlnorm(nens, mean=mu, sd=sigma)
z <- dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)

png("logfunc.png",width = 500, height = 500,bg="white")

plot(function(x) {dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
xlim=c(0,5))
x <- pmax(pmin(x,xmax),0.1)
points(x,z)

dev.off()


write(x,file=paste('factors_',name,'.txt',sep=''),
      ncolumns=1,append=FALSE)



par(col="black")


qlnorm(x), meanlog = mu, sdlog = sigma, lower.tail = TRUE, log.p = FALSE)
plnorm(x), meanlog = 0, sdlog = 1, lower.tail = TRUE, log.p = FALSE)


par(col="black")
plot(function(x) {dnorm(x,mean=1,sd=0.5, log = FALSE)},0:5)
x <- rnorm(100, mean=1, sd=.5)
qqnorm(x)# to check for normal distribution




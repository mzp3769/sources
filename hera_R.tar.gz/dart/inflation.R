# to plot inflation as alpha and sigma a parameter

alpha <- seq(from=0,to=3,by=0.05)
sigma_post <- seq(from=0.0 ,to=1, by=0.05)
sigma_new <- array(NA,c(length(alpha),length(sigma_post)))

for (i in (1:length(alpha))) {
for (j in (1:length(sigma_post))) {
    sigma_prior <- sigma_post[j]*3
    sigma_new[i,j] <- ((1.-alpha[i])*sigma_post[j]+alpha[i]*sigma_prior)
    if (sigma_new[i,j] < 0) sigma_new[i,j] <- NA
}}

x11(width=5,height=5)

filled.contour(alpha,sigma_post,sigma_new,nlevels=50,color.palette=rainbow)
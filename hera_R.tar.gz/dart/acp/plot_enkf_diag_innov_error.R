var="pm2_5"

tests <- c("test_137")#,"test_124")

simnames <- c("RMSE","SQRT(S+R)","SPREAD")

tcolors <- c("blue","red","green3")

indir="../indata"

plotdates <- c("2010/06/01","2010/06/15","2010/07/01","2010/07/15")
nmaxtimes <- 1e3
nmaxnames <- 10
ntests <- length(tests)
ntimes <- 0

allstats <- array(NA,c(ntests,nmaxtimes,nmaxnames))

k <- 1

for (test in tests) {

    fname <- paste(indir,"/",test,"/enkf_diags_",test,"_",var,".log"
                   ,sep='')

    thisfile <- file(fname,"ra")
    
    names <- scan(thisfile,what='a',nlines=1)

    vartable <- try(
    read.table(thisfile,header=FALSE,skip=0,sep=' '),silent=TRUE)
    if (class(vartable)=="try-error") {
	print(c("FILE EMPTY",c(field,level)))
	close(thisfile)			  
    next } 
    close(thisfile)


    nlines <- dim(vartable)[1]
    dates <- NULL
    times <- NULL

    if (ntimes < nlines) {

        for (i in 1:nlines) {

	    years <- vartable[i,1] %/% 1000000
	    months <- (vartable[i,1] %% 1000000) %/% 10000
	    days  <-  (vartable[i,1] %% 10000) %/% 100
	    hours <-  (vartable[i,1] %% 100)

	    dates <- c(dates,paste(as.character(years),"-",
		 as.character(months),"-",as.character(days),sep=""))
	    times <- c(times,paste(as.character(hours),":00:00",sep=""))
	}    

    ntimes <- nlines


    alldates <- as.POSIXlt(paste(dates,times),"UTC")

    }
	
    nnames <- length(names)

    for (j in 2:nnames) {
        allstats[k,1:nlines,j-1] <-  as.array(vartable[,j])
    }

    k <- k+1

}

#plot single test innov vs. error

      	    
name <- "diag_innov_error"
picname <-  paste("./pics/",name,"_",test,"_",var,".pdf",sep='')

nf1=2
nf2=3
nf3=4

allstats[1:ntests,,nf1] <- pmin(allstats[1:ntests,,nf1],11.95)

ymax <- max(allstats[1:ntests,,nf1],allstats[1:ntests,,nf2],na.rm=TRUE)+0.05 
                      
ymin <- 0
xmin <- min(alldates)
xmax <- max(alldates)

k <- 1

pdf(picname,height=5.5,width=7,bg="white")

plot(alldates,allstats[k,1:ntimes,nf1],type="l",lwd=2,lty=1,
cex=1.,col=tcolors[1],xlab='Time',ylab='',yaxs="i",xaxs="i",
ylim=c(ymin,ymax),xaxt='n')#,main=name)

lines(alldates,allstats[k,1:ntimes,nf2],type="l",lwd=2,lty=1,
cex=1.,col=tcolors[2])

lines(alldates,allstats[k,1:ntimes,nf3],type="l",lwd=2,lty=1,
cex=1.,col=tcolors[3])


axis.POSIXct(1,alldates,format="%d %b %Y",at=plotdates)

legend(x=xmax,y=ymin,xjust=1,yjust=0,col=tcolors,
lwd=2,legend=simnames,cex=.8)

dev.off()




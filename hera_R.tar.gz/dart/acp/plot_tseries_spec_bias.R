tests <- c("test_129","test_134","test_130")
tests <- c("test_141","test_137","test_140")
tcolors <- c("red","violet","blue","orange")
danames <- c("NoDA","EnKF_TOT","EnKF_SPEC")


names <- c("BIAS","PRMSE","CORR") # (3,4,5)
colnumber <- 3
spec <- "SO4"
network <- "improve"
network <- "stn"

year_start <- "2010"
month_start <- "06"
day_start <- "01"
hour_start <- "00"
minute_start <- "00"
secont_start <- "00"

days2skip <- 3

plotdates <- c("2010/06/01 UTC","2010/07/01 UTC")

#eliminate erroneous observations from calculating statistics
#max values for "BIAS","PRMSE","CORR"
allstats_max <- c(-20.,20.,1.)

#name <- names[colnumber]
#ylabstring <- as.character(expression(name,
#" [",mu,"g"," ", m^{-3},"]",sep=""))
#ylabstring <- expression(paste("[",mu,"g","  ",m^{-3},"]",
#sep=""))

ntests <- length(tests)

outdir <- "./pics/"
indir <- "../indata/"

varname <- spec

yyyymmdd_start <- paste(year_start,month_start,day_start,
sep="-")

time_start <- paste(hour_start,minute_start,secont_start,
sep=":")

date_start <- as.POSIXlt(paste(yyyymmdd_start,time_start),"UTC")

ntimes <- NULL
nmaxtimes <- 1e4

allstats <- array(NA,c(ntests,nmaxtimes))

k <- 1

for (test in tests) {
    fname <-  paste(indir,test,'/',network,'/stats_',varname,
    '.txt',sep="")
    infile <- file(fname,"ra")
    vartable <- try(
    read.table(infile,header=FALSE,skip=0),silent=TRUE)
    if (class(vartable)=="try-error") {
#    print(c("FILE EMPTY",infile))
    close(infile)
    next }
    ntimes <- c(ntimes,length(vartable[,1]))
    if (ntimes[k] > nmaxtimes) {
    print("CRY FOUL: INCREASE nmaxtimes")
    stop(paste("nmaxtimes = ",as.character(nmaxtimes),
    " ntimes[",as.character(k),"] =",as.character(ntimes[k])))
    }
    allstats[k,1:ntimes[k]] <- as.array(vartable[,colnumber])
    close(infile)
    k <- k+1
}

alldates <- seq(date_start,by=days2skip*24*3600,
length=max(ntimes))


pdfname <- paste(outdir,varname,'_',network,'_',names[colnumber-2],
'.pdf',sep="")
pdf(pdfname,width = 7, height = 5.5,bg="white")

maintitle=paste(toupper(network),varname,sep=" :  ")
xlabstring <- expression("Time")
ylabstring <- names[colnumber-2]


xmin <- min(alldates)
xmax <- max(alldates)

ymin <- min(allstats,na.rm=TRUE)
ymax <- max(allstats,na.rm=TRUE)

if (colnumber == 3 ) {
ymin <- min(allstats,na.rm=TRUE) -0.5*abs(min(allstats,na.rm=TRUE))
#ymin <- min(allstats,na.rm=TRUE) -0.1*abs(min(allstats,na.rm=TRUE)) #stn
#ymin <- 0
ymax <- max(allstats,na.rm=TRUE) + 2.0 #stn so4
#ymax <- max(allstats,na.rm=TRUE) + 0.5 #imp so4
#ymax <- max(allstats,na.rm=TRUE) + 0.025 #imp EC
#ymax <- max(allstats,na.rm=TRUE) + 0.1 #stn EC
#ymax <- max(allstats,na.rm=TRUE) + 0.75 #stn OC
#ymax <- max(allstats,na.rm=TRUE) + 0.25 #imp OC

yloc <- ymax
yjust <- 1.
ylabstring <- expression(paste("BIAS [",mu,"g","  ",m^{-3},"]"))
}


if (colnumber == 4) {
ymin <- min(allstats,na.rm=TRUE)-1
ymax <- max(allstats,na.rm=TRUE)+1
yloc <- ymin
yjust <- 0
ylabstring <- expression(paste("PRMSE [",mu,"g","  ",m^{-3},"]"))
}

if (colnumber == 5) {
ymin <- min(allstats,na.rm=TRUE)-.1
ymax <- max(allstats,na.rm=TRUE)+.1
yloc <- ymin
yjust <- 0
ylabstring <- "CORR"
}

plot(alldates[1:ntimes[1]],allstats[1,1:ntimes[1]],
ylim=c(ymin,ymax),col=tcolors[1],main=maintitle,
xlab='',ylab=ylabstring,xaxt='n',xaxs="i",yaxs="i",
cex.axis=1.,cex.lab=1.,type="l",lwd=3,cex=1.)
axis.POSIXct(1,alldates,format="%B %Y",at=plotdates)
zero <- array(0,max(ntimes))
lines(alldates[1:ntimes[1]],zero,col="black",lwd=1)

k <- 2
for (test in tests[k:ntests]) {
lines(alldates[1:ntimes[k]],allstats[k,1:ntimes[k]],
col=tcolors[k],lwd=3)
k <- k+1
}

legend(x=xmax,y=yloc,xjust=1,yjust=yjust,col=tcolors[1:ntests],
lwd=3,legend=danames[1:ntests],cex=0.9)

dev.off()








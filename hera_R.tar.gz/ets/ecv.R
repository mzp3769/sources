#ecv(o,r,ets,q) - economic value as a function of o,r,ets,q
#              q=b/a, o=(a+c)/T, T=a+b+c+d in contingency table
#              for Atmos. Environ. paper.

ecvfunc <- function(o,r,ets,q) {
  
   ecv <- ( min(o,r) - f*r - o + f/(q+1) ) /
          ( min(o,r) -o*r ) 

   return(ecv)
}
#To run etsfunc for the ragne of f's and q's 

o <- .05

fmin <- 0
fmax <- 1
delf <- 0.01
nf <- (fmax-fmin)/delf+1

qmin <- 0
qmax <- 5
delq <- .01
nq <- (qmax-qmin)/delq+1

source("ets.R")

etsarray <- array(NA,c(nf,nq))

fvec <- seq(fmin,fmax,by=delf)
qvec <- seq(qmin,qmax,by=delq)

i <- 0
for (f in fvec) {
    i <- i+1
    j <- 0
    for (q in qvec) {
         j <- j+1
	 if (q >= f/o-1) {
             etsarray[i,j] <- etsfunc(f,q,o)
         } else {
             etsarray[i,j] <- NA
         }
    }
}


qfunc <- fvec/o -1

xstring <- expression("f")
ystring <- expression("q")

name <- paste("ets_",as.character(o),".eps",sep="")
postscript(name,width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

if (o == .7) {
   pal <- palette(gray(seq(1.,0.,len=6)))
   filled.contour(fvec,qvec,etsarray,
               levels=c(-.2,0.,.2,.4,.6,.8,,1.),zlim=c(-1,1),
               col=pal,xlab=xstring,ylab=ystring)
   text(.05,4.5,labels="b",cex=1.5,vfont=c("serif","plain"))
}
if (o == .2) {
   pal <- palette(gray(seq(1.,0.,len=8)))
   filled.contour(fvec,qvec,etsarray,
               levels=c(-.6,-.4,-.2,,0.,.2,.4,,.6,.8,,1.),zlim=c(-.6,1),
               xlab=xstring,ylab=ystring,
               col=pal,key.axes=axis(4,c(-.6,-.4,-.2,0.,.2,.4,.6,.8,1.)))
   text(.05,4.5,labels="a",cex=1.5,vfont=c("serif","plain"))
if (o == .05) {
   pal <- palette(gray(seq(1.,0.,len=8)))
   filled.contour(fvec,qvec,etsarray,
               levels=c(-.6,-.4,-.2,,0.,.2,.4,,.6,.8,,1.),zlim=c(-.6,1),
               xlab=xstring,ylab=ystring,
               col=pal,key.axes=axis(4,c(-.6,-.4,-.2,0.,.2,.4,.6,.8,1.)))
   text(.05,4.5,labels="a",cex=1.5,vfont=c("serif","plain"))
}

#wrong               plot.axes={axis(1); axis(2);lines(fvec,qfunc)})
dev.off()
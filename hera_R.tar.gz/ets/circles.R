#To run etsfunc for the range of f's and q's 

r <- 1.
R <- r

a <- 2.*r^2*(pi/3.-.25*sqrt(3)) 
b <- pi*R^2 - a
f <- a+b
q <- b/a
o <-  pi*r^2

tot <- 10.*o
f <- f/tot
o <- o/tot

ets <- (f/(q+1)-f*o)/(o+f-f/(q+1)-f*o)

feq <- ets*o/(1.-o+ets*o)
req <- sqrt(feq/pi)

stop

#xstring <- expression("f")
#ystring <- expression("q")

name <- "circles.png"

png(name,width = 900, height = 900,bg="white")

grid.circle(x=0.25, y=0.5, r=0.25, default.units="npc", name=NULL,
            gp=gpar(), draw=TRUE, vp=NULL)

grid.circle(x=0.75, y=0.5, r=0.25, default.units="npc", name=NULL,
            gp=gpar(), draw=TRUE, vp=NULL)


if (o == .1) {
#   pal <- palette(gray(seq(1.,0.,len=8)))
   pal <- rainbow#palette(gray(seq(1.,0.,len=8)))
   filled.contour(fvec,qvec,etsarray,
               levels=c(-.4,-.2,,0.,.2,.4,,.6,.8,,1.),zlim=c(-.4,1),
               xlab=xstring,ylab=ystring,xlim=range(0,.3),ylim=range(0,2),
	       color.palette=rainbow,
#               col=pal,
	       key.axes=axis(4,c(-.4,-.2,0.,.2,.4,.6,.8,1.)),
               plot.axes={axis(1); axis(2);
                          axis(3,seq(-1,10,by=10));
                          axis(4,seq(-1,10,by=10));
                          contour(fvec,qvec,qfunc,add=TRUE,
                                  levels=seq(0,2,by=10),
                                  xlim=range(0,1),ylim=range(0,1),
                                  zlim=range(0,1),method="flattest",
                                  labcex=0.0001,lwd=1.)
                         })


   text(.02,1.8,labels="a",cex=2.5,vfont=c("serif","plain"))
}

dev.off()


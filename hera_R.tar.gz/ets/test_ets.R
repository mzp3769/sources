#To test EEETS and EETS 

omin <- 0
omax <- 1
delo <- 0.01
no <- (omax-omin)/delo+1

fmin <- 0
fmax <- 1
delf <- 0.01
nf <- (fmax-fmin)/delf+1

qmin <- 0
qmax <- 2
delq <- .05
nq <- (qmax-qmin)/delq+1

source("ets.R")
source("fe.R")
source("fee.R")

etsarray <- array(NA,c(nf,nq,no))
eetsarray <- array(NA,c(nf,nq,no))
eeetsarray <- array(NA,c(nf,nq,no))
fearray <- array(NA,c(nf,nq,no))

fvec <- seq(fmin,fmax,by=delf)
qvec <- seq(qmin,qmax,by=delq)
ovec <- seq(omin,omax,by=delo)

i <- 0
for (f in fvec) {
    i <- i+1
    print(f)
    j <- 0
    for (q in qvec) {
         j <- j+1
         k <- 0
         for (o in ovec) {
             k <- k+1
             if ((o > 0) && (q >= f/o-1) && (o <= 1/(q+1))) {
                 ets <- etsfunc(f,q,o)
                 etsarray[i,j,k] <- ets
                 fe <- fefunc(ets,o)
                 fearray[i,j,k] <- fe
                 eetsarray[i,j,k] <- etsfunc(fe,q,o)
                 fearray[i,j,k] <- feefunc(ets)
                 eeetsarray[i,j,k] <- etsfunc(fearray[i,j,k],q,o)
             } else {
                 etsarray[i,j,k] <- NA
                 eetsarray[i,j,k] <- NA
                 eeetsarray[i,j,k] <- NA
             }
         }
    }
}


#pal <- palette("default")
#pal <- palette(rainbow(10))
#image(fvec,qvec,etsarray[,,10],zlim=c(-.1,1))

#filled.contour(fvec,qvec,etsarray[,,30],zlim=c(-1,1))
#filled.contour(fvec,qvec,eeetsarray[,,30],zlim=c(-1,1))


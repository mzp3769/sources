#To run etsfunc for the ragne of f's and q's 

o <- .5

nf <- 251
nq <- nf
fmin <- 0
fmax <- 1.
delf <- (fmax-fmin)/(nf-1)

qmin <- 0
qmax <- 2
delq <- (qmax-qmin)/(nq-1)

source("ets.R")
source("fe.R")

eetsarray <- array(NA,c(nf,nq))


fvec <- seq(fmin,fmax,by=delf)
qvec <- seq(qmin,qmax,by=delq)

i <- 0
for (f in fvec) {
    i <- i+1
    j <- 0
    for (q in qvec) {
         j <- j+1
	 if ((q >= f/o-1) && (o <= 1/(q+1))) {
             ets <- etsfunc(f,q,o)
             fe <- fefunc(ets,o)
             eetsarray[i,j] <- etsfunc(fe,q,o)
         } else {
             ets <- NA
             eetsarray[i,j] <- NA
         }
    }
}


qfunc <- array(NA,c(nf,nq))
for (i in 1:nf) {
    for (j in 1:nq) {
        qfunc[i,j] <- fvec[i]/o-1-qvec[j]
    }
}


xstring <- expression("f")
ystring <- expression("q")

name <- paste("eets_",as.character(o),".eps",sep="")
postscript(name,width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

if (o == .5) {
   pal <- palette(gray(seq(1.,0.,len=8)))
   filled.contour(fvec,qvec,eetsarray,
               levels=c(-.4,-.2,,0.,.2,.4,,.6,.8,,1.),zlim=c(-.4,1),
               xlab=xstring,ylab=ystring,
               col=pal,key.axes=axis(4,c(-.4,-.2,0.,.2,.4,.6,.8,1.)),
               plot.axes={axis(1); axis(2);
                          axis(3,seq(-1,10,by=10));
                          axis(4,seq(-1,10,by=10));
                          contour(fvec,qvec,qfunc,add=TRUE,
                                  levels=seq(0,2,by=.05),
                                  xlim=range(0,1),ylim=range(0,1),
                                  zlim=range(0,1),method="flattest",
                                  labcex=0.0001,lwd=1)
                         })
   text(.058,1.8,labels="b",cex=1.5,vfont=c("serif","plain"))
}

#wrong               plot.axes={axis(1); axis(2);lines(fvec,qfunc)})
dev.off()
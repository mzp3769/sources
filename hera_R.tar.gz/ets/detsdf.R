#ets(f,q,r) - equaitable threat score as function of forecast area,
#              q=b/a, o=(a+c)/T, T=a+b+c+d in contingency table
#              for Atmos. Environ. paper.

detsdffunc <- function(f,q,o) {
  
   detsdf <- (1-o*(1+q))/(f-f*o*(1+q))-
             (f*(1+q)-1-o*(1+q))/((f+o)*(1+q)-f-f*o*(1+q))
#   detsdf <- f^2*(q-1)/(q+1)+2*f*o-o*q/(1+q)
 
   return(detsdf)
}
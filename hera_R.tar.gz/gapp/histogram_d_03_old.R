library(ncdf)
sim <- "MYJ"
field <- "RAINNC"
freq <- "_hourly"
domain <- "_d_03_"

nc <- open.ncdf( paste("/export/scratch2/pagowski/stuff/gapp2005/indata/processed/old/",field,domain,sim,"_2004-06-01_00:00:00",freq,"_1.nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
close.ncdf(nc)
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ixs <- 1
ixe <- nx
jxs <- 1
jxe <- ny

ntimes <- v1$varsize[3]
rainncave <- array(0.,c(24))
for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
rainncave[j] <- mean(data1[ixs:ixe,jxs:jxe,i])+rainncave[j]}
rm(data1)

raintot <- rainncave

nc <- open.ncdf( paste("/export/scratch2/pagowski/stuff/gapp2005/indata/processed/old/",field,domain,sim,"_2004-06-01_00:00:00",freq,"_2.nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
close.ncdf(nc)
nx <- v1$varsize[1]
ny <- v1$varsize[2]

ntimes <- v1$varsize[3]
for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
rainncave[j] <- mean(data1[ixs:ixe,jxs:jxe,i])+rainncave[j]}
rm(data1)

raintot <- raintot + rainncave


nc <- open.ncdf( paste("/export/scratch2/pagowski/stuff/gapp2005/indata/processed/old/",field,domain,sim,"_2004-06-01_00:00:00",freq,"_3.nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
close.ncdf(nc)
nx <- v1$varsize[1]
ny <- v1$varsize[2]

ntimes <- v1$varsize[3]
for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
rainncave[j] <- mean(data1[ixs:ixe,jxs:jxe,i])+rainncave[j]}
rm(data1)

raintot <- raintot + rainncave

field="RAINTOT"
png(paste("histogram_",field,domain,sim,freq,".png",sep=""),
width = 300, height = 600,bg="white")
par(font.axis=2)
barplot(rainncave,space=0,col=c("skyblue"),
xlim=c(1,24),ylim=c(0,5),
axes=TRUE,xlab="time(UTC)",ylab="precip (mm/h)")

par(font=2) 
mtext(side = 1, at=5.7,"06")
mtext(side = 1, at=11.7,"12")
mtext(side = 1, at=17.7,"18")
mtext(side = 1, at=23.7,"00")
text(12,4.9,labels="A",cex=1.5)
dev.off()



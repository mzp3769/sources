library(ncdf)
sim <- "MYJ_NOAH_ens_0"
type <- "_4histogram"
domain <- "_d_02_"
month <-"_jun_2004" 

# the input file is the average over dimensions

field <- "RAINC"
nc <- open.ncdf(paste("/export/scratch/pagowski/stuff/gapp2005/indata/processed/",field,type,domain,sim,month,".nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

raincave <- data1

field <- "RAINNC"
nc <- open.ncdf(paste("/export/scratch/pagowski/stuff/gapp2005/indata/processed/",field,type,domain,sim,month,".nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

rainncave <- data1

raintot <- raincave+rainncave
field="RAINTOT"
fname <- paste( "./posts/",field,domain,sim,"_trend",month,".eps",
sep="")
postscript(fname,width=5.95, height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
par(font.axis=2)

plot(raincave,col=c("red"),type="l",lwd=2,xaxs="i",yaxs="i",
xlim=c(0,ntimes),ylim=c(0,1.2),
xlab="time(h)",ylab="precip (mm)")

lines(rainncave,col=c("green"),type="l",lwd=2)
lines(raintot,col=c("blue"),type="l",lwd=2)

#par(font=2)
#mtext(side = 1, at=5.525,"06")
#mtext(side = 1, at=11.525,"12")
#mtext(side = 1, at=17.525,"18")
#mtext(side = 1, at=23.525,"00")
#text(12,4.9,labels="A",cex=1.5)
dev.off()
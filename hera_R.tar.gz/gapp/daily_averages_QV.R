library(ncdf)
domain <- "_d_02"
month="_jun"
year="_2004"
fields=c("QV")

sims <- c("run_11aa","run_11ba","run_11ca",
          "run_12aa","run_12ba","run_12ca",
          "run_13aa","run_13ba","run_13ca",
          "run_14aa","run_14ba","run_14ca")

nsims <- length(sims)


for (field in fields) {

print(field)

k <- 0

for (sim in sims) {


k <- k+1

print(sim)

print("getting data")

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/",field,domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nz <- v1$varsize[1]
ntimes <- v1$varsize[2]
close.ncdf(nc)

if (k==1) {
  varaveth <- array(0.,c(nz,24,nsims))
}
ndays <- (ntimes-1)/24

for (i in 2:ntimes) {
j <- (i-1)%%24
if (j == 0) j <- 24 
varaveth[,j,k] <- data1[,i]+varaveth[,j,k]
}

th <- varaveth

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/","PH",domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nz_stag <- v1$varsize[1]
ntimes <- v1$varsize[2]
close.ncdf(nc)

if (k==1) {
  varave <- array(0.,c(nz_stag,24,nsims))
}


for (i in 2:ntimes) {
j <- (i-1)%%24
if (j == 0) j <- 24
varave[,j,k] <- data1[,i]+varave[,j,k]
}
rm(data1)

ph <- th

for (i in 1:nz) {
ph[i,,] <- .5*(varave[i,,]+varave[i+1,,])/9.81
}
}

for (i in 1:24) {
for (j in 1:nsims) {
ph[,i,j]=ph[,i,j]-ph[1,i,j]
}}

th <- th/ndays
ph <- ph/ndays

png(paste("./pngs/vprof_",field,domain,month,year,".png",sep=""),
width = 400, height = 600,bg="white")

ymin <- 0
ymax <- 3000.
xmin <- 2.e-3
xmax <- 1.e-2

colors <- rainbow(nsims/3)

plot(th[1:19,12,1],ph[1:19,12,1],"l",col=colors[1],ylim=c(ymin,ymax),
xlim=c(xmin,xmax),
xlab="g/kg",ylab="m",yaxs="i",xaxs="i",lwd=5,cex.axis=1)
#axis(1, at=xvec, labels=lxvec,cex.axis=2)



for (i in 2:nsims) {
j <- i%%3
if (j==1) ltyp <- 1
if (j==2) ltyp <- 5
if (j==0) ltyp <- 3
k <- (i-1)%/%3 + 1
lines(th[1:19,12,i],ph[1:19,12,1],col=colors[k],lwd=5,lty=ltyp)
}

}

if (field=="QV") {
legend(0.00745,ymax,cex=.75,
lwd=3,c("YR","MN","MR","YN"),
col=colors)
}



dev.off()

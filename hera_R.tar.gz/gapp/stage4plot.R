dir <-'.'
fname <- "stage4.ascii"
month <- "_2004_06"

fobs <- file(paste(dir,'/',fname,sep=""),"ra")
dims <- array(scan(fobs,what=0,n=2),c(2))
nx <- dims[1]
ny <- dims[2]
obs <- array(scan(fobs,what=0.,n=nx*ny),c(nx,ny))
close(fobs)
#lim <- max(obs)
lim <- 300
fname <- paste(	"./pngs/stage4_accum",month,".png",sep="")
#fname <- paste(	"./posts/stage4_accum",month,".eps",sep="")
png(fname,width = 614, height=604, bg="white")
#postscript(fname,width=6., height=6.,
#postscript(fname,width=5.95, height=6.,
#horizontal = FALSE, onefile = FALSE, paper = "special",
#           family = "URWHelvetica")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=obs,
levels=c(1,10,50,100,150,200,250,300),
asp=1,col = rainbow(7,start=.15,end=.75,
gamma=1.),plot.axes={axis(1,at=c(1,100,200,300),font=2);
axis(2,at=c(1,100,200,300,400),font=2)},
xaxs = "i", yaxs = "i",zlim=range(0.,lim),
font=2,xlab="E-W domain size",ylab="S-N domain size",
key.title = title(main="Precip\n(mm)"),
key.axes=axis(4,at=c(1,10,50,100,150,200,250,300),font=2))
dev.off()	



dir <-'/export/scratch/pagowski/stuff/gapp/outdata'
prefix <- "stage4"
month <- "_2004_07"
suffix <- "_trend.txt"

fobs <- file(paste(dir,'/',prefix,month,suffix,sep=""),"ra")
a <- readLines(fobs)
close(fobs)
ntimes <- length(a)	

fobs <- file(paste(dir,'/',prefix,month,suffix,sep=""),"ra")
obs <- array(scan(fobs,what=0.,n=ntimes*2),c(2,ntimes))
close(fobs)

fname <- paste( "./posts/stage4_trend",month,".eps",sep="")
postscript(fname,width=5.95, height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
par(font.axis=2)
plot(obs[1,],obs[2,],col=c("blue"),type="l",lwd=2,xaxs="i",yaxs="i",
xlim=c(0,ntimes-1),ylim=c(0,1.2),
xlab="time(h)",ylab="precip (mm)")

#par(font=2) 
#mtext(side = 1, at=5.525,"06")
#mtext(side = 1, at=11.525,"12")
#mtext(side = 1, at=17.525,"18")
#mtext(side = 1, at=23.525,"00")
#text(12,4.9,labels="A",cex=1.5)
dev.off()



dir <-'.'
fname <- "stage4.ascii"
month <- "_2004_06"
date <- "_jun_2004"

fobs <- file(paste(dir,'/',fname,sep=""),"ra")
dims <- array(scan(fobs,what=0,n=2),c(2))
nx <- dims[1]
ny <- dims[2]
obs <- array(scan(fobs,what=0.,n=nx*ny),c(nx,ny))
close(fobs)
#lim <- max(obs)
lim <- 300
fname <- paste(	"./pngs/stage4_accum",date,".png",sep="")
png(fname,width = 505, height = 520,bg="white")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=obs,
levels=c(1,10,50,100,150,200,250,300),
asp=1,col = rainbow(7,start=.15,end=.75,
gamma=1.),plot.axes={axis(1,at=c(1,150,300),labels=c("1","50","100"),font=2);
axis(2,at=c(1,150,300),labels=c("1","50","100"),font=2)},
xaxs = "i", yaxs = "i",zlim=range(0.,lim),
font=2,xlab="E-W domain size",ylab="S-N domain size",
#key.title = title(main="Precip\n(mm)")
key.axes=axis(4,at=c(1,10,50,100,150,200,250,300),font=2))
dev.off()	



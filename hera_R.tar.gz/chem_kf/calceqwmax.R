bhour <- 4
ehour <- 28-8

eqw8hrmax <- array(NA,c(ndays,nstations))
eqw1hrmax <- array(NA,c(ndays,nstations))
allmodelsave <- array(NA,c(nhours,nstations))

for (ist in 1:nstations) {
    print(ist)
    for (ihour in 1:nhours) {
        allmodelsave[ihour,ist] <- mean(allmodels[ihour,,ist])
    }
    for (iday in 1:ndays) {
        maxeqw8hr <- NA
        maxeqw1hr <- NA
        for (ihour in bhour:ehour) {
            jhour <- (iday-1)*24+ihour
            khour <- min(jhour+8,nhours)
            tmp <- mean(allmodelsave[jhour:khour,ist],na.rm=TRUE)
            maxeqw8hr <- max(tmp,maxeqw8hr,na.rm=TRUE)  
        }
        maxeqw1hr <- max(allmodelsave[((iday-1)*24+bhour):
                                     min(iday*24+bhour,nhours),ist])
        if (maxeqw1hr < 0) maxeqw1hr <- NA
        if (maxeqw8hr < 0) maxeqw8hr <- NA

        if (is.infinite(maxeqw8hr)) maxeqw8hr <- NA
        if (is.infinite(maxeqw1hr)) maxeqw1hr <- NA

        eqw8hrmax[iday,ist] <- maxeqw8hr
        eqw1hrmax[iday,ist] <- maxeqw1hr
    }
}

persist8hrmax <- array(NA,c(ndays,nstations))
persist1hrmax <- array(NA,c(ndays,nstations))

for (iday in 2:ndays) {
    persist8hrmax[iday,] <- allobs8hrmax[iday-1,]
    persist1hrmax[iday,] <- allobs1hrmax[iday-1,]
}
persist8hrmax[1,] <- persist8hrmax[2,]
persist1hrmax[1,] <- persist1hrmax[2,]

rm(allmodelsave)

source("mykalmanfilter.R")

nstations <- 360
ndays <- 56

delta <- .95

time <- '_00z'

cmodels <- c('aurams'  , 'bams15k' , 'bams45k',
             'chronos' , 'cmaq1'   , 'ui12k'  ,
             'wrf2'    )

suffix <- '_3d'

indir <- '/export/scratch2/pagowski/stuff/luca/indata'

obsfile <- paste(indir,'/','obs',suffix,time,sep="")
nens <- length(cmodels)

modelfiles <- c(paste(indir,'/',cmodels,suffix,time,sep=""))


nhours <- ndays*24
allobs <- array(NA,c(nhours,nstations))	
allmodels <- array(NA,c(nhours,nens,nstations))	

fobs <- file(obsfile,"ra")
i <- 1
for (n in 1:ndays) {
#    date <- scan(fmodel,what='1',n=1)
#    print(n)
#    print(date)	

    for (hour in 1:24)  {
	allobs[i,] <- array(scan(fobs,what=0.,n=nstations),
				  nstations)
	i <- i+1
	print(hour)
    }
}
close(fobs)

for (j in 1:nens) {
    fmodel <- file(modelfiles[j],"ra")
    i <- 1
    for (n in 1:ndays) {
#    date <- scan(fmodel,what='1',n=1)
#    print(n)
#    print(date)	

         for (hour in 1:24)  {
	     allmodels[i,j,] <- array(scan(fmodel,what=0.,n=nstations),
				  nstations)
             i <- i+1
	     print(hour)
         }
    }
    close(fmodel)
}

print("KF")

kalmanfilter <- array(NA,c(nhours,nstations))
weights <- array(NA,c(nhours,nens,nstations))

for (i in 1:nstations) {
    print(i)
    models <- allmodels[,,i]
    obs <- allobs[,i]
    kalmanlist <- myKalmanFilter(obs, models, delta)
    kalmanfilter[,i] <- kalmanlist$kf
    weights[,,i] <- kalmanlist$weights
}


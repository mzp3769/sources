#8hr
plot(rvec,ecv8hr[1,1,],col="red",lwd=2,
ylim=c(-.25,1),type="l")
lines(rvec,ecv8hr[2,1,],col="blue",lwd=2,type="l")
lines(rvec,ecv8hr[3,1,],col="green",lwd=2,type="l")


econvmax <- array(NA,rlength)
for (i in 1:rlength) {
    econvmax[i] <- max(econv[,i])
}

plot(rvec,econv[1,],ylim=c(0,1),type="l")
for (i in 1:nintervals) {
lines(rvec,econv[i,],col="purple")
}

for (i in 1:(nens+2)) {
lines(rvec,ecv8hr[i,1,],type="l",col="red")
}

lines(rvec,econvmax,type="l",lwd=4,col="purple")
lines(rvec,econvmax,type="l",lwd=4,col="blue")

points(b851$obar,.5,col="red",pch=23)

lines(rvec,ecv1hr[1,3,],col="red",lwd=2,type="l")
lines(rvec,ecv1hr[2,3,],col="blue",lwd=2,type="l")

x11()
plot(rvec,ecv8hr[1,2,],col="red",lwd=2,
ylim=c(-.25,1),type="l")
lines(rvec,ecv8hr[2,2,],col="blue",lwd=2,type="l")
lines(rvec,ecv8hr[3,2,],col="green",lwd=2,type="l")

x11()
plot(rvec,ecv8hr[1,3,],col="red",lwd=2,
ylim=c(-.25,1),type="l")
lines(rvec,ecv8hr[2,3,],col="blue",lwd=2,type="l")
lines(rvec,ecv8hr[3,3,],col="green",lwd=2,type="l")


x11()
plot(rvec,ecv8hr[1,4,],col="red",lwd=2,
ylim=c(-.25,1),type="l")
lines(rvec,ecv8hr[2,4,],col="blue",lwd=2,type="l")
lines(rvec,ecv8hr[3,4,],col="green",lwd=2,type="l")

#1hr
x11()
plot(rvec,ecv1hr[1,1,],col="red",lwd=2,
ylim=c(-.25,1),type="l")
lines(rvec,ecv1hr[2,1,],col="blue",lwd=2,type="l")
lines(rvec,ecv1hr[3,1,],col="green",lwd=2,type="l")

x11()
plot(rvec,ecv1hr[1,2,],col="red",lwd=2,
ylim=c(-.25,1),type="l")
lines(rvec,ecv1hr[2,2,],col="blue",lwd=2,type="l")
lines(rvec,ecv1hr[3,2,],col="green",lwd=2,type="l")

x11()
plot(rvec,ecv1hr[1,3,],col="red",lwd=2,
ylim=c(0,1),type="l")
lines(rvec,ecv1hr[2,3,],col="blue",lwd=2,type="l")
lines(rvec,ecv1hr[3,3,],col="green",lwd=2,type="l")

x11()
plot(rvec,ecv1hr[1,4,],col="red",lwd=2,
ylim=c(0,1),type="l")
lines(rvec,ecv1hr[2,4,],col="blue",lwd=2,type="l")
lines(rvec,ecv1hr[3,4,],col="green",lwd=2,type="l")


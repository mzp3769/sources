bhour <- 4
ehour <- 28-8

kf8hrmax <- array(NA,c(ndays,nstations))
kf1hrmax <- array(NA,c(ndays,nstations))

for (ist in 1:nstations) {
    print(ist)
    for (iday in 1:ndays) {
        maxkf8hr <- NA
        maxkf1hr <- NA
        for (ihour in bhour:ehour) {
            jhour <- (iday-1)*24+ihour
            khour <- min(jhour+8,nhours)
# for testing
#            tmp <- mean(allmodels[jhour:khour,8,ist], na.rm=TRUE)
            tmp <- mean(kalmanfilter[jhour:khour,ist], na.rm=TRUE)
            maxkf8hr <- max(tmp,maxkf8hr,na.rm=TRUE)  
        }
# for testing
#        maxkf1hr <- max(allmodels[((iday-1)*24+bhour):
#                                     min(iday*24+bhour,nhours),8,ist],
        maxkf1hr <- max(kalmanfilter[((iday-1)*24+bhour):
                                     min(iday*24+bhour,nhours),ist],
                        na.rm=TRUE)
        if (is.infinite(maxkf8hr)) maxkf8hr <- NA
        if (is.infinite(maxkf1hr)) maxkf1hr <- NA

        kf8hrmax[iday,ist] <- maxkf8hr
        kf1hrmax[iday,ist] <- maxkf1hr
    }
}


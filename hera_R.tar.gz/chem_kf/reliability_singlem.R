nmodels <- nens
nintervals <- nmodels+1
allmodelsxhrmax <- singlem_kf1hrmax[,1:nmodels,]
allobsxhrmax <- allobs1hrmax

p_obs_singlem <- array(0.,c(ndays+1,nintervals))
p_models_singlem <- array(0.,c(ndays+1,nintervals))

j <- 0

thres <- 70 # 83. 1h

bbrier <- 0.
clim <- 0.

for (iday in 1:ndays) {
    print(iday)
    k <- 0
    for (ist in 1:nstations) {
        if (is.na(allobsxhrmax[iday,ist]) ||
            any(is.na(allmodelsxhrmax[iday,,ist]))) {
#           write(ist,file="test1.txt",append=TRUE)
           next
        }

        k <- k+1
        j <- j+1

        p_m <- 0

        for (iens in 1:nmodels) {
            if (allmodelsxhrmax[iday,iens,ist] > thres) { 
               p_m <- p_m+1
            }               
        }
        p_models_singlem[iday,p_m+1] <- p_models_singlem[iday,p_m+1]+1  
        p_models_singlem[ndays+1,p_m+1] <- 
                                     p_models_singlem[ndays+1,p_m+1]+1  

	o <- 0
        if (allobsxhrmax[iday,ist] > thres) {
           p_obs_singlem[iday,p_m+1] <- p_obs_singlem[iday,p_m+1]+1
           p_obs_singlem[ndays+1,p_m+1] <- p_obs_singlem[ndays+1,p_m+1]+1
	   o <- 1
        }

	clim <- clim+o
	bbrier <- ((p_m-1)/nmodels-o)^2 + bbrier

    }
    p_obs_singlem[iday,] <- p_obs_singlem[iday,]/
                            p_models_singlem[iday,] 
    p_models_singlem[iday,] <- p_models_singlem[iday,]/k
}

clim <- clim/j
bbrier <- bbrier/j

rel <- 0.
res <- 0.

for (k in 1:nintervals) {
   rel <-  p_models_singlem[ndays+1,k]*(
           (k-1)/nmodels-
           p_obs_singlem[ndays+1,k]/p_models_singlem[ndays+1,k]
                           )^2 + rel
   res <-  p_models_singlem[ndays+1,k]*(
           p_obs_singlem[ndays+1,k]/p_models_singlem[ndays+1,k]-
           clim)^2 + res

}

unc <- clim*(1.-clim)

p_obs_singlem[ndays+1,] <- p_obs_singlem[ndays+1,]/
                           p_models_singlem[ndays+1,]
p_models_singlem[ndays+1,] <- p_models_singlem[ndays+1,]/j

#rel <- rel/j
#res <- res/j                            

#print(rel-res+unc)
#print(bbrier)

source("mykalmanfilter.R")

delta <- .9

time <- '_00z'

nstations <- 360
ndays <- 56

nhours <- ndays*24

print("KF")

models <- array(NA,c(nens,nhours))

kalmanfilter <- array(NA,c(nhours,nstations))
weights <- array(NA,c(nhours,nens,nstations))

for (i in 1:nstations) {
    print(i)
    models <- allmodels[,,i]
    obs <- allobs[,i]
    kalmanlist <- myKalmanFilter(obs, models, delta)
    kalmanfilter[,i] <- kalmanlist$kf
    weights[,,i] <- kalmanlist$weights
}

source("kalmanfilter3.R")
model <- 'bams15k_3d_00z'

indir <- '/export/scratch/pagowski/stuff/luca/indata/'
obsfile <- paste(indir,'obs_3d_00z',sep="")
modelfile <- paste(indir,model,sep="")

nstations <- 360
ndays <- 56

nhours <- ndays*24
allobs <- array(0.,c(nhours,nstations))	
allpred <- array(0.,c(nhours,nstations))	



fobs <- file(obsfile,"ra")
i <- 1
for (n in 1:ndays) {
#    date <- scan(fmodel,what='1',n=1)
#    print(n)
#    print(date)	

    for (hour in 1:24)  {
	allobs[i,] <- array(scan(fobs,what=0.,n=nstations),
				  nstations)
	i <- i+1
	print(hour)
    }
}
close(fobs)


fmodel <- file(modelfile,"ra")
i <- 1
for (n in 1:ndays) {
#    date <- scan(fmodel,what='1',n=1)
#    print(n)
#    print(date)	

    for (hour in 1:24)  {
	allpred[i,] <- array(scan(fmodel,what=0.,n=nstations),
				  nstations)
	i <- i+1
	print(hour)
    }
}
close(fmodel)

par <- list(iperiod = 48, update = 24, varo = 0.0005,
                  varp = 1, start = c(0,0), timeZone = 0, missing=-999.)
algorithm <- 1 

# 4 algorithm <- 2

kalmanfilter <- array(NA,c(nhours,nstations))

for (i in 1:nstations) {
    print(i)
    maxmodel <- max(allpred[,i]) 

#1    scale <- max(allpred[,i]) 
#2    scale <- max(allobs[,i])
    scale <- 1
    if (maxmodel >= 0.) {
    pred <- allpred[,i]/scale
    obs <- allobs[,i]/scale
    kalmanlist <- KalmanFilter3(obs, pred, par, algorithm)
    kalmanfilter[,i] <- kalmanlist$newKf*scale 
    }
}


rmsepred <- array(NA,nstations)
rmsekf   <- array(NA,nstations)
aveobs <- array(NA,nstations)
avepred <- array(NA,nstations)
avekf <- array(NA,nstations)
corrpred <- array(NA,nstations)
corrkf <- array(NA,nstations)
corrpredkf <- array(NA,nstations)
stdevobs <- array(NA,nstations)
stdevpred <- array(NA,nstations)
stdevkf <- array(NA,nstations)

obs <-array(NA,nhours)
pred <-array(NA,nhours)

for (i in 1:nstations) {
    k <- 0
    print(i)
    for (j in {par$iperiod+1}:nhours) {
        if (allobs[j,i] >= 0.) {
            obs[j] <- allobs[j,i]
        } 
        if (allpred[j,i] >= 0.) {
            pred[j] <- allpred[j,i]
        } 
    }

    kf <- kalmanfilter[,i]

    aveobs[i] <- mean(obs, na.rm=TRUE)
    avepred[i] <- mean(pred, na.rm=TRUE)
    avekf[i] <- mean(kf, na.rm=TRUE)
    stdevobs[i] <- sd(obs, na.rm=TRUE)
    stdevpred[i] <- sd(pred, na.rm=TRUE)
    stdevkf[i] <- sd(kf, na.rm=TRUE)
    corrpred[i] <- cor(obs,pred,use="complete.obs")
    corrkf[i] <- cor(obs,kf,use="complete.obs")
    corrpredkf[i] <- cor(pred,kf,use="complete.obs")
    rmsepred[i]  <- sqrt(mean((pred-obs)^2, na.rm=TRUE))
    rmsekf[i]  <- sqrt(mean((kf-obs)^2, na.rm=TRUE))
}

rmsepredave <- mean(rmsepred,na.rm=TRUE)
rmsekfave <- mean(rmsekf,na.rm=TRUE)
corrpredave <- mean(corrpred,na.rm=TRUE)
corrkfave <- mean(corrkf,na.rm=TRUE)    
corrpredkfave <- mean(corrpredkf,na.rm=TRUE)
stdevobsave <- mean(stdevobs,na.rm=TRUE)
stdevpredave <- mean(stdevpred,na.rm=TRUE)
stdevkfave <- mean(stdevkf,na.rm=TRUE)

allstats <- array(c(rmsepredave,rmsekfave,corrpredave,corrkfave,
                    corrpredkfave,stdevobsave,stdevpredave,stdevkfave),8)

write(allstats,file=paste(model,'_results.txt',sep=""),ncolumns=8)


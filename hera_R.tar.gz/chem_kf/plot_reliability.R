cols <- rainbow(100)

#reliability
icol <- 40

#x11()
dev.set(2)

plot(c(0:nens),p_obs[1,],type="l",lwd=1,col=cols[icol],xlim=c(0,1),
ylim=c(0,1.))
for (iday in 2:ndays) {
    print(iday)
    lines(c(0:nens)/nens,p_obs[iday,],type="l",lwd=1,col=cols[iday+icol])
}

lines(c(0:nens)/nens,p_obs[ndays+1,],type="l",lwd=4,col="red")
lines(c(0:nens)/nens,p_obs[ndays+1,],type="p",lwd=4,col="red")
lines(seq(0,1,by=.1),seq(0,1,by=.1),type="l",lwd=4,col="blue")


#sharpness
#x11()
dev.set(3)
plot(c(0:nens),p_models[1,],type="l",lwd=1,
col=cols[icol],xlim=c(0,nens+1),
ylim=c(0,1.))
for (iday in 2:ndays) {
    print(iday)
    lines(c(0:nens),p_models[iday,],type="l",lwd=1,col=cols[iday+icol])
}
lines(c(0:nens),p_models[ndays+1,],type="l",lwd=4,col="red")
lines(c(0:nens),p_models[ndays+1,],type="p",lwd=4,col="red")
#plot(c(0:nens),p_models[ndays+1,],type="l",lwd=4,col="red")

econvmax <- array(NA,rlength)
for (i in 1:rlength) {
    econvmax[i] <- max(econv[,i])
}

postscript("econv_example.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")
#           family = c("hv______.afm", 
#                      "hvb_____.afm", 
#                      "hvo_____.afm", 
#                     "hvbo____.afm", 
#                      "sy______.afm"))

par(ann=TRUE)
par(mar=c(4,4,2,2))
par(lab=c(4,4,4))
par(las=0)
par(cex.axis=1)
par(cex.lab=1)
par(ask=FALSE)

plot(rvec,econv[2,],type="l",lwd=1,col="black",
xlab="cost-loss ratio",ylab="economic value",
xlim=c(0,1.),ylim=c(0.,.8),xaxs="i",yaxs="i")
for (i in 3:nintervals) {
lines(rvec,econv[i,],col="black",lwd=1)
}

lines(rvec,econvmax,col="black",lwd=2)

xcoord <- c(0.1154879, 0.1262444, 0.1598582, 0.1948167, 
0.2326994, 0.2621058, 0.2888389)
ycoord <- c(0.5491306, 0.5184792, 0.4229885, 0.3145299,
0.22109479, 0.14098798, 0.05126836)

par(cex=1.10)

for (i in 1:nmodels) {
points(x=xcoord[i],y=ycoord[i],pch=as.character(i))
}


dev.off()
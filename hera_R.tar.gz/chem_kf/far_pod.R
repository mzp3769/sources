

postscript("far_8hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("FAR")

barplot(far8hr[8:10,],
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("30","50","70","85"),
ylim=c(0,1.),xlab=xlabstring,ylab=ylabstring,
legend=c("KF","AVE","PERSIST"))
axis(1,at=c(0,50))
text(2,0.9,labels="b",cex=1.5,vfont=c("serif","plain"))

dev.off()

postscript("pod_8hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("POD")

barplot(pod8hr[8:10,],
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("30","50","70","85"),
ylim=c(0,1.),xlab=xlabstring,ylab=ylabstring,
legend=c("KF","AVE","PERSIST"))
axis(1,at=c(0,50))
text(2,0.9,labels="c",cex=1.5,vfont=c("serif","plain"))

dev.off()



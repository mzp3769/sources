plot(sorted_models8hrmax$x,n_freq,type="l",lwd=2,col="blue")

for (iday in 1:10) {
    print(iday)
    lines(sorted_models8hrmax_daily[iday,(1:n_nna_models_daily[iday]),1],
          c(1:n_nna_models_daily[iday])/n_nna_models_daily[iday],
          type="l",lwd=1,col="black")
}

for (iday in 1:20) {
    print(iday)
    lines(sorted_models8hrmax_daily[iday,(1:n_nna_models_daily[iday]),1],
          c(1:n_nna_models_daily[iday])/n_nna_models_daily[iday],
          type="l",lwd=1,col="red")
}

for (iday in 1:30) {
    print(iday)
    lines(sorted_models8hrmax_daily[iday,(1:n_nna_models_daily[iday]),1],
          c(1:n_nna_models_daily[iday])/n_nna_models_daily[iday],
          type="l",lwd=1,col="green")
}

for (iday in 1:40) {
    print(iday)
    lines(sorted_models8hrmax_daily[iday,(1:n_nna_models_daily[iday]),1],
          c(1:n_nna_models_daily[iday])/n_nna_models_daily[iday],
          type="l",lwd=1,col="purple")
}


for (iday in 1:ndays) {
    print(iday)
    lines(sorted_models8hrmax_daily[iday,(1:n_nna_models_daily[iday]),1],
          c(1:n_nna_models_daily[iday])/n_nna_models_daily[iday],
          type="l",lwd=1,col="orange")
}

#thresholds

plot(c(1:nens),threshholds[1,1:nens],type="l",lwd=2,col="blue")
for (iday in 1:ndays) {
    print(iday)
    lines(c(1:nens),threshholds[iday,1:nens],
          type="l",lwd=1,col="black")
}

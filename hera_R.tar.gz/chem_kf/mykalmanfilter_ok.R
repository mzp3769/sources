# myKalmanFilter(obs, models, delta)
# Author: MP CIRA, June 2005 

myKalmanFilter <- function(obs, models, delta) {


    tlength  <- length(obs)	    
    mykf <- array(NA,tlength)
    weights <- array(NA,c(tlength,nens))
    phi <- array(NA,nens)
    psi <- array(NA,nens)

    for (hour in 1:24) {

       n <- 1
       d <- .1
       s <- d/n
       m <- array(1./nens,nens)	
       c <- array(1.,nens)
       for (t in seq(hour,tlength,by=24)) {
           modelst <- models[t,]
           obst <- obs[t]

           if (min(modelst) < 0.) {
               mykf[t] <- NA
               weights[t,] <- NA
               next
           } 

           if (obst < 0) {
               mykf[t] <- NA
               weights[t,] <- NA
               next
           }

           f <- as.numeric(crossprod(modelst,m))
           mykf[t] <- f
           weights[t,] <- m
           phi <- c/delta
           psi <- as.numeric(crossprod(modelst^2,phi)) + s

           n <- n+1
           e <- obst-f
           d <- d + s*e^2/psi
           s <- d/n

           k <- c(modelst * phi)/psi
           m <- m + k*e
           c <- s/psi * phi

       }
    }

  kflist <- list("kf"=mykf,"weights"=weights)

return(kflist)

}



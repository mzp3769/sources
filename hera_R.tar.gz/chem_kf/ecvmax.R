ecvmax <- array(NA,rlength)
ecv <- ecv858sm[1:7,]
for (i in 1:rlength) {
    ecvmax[i] <- max(ecv[,i])
}
ecvmax858sm <- ecvmax

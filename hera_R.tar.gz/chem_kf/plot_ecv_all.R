postscript("econv_858.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

econv <- ecv8hr[,3,]
ecvmaxsm <- ecvmax858sm
ecvmax <- ecvmax858

lab <- "e"

plotleg <- FALSE
#plotleg <- TRUE

par(ann=TRUE)
par(mar=c(4,4,2,2))
par(lab=c(4,4,4))
par(las=0)
par(cex.axis=1)
par(cex.lab=1)
par(ask=FALSE)

plot(rvec,ecvmax,type="l",lwd=3,col="red",
xlab="cost-loss ratio",ylab="economic value",
xlim=c(0,1.),ylim=c(0.,.8),xaxs="i",yaxs="i")


lines(rvec,ecvmaxsm,col="purple",lwd=3)

for (i in 1:nmodels) {
   lines(rvec,econv[i,],col="black",lwd=1)
}
lines(rvec,econv[(nmodels+1),],col="blue",lwd=3)
lines(rvec,econv[(nmodels+2),],col="green",lwd=3)

text(0.1,0.725,labels=lab,cex=1.5,vfont=c("serif","plain"))

if (plotleg) {

legend(x=.75,y=.8,lty=1,lwd=3,
legend=c("models","AVE","DLR","PR","PRDLR"),
col=c("black","green","blue","red","purple"))

}




dev.off()
source("mykalmanfilter_singlem.R")
#assuming that files with obs/model output were read

delta <- .95

time <- '_00z'

cmodels <- c('aurams'  , 'bams15k' , 'bams45k',
             'chronos' , 'cmaq1'   , 'ui12k'  ,
             'wrf2'    )

singlem_kf8hrmax <- array(NA,c(ndays,nens,nstations))
singlem_kf1hrmax <- array(NA,c(ndays,nens,nstations))


for (imodel in 1:nens) {

print("imodel")
print(imodel)

models <- array(1,c(nhours,2))
#mmodels <- array(1,c(nhours,nens))
#allobs <- array(NA,c(nhours,nstations))
#allmodels <- array(NA,c(nhours,nens,nstations))

kalmanfilter_singlem <- array(NA,c(nhours,nstations))
weights_singlem <- array(NA,c(nhours,2,nstations))

for (i in 1:nstations) {
    print(i)
    models[,2] <- allmodels[,imodel,i]
#    print(models)
    obs <- allobs[,i]
    kalmanlist <- myKalmanFilter_singlem(obs, models, delta, 2)
    kalmanfilter_singlem[,i] <- kalmanlist$kf
    weights_singlem[,,i] <- kalmanlist$weights
}

print("calcmax")
source("calcmax_singlem.R")

singlem_kf8hrmax[,imodel,] <- ssinglem_kf8hrmax
singlem_kf1hrmax[,imodel,] <- ssinglem_kf1hrmax

}

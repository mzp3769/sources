#8hr

thresh8hr <- c(30,50,70,80)
nthresh <- length(thresh8hr)

rmse8hrmax <- array(NA,c(ndays,nens+4)) # for all members,eqw,persist,kf
bias8hrmax <- array(NA,c(ndays,nens+4)) # for all members,eqw,persist,kf

cor8hrmax <- array(NA,c(ndays,nens+4)) # for all members,eqw,persist,kf
acc8hrmax <- array(NA,c(ndays,nens+4)) 
ets8hrmax <- array(NA,c(nens+4,nthresh)) 
ccor8hrmax <- array(NA,c(nens+4,nstations)) 
rrmse8hrmax <- array(NA,c(nens+4,nstations)) 
bbias8hrmax <- array(NA,c(nens+4,nstations)) 

n8hrtot <- 0

for (iday in 1:ndays) {
    print(iday)
    for (iens in 1:nens) {
         rmse8hrmax[iday,iens]  <- 
#         sqrt
              (mean((allmodels8hrmax[iday,iens,]-allobs8hrmax[iday,])^2, 
         na.rm=TRUE))
    }
    for (ist in 1:nstations) {
         if (!is.na(eqw8hrmax[iday,ist]) &&
             !is.na(allobs8hrmax[iday,ist])) {
             n8hrtot <- n8hrtot +1
         }
    }           

    rmse8hrmax[iday,nens+1]  <- 
#    sqrt
         (mean((kf8hrmax[iday,]-allobs8hrmax[iday,])^2, na.rm=TRUE))
    rmse8hrmax[iday,nens+2]  <- 
#    sqrt
         (mean((eqw8hrmax[iday,]-allobs8hrmax[iday,])^2, na.rm=TRUE))
    rmse8hrmax[iday,nens+3]  <- 
#    sqrt
         (mean((persist8hrmax[iday,]-allobs8hrmax[iday,])^2, na.rm=TRUE))
    rmse8hrmax[iday,nens+4]  <- 
#    sqrt
         (mean((kf8hrmax_new[iday,]-allobs8hrmax[iday,])^2, na.rm=TRUE))

    bias8hrmax[iday,nens+1]  <- 
         (mean((kf8hrmax[iday,]-allobs8hrmax[iday,]), na.rm=TRUE))
    bias8hrmax[iday,nens+2]  <- 
         (mean((eqw8hrmax[iday,]-allobs8hrmax[iday,]), na.rm=TRUE))
    bias8hrmax[iday,nens+3]  <- 
         (mean((persist8hrmax[iday,]-allobs8hrmax[iday,]), na.rm=TRUE))
    bias8hrmax[iday,nens+4]  <- 
         (mean((kf8hrmax_new[iday,]-allobs8hrmax[iday,]), na.rm=TRUE))

    cor8hrmax[iday,nens+1] <- cor(kf8hrmax[iday,],allobs8hrmax[iday,],
                                    use="complete.obs")
    cor8hrmax[iday,nens+2] <- cor(eqw8hrmax[iday,],allobs8hrmax[iday,],
                                    use="complete.obs")
    cor8hrmax[iday,nens+3] <-cor(persist8hrmax[iday,],allobs8hrmax[iday,],
                                    use="complete.obs")
    cor8hrmax[iday,nens+4] <- cor(kf8hrmax_new[iday,],allobs8hrmax[iday,],
                                    use="complete.obs")
    acc8hrmax[iday,nens+1]  <- 
         cor((kf8hrmax[iday,]-clim8hrmax),
             (allobs8hrmax[iday,]-clim8hrmax),use="complete.obs")
    acc8hrmax[iday,nens+2]  <- 
         cor((eqw8hrmax[iday,]-clim8hrmax),
             (allobs8hrmax[iday,]-clim8hrmax),use="complete.obs")
    acc8hrmax[iday,nens+3]  <- 
         cor((persist8hrmax[iday,]-clim8hrmax),
             (allobs8hrmax[iday,]-clim8hrmax),use="complete.obs")
    acc8hrmax[iday,nens+4]  <- 
         cor((kf8hrmax_new[iday,]-clim8hrmax),
             (allobs8hrmax[iday,]-clim8hrmax),use="complete.obs")
}

rmse8hrmaxave <- array(NA,c(nens+4))
bias8hrmaxave <- array(NA,c(nens+4))
cor8hrmaxave <- array(NA,c(nens+4))

for (iens in (nens+1):(nens+4)) {
     cor8hrmaxave[iens] <- mean(cor8hrmax[,iens],na.rm=TRUE)
     rmse8hrmaxave[iens] <- sqrt(mean(rmse8hrmax[,iens],na.rm=TRUE))
     bias8hrmaxave[iens] <- mean(bias8hrmax[,iens],na.rm=TRUE)
}


#method = c("pearson", "kendall", "spearman"))
for (ist in 1:nstations) {
     ccor8hrmax[nens+1,ist] <- cor(kf8hrmax[1:ndays,ist],
                                   allobs8hrmax[1:ndays,ist],
                                    use="complete.obs")
     ccor8hrmax[nens+2,ist] <- cor(eqw8hrmax[1:ndays,ist],
                                   allobs8hrmax[1:ndays,ist],
                                   use="complete.obs")
     ccor8hrmax[nens+3,ist] <- cor(persist8hrmax[1:ndays,ist],
                                   allobs8hrmax[1:ndays,ist],
                                    use="complete.obs")
     ccor8hrmax[nens+4,ist] <- cor(kf8hrmax_new[1:ndays,ist],
                                   allobs8hrmax[1:ndays,ist],
                                    use="complete.obs")
     rrmse8hrmax[nens+1,ist]  <-
#     sqrt
          (mean((kf8hrmax[1:ndays,ist]-allobs8hrmax[1:ndays,ist])^2, 
                na.rm=TRUE))
     rrmse8hrmax[nens+2,ist]  <-
#     sqrt
          (mean((eqw8hrmax[1:ndays,ist]-allobs8hrmax[1:ndays,ist])^2, 
                na.rm=TRUE))
     rrmse8hrmax[nens+3,ist]  <-
#     sqrt
          (mean((persist8hrmax[1:ndays,ist]-allobs8hrmax[1:ndays,ist])^2, 
                na.rm=TRUE))
     rrmse8hrmax[nens+4,ist]  <-
#     sqrt
          (mean((kf8hrmax_new[1:ndays,ist]-allobs8hrmax[1:ndays,ist])^2, 
                na.rm=TRUE))


     bbias8hrmax[nens+1,ist]  <-
          (mean((kf8hrmax[1:ndays,ist]-allobs8hrmax[1:ndays,ist]), 
                na.rm=TRUE))
     bbias8hrmax[nens+2,ist]  <-
          (mean((eqw8hrmax[1:ndays,ist]-allobs8hrmax[1:ndays,ist]), 
                na.rm=TRUE))
     bbias8hrmax[nens+3,ist]  <-
          (mean((persist8hrmax[1:ndays,ist]-allobs8hrmax[1:ndays,ist]), 
                na.rm=TRUE))
     bbias8hrmax[nens+4,ist]  <-
          (mean((kf8hrmax_new[1:ndays,ist]-allobs8hrmax[1:ndays,ist]), 
                na.rm=TRUE))

}

rrmse8hrmaxave <- array(NA,c(nens+4))
bbias8hrmaxave <- array(NA,c(nens+4))
ccor8hrmaxave <- array(NA,c(nens+4))

for (iens in (nens+1):(nens+4)) {
     ccor8hrmaxave[iens] <- mean(ccor8hrmax[iens,],na.rm=TRUE)
     rrmse8hrmaxave[iens] <- sqrt(mean(rrmse8hrmax[iens,],na.rm=TRUE))
     bbias8hrmaxave[iens] <- mean(bbias8hrmax[iens,],na.rm=TRUE)
}

a8hr <- array(0,c(nens+4,nthresh))
b8hr <- array(0,c(nens+4,nthresh))
c8hr <- array(0,c(nens+4,nthresh))
d8hr <- array(0,c(nens+4,nthresh))
ra8hr <- array(0,c(nens+4,nthresh))

for (iday in 1:ndays) {
    print(iday)
    for (ist in 1:nstations) {
        if (is.na(allobs8hrmax[iday,ist]) ||
            is.na(eqw8hrmax[iday,ist]) ||
            is.na(persist8hrmax[iday,ist]) ||
            is.na(kf8hrmax[iday,ist]) || 
            is.na(kf8hrmax_new[iday,ist])) next

        for (ith in 1:nthresh) {
            if (allobs8hrmax[iday,ist] > thresh8hr[ith] ) {
                if (kf8hrmax[iday,ist] > thresh8hr[ith]) {
                    a8hr[nens+1,ith] <- a8hr[nens+1,ith] + 1
                } else {
                    c8hr[nens+1,ith] <- c8hr[nens+1,ith] + 1
                }
                if (eqw8hrmax[iday,ist] > thresh8hr[ith]) {
                    a8hr[nens+2,ith] <- a8hr[nens+2,ith] + 1
                } else {
                    c8hr[nens+2,ith] <- c8hr[nens+2,ith] + 1
                }
                if (persist8hrmax[iday,ist] > thresh8hr[ith]) {
                    a8hr[nens+3,ith] <- a8hr[nens+3,ith] + 1
                } else {
                    c8hr[nens+3,ith] <- c8hr[nens+3,ith] + 1
                }
                if (kf8hrmax_new[iday,ist] > thresh8hr[ith]) {
                    a8hr[nens+4,ith] <- a8hr[nens+4,ith] + 1
                } else {
                    c8hr[nens+4,ith] <- c8hr[nens+4,ith] + 1
                }
            } else {
                if (kf8hrmax[iday,ist] > thresh8hr[ith]) {
                    b8hr[nens+1,ith] <- b8hr[nens+1,ith] + 1
                } else {
                    d8hr[nens+1,ith] <- d8hr[nens+1,ith] + 1
                }
                if (eqw8hrmax[iday,ist] > thresh8hr[ith]) {
                    b8hr[nens+2,ith] <- b8hr[nens+2,ith] + 1
                } else {
                    d8hr[nens+2,ith] <- d8hr[nens+2,ith] + 1
                }
                if (persist8hrmax[iday,ist] > thresh8hr[ith]) {
                    b8hr[nens+3,ith] <- b8hr[nens+3,ith] + 1
                } else {
                    d8hr[nens+3,ith] <- d8hr[nens+3,ith] + 1
                }
                if (kf8hrmax_new[iday,ist] > thresh8hr[ith]) {
                    b8hr[nens+4,ith] <- b8hr[nens+4,ith] + 1
                } else {
                    d8hr[nens+4,ith] <- d8hr[nens+4,ith] + 1
                }
            }
        }
    }
}             

ra8hr <- (a8hr+b8hr)*(a8hr+c8hr)/(a8hr+b8hr+c8hr+d8hr)

for (iens in (nens+1):(nens+4)) {
    ets8hrmax[iens,] <- (a8hr[iens,]-ra8hr[iens,])/
                        (a8hr[iens,]+b8hr[iens,]+c8hr[iens,]-ra8hr[iens,])
}

bb8hr <- (a8hr+b8hr)/(a8hr+c8hr)
far8hr <- b8hr/(b8hr+d8hr)
pod8hr <- a8hr/(a8hr+c8hr)
tss8hr <- pod8hr-far8hr
csi8hr <- a8hr/(a8hr+b8hr+c8hr)

#1hr

thresh1hr <- c(30,50,70,85)
nthresh <- length(thresh1hr)


rmse1hrmax <- array(NA,c(ndays,nens+4)) # for all members,eqw,persist,kf
bias1hrmax <- array(NA,c(ndays,nens+4)) # for all members,eqw,persist,kf
cor1hrmax <- array(NA,c(ndays,nens+4)) # for all members,eqw,persist,kf
acc1hrmax <- array(NA,c(ndays,nens+4)) 
ets1hrmax <- array(NA,c(nens+4,nthresh)) 
ccor1hrmax <- array(NA,c(nens+4,nstations)) 
rrmse1hrmax <- array(NA,c(nens+4,nstations))
bbias1hrmax <- array(NA,c(nens+4,nstations)) 


n1hrtot <- 0

for (iday in 1:ndays) {
    print(iday)
    for (iens in 1:nens) {
         rmse1hrmax[iday,iens]  <- 
#         sqrt
              (mean((allmodels1hrmax[iday,iens,]-allobs1hrmax[iday,])^2, 
         na.rm=TRUE))
    }

    for (ist in 1:nstations) {
         if (!is.na(eqw1hrmax[iday,ist]) && 
             !is.na(allobs8hrmax[iday,ist])) {
             n1hrtot <- n1hrtot +1
         }
    }           

    rmse1hrmax[iday,nens+1]  <- 
#    sqrt
         (mean((kf1hrmax[iday,]-allobs1hrmax[iday,])^2, na.rm=TRUE))
    rmse1hrmax[iday,nens+2]  <- 
#    sqrt
         (mean((eqw1hrmax[iday,]-allobs1hrmax[iday,])^2, na.rm=TRUE))
    rmse1hrmax[iday,nens+3]  <- 
    sqrt(mean((persist1hrmax[iday,]-allobs1hrmax[iday,])^2, na.rm=TRUE))
    rmse1hrmax[iday,nens+4]  <- 
#    sqrt
         (mean((kf1hrmax_new[iday,]-allobs1hrmax[iday,])^2, na.rm=TRUE))


    bias1hrmax[iday,nens+1]  <- 
         (mean((kf1hrmax[iday,]-allobs1hrmax[iday,]), na.rm=TRUE))
    bias1hrmax[iday,nens+2]  <- 
         (mean((eqw1hrmax[iday,]-allobs1hrmax[iday,]), na.rm=TRUE))
    bias1hrmax[iday,nens+3]  <- 
         (mean((persist1hrmax[iday,]-allobs1hrmax[iday,]), na.rm=TRUE))
    bias1hrmax[iday,nens+4]  <- 
         (mean((kf1hrmax_new[iday,]-allobs1hrmax[iday,]), na.rm=TRUE))



    cor1hrmax[iday,nens+1] <- cor(kf1hrmax[iday,],allobs1hrmax[iday,],
                                    use="complete.obs")
    cor1hrmax[iday,nens+2] <- cor(eqw1hrmax[iday,],allobs1hrmax[iday,],
                                    use="complete.obs")
    cor1hrmax[iday,nens+3] <-cor(persist1hrmax[iday,],allobs1hrmax[iday,],
                                    use="complete.obs")
    cor1hrmax[iday,nens+4] <- cor(kf1hrmax_new[iday,],allobs1hrmax[iday,],
                                    use="complete.obs")


    acc1hrmax[iday,nens+1]  <- 
         cor((kf1hrmax[iday,]-clim1hrmax),
             (allobs1hrmax[iday,]-clim1hrmax),use="complete.obs")
    acc1hrmax[iday,nens+2]  <- 
         cor((eqw1hrmax[iday,]-clim1hrmax),
             (allobs1hrmax[iday,]-clim1hrmax),use="complete.obs")
    acc1hrmax[iday,nens+3]  <- 
         cor((persist1hrmax[iday,]-clim1hrmax),
             (allobs1hrmax[iday,]-clim1hrmax),use="complete.obs")
    acc1hrmax[iday,nens+4]  <- 
         cor((kf1hrmax_new[iday,]-clim1hrmax),
             (allobs1hrmax[iday,]-clim1hrmax),use="complete.obs")
}

cor1hrmaxave <- array(NA,c(nens+4))
rmse1hrmaxave <- array(NA,c(nens+4))
bias1hrmaxave <- array(NA,c(nens+4))

for (iens in (nens+1):(nens+4)) {
     cor1hrmaxave[iens] <- mean(cor1hrmax[,iens],na.rm=TRUE)
     rmse1hrmaxave[iens] <- sqrt(mean(rmse1hrmax[,iens],na.rm=TRUE))
     bias1hrmaxave[iens] <- mean(bias1hrmax[,iens],na.rm=TRUE)
}

#method = c("pearson", "kendall", "spearman"))
for (ist in 1:nstations) {
     ccor1hrmax[nens+1,ist] <- cor(kf1hrmax[1:ndays,ist],
                                   allobs1hrmax[1:ndays,ist],
                                    use="complete.obs")
     ccor1hrmax[nens+2,ist] <- cor(eqw1hrmax[1:ndays,ist],
                                   allobs1hrmax[1:ndays,ist],
                                   use="complete.obs")
     ccor1hrmax[nens+3,ist] <- cor(persist1hrmax[1:ndays,ist],
                                   allobs1hrmax[1:ndays,ist],
                                    use="complete.obs")
     ccor1hrmax[nens+4,ist] <- cor(kf1hrmax_new[1:ndays,ist],
                                   allobs1hrmax[1:ndays,ist],
                                    use="complete.obs")
     rrmse1hrmax[nens+1,ist]  <-
#     sqrt
          (mean((kf1hrmax[1:ndays,ist]-allobs1hrmax[1:ndays,ist])^2, 
                na.rm=TRUE))
     rrmse1hrmax[nens+2,ist]  <-
#     sqrt
          (mean((eqw1hrmax[1:ndays,ist]-allobs1hrmax[1:ndays,ist])^2, 
                na.rm=TRUE))
     rrmse1hrmax[nens+3,ist]  <-
#     sqrt
          (mean((persist1hrmax[1:ndays,ist]-allobs1hrmax[1:ndays,ist])^2, 
                na.rm=TRUE))
     rrmse1hrmax[nens+4,ist]  <-
#     sqrt
          (mean((kf1hrmax_new[1:ndays,ist]-allobs1hrmax[1:ndays,ist])^2, 
                na.rm=TRUE))

     bbias1hrmax[nens+1,ist]  <-
          (mean((kf1hrmax[1:ndays,ist]-allobs1hrmax[1:ndays,ist]), 
                na.rm=TRUE))
     bbias1hrmax[nens+2,ist]  <-
          (mean((eqw1hrmax[1:ndays,ist]-allobs1hrmax[1:ndays,ist]), 
                na.rm=TRUE))
     bbias1hrmax[nens+3,ist]  <-
          (mean((persist1hrmax[1:ndays,ist]-allobs1hrmax[1:ndays,ist]), 
                na.rm=TRUE))
     bbias1hrmax[nens+4,ist]  <-
          (mean((kf1hrmax_new[1:ndays,ist]-allobs1hrmax[1:ndays,ist]), 
                na.rm=TRUE))

}

ccor1hrmaxave <- array(NA,c(nens+4))
rrmse1hrmaxave <- array(NA,c(nens+4))
bbias1hrmaxave <- array(NA,c(nens+4))

for (iens in (nens+1):(nens+4)) {
     ccor1hrmaxave[iens] <- mean(ccor1hrmax[iens,],na.rm=TRUE)
     rrmse1hrmaxave[iens] <- sqrt(mean(rrmse1hrmax[iens,],na.rm=TRUE))
     bbias1hrmaxave[iens] <- mean(bbias1hrmax[iens,],na.rm=TRUE)
}


a1hr <- array(0,c(nens+4,nthresh))
b1hr <- array(0,c(nens+4,nthresh))
c1hr <- array(0,c(nens+4,nthresh))
d1hr <- array(0,c(nens+4,nthresh))
ra1hr <- array(0,c(nens+4,nthresh))

for (iday in 1:ndays) {
    print(iday)
    for (ist in 1:nstations) {
        if (is.na(allobs1hrmax[iday,ist]) ||
            is.na(eqw1hrmax[iday,ist]) ||
            is.na(persist1hrmax[iday,ist]) ||
            is.na(kf1hrmax[iday,ist]) || 
            is.na(kf1hrmax_new[iday,ist])) next

        for (ith in 1:nthresh) {
            if (allobs1hrmax[iday,ist] > thresh1hr[ith] ) {
                if (kf1hrmax[iday,ist] > thresh1hr[ith]) {
                    a1hr[nens+1,ith] <- a1hr[nens+1,ith] + 1
                } else {
                    c1hr[nens+1,ith] <- c1hr[nens+1,ith] + 1
                }
                if (eqw1hrmax[iday,ist] > thresh1hr[ith]) {
                    a1hr[nens+2,ith] <- a1hr[nens+2,ith] + 1
                } else {
                    c1hr[nens+2,ith] <- c1hr[nens+2,ith] + 1
                }
                if (persist1hrmax[iday,ist] > thresh1hr[ith]) {
                    a1hr[nens+3,ith] <- a1hr[nens+3,ith] + 1
                } else {
                    c1hr[nens+3,ith] <- c1hr[nens+3,ith] + 1
                }
                if (kf1hrmax_new[iday,ist] > thresh1hr[ith]) {
                    a1hr[nens+4,ith] <- a1hr[nens+4,ith] + 1
                } else {
                    c1hr[nens+4,ith] <- c1hr[nens+4,ith] + 1
                }
            } else {
                if (kf1hrmax[iday,ist] > thresh1hr[ith]) {
                    b1hr[nens+1,ith] <- b1hr[nens+1,ith] + 1
                } else {
                    d1hr[nens+1,ith] <- d1hr[nens+1,ith] + 1
                }
                if (eqw1hrmax[iday,ist] > thresh1hr[ith]) {
                    b1hr[nens+2,ith] <- b1hr[nens+2,ith] + 1
                } else {
                    d1hr[nens+2,ith] <- d1hr[nens+2,ith] + 1
                }
                if (persist1hrmax[iday,ist] > thresh1hr[ith]) {
                    b1hr[nens+3,ith] <- b1hr[nens+3,ith] + 1
                } else {
                    d1hr[nens+3,ith] <- d1hr[nens+3,ith] + 1
                }
                if (kf1hrmax_new[iday,ist] > thresh1hr[ith]) {
                    b1hr[nens+4,ith] <- b1hr[nens+4,ith] + 1
                } else {
                    d1hr[nens+4,ith] <- d1hr[nens+4,ith] + 1
                }
            }
        }
    }
}             

ra1hr <- (a1hr+b1hr)*(a1hr+c1hr)/(a1hr+b1hr+c1hr+d1hr)

for (iens in (nens+1):(nens+4)) {
    ets1hrmax[iens,] <- (a1hr[iens,]-ra1hr[iens,])/
                        (a1hr[iens,]+b1hr[iens,]+c1hr[iens,]-ra1hr[iens,])
}

bb1hr <- (a1hr+b1hr)/(a1hr+c1hr)
far1hr <- b1hr/(b1hr+d1hr)
pod1hr <- a1hr/(a1hr+c1hr)
tss1hr <- pod1hr-far1hr
csi1hr <- a1hr/(a1hr+b1hr+c1hr)


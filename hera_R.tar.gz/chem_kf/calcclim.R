clim8hrmax <- array(NA,nstations)
clim1hrmax <- array(NA,nstations)

for (ist in 1:nstations) {
    clim8hrmax[ist] <- mean(allobs8hrmax[,ist],na.rm=TRUE)
    if (is.nan(clim8hrmax[ist])) clim8hrmax[ist] <- NA
    clim1hrmax[ist] <- mean(allobs1hrmax[,ist],na.rm=TRUE)
    if (is.nan(clim1hrmax[ist])) clim1hrmax[ist] <- NA
}

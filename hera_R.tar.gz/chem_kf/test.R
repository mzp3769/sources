p <- 0
for (iday in 1:ndays) {
    for (ist in 1:nstations) {
        if (is.na(allobs8hrmax[iday,ist])) next
        if (allobs8hrmax[iday,ist] > 85) p <- p+1
    }
}
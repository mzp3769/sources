#8hr
postscript("bias_8hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("BR")

barplot(bb8hr[8:10,],
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("30","50","70","85"),
ylim=c(0,3.25),xlab=xlabstring,ylab=ylabstring,
legend=c("DLR","AVE","PERSIST"))
axis(1,at=c(0,50))
text(2,2.8,labels="a",cex=1.5,vfont=c("serif","plain"))

dev.off()

postscript("ets_8hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("ETS")

barplot(ets8hrmax[8:10,],
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("30","50","70","85"),
ylim=c(0,0.5),xlab=xlabstring,ylab=ylabstring,
legend=c("DLR","AVE","PERSIST"))
axis(1,at=c(0,50))
text(2,0.45,labels="b",cex=1.5,vfont=c("serif","plain"))

dev.off()

#1hr

postscript("bias_1hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("BR")

barplot(bb1hr[8:10,],
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("30","50","70","85"),
ylim=c(0,2.0),xlab=xlabstring,ylab=ylabstring,
legend=c("DLR","AVE","PERSIST"))
axis(1,at=c(0,50))
text(2,1.85,labels="c",cex=1.5,vfont=c("serif","plain"))

dev.off()

postscript("ets_1hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring=expression("threshold (ppbv)")
ylabstring=expression("ETS")

barplot(ets1hrmax[8:10,],
beside=TRUE,xlim=c(1,20),space=c(0,2),
names.arg=c("30","50","70","85"),
ylim=c(0,0.5),xlab=xlabstring,ylab=ylabstring,
legend=c("DLR","AVE","PERSIST"))
axis(1,at=c(0,50))
text(2,0.45,labels="d",cex=1.5,vfont=c("serif","plain"))

dev.off()



nndays <- 55
nstations <- 360

#8hr
infile <- '/export/scratch/pagowski/stuff/chem/src_grl/ae_8hrmax.txt'
fae <- file(infile,"ra")

allobshrmax <- array(NA,c(nndays,nstations))
allmodelshrmax <- array(NA,c(nndays,nstations))

for (i in 1:nndays) {
    print(i)
    allobshrmax[i,] <- scan(fae,what=0.,n=nstations)
    allmodelshrmax[i,] <- scan(fae,what=0.,n=nstations)
}

close(fae)

rmsehrmax <- array(NA,c(nndays)) 
biashrmax <- array(NA,c(nndays))
corhrmax <- array(NA,c(nndays)) 
rrmsehrmax <- array(NA,c(nstations)) 
bbiashrmax <- array(NA,c(nstations))
ccorhrmax <- array(NA,c(nstations)) 

for (iday in 1:nndays) {
    print(iday)
    for (ist in 1:nstations) {
         if ((allmodelshrmax[iday,ist] < 0.) || 
             (allobshrmax[iday,ist] < 0.)) {
             allmodelshrmax[iday,ist] <- NA
             allobshrmax[iday,ist]  <- NA
         }
    }
    corhrmax[iday] <- cor(allmodelshrmax[iday,],
                          allobshrmax[iday,],
                          use="complete.obs")
    rmsehrmax[iday]  <- 
#         sqrt
              (mean((allmodelshrmax[iday,]-allobshrmax[iday,])^2, 
         na.rm=TRUE))
    biashrmax[iday] <- mean(allmodelshrmax[iday,]-allobshrmax[iday,],
         na.rm=TRUE)
}

cor8hrmaxave_svd <- mean(corhrmax,na.rm=TRUE)
rmse8hrmaxave_svd <- sqrt(mean(rmsehrmax,na.rm=TRUE))
bias8hrmaxave_svd <- mean(biashrmax,na.rm=TRUE)

#method = c("pearson", "kendall", "spearman"))
for (ist in 1:nstations) {
     ccorhrmax[ist] <- cor(allmodelshrmax[1:nndays,ist],
                            allobshrmax[1:nndays,ist],
                            use="complete.obs")
     rrmsehrmax[ist] <- 
                       #sqrt
                            (mean((allmodelshrmax[1:nndays,ist]
                                    -allobshrmax[1:nndays,ist])^2,
                na.rm=TRUE))
     bbiashrmax[ist] <- mean((allmodelshrmax[1:nndays,ist]
                                    -allobshrmax[1:nndays,ist]),
                na.rm=TRUE)
}

ccor8hrmaxave_svd <- mean(ccorhrmax,na.rm=TRUE)
rrmse8hrmaxave_svd <- sqrt(mean(rrmsehrmax,na.rm=TRUE))
bbias8hrmaxave_svd <- mean(bbiashrmax,na.rm=TRUE)

#1hr

infile <- '/export/scratch/pagowski/stuff/chem/src_grl/ae_1hrmax.txt'
fae <- file(infile,"ra")

allobshrmax <- array(NA,c(nndays,nstations))
allmodelshrmax <- array(NA,c(nndays,nstations))

for (i in 1:nndays) {
    print(i)
    allobshrmax[i,] <- scan(fae,what=0.,n=nstations)
    allmodelshrmax[i,] <- scan(fae,what=0.,n=nstations)
}

close(fae)

rmsehrmax <- array(NA,c(nndays)) 
biashrmax <- array(NA,c(nndays))
corhrmax <- array(NA,c(nstations)) 
rrmsehrmax <- array(NA,c(nstations)) 
bbiashrmax <- array(NA,c(nstations))
ccorhrmax <- array(NA,c(nstations)) 

for (iday in 1:nndays) {
    print(iday)
    for (ist in 1:nstations) {
         if ((allmodelshrmax[iday,ist] < 0.) || 
             (allobshrmax[iday,ist] < 0.)) {
             allmodelshrmax[iday,ist] <- NA
             allobshrmax[iday,ist]  <- NA
         }
    }
    corhrmax[iday] <- cor(allmodelshrmax[iday,],
                          allobshrmax[iday,],
                          use="complete.obs")
    rmsehrmax[iday]  <- 
#         sqrt
              (mean((allmodelshrmax[iday,]-allobshrmax[iday,])^2, 
         na.rm=TRUE))
    biashrmax[iday] <- mean(allmodelshrmax[iday,]-allobshrmax[iday,],
         na.rm=TRUE)
}

cor1hrmaxave_svd <- mean(corhrmax,na.rm=TRUE)
rmse1hrmaxave_svd <- sqrt(mean(rmsehrmax,na.rm=TRUE))
bias1hrmaxave_svd <- mean(biashrmax,na.rm=TRUE)

#method = c("pearson", "kendall", "spearman"))
for (ist in 1:nstations) {
     ccorhrmax[ist] <- cor(allmodelshrmax[1:nndays,ist],
                            allobshrmax[1:nndays,ist],
                            use="complete.obs")
     rrmsehrmax[ist] <- 
                       #sqrt
                            (mean((allmodelshrmax[1:nndays,ist]
                                    -allobshrmax[1:nndays,ist])^2,
                na.rm=TRUE))
     bbiashrmax[ist] <- mean((allmodelshrmax[1:nndays,ist]
                                    -allobshrmax[1:nndays,ist]),
                na.rm=TRUE)
}

ccor1hrmaxave_svd <- mean(ccorhrmax,na.rm=TRUE)
rrmse1hrmaxave_svd <- sqrt(mean(rrmsehrmax,na.rm=TRUE))
bbias1hrmaxave_svd <- mean(bbiashrmax,na.rm=TRUE)


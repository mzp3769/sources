dir <- "/export/scratch/pagowski/stuff/wrf1d/from_dorita"
fname <- "ebbr.nc"

nc <- open.ncdf(paste(dir,"/",fname,sep=""), readunlim=FALSE)

sensfluxname <- "h"
qcsensfluxname <- "qc_h"
latfluxname <- "e"
qclatfluxname <- "qc_e"
bowenname <- "bowen"
windname <- "wind_s"
qcwindname <- "qc_wind_s"
tairname <- "tair_bot"
qctairname <- "qc_tair_bot"
presname <- "pres"
qcpresname <- "qc_pres"

times <- get.var.ncdf( nc, "time")
timeoffset <- get.var.ncdf( nc, "time_offset")

ntimes <- dim(times)

sensflux <- get.var.ncdf( nc, sensfluxname )
qcsensflux <- get.var.ncdf( nc, qcsensfluxname )

latflux <- get.var.ncdf( nc, latfluxname )
qclatflux <- get.var.ncdf( nc, qclatfluxname )

bowen <- get.var.ncdf( nc, bowenname )

wind <- get.var.ncdf( nc, windname )
qcwind <- get.var.ncdf( nc, qcwindname )

tair <- get.var.ncdf( nc, tairname)
qctair <- get.var.ncdf( nc, qctairname)

pres <- get.var.ncdf( nc, presname)
qcpres <- get.var.ncdf( nc, qcpresname)

close.ncdf(nc)

for (i in 1:ntimes) {
    if (qcwind[i] > 0) {
        wind[i] <- NA
    }
    if (qclatflux[i] > 0) {
        latflux[i] <- NA
    }

    if (qcsensflux[i] > 0) {
        sensflux[i] <- NA
    }

    if (qctair[i] > 0) {
        tair[i] <- NA
    }
    if (qcpres[i] > 0) {
        pres[i] <- NA
    }

}

source("const.R")
tair <- tair+273.15
pres <- pres*1.e3
rho <- pres/(rgas*tair)
thflux <- -sensflux/(rho*cp)
qflux <- -latflux/(rho*l_evap)


source("corrna.R")
for (i in 1:ntimes) {
   print(i)
   thflux[i] <- corrnafunc(thflux)
   qflux[i] <- corrnafunc(qflux)
   wind[i] <- corrnafunc(wind)
}

thvirtflux <- thflux+virtfactor*tair*qflux

oldwind <- wind
oldthflux <- thflux
oldqflux <- qflux
oldthvirtflux <- thvirtflux


allflux <- array(c(thflux,qflux,wind),c(ntimes,3))
file("fluxes.txt","w")
for (i in 1:ntimes) {
    write(allflux[i,],file="fluxes.txt",
    ncolumns=3,append=TRUE)
}

stop("stop in readflux.R")


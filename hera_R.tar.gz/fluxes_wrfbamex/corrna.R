corrnafunc <- function(vector) {
# to remove NA values

   if (is.na(vector[i])) {
      if (!(is.na(vector[i+1]))) {
          vector[i] <- .5*(vector[i-1]+vector[i+1])
      }
      if (!(is.na(vector[i+2]))) {
          vector[i] <- 2./3.*vector[i-1]+1./3.*vector[i+2]
      } else {
          vector[i] <- vector[i-1]
      }
   }
   return(vector[i])

}

zwind <- 3.4
zbot <- .96
ztop <- 1.96
zo <- .15
hpbl <- 1500.
epsmol <- 1.e-8

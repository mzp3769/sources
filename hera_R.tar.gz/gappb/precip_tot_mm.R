library(ncdf)
year="_2005"
field="RAINTOT"

sims <- c("_sim_112bb","_sim_112cb",
          "_sim_113bb","_sim_113cb",
          "_sim_114bb","_sim_114cb",
          "_sim_115bb","_sim_115cb",
          "_sim_116bb","_sim_116cb")


for (sim in sims) {

print(sim)

print("getting data")

fname <-  paste("/export/scratch2/pagowski/stuff/gapp/output/",
field,sim,year,".nc",sep="")

nc <- open.ncdf(fname,readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ntimes <- v1$varsize[3]
close.ncdf(nc)

ixs <- 1
ixe <- nx
jxs <- 1
jxe <- ny


par(mar=c(2.1,4.1,2.1,0.1))
par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)

outname <- paste("./pngs/new/",field,"_accum",sim,year,".png",sep="")

png(outname,width = 700, height = 515,bg="white")

filled.contour(x=seq(1,nx),y=seq(1,ny),z=data1[ixs:ixe,jxs:jxe],
levels=c(1,10,50,100,150,200,250,300),
,asp=1,
col = rainbow(7,start=.15,end=.75,
gamma=1.),plot.axes={axis(1,at=c(1,30,60,90),font=2);
axis(2,at=c(1,30,60),font=2)},
xaxs = "i", yaxs = "i",
font=2,xlab="E-W domain size",ylab="S-N domain size",
#key.title = title(main="Precip\n(mm)"),
key.axes=axis(4,at=c(.1,10,50,100,150,200,250,300),font=2))
dev.off()
}


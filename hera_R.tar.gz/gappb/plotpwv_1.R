




plot(seq(1,ntimes,by=1),pwv,"l",col="red",lwd=5)


xvec <- seq(0,23,by=1)
xmin <- min(xvec)
xmax <- max(xvec)

pwvaa <- pwv
pwvaa[1,,,] <- pwv[24,,,]
pwvaa[2:24,,,] <-  pwv[1:23,,,]

#pwvaa <- pwv

i <- 3 #month
j <- 1 #MP
k <- 6 #sim

ymin <- min(pwvaa[,i,j,k])
ymax <- max(pwvaa[,i,j,k])

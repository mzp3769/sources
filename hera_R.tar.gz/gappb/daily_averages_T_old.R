library(ncdf)

nhour <- 24

dir <- "data"
abc <- c("a","b","c")
cab <- c("a")
nums <- c(102:106,112:116)


prefix <- "_sim_"
suffix <- ".nc"

fieldsc <- c("TM","TP","T")
fieldsnc <- c("PHM","PHP","PH")
fieldsncs <- c("TDM","TDP","TD")


nsims <- length(nums)
sim <- array(nsims)

jj <- 0

for (fieldc in fieldsc) {

jj <- jj+1
sig <- substr(fieldc,10,10)
if (sig=='_') sig=""

for (jchar in cab) {
for (ichar in abc) {

kk <- 0
for (k in nums) {
kk <- kk+1

if (k < 110) {
year <- "_2004"
} else {
year <- "_2005"
}

sim[kk] <- paste(prefix,as.character(k),jchar,ichar,sep="")

fnamec <- paste(dir,"/",fieldc,sim[kk],year,suffix,sep="")
print(fnamec)

nc <- open.ncdf(fnamec,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nz <- v1$varsize[1]
ntimes <- v1$varsize[2]
close.ncdf(nc)
ntimes <- ((ntimes-1)%/%24)*24+1

if (kk==1) {
  varaveth <- array(0.,c(nz,24,nsims))
  th <- varaveth
  ph <- th
  td <- th
}
ndays <- (ntimes-1)/24

for (i in 2:ntimes) {
j <- (i-1)%%24
if (j == 0) j <- 24 
varaveth[,j,kk] <- data1[,i]+varaveth[,j,kk]
}

#ph
fieldnc <- fieldsnc[jj]
fnamec <- paste(dir,"/",fieldnc,sim[kk],year,suffix,sep="")
print(fnamec)

nc <- open.ncdf(fnamec,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nz_stag <- v1$varsize[1]
ntimes <- v1$varsize[2]
close.ncdf(nc)
ntimes <- ((ntimes-1)%/%24)*24+1

if (kk==1) {
  varave <- array(0.,c(nz_stag,24,nsims))
}

ter <- data1[1,1]/9.81

for (i in 2:ntimes) {
j <- (i-1)%%24
if (j == 0) j <- 24
varave[,j,kk] <- data1[,i]+varave[,j,kk]
}


for (i in 1:nz) {
ph[i,,kk] <- .5*(varave[i,,kk]+varave[i+1,,kk])/9.81
}

#td
fieldnc <- fieldsncs[jj]
fnamec <- paste(dir,"/",fieldnc,sim[kk],year,suffix,sep="")
print(fnamec)

nc <- open.ncdf(fnamec,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nz <- v1$varsize[1]
ntimes <- v1$varsize[2]
close.ncdf(nc)
ntimes <- ((ntimes-1)%/%24)*24+1

if (kk==1) {
  varavetd <- array(0.,c(nz,24,nsims))
}

for (i in 2:ntimes) {
j <- (i-1)%%24
if (j == 0) j <- 24
varavetd[,j,kk] <- data1[,i]+varavetd[,j,kk]
}

th[,,kk] <- varaveth[,,kk]/ndays
ph[,,kk] <- ph[,,kk]/ndays-ter
td[,,kk] <- varavetd[,,kk]/ndays
}

nsims1 <- nsims/2

ymin <- 0
ymax <- 1500.
i <- 1
while (min(ph[i,,]) < ymax) {
i <- i+1
}
nlev <- i

xmin <- min(td[1:nlev,nhour,1:nsims1],na.rm=TRUE)-1
xmax <- max(th[1:nlev,nhour,1:nsims1])+1
colors <- rainbow(nsims/2)

year <- "_2004"
fname <- paste("./pngs/",fieldc,"_",jchar,ichar,year,"_average",
               ".png",sep="")
png(fname,width=300, height=500.,bg="white")

plot(th[1:nlev,nhour,1],ph[1:nlev,nhour,1],"l",col=colors[1],
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab="C",ylab="m",yaxs="i",xaxs="i",lwd=5,cex.axis=1)
#axis(1, at=xvec, labels=lxvec,cex.axis=2)

lines(td[1:nlev,nhour,1],ph[1:nlev,nhour,1],col=colors[i],lwd=5,lty=3)

for (i in 2:nsims1) {
#j <- i%%3
#if (j==1) ltyp <- 1
#if (j==2) ltyp <- 5
#if (j==0) ltyp <- 3
#k <- (i-1)%/%3 + 1
lines(th[1:nlev,nhour,i],ph[1:nlev,nhour,i],col=colors[i],lwd=5,lty=1)
lines(td[1:nlev,nhour,i],ph[1:nlev,nhour,i],col=colors[i],lwd=5,lty=3)
}

dev.off()

nsims1 <- nsims/2+1

ymin <- 0
ymax <- 1500.
i <- 1
while (min(ph[i,,]) < ymax) {
i <- i+1
}
nlev <- i

xmin <- min(td[1:nlev,nhour,nsims1:nsims],na.rm=TRUE)-1
xmax <- max(th[1:nlev,nhour,nsims1:nsims])+1
colors <- rainbow(nsims/2)

year <- "_2005"
fname <- paste("./pngs/",fieldc,"_",jchar,ichar,year,"_average",
               ".png",sep="")
png(fname,width=300, height=500.,bg="white")

plot(th[1:nlev,nhour,nsims1],ph[1:nlev,nhour,nsims1],"l",col=colors[1],
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab="C",ylab="m",yaxs="i",xaxs="i",lwd=5,cex.axis=1)
#axis(1, at=xvec, labels=lxvec,cex.axis=2)
lines(td[1:nlev,nhour,1],ph[1:nlev,nhour,nsims1],col=colors[1],
lwd=5,lty=3)


for (i in nsims1:nsims) {
#j <- i%%3
#if (j==1) ltyp <- 1
#if (j==2) ltyp <- 5
#if (j==0) ltyp <- 3
#k <- (i-1)%/%3 + 1
lines(th[1:nlev,nhour,i],ph[1:nlev,nhour,i],col=colors[i-nsims1+1],
lwd=5,lty=1)
lines(td[1:nlev,nhour,i],ph[1:nlev,nhour,i],col=colors[i-nsims1+1],
lwd=5,lty=3)
}

dev.off()

}}}






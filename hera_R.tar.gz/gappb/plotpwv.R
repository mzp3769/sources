# need to execute skewts_pwv.R first and assign pwva, pwvb, pwvc

pwvaa <- pwva
pwvaa[1,,,] <- pwva[24,,,]
pwvaa[2:24,,,] <-  pwva[1:23,,,]

pwvbb <- pwvb
pwvbb[1,,,] <- pwvb[24,,,]
pwvbb[2:24,,,]  <- pwvb[1:23,,,]

pwvcc <- pwvc
pwvcc[1,,,] <- pwvc[24,,,]
pwvcc[2:24,,,]  <- pwvc[1:23,,,]

#imonth <- 2 #month
#ifield <- 3 #MP
#isim <- 1 #sim
#isoil <- 1 #soil moisture 
#pwvaa[1:24,im,if,is]

nmonth <- length(abc)
nfield <- length(fieldsc)
nsim <- nsims
nsoil <- nmonth

allpwv <- array(NA,c(24,nmonth,nfield,nsim,nsoil))
allpw <- array(NA,c(nmonth,nfield,nsim,nsoil))
allpwv[,,,,1] <- pwvaa
allpwv[,,,,2] <- pwvbb
allpwv[,,,,3] <- pwvcc


#nmonth <- 1 #month
#nfield <- 1 #MP
#nsim <- 1 #sim
#nsoil <- 1 #soil moisture

nsim1 <- nsim/2

for (imonth in 1:nmonth) {
  for (ifield in 1:nfield) {
    for (isoil in 1:nsoil) {

      mpwvaa <- apply(allpwv[,imonth,ifield,1:nsim1,isoil],1,mean)
      allpwv[,imonth,ifield,1:nsim1,isoil] <- 
      allpwv[,imonth,ifield,1:nsim1,isoil] - mpwvaa

      mpwvaa <- apply(allpwv[,imonth,ifield,(nsim1+1):nsim,isoil],1,mean)
      allpwv[,imonth,ifield,(nsim1+1):nsim,isoil] <- 
      allpwv[,imonth,ifield,(nsim1+1):nsim,isoil] - mpwvaa

      allpw[imonth,ifield,,isoil] <- 
           apply(allpwv[,imonth,ifield,,isoil],2,mean)  
}}}


x11(width=4,height=4)
axvec=c(0,6,12,18)
alxvec=c("00","06","12","18")
colors <- rainbow(nsim/2)

imonth <- 1 #month
ifield <- 2 #MP
isim <- 1 #sim
isoil <- 3 #soil moisture

xvec <- seq(0,23,by=1)
xmin <- min(xvec)
xmax <- max(xvec)
ymin <- min(allpwv[,,ifield,,])-.05
ymax <- max(allpwv[,,ifield,,])+.5

psize <- c(.75,1,.5)
pchar <- c(19,19,19)

jsoil <- isoil


plot(xvec,array(NA,24),col=colors[isim],type="p",
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab="hour",ylab="mm",yaxs="i",xaxs="i",cex.axis=1,xaxt = "n")
axis(1, at=axvec, labels=alxvec,cex.axis=1.2)

for (isoil in jsoil:jsoil) {
for (imonth in 1:nmonth) {
  for (isim in 1:nsim1) {
    points(xvec,allpwv[,imonth,ifield,isim,isoil],col=colors[isim],
       type="p",cex=psize[isoil],pch=pchar[isoil])
  }

  for (isim in (nsim1+1):nsim) {
    points(xvec,allpwv[,imonth,ifield,isim,isoil],
       col=colors[isim-nsim1],
       type="p",cex=psize[isoil],pch=pchar[isoil])
  }
  legend(xmax-4.5,ymax,cex=.5,
  lwd=3,c("GR","BFC","KR","KF","AR"),col=colors)

}}

imonth <- 1 #month
ifield <- 3 #MP
isim <- 1 #sim
isoil <- 1 #soil moisture
jsoil <-3

xvec <- seq(1,3,by=1)
xmin <- min(xvec)-1
xmax <- max(xvec)+1
ymin <- min(allpw[,,,])-.05
ymax <- max(allpw[,,,])+.05

axvec=c(1,2,3)
alxvec=c("1","2","3")

psize <- c(.5,.75,1.)
pchar <- c(19,19,19)

#x11(width=4,height=4)

fname <- "./pngs/pwv_MP.png"
png(fname,width=700, height=700.,bg="white")

plot(xvec,array(NA,3),col=colors[isim],type="p",
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xlab="soil",ylab="mm",yaxs="i",xaxs="i",cex.axis=1,xaxt = "n")
axis(1, at=axvec, labels=alxvec,cex.axis=1.2)


for (imonth in 1:nmonth) {
  for (isim in 1:nsim1) {
    points(xvec,c(allpw[imonth,ifield,isim,3],
                  allpw[imonth,ifield,isim,1],
                  allpw[imonth,ifield,isim,2]),
                  col=colors[isim],
                  type="p",cex=psize,pch=pchar)
    lines(xvec,c(allpw[imonth,ifield,isim,3],
                  allpw[imonth,ifield,isim,1],
                  allpw[imonth,ifield,isim,2]),
                  col=colors[isim],
                  type="l",lwd=3)

  }

  for (isim in (nsim1+1):nsim) {
    points(xvec,c(allpw[imonth,ifield,isim,3],
                  allpw[imonth,ifield,isim,1],
                  allpw[imonth,ifield,isim,2]),
                  col=colors[isim-nsim1],
                  type="p",cex=psize,pch=pchar)
    lines(xvec,c(allpw[imonth,ifield,isim,3],
                  allpw[imonth,ifield,isim,1],
                  allpw[imonth,ifield,isim,2]),
                  col=colors[isim-nsim1],
                  type="l",lwd=3)

  }
  legend(xmax-.75,ymax,cex=.5,
  lwd=3,c("GR","BFC","KR","KF","AR"),col=colors)
}



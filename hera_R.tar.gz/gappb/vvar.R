library(ncdf)
dir <- "data"
abc <- c("a","b","c")
cab <- c("c","a","b")
nums <- c(102:106,112:116)

fieldc <- c("GLW_tave")
hgtm <- 1800
xlv <- 2.5E6

prefix <- "_sim_"
suffix <- ".nc"


vvart <- array(NA,c(length(abc),3,
                      length(nums),length(cab)))

sim <- array(length(abc)*length(cab)*length(nums))

nfield <- 3
nsim <- length(nums)
nabc <- length(abc)
ncab <- length(cab)

nmonth <- nabc
nsoil <- ncab


kk <- 0
for (k in nums) {
kk <- kk+1

if (k < 110) {
year <- "_2004"
} else {
year <- "_2005"
}

jjj <- 0
for (jchar in cab) {
jjj <- jjj+1

ii <- 0
for (ichar in abc) {
ii <- ii+1

sim[ii] <- paste(prefix,as.character(k),jchar,ichar,sep="")


fnamec <- paste(dir,"/",fieldc,sim[ii],year,suffix,sep="")
print(fnamec)

# the input file is hourly the average over dimensions

nc <- open.ncdf(fnamec,readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
close.ncdf(nc)
if (fieldc=="QFX_tave") {
  vvar <- data1*xlv
} else {
  vvar <- data1
}

nc <- open.ncdf("./data/HGT.nc",readunlim=FALSE )
v1 <- nc$var[[1]]
data2 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
close.ncdf(nc)
hgt <- data2

kkk <- 0
vvarm <- 0
vvarp <- 0

for (i in 1:nx) {
   for (j in 1:ny) {
   if (hgt[i,j] > hgtm) {
      kkk <- kkk+1
      vvarm <- vvarm+vvar[i,j]
   } else {
      vvarp <- vvarp+vvar[i,j]
   }
}}
vvarm <- vvarm/kkk
vvarp <- vvarp/(nx*ny-kkk)
vvarmp <- mean(vvar)


rm(data1,data2)

vvart[ii,1,kk,jjj] <- vvarm 
vvart[ii,2,kk,jjj] <- vvarp 
vvart[ii,3,kk,jjj] <- vvarmp


}}}



library(ncdf)

dx <- 5000.
dy <- 5000.


print("Uw")
#Uw
nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/tmp_w.nc",
      readunlim=FALSE )

dnw <- get.var.ncdf( nc, "DNW" )
mub <- get.var.ncdf( nc, "MUB" )
mu <- get.var.ncdf( nc, "MU" )

close.ncdf(nc)


nz <- dim(dnw)[1]
ntimes <- dim(dnw)[2]
ny <-  dim(mu)[2]

fluxuw <- array(NA,c(ny,nz,ntimes))
mutot <- array(NA,ntimes)


nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/u_w.nc",
      readunlim=FALSE )

u <- get.var.ncdf( nc, "U" )
mapfacu <- get.var.ncdf( nc, "MAPFAC_U" )

close.ncdf(nc)

for (j in 1:ny) {
    mutot <- .5*(mu[1,j,] + mub[1,j,] + mu[2,j,] + mub[2,j,])
    fluxuw[j,,] <- -dnw*mutot/9.81 * dy * u[j,,]/mapfacu[j,]
}


print("Ue")
#Ue
nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/tmp_e.nc",
      readunlim=FALSE )

dnw <- get.var.ncdf( nc, "DNW" )
mub <- get.var.ncdf( nc, "MUB" )
mu <- get.var.ncdf( nc, "MU" )

close.ncdf(nc)


nz <- dim(dnw)[1]
ntimes <- dim(dnw)[2]
ny <-  dim(mu)[2]

fluxue <- array(NA,c(ny,nz,ntimes))
mutot <- array(NA,ntimes)


nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/u_e.nc",
      readunlim=FALSE )

u <- get.var.ncdf( nc, "U" )
mapfacu <- get.var.ncdf( nc, "MAPFAC_U" )

close.ncdf(nc)

for (j in 1:ny) {
    mutot <- .5*(mu[1,j,] + mub[1,j,] + mu[2,j,] + mub[2,j,])
    fluxue[j,,] <- -dnw*mutot/9.81 * dy * u[j,,]/mapfacu[j,]
}

fluxu <- fluxuw-fluxue

boundu <- .5*sum(fluxu[,,1]+fluxu[,,24])

totfluxu <- sum(fluxu)-boundu

print("Vs")
#Vs
nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/tmp_s.nc",
      readunlim=FALSE )

dnw <- get.var.ncdf( nc, "DNW" )
mub <- get.var.ncdf( nc, "MUB" )
mu <- get.var.ncdf( nc, "MU" )

close.ncdf(nc)

nz <- dim(dnw)[1]
ntimes <- dim(dnw)[2]
nx <-  dim(mu)[1]

fluxvs <- array(NA,c(nx,nz,ntimes))
mutot <- array(NA,ntimes)


nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/v_s.nc",
      readunlim=FALSE )

v <- get.var.ncdf( nc, "V" )
mapfacv <- get.var.ncdf( nc, "MAPFAC_V" )

close.ncdf(nc)

for (i in 1:nx) {
    mutot <- .5*(mu[i,1,] + mub[i,1,] + mu[i,2,] + mub[i,2,])
    fluxvs[i,,] <- -dnw*mutot/9.81 * dx * v[i,,]/mapfacv[i,]
}


print("Vn")
#Vn
nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/tmp_n.nc",
      readunlim=FALSE )

dnw <- get.var.ncdf( nc, "DNW" )
mub <- get.var.ncdf( nc, "MUB" )
mu <- get.var.ncdf( nc, "MU" )

close.ncdf(nc)

nz <- dim(dnw)[1]
ntimes <- dim(dnw)[2]
nx <-  dim(mu)[1]

fluxvn <- array(NA,c(nx,nz,ntimes))
mutot <- array(NA,ntimes)


nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/v_n.nc",
      readunlim=FALSE )

v <- get.var.ncdf( nc, "V" )
mapfacv <- get.var.ncdf( nc, "MAPFAC_V" )

close.ncdf(nc)

for (i in 1:nx) {
    mutot <- .5*(mu[i,1,] + mub[i,1,] + mu[i,2,] + mub[i,2,])
    fluxvn[i,,] <- -dnw*mutot/9.81 * dx * v[i,,]/mapfacv[i,]
}


fluxv <- fluxvs-fluxvn

boundv <- .5*sum(fluxv[,,1]+fluxv[,,24])

totfluxv <- sum(fluxv)-boundv

totflux <- (totfluxu+totfluxv)*3600.

print("masst1")
#air mass change

#t1
nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/tmp_t1.nc",
      readunlim=FALSE )

dnw <- get.var.ncdf( nc, "DNW" )
mub <- get.var.ncdf( nc, "MUB" )
mu <- get.var.ncdf( nc, "MU" )
mapfacm <- get.var.ncdf( nc, "MAPFAC_M" )

close.ncdf(nc)

mutot <- mu+mub

masst1 <- array(0.,dim(mu))

for (k in 1:nz) {
   masst1 <- masst1 -dnw[k]*mutot * dx * dy/(9.81*mapfacm*mapfacm)
}

print("masst2")
#t2
nc <- open.ncdf(
      "/export/scratch2/pagowski/stuff/gapp/outdata/d_02/tmp_t2.nc",
      readunlim=FALSE )


dnw <- get.var.ncdf( nc, "DNW" )
mub <- get.var.ncdf( nc, "MUB" )
mu <- get.var.ncdf( nc, "MU" )
mapfacm <- get.var.ncdf( nc, "MAPFAC_M" )

close.ncdf(nc)

mutot <- mu+mub

masst2 <- array(0.,dim(mu))

for (k in 1:nz) {
   masst2 <- masst2 -dnw[k]*mutot * dx * dy/(9.81*mapfacm*mapfacm)
}

dm <- sum(masst2)-sum(masst1)


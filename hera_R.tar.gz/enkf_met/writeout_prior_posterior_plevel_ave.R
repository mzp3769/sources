test <- "test_911"

#type="pprior"

types <- c("prior","posterior")

statnames <- c("ME","RMSE")

for (type in types) {
for (statname in statnames) {


print("DOES NOT WRITE DOUBLE STATS")

fields3d <- c("TT","UU","VV","GHT","QVAPOR")
levels <- c("P925","P850","P700","P500","P400","P250","P100")
#levels <- c("P600")- for some reasons fails
suffix <- "cnt.txt"

stats <- c("FBAR","OBAR","FSTDEV","OSTDEV","PR_CORR","ME","BCMSE","RMSE")
minstat <- 7

plotdates <- c("2012/06/01","2012/07/01")

times_ave <- seq(as.POSIXlt(plotdates[1],"UTC"),by=3600,length=24)
assimtimes <- seq(as.POSIXlt(plotdates[1],"UTC"),by=6*3600,length=4)

write(c("field", "level",format(assimtimes,format="%H"))
     ,paste("./outdata/",test,'_',type,"_",statname,".txt",sep='')
     ,ncolumns=6,append=FALSE)

indir=paste("./indata/",test,"/point_stats_plevel_",type,sep='')

sumup <- function(k,statplot) {
     if (k > 24) {
     stop("hour need to be smaller than 24")
     }
     tindex <- 
     which(format(alldates,"%T")==format(times_ave[k],"%T"))
     if (length(tindex) < minstat ) {
     sumpup <- NA
     } else {
     sumup <- sum(statplot[tindex],na.rm=TRUE)/length(tindex)
     }
}

for (field in fields3d) {
    for (level in levels) {
    	print(c(field,level))
        fname <- paste(indir,'/',field,'_',level,'_',suffix,sep="")
	thisfile <- file(fname,"ra")
	names <- scan(thisfile,what='a',sep=',',nlines=1)
 	vartable <- try(
	read.table(thisfile,header=FALSE,skip=0,sep=','),silent=TRUE)
	if (class(vartable)=="try-error") {
	print(c("FILE EMPTY",c(field,level)))
	close(thisfile)			  
	next } 
	close(thisfile)
	ndate <- which(names=="FCST_VALID_BEG")
	ntotal <-  which(names=="TOTAL")

	total <- vartable[,ntotal]

	nlines <- length(total)

	istat <- which(names==statname)

	totdays <- NULL
	hours <- NULL
	statplot <- NULL

	print(nlines)

	for (i in 1:nlines) {
	if (total[i] < minstat) next
	totdays <- c(totdays,as.numeric(substr(vartable[i,ndate],1,8)))
	hours <- c(hours,as.numeric(substr(vartable[i,ndate],10,11)))
	statplot <- c(statplot,vartable[i,istat])

	}

	years <- totdays %/%10000
	months <- (totdays %% 10000) %/% 100
	days <-  (totdays %% 10000) %% 100

	alldates <- paste(as.character(years),"-",
		 as.character(months),"-",as.character(days),sep="")	
	times <- paste(as.character(hours),":00:00",sep="")

	alldates <- as.POSIXlt(paste(alldates,times),"UTC")
	
	statave <- NULL


	for (hour in seq(24)) {
	statave <- c(statave,sumup(hour,statplot))
        }

	output <- format(statave,digits=4)

	write(c(field,level
             ,output[1],output[7],output[13],output[19])
             ,paste("./outdata/",test,'_',type,"_",statname,".txt"
             ,sep=''),sep=','
             ,ncolumns=6,append=TRUE)

    }
}

write(c("STOP","STOP",
        "9999","9999","9999","9999")
        ,paste("./outdata/",test,'_',type,"_",statname,".txt"
        ,sep=''),sep=','
        ,ncolumns=6,append=TRUE)


}}
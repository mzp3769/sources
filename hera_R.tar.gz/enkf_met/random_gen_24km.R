#generate series of random numbers for 117 forecasts for 24km

series_length <- 48*3600

RNGkind("Mersen")

nens <- 117

nfcst <- 999


for (ifcst in 0:nfcst) {

    print(ifcst)

    fname <- paste('./outdata/sample_24km.',
    sprintf("%03d",ifcst),sep='')

    vect <- sample((1:nens),replace=FALSE)
    write(sprintf("%03d",vect),
    file=fname,ncolumns=nfcst,append=FALSE)

}

sim="test_033"

regions <- c("nh","tr","sh")

var <- "ps"

tests <- c(paste(sim,"_",regions[1],sep=''),
           paste(sim,"_",regions[2],sep=''),
           paste(sim,"_",regions[3],sep='')) 

tcolors <- c("green","red","blue")

indir="./indata/diags/"

plotdates <- c("2012/11/01","2012/11/05","2012/11/10",
	       "2012/11/15","2012/11/20","2012/11/25","2012/11/30")
nmaxtimes <- 1e3
nmaxnames <- 10
ntests <- length(tests)
ntimes <- 0

allstats <- array(NA,c(ntests,nmaxtimes,nmaxnames))

k <- 1

for (test in tests) {

    fname <- paste(indir,"enkf_stats_",var,"_",test,".log",sep='')

    thisfile <- file(fname,"ra")
    
    names <- scan(thisfile,what='a',nlines=1)

    vartable <- try(
    read.table(thisfile,header=FALSE,skip=0,sep=' '),silent=TRUE)
    if (class(vartable)=="try-error") {
	print(c("FILE EMPTY",c(field,level)))
	close(thisfile)			  
    next } 
    close(thisfile)


    nlines <- dim(vartable)[1]
    dates <- NULL
    times <- NULL

    if (ntimes < nlines) {

        for (i in 1:nlines) {

	    years <- vartable[i,1] %/% 1000000
	    months <- (vartable[i,1] %% 1000000) %/% 10000
	    days  <-  (vartable[i,1] %% 10000) %/% 100
	    hours <-  (vartable[i,1] %% 100)

	    dates <- c(dates,paste(as.character(years),"-",
		 as.character(months),"-",as.character(days),sep=""))
	    times <- c(times,paste(as.character(hours),":00:00",sep=""))
	}    

    ntimes <- nlines


    alldates <- as.POSIXlt(paste(dates,times),"UTC")

    }
	
    nnames <- length(names)

    for (j in 2:nnames) {
        allstats[k,1:nlines,j-1] <-  as.array(vartable[,j])
    }

    k <- k+1

}

#plot several tests on a single plot
#plot prior and posterior on a single plot

      	    
name <- "bias"
picname <-  paste("./pics/",name,"_",var,"_",sim,".png",sep='')

nf1=1
nf2=4

ymax <- max(allstats[1:ntests,,nf1],allstats[1:ntests,,nf2],na.rm=TRUE)
ymin <- min(allstats[1:ntests,,nf1],allstats[1:ntests,,nf2],na.rm=TRUE)
xmin <- min(alldates)
xmax <- max(alldates)

k <- 1

png(picname,width=600, height=400.,bg="white")

plot(alldates,allstats[k,1:ntimes,nf1],type="l",lwd=2,lty=1,
cex=1.,col=tcolors[k],xlab='Time',ylab='',yaxs="i",xaxs="i",
ylim=c(ymin,ymax),xaxt='n',main=name)

#axis.POSIXct(1,alldates,format="%d %b %Y",at=plotdates)
axis.POSIXct(1,alldates,format="%Y/%m/%d",at=plotdates)
lines(alldates,allstats[k,1:ntimes,nf2],type="l",lwd=2,lty=2,
cex=1.,col=tcolors[k])

k <- 2

for (test in tests[2:ntests]) {
    lines(alldates,allstats[k,1:ntimes,nf1],type="l",lwd=2,lty=1,
    cex=1.,col=tcolors[k])
    lines(alldates,allstats[k,1:ntimes,nf2],type="l",lwd=2,lty=2,
    cex=1.,col=tcolors[k])
    k <- k+1
}    

legend(x=xmax,y=ymax,xjust=1,yjust=1,col=tcolors,
lwd=2,legend=regions,cex=1)


dev.off()

name <- "innov"

picname <-  paste("./pics/",name,"_",var,"_",sim,".png",sep='')

nf1=2
nf2=5

ymax <- max(allstats[1:ntests,,nf1],allstats[1:ntests,,nf2],na.rm=TRUE)
ymin <- 0
xmin <- min(alldates)
xmax <- max(alldates)

k <- 1

png(picname,width=600, height=400.,bg="white")

plot(alldates,allstats[k,1:ntimes,nf1],type="l",lwd=2,lty=1,
cex=1.,col=tcolors[k],xlab='Time',ylab='',yaxs="i",xaxs="i",
ylim=c(ymin,ymax),xaxt='n',main=name)

#axis.POSIXct(1,alldates,format="%d %b %Y",at=plotdates)
axis.POSIXct(1,alldates,format="%Y/%m/%d",at=plotdates)
lines(alldates,allstats[k,1:ntimes,nf2],type="l",lwd=2,lty=2,
cex=1.,col=tcolors[k])

k <- 2

for (test in tests[2:ntests]) {
    lines(alldates,allstats[k,1:ntimes,nf1],type="l",lwd=2,lty=1,
    cex=1.,col=tcolors[k])
    lines(alldates,allstats[k,1:ntimes,nf2],type="l",lwd=2,lty=2,
    cex=1.,col=tcolors[k])
    k <- k+1
}    

legend(x=xmax,y=ymax,xjust=1,yjust=1,col=tcolors,
lwd=2,legend=regions,cex=1)


dev.off()

name <- "spread"

picname <-  paste("./pics/",name,"_",var,"_",sim,".png",sep='')

nf1=3

ymax <- max(allstats[1:ntests,,nf1],na.rm=TRUE)
ymin <- 0
xmin <- min(alldates)
xmax <- max(alldates)

k <- 1

png(picname,width=600, height=400.,bg="white")


plot(alldates,allstats[k,1:ntimes,nf1],type="l",lwd=2,lty=1,
cex=1.,col=tcolors[k],xlab='Time',ylab='',yaxs="i",xaxs="i",
ylim=c(ymin,ymax),xaxt='n',main=name)

#axis.POSIXct(1,alldates,format="%d %b %Y",at=plotdates)
axis.POSIXct(1,alldates,format="%Y/%m/%d",at=plotdates)

k <- 2

for (test in tests[2:ntests]) {
    lines(alldates,allstats[k,1:ntimes,nf1],type="l",lwd=2,lty=1,
    cex=1.,col=tcolors[k])
    k <- k+1
}    

legend(x=xmax,y=ymax,xjust=1,yjust=1,col=tcolors,
lwd=2,legend=regions,cex=1)


dev.off()


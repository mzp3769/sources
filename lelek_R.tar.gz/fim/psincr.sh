#!/bin/ksh

MAINDIR=/Volumes/local/scratch/stuff/R/fim
INDIR=${MAINDIR}/indata
PICDIR=${MAINDIR}/pics

for infile in ${INDIR}/psincr_*_ensmean
do
    outfile=${outdir}/`basename $infile | sed -e "s/gincr/psincr/g"`
    basefile=`basename $infile`
    ln -sf $infile ${INDIR}/incr.txt
    echo $basefile
    R CMD BATCH fimincr.R ${basefile}.log
    picname=${basefile}.png
    /bin/mv ${PICDIR}/incr.png ${PICDIR}/${picname}
    /bin/mv ${basefile}.log ${MAINDIR}/logs
done

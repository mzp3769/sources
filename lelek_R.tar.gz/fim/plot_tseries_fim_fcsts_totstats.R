test <- "test_114"

prefix <- "fim_stats_fcsts_Global3D"
vars <- c("mass","watervapor","cloudwater")
nvars <- length(vars)
dt <- 12

Sys.setenv(TZ="UTC")

tcolors <- c("red","violetred2","blue")

indir <- "./indata/diags/"
outdir <- "./pics/"

plotdates <- c("2012/11/01","2012/11/05","2012/11/10",
               "2012/11/15","2012/11/20","2012/11/25",
	       "2012/11/30","2012/12/05","2012/12/10",
	       "2012/12/15")

ncolumns <- 2

ivar <- 1


for (ivar in 1:nvars) {

    var <- vars[ivar]

    pname <- paste(indir,prefix,var,"_",test,sep='')
    files <- try(system(paste("ls ", pname,'*',sep=''),intern=TRUE))

    nfiles <- length(files)

    j <- 0


    for (fname in files) {
        j <- j+1
        thisfile <- file(fname,"ra")
	data <- scan(thisfile,what=1,nlines=1,quiet=TRUE)
	thisdate <- data[1]
	nlines <- data[2]

	years <- thisdate %/% 1000000
	months <- (thisdate %% 1000000) %/% 10000
	days  <-  (thisdate %% 10000) %/% 100
	hours <-  (thisdate %% 100)
	datestart <- c(paste(as.character(years),"-",
		 as.character(months),"-",as.character(days),sep=""))
	timestart <- c(paste(as.character(hours),":00:00",sep=""))

	datestart <- as.POSIXlt(paste(datestart,timestart),"UTC")

	if (j==1) {
	   allstats <- array(NA,c(nfiles,nlines))
	   alldates <- as.POSIXlt(array(0,c(nfiles*nlines)),
                                  origin=datestart,"UTC")
        }

	for (i in 1:nlines) {
	    k <- (j-1)*nlines+i
	    data <- scan(thisfile,what=1,nlines=1,quiet=TRUE)
	    allstats[j,i] <- data[1]
	    alldates[k] <- datestart+data[2]*3600
        }

    close(thisfile)

    }	

    ylabstring <- var

    ymin <- min(allstats)
    ymax <- max(allstats)
    xmin <- min(alldates)
    xmax <- max(alldates)

    pngname <- paste(outdir,var,'_',test,'.png',sep="")
    png(pngname,width=800, height=600.,bg="white")

    plot(alldates,1:length(alldates),ylim=c(ymin,ymax),
    col=tcolors[k],
    xlab='',ylab=ylabstring,xaxt='n',yaxs="i",xaxs="i",
    cex.axis=1.,cex.lab=1.,type="n",lwd=2,cex=1.)
    axis.POSIXct(1,alldates,format="%Y/%m/%d",at=plotdates)

    for (j in 1:nfiles) {
        k <- (j-1)*nlines+1
    	lines(alldates[k:(k+nlines-1)],allstats[j,1:nlines],
	col=tcolors[ivar],lwd=1)
    }

    dev.off()

}


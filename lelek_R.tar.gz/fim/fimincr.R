#to plot psinc

fdata <- file(paste('./indata/incr.txt'),"ra")
dims <- array(scan(fdata,what=0,n=2))
nx <- dims[1]
ny <- dims[2]

gridvals <- array(NA,c(nx,ny))

for (i in 1:ny) {
    print(i)
    gridvals[,ny-i+1] <- array(scan(fdata,what=0.,n=nx))
    
}

close(fdata)

north <- 89
south <- -89

left <- 0
right <- 359

xx <- seq(left,right,(right-left)/(nx-1))

yy <- seq(south,north,(north-south)/(ny-1))

width <- 800
height <- 600

picname <- "./pics/incr.png"
png(picname,width=width, height=height,bg="white")
#for mean
#filled.contour(xx,yy,gridvals,zlim=c(-200,200),nlevels=16,color.palette=rainbow)

#for individual
filled.contour(xx,yy,gridvals,zlim=c(-400,400),nlevels=16,color.palette=rainbow)


dev.off()



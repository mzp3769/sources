#to test if spectral interpolationworks ok

fdata <- file(paste('./indata/specdata.txt'),"ra")
dims <- array(scan(fdata,what=0,n=3))
nz <- dims[1]
ny <- dims[2]
nx <- dims[3]

gridvals <- array(NA,c(nx,ny))

for (i in 1:ny) {
    gridvals[,i] <- array(scan(fdata,what=0.,n=nx))
}

filled.contour(gridvals,color.palette=rainbow)

close(fdata)


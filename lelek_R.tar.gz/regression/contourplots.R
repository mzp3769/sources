fvor <- file("fort.30","ra")
nx <- scan(fvor,what=1,n=1)
ny <- scan(fvor,what=1,n=1)
vor <- array(scan(fvor,what=0.,n=nx*ny),c(nx,ny))
close(fvor)

vor <- pmax(vor,0.)
vormin <- min(vor)
vormax <- max(vor)

filled.contour(vor,nlevels=10,zlim=c(vormin,vormax),
               color.palette=rainbow)

x11()


fstream <- file("fort.40","ra")
nx <- scan(fvor,what=1,n=1)
ny <- scan(fvor,what=1,n=1)
stream <- array(scan(fstream,what=0.,n=nx*ny),c(nx,ny))
close(fstream)

strmin <- min(stream)
strmax <- max(stream)

filled.contour(stream,nlevels=10,zlim=c(strmin,strmax),
               color.palette=rainbow)


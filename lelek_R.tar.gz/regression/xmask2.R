#this is for shrunk domain in latitude for regression
#to plot xmask2
name <- "./indata/xmask2.txt"
nlat <- 32
nlon <- 133
infile <- file(name,"ra")

xmask <- array(NA,c(nlon,nlat))
for (i in 1:nlat) {
for (j in 1:nlon) {
    xmask[j,i] <- scan(infile,what=1,n=1,quiet=TRUE)
#print(c(i,j,xmask[j,i]))
}
}
close(infile)

x <- seq(1:nlon)
y <- seq(1:nlat)

x11()
filled.contour(x,y,xmask)

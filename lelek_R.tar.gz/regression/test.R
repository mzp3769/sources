ftest <- file("RDATA.txt","ra")
nx <- scan(ftest,what=1,n=1)
ny <- scan(ftest,what=1,n=1)
nvar <- scan(ftest,what=1,n=1)
data <- array(scan(ftest,what=0.,n=nx*ny*nvar),c(nvar,nx,ny))
close(ftest)

for (i in 1:nvar) {
  dmax <- max(data[i,,])
  dmin <- min(data[i,,])
  x11(width=4.5,height=4.5)
  filled.contour(data[i,,],nlevels=20,zlim=c(dmin,dmax),
               color.palette=rainbow)
locator()
}

ftest <- file("./indata/fort.101","ra")
ftest <- file("./indata/fort.201","ra")
nvar <- 7
nx <- 34
ny <- 34	
data <- array(scan(ftest,what=0.,n=nx*ny*nvar),c(nvar,nx*ny))
close(ftest)

library(fields)

z <- array(0,c(nx,ny))
l <- 0
for (i in 1:ny) {
for (j in 1:nx) {
    l <- l+1
    z[i,j] <- data[7,l]
}}

x <- 1:34
y <- 1:34
#quilt.plot(x,y,z)
#image.plot(x,y,z)
zmin <- min(z)
zmax <- max(z)
x11(width=5.6,height=5)

filled.contour(x,y,z,nlevels=20,zlim=c(zmin,zmax),color.palette=rainbow)
#filled.contour(x,y,z,nlevels=20,zlim=c(zmin,zmax),color = terrain.colors)


for (i in 1:nvar) {
  dmax <- max(data[i,,])
  dmin <- min(data[i,,])
  x11(width=4.5,height=4.5)
  filled.contour(data[i,,],nlevels=20,zlim=c(dmin,dmax),
               color.palette=rainbow)
locator()
}

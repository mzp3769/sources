#to plot vertical regressions for two variables gsi
name <- "./indata/varb_over_vart.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1)

ratio <- array(NA,c(nz,nz))
val <- ratio

for (k in 1:nz) {
    for (l in 1:nz) {
        data <- scan(infile,what=1,n=4,quiet=TRUE)
	ratio[k,l] <- data[3]
	val[k,l] <- data[4]
    }
} 

close(infile)

nlevs=20

x <- 1:nz
y <- x

zmin <- min(ratio)
zmax <- max(ratio)	

x11(width=5.6,height=5)

filled.contour(x,y,ratio[1:nz,1:nz],
               nlevels=nlevs,zlim=range(zmin,zmax),
               color.palette=rainbow)

vect <- array(NA,nz)

system("rm -f varbal2vartot.txt") 
title <- 'varbal2vartot.txt'
for (i in 1:nz) {
    vect[i] <- sort(ratio[,i], method = "sh", index.return=TRUE)$ix[nz]
    write(nz,file=title,ncolumns=1,append=FALSE)
    write(c(i,vect[i],max(ratio[,i])),file=title,ncolumns=3,append=TRUE)
} 




#x11(width=5.6,height=5)

#zmin <- min(val)
#zmax <- max(val)

#filled.contour(x,y,val[1:nz,1:nz],
#               nlevels=nlevs,zlim=range(zmin,zmax),
#               color.palette=rainbow)



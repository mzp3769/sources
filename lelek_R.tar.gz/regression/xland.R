library(fields)
infile <- file("./indata/xlandfull_dump.bin","rb")
trash <- readBin(infile,what=integer(), n=1,size=4)
dims <- readBin(infile,what=integer(), n=4,size=4)
nx <- dims[1]
ny <- dims[2]
xland <- array(NA,c(nx,ny))
trash <- readBin(infile,what=numeric(), n=2,size=4)
x <- readBin(infile,what=numeric(), n=nx*ny,size=4)
close(infile)

xlandf <- function(x) {
if (x > 1) xlandf <- 0 else xlandf <- 1
}

x <- sapply(x,FUN=xlandf)

for (j in 1:ny) xland[,j] <- x[((j-1)*nx+1):(j*nx)]

yland <- xland

for (i in 1:nx) {
    for (j in 1:ny) {
    	imin <- max(i-3,1)
	imax <- min(i+3,nx)
    	jmin <- max(j-3,1)
	jmax <- min(j+3,ny)
        if (any(xland[imin:imax,jmin:jmax] > 0)) yland[i,j] <- 1
}
}


x <- seq(1:nx)
y <- seq(1:ny)

filled.contour(x,y,xland)

dx <- 1
dy <- 1

wght<- setup.image.smooth( nrow=nx, ncol=ny,  dx=dx, dy=dy,
             theta=5, xwidth=5, ywidth=5)

x11()
xland1 <- image.smooth(yland, dx=dx, dy=dy, wght)
#image.plot(xland1)
filled.contour(x,y,xland1$z)

write(dims[1:2],file="./indata/mask.txt",ncolumns=2,append=FALSE)
write(xland1$z,file="./indata/mask.txt",ncolumns=1,append=TRUE)

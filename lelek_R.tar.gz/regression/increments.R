library(ncdf)

month <- "jul"
fcst <- "24"
utc <- "00"

if (nchar(utc) > 0) {
   infile <- paste("../../regression/test_838/",month,"/incr_",fcst,
                  "_ave_",utc,".nc",sep='')
} else {
   infile <- paste("../../regression/test_838/",month,"/incr_",fcst,
                  "_ave.nc",sep='')
}

var <- 'PM2_5_DRY'
nc <- open.ncdf(infile, readunlim=FALSE )
pm25_incr <- get.var.ncdf( nc, var )
nx <- dim(pm25_incr)[1]
ny <- dim(pm25_incr)[2]
close.ncdf(nc)

x <- seq(1:nx)
y <- seq(1:ny)

incrmin <- -5
incrmax <- 10
bounds <- abs(incrmax-incrmin)


xrange <- function(x,xmin,xmax) {
if (x < xmin ) {
   xrange <- xmin 
} else if (x > xmax ) {
   xrange <- xmax 
} else xrange <- x
}

pmrange <- apply(pm25_incr,MARGIN=c(1,2),
FUN=xrange,xmin=incrmin,xmax=incrmax)

reverse_rainbow <- function(x) rev(rainbow(x))

if (nchar(utc) > 0) {
fname <- paste('increment_',month,'_',fcst,'_',utc,'.png',sep='')
} else { 
fname <- paste('increment_',month,'_',fcst,'.png',sep='')
}

#both "cairo" or "Xlib" work, otherwise vertical and horizontal lines
png(fname,
#width = 500, height = 500,bg="white",type="Xlib")
width = 500, height = 500,bg="white",type="cairo")
filled.contour(x,y,pmrange,zlim=c(incrmin,incrmax),
color.palette=reverse_rainbow,nlevels=bounds
)

dev.off()
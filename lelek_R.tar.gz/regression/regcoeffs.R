#to plot vertical regressions for two variables gsi
name <- "./indata/regcoeffs.txt"
title <- "./indata/regvals.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1,quiet=TRUE)

regr <- array(NA,c(nz,nz))
ratio <- regr

for (k in 1:nz) {
    for (l in 1:nz) {
        data <- scan(infile,what=1,n=4,quiet=TRUE)
	regr[k,l] <- data[3]
	ratio[k,l] <- data[4]
    }
} 

close(infile)

nlevs=20

x <- 1:nz
y <- x

zmin <- min(regr)
zmax <- max(regr)	

x11(width=5.6,height=5)

filled.contour(x,y,regr[1:nz,1:nz],
               nlevels=nlevs,zlim=range(zmin,zmax),
               color.palette=rainbow)


x11(width=5.6,height=5)

zmin <- min(ratio)
zmax <- max(ratio)

filled.contour(x,y,ratio[1:nz,1:nz],
               nlevels=nlevs,zlim=range(zmin,zmax),
               color.palette=rainbow)

vect <- array(NA,c(nz,8))

system("rm -f ./indata/regvals.txt")

write(nz,file=title,ncolumns=1,append=FALSE)

newvect <- array(NA,c(nz,2))

for (i in 1:nz) {
    vect[i,] <- sort(ratio[,i], method = "sh", 
    index.return=TRUE)$ix[nz:(nz-7)]
    write('*****',file=title,ncolumns=1,append=TRUE)
    write(c(i,vect[i,1],regr[vect[i,1],i],ratio[vect[i,1],i]),
    file=title,ncolumns=4,append=TRUE)
    write(c(i,vect[i,2],regr[vect[i,2],i],ratio[vect[i,2],i]),
    file=title,ncolumns=4,append=TRUE)
    write(c(i,vect[i,3],regr[vect[i,3],i],ratio[vect[i,3],i]),
    file=title,ncolumns=4,append=TRUE)
    write(c(i,vect[i,4],regr[vect[i,4],i],ratio[vect[i,4],i]),
    file=title,ncolumns=4,append=TRUE)
    write(c(i,vect[i,5],regr[vect[i,5],i],ratio[vect[i,5],i]),
    file=title,ncolumns=4,append=TRUE)
    write(c(i,vect[i,6],regr[vect[i,6],i],ratio[vect[i,6],i]),
    file=title,ncolumns=4,append=TRUE)
    write(c(i,vect[i,7],regr[vect[i,7],i],ratio[vect[i,7],i]),
    file=title,ncolumns=4,append=TRUE)
    write(c(i,vect[i,8],regr[vect[i,8],i],ratio[vect[i,8],i]),
    file=title,ncolumns=4,append=TRUE)


    newvect[i,] <- c(regr[vect[i,1],i],ratio[vect[i,1],i])
}

xmin <- min(newvect[,1])
xmax <- max(newvect[,1])

x11(width=5,height=5)
plot(newvect[,1],1:nz,xlim=c(xmin,xmax),xaxs="i",yaxs="i",type="l",lwd=2,
     xlab="Regcoeff",ylab="Level")

xmin <- 0
xmax <- max(newvect[,2])

x11(width=5,height=5)
plot(newvect[,2],1:nz,xlim=c(xmin,xmax),xaxs="i",yaxs="i",type="l",lwd=2,
     xlab="bal2tot",ylab="Level")

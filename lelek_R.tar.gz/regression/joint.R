#to plot vertical regressions for two variables gsi
name <- "./indata/cov_balance.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1,quiet=TRUE)

regr <- array(NA,c(nz,3))

for (k in 1:nz) {
    data <- scan(infile,what=1,n=4,quiet=TRUE)
    regr[k,] <- data[2:4]
} 

close(infile)

nlevs=20

y <- 1:nz

xmin <- 0
xmax <- max(regr)

x11(width=5,height=5)
tiff("pm_total_regression.tiff",width = 600, height = 600)
#tiff("o3_total_regression.tiff",width = 600, height = 600)

plot(regr[,1],y,xlim=c(xmin,xmax),xaxs="i",yaxs="i",type="l",lwd=2,
     xlab="Balance",ylab="Level")
points(regr[,1],y,col="black",pch=24,cex=.6)

dev.off()

#lines(regr[,2],y,col="red",lwd=2)
#points(regr[,2],y,col="red",pch=25,cex=.6)

#lines(regr[,3],y,col="blue",lwd=2)
#points(regr[,3],y,col="blue",pch=23,cex=.6)

name <- "iterations.txt"
npoints <- 5
nx <- 200
ny <- 41
#x11()

#png("zeta_min.png",width = 380, height = 360,bg="white")


ylabstring <- expression("dlogzh")
xlabstring <- expression("logm")

#dev.set(3)
infile <- file(name,"ra")
a <- readLines(infile)
ntimes <- length(a)
close(infile)
infile <- file(name,"ra")
var <- array(0,c(ntimes,npoints))
for (i in 1:ntimes) {
	var[i,] <- array(scan(infile,what=0.,n=npoints))
}
close(infile)
zeta <- array(0,c(ny,nx))
k <- 0
for (i in 1:nx) {
	for (j in 1:ny) {
		k <- k+1	
		zeta[ny-j+1,i] <- var[k,npoints]
	}			 
}

x <- seq(-1,1,by=.05)

y <- seq(3.912022,13.912021,by=.05)
#y <- seq(3.912022,13.912022,by=.5)
y <- y/2.3025851


postscript("iter.eps",width = 6.5, height = 5.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")


par(xaxs="i")
par(yaxs="i")
par(cex.axis=1.2)
par(cex.lab=1.3)
par(mar=c(4.1,4.1,2.1,2.1))
par(font.lab=2)
par(tcl=-0.3)
par(ann=FALSE)
ylabstring <- expression(log[10](z[0]/z[H]))
xlabstring <- expression(Rb)

pal <- palette(gray(seq(1.,0.,len=4)))
#image(x,y,zeta,
#xlim=range(-1,1),ylim=range(1.7,6.),zlim=range(2,5),
#levels=c(0,1,2,3,4,5),
#col = pal)

#grid <- expand.grid(x=x, y=y)
#grid$z <- zeta

#levelplot(zeta~x*y,data=grid)


filled.contour(x,y,zeta,
xlim=range(-1,1),ylim=range(1.7,6.),zlim=range(2,4),
levels=c(2,3,4,5),frame.plot = TRUE,
xlab=xlabstring,ylab=ylabstring,
key.axes=axis(4,seq(2,4,by = 1)),
col = pal,plot.axes={ axis(1); axis(2); contour(x,y,zeta,add=TRUE,
xlab=xlabstring,ylab=ylabstring,labcex=1,
las = 1,xlim=range(-1,1),ylim=range(1.7,6.),zlim=range(2,5),
levels=c(0,1,2,3,4,5),
lwd=1.5,method="flattest")})
#plot.axes={ axis(1); axis(2); points(10,10) }) })


#contour(x,y,zeta,add=TRUE,
#xlab=xlabstring,ylab=ylabstring,labcex=.85,
#las = 1,xlim=range(-1,1),ylim=range(1.7,6.),zlim=range(2,5),
#levels=c(0,1,2,3,4,5),
#lwd=1.5,method="flattest",axes=TRUE,
#plot.axes={ axis(1); axis(2); points(10,10) })
text(-.9,5.5,labels="b",cex=2.25)

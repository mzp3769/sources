name <- "zeta.txt"
npoints <- 3
nx <- 11
ny <- 21
#x11()

#png("zeta_min.png",width = 380, height = 360,bg="white")


ylabstring <- expression("dlogzh")
xlabstring <- expression("logm")

#dev.set(3)
infile <- file(name,"ra")
a <- readLines(infile)
ntimes <- length(a)
close(infile)
infile <- file(name,"ra")
var <- array(0,c(ntimes,3))
for (i in 1:ntimes) {
	var[i,] <- array(scan(infile,what=0.,n=3))
}
close(infile)
zeta <- array(0,c(ny,nx))
k <- 0
for (i in 1:nx) {
	for (j in 1:ny) {
		k <- k+1	
		zeta[j,i] <- var[k,3]
	}			 
}
xl <- min(var[,1])
xu <- max(var[,1])
yl <- min(var[,2])
yu <- max(var[,2])


#x <- seq(xl,xu,by=.1)
#y <- seq(yl,yu,by=.5)

#x <- seq(2.995730,13.495730,by=.5)

#x <- seq(3.912022,13.412022,by=.5)
#x <- seq(4.605170,13.605170,by=.5)
#y <- seq(0.,5.,by=.5)


x <- seq(3.912022,13.912022,by=.5)
x <- x/2.3025851
#x <- exp(x)

y <- seq(0.,5.,by=.5)
y <- y/2.3025851


postscript("zeta.eps",width = 6.5, height = 6.5,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")


par(xaxs="i")
par(yaxs="i")
par(cex.axis=1.2)
par(cex.lab=1.3)
par(mar=c(4.1,4.1,2.1,2.1))
par(font.lab=2)
par(tcl=-0.3)

ylabstring <- expression(log[10](z[0]/z[H]))
xlabstring <- expression(log[10](z/z[0]))

contour(x,y,zeta,
xlab=xlabstring,ylab=ylabstring,labcex=.85,
las = 1,xlim=range(1.7,6),ylim=range(0.0,2),zlim=range(-1,-12),
#levels=c(-2,-4,-6,-8,-10,-12),lwd=1.5,method="flattest",
lwd=1.5,method="flattest",
plot.axes={ axis(1); axis(2); points(10,10) })
#mtext(c(expression(paste(sigma[s],"  "))),side=1,outer=FALSE,
#at=3,cex=2)
text(1.9,1.9,labels="b",cex=2.25)

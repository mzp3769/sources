name <- "zeta.txt"
npoints <- 3
nx <- 6
ny <- 11
#x11()

dx=2./nx
dy=2./ny

#png("zeta_fit.png",width = 380, height = 360,bg="white")



#dev.set(3)
infile <- file(name,"ra")
a <- readLines(infile)
ntimes <- length(a)
close(infile)
infile <- file(name,"ra")
var <- array(0,c(ntimes,3))
for (i in 1:ntimes) {
	var[i,] <- array(scan(infile,what=0.,n=3))
}
close(infile)
zetasurf <- array(0,c(ny,nx))
#zetaframe <- data.frame(x=var[,1],y=var[,2],z=var[,3])
#zeta.kr <- surf.ls(2, zetaframe)
#zeta.kr$beta[8]=0
#zeta.kr$beta[12:15]=0

xl <- min(var[,1])
xu <- max(var[,1])
yl <- min(var[,2])
yu <- max(var[,3])

a = -1.3610871813576932E+01
b =  1.6988056242263614E+00
c =  5.7683514337071582E+00
d = -1.2226971828356656E-01
e = -6.2951864727214413E-01
f = -4.3572117679594247E-01

k <- 0
for (i in 1:nx) {
	for (j in 1:ny) {
		k <- k+1	
		xi <- var[k,1]
		yi <- var[k,2]	
		zetasurf[j,i] <- 
#1		a*xi^b + c*yi^d + e
#2                a + xi^b*yi^c
#3                (a + b*xi + c*yi)/(1+d*xi+e*yi)
                a + b*xi + c*yi + d*xi^2 + e*yi^2 + f*xi*yi               
#	if (xi < 6) zetasurf[j,i] <- zetasurf[j,i] - 
#		zetasurf[j,i] <- predict(zeta.kr,xi,yi) 
	}			 
}

x <- seq(9.210340,14.210340,by=.5)
x <- x/2.3025851

y <- seq(-2.5,0.,by=.5)
y <- y/2.3025851


#filled.contour(zetasurf,nlevels=11,
#filled.contour(x,y,zetasurf,nlevels=11,
#color.palette=rainbow,
#xlab=xlabstring,ylab=ylabstring,cex.lab=1.2,cex.axis=1.2,
#xaxs = "i", yaxs = "i", las = 1,zlim=range(0,-13),
#plot.axes={ axis(1); axis(2); points(10,10) })

postscript("surf.eps",width = 6.5, height = 6.5,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")


par(xaxs="i")
par(yaxs="i")
par(cex.axis=1.2)
par(cex.lab=1.3)
par(mar=c(4.1,4.1,2.1,2.1))
par(font.lab=2)
par(tcl=-0.3)

ylabstring <- expression(log[10](z[0]/z[H]))
xlabstring <- expression(log[10](z/z[0]))



contour(x,y,zetasurf,
xlab=xlabstring,ylab=ylabstring,labcex=.85,
las = 1,xlim=range(4,6),ylim=range(-1.,0.),zlim=range(-24,-7),
levels=c(-8,-9,-10,-11,-12,-13,-14,-15,-16,-17),
lwd=1.5,method="flattest",
plot.axes={ axis(1); axis(2); points(10,10) })
text(4.1,-.05,labels="c",cex=2.25)



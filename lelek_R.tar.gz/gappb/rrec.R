library(ncdf)
prefix <- "./data_recycle/recycling_ratio_sim_"
suffix <- ".nc"

abc <- c("a","b","c")
cab <- c("c","a","b")
nums <- c(102:106,112:116)
ndim <- length(nums)*length(abc)*length(abc)

peff <- array(NA,ndim)
sims <- array(NA,ndim)

count <- 0

for (k in nums) {
for (j in abc) {
for (i in cab) {

count <- count+1

sim <- (paste(k,i,j,sep=""))
print(sim)

sims[count] <- sim

nc <- open.ncdf(paste(prefix,sim,suffix,sep=""),readunlim=FALSE)
v1 <- nc$var[[1]]
peff[count] <- get.var.ncdf( nc, v1 )
close.ncdf(nc)
}}}


png(paste("./pngs/recycling_ratio.png",sep=""),
width = 700, height = 700,bg="white")

colors <- rainbow(ndim/(length(abc)*length(cab)*2))

ymin <- min(peff)-.01
ymax <- max(peff)+.01
xmin <- 0
xmax <- length(abc)+1

xvec <- 1:length(cab)

count <- 0
ccount <- 0

for (k in nums) {
if (ccount==5) ccount=0
ccount <- ccount+1
color <- colors[ccount]
for (j in abc) {
for (i in cab) {

count <- count+1

if (i==cab[1]) {
psize <- 1 
x <- 1
}

if (i==cab[2]) {
psize <- 1.25
x <- 2
}

if (i==cab[3]) {
psize <- 1.5
x <- 3
}

#if (i==abc[1]) x <- 1
#if (i==abc[2]) x <- 2
#if (i==abc[3]) x <- 3

if (count==1) {
plot(x,peff[count],col=color,xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="",ylab="Recycling ratio",xaxs="i",yaxs="i",
cex.axis=2,type="p",cex=psize,pch=19,xaxt = "t")
#axis(1, at=xvec, labels=lxvec,cex.axis=2)
} else {
points(x,peff[count],col=color,type="p",cex=psize,pch=19)
}

}
lines(xvec,peff[(count-2):count],col=color,type="l",lwd=5)
}
}

legend(3.36,ymax,cex=.75,
lwd=3,c("GR","BFC","KR","KF","AR"),
col=colors)

dev.off()


#to plot a profile of increment
library(ncdf4)

ncname <- './indata_incr/diff_t1_c24.nc'
#ncname <- './indata_incr/diff_t1_c12.nc'
nc <- nc_open(ncname, readunlim=FALSE )
dust_incr <- ncvar_get(varid = 'dust1',nc)
nx <- nc$dim[["xaxis_1"]]$len
ny <- nc$dim[["yaxis_1"]]$len
nz <- nc$dim[["zaxis_1"]]$len
nc_close(nc)

nx1 <- nx/2+1 
nx2 <- nx

ny1 <- ny/2+1
ny2 <- ny

picratio <- 0.95
width <- 700
height <- width * picratio

cols <- rainbow(20)

zlims <- c(0,3)
picname <- paste("./pics/dust_incr.png",sep='')
png(picname,width = width, height = height,bg="white")
filled.contour(nx1:nx2,ny1:ny2,dust_incr[nx1:nx2,ny1:ny2,nz],
nlevels=15, zlim=zlims,col=cols,
xaxs="i",yaxs="i")
dev.off()


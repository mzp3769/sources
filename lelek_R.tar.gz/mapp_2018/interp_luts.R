#to fit curves or surfaces (SS) for ESRL GOCART species 
#using NASA's tables 

library(ncdf4)
library(fields)

dust_radii_esrl <- c(0.55,1.4,2.4,4.5,8.0)*1.e-6
seasalt_radii_esrl <- c(0.3,1.0,3.25,7.5)*1.e-6
p25_radius <- (0.78*(dust_radii_esrl[1])^3+
	       0.22*(dust_radii_esrl[2])^3)^(1./3.)

missval <- 1.e+30

indir <- "./luts_in"
outdir <- "./luts_out"

species <- c("BC","DU","OC","SS","SU")

luts_in <- paste(indir,"/optics_",species,".nc",sep="")
luts_out <- paste(outdir,"/optics_",species,"_esrl.nc",sep="")

ispec <- 0

for (spec in species) { 

    ispec <- ispec+1    

    lutin=luts_in[ispec]
    nc <- nc_open(lutin,readunlim=FALSE, write=FALSE )
    nradius <- nc$dim[["radius"]]$len
    nlambda <- nc$dim[["lambda"]]$len
    nrh <- nc$dim[["rh"]]$len
    rh <- ncvar_get(varid="rh",nc)
    lambda <- ncvar_get(varid="lambda",nc)
    radius <- ncvar_get(varid="radius",nc)
    rlow <- ncvar_get(varid="rLow",nc)
    rup <- ncvar_get(varid="rUp",nc)
    reff <- ncvar_get(varid="rEff",nc)
    rmass <- ncvar_get(varid="rMass",nc)
    qext <- ncvar_get(varid="qext",nc)
    nc_close(nc)	

    if (spec == "BC" || spec == "OC") {
       radiusout <- radius
       nradiusout <- length(radiusout)
       qextout <- qext

    }  else if (spec == "SU") {    
       radiusout <- radius[1]
       nradiusout <- length(radiusout)
       qextout <- qext[,,1]

    }  else if (spec == "DU") {
       radiusout <- dust_radii_esrl        
       nradiusout <- length(radiusout)

       x <- log(lambda)
       y <- radius

       grid.l <- list(abcissa=x,ordinate=y)
       xg <- make.surface.grid(grid.l)

       qextout <- array(NA,dim=c(nlambda,nrh,nradiusout))       

       z <- qext[,1,]

       obj <- Tps( xg, c(z), lambda=0)

       xpred <- array(NA,dim=c(nlambda*nradiusout,2))

       for (i in 1:nradiusout) {
           bracket <- ((i-1)*nlambda+1):(i*nlambda)
	   xpred[bracket,1] <- x
	   xpred[bracket,2] <- radiusout[i]
       }

       newvals <- predict(obj,xpred)

       for (i in 1:nradiusout) {
       	   bracket <- ((i-1)*nlambda+1):(i*nlambda)
       	   qextout[,,i] <- newvals[bracket]
       }


       radiusoutp25 <- p25_radius
       xpred <- array(NA,dim=c(nlambda,2))
       qextoutp25 <- array(NA,dim=c(nlambda,nrh,1))       
       bracket <- 1:nlambda
       xpred[bracket,1] <- x
       xpred[bracket,2] <- radiusoutp25

       newvals <- predict(obj,xpred)
       qextoutp25[,,1] <- newvals[bracket]

    }  else if (spec == "SS") {
       radiusout <- seasalt_radii_esrl
       nradiusout <- length(radiusout)

       x <- log(lambda)
       y <- radius

       grid.l <- list(abcissa=x,ordinate=y)
       xg <- make.surface.grid(grid.l)

       qextout <- array(NA,dim=c(nlambda,nrh,nradiusout))       

       for (irh in 1:nrh) {
       	   z <- qext[,irh,]
	   obj <- Tps( xg, c(z), lambda=0)

           xpred <- array(NA,dim=c(nlambda*nradiusout,2))

	   for (i in 1:nradiusout) {
               bracket <- ((i-1)*nlambda+1):(i*nlambda)
	       xpred[bracket,1] <- x
	       xpred[bracket,2] <- radiusout[i]
       	   }

       	   newvals <- predict(obj,xpred)

	   for (i in 1:nradiusout) {
       	       bracket <- ((i-1)*nlambda+1):(i*nlambda)
       	       qextout[,irh,i] <- newvals[bracket]
       	   }
       }

    }  else {
       stop("undefined species")
    }

    radiusdim <- ncdim_def('radius_dim','m',radiusout)
    radius_out <- ncvar_def('radius', 'm', list(radiusdim), missval,
    prec='double')

    rhdim <- ncdim_def('rh_dim','fraction',rh)    
    rh_out <- ncvar_def('rh', 'fraction', list(rhdim), 
    missval,'relative humidity',prec='double')

    lambdadim <- ncdim_def('nlambda','m',lambda)    
    lambda_out <- ncvar_def('lambda', 'm', list(lambdadim), 
    missval,'wavelength',prec='double')

    qext_out <- ncvar_def('qext', 'dimensionless', 
    list(lambdadim,rhdim,radiusdim), 
    missval,'extinction efficiency',prec='double')

    lutout=luts_out[ispec]

    mc <- nc_create(lutout,list(radius_out,rh_out,lambda_out,qext_out))
    ncvar_put(mc,radius_out,radiusout,start=1,count=nradiusout)
    ncvar_put(mc,rh_out,rh,start=1,count=nrh)
    ncvar_put(mc,lambda_out,lambda,start=1,count=nlambda)
    ncvar_put(mc,qext_out,qextout,start=c(1,1,1),
    count=c(nlambda,nrh,nradiusout))
    nc_close(mc)

}

radiusdim <- ncdim_def('radius_dim','m',radiusoutp25)
radius_out <- ncvar_def('radius', 'm', list(radiusdim), missval,
prec='double')

rhdim <- ncdim_def('rh_dim','fraction',rh)
rh_out <- ncvar_def('rh', 'fraction', list(rhdim), 
missval,'relative humidity',prec='double')

lambdadim <- ncdim_def('nlambda','m',lambda)
lambda_out <- ncvar_def('lambda', 'm', list(lambdadim), 
missval,'wavelength',prec='double')

qext_out <- ncvar_def('qext', 'dimensionless', 
list(lambdadim,rhdim,radiusdim), 
missval,'extinction efficiency',prec='double')

luts_out <- paste(outdir,"/optics_",species,"_esrl.nc",sep="")
lutout=paste(outdir,"/optics_P25_esrl.nc",sep="")

mc <- nc_create(lutout,list(radius_out,rh_out,lambda_out,qext_out))
ncvar_put(mc,radius_out,radiusoutp25,start=1,count=1)
ncvar_put(mc,rh_out,rh,start=1,count=nrh)
ncvar_put(mc,lambda_out,lambda,start=1,count=nlambda)
ncvar_put(mc,qext_out,qextoutp25,start=c(1,1,1),
count=c(nlambda,nrh,1))
nc_close(mc)


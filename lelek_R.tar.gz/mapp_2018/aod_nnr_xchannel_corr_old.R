#to plot cross-channel correlations
library(ncdf4)
library("corrplot")

indir <- "./indata_hl/hl_BCKG_012_nothin_logaod_eps_0.01"
corename <- "nnr_fv3.MYD04.land.covar_hl_final.201508"

aod_file <- paste(indir,"/",corename,".nc",sep='')

nc <- nc_open(aod_file,readunlim=FALSE, write=FALSE )

chname <- "channels_ocean"
nchan <- nc$dim[[chname]]$len
if (is.null(nchan)) {
   chname <- "channels_land"
   nchan <- nc$dim[[chname]]$len
   if (is.null(nchan)) {
      chname <- "channels_deep"
      nchan <- nc$dim[["chname"]]$len
   }
}

if (is.null(nchan)) {
  print("nchan not found - stopping")
  stop("nchan")
}

covar <- ncvar_get(varid="covar",nc)
gaussian <- ncvar_get(varid="Gaussian",nc)
soar <- ncvar_get(varid="soar",nc)
covar_index <- ncvar_get(varid="covar_index",nc)
channels <- ncvar_get(varid=chname,nc)
counts_in_bins <- ncvar_get(varid="counts_in_bins",nc)
nc_close(nc)

obscovar <- (covar[,1,1] - gaussian[,1,1])

covar_matrix <- array(NA,c(nchan,nchan))
corr_matrix <- array(NA,c(nchan,nchan))

ncovars <- nchan*(nchan+1)/2

for (k in (1:ncovars)) {
    i <- covar_index[k,1]%/%100
    j <- covar_index[k,1]%%100
    covar_matrix[i,j] <- obscovar[k]
    covar_matrix[j,i] <-  covar_matrix[i,j] 
    corr_matrix[i,j] <- covar_matrix[i,j]/covar_matrix[i,i]
    corr_matrix[j,i] <- corr_matrix[i,j] 
}

covar.mat <- covar_matrix*100
colnames(covar.mat) <- paste(as.character(channels),"nm")
rownames(covar.mat) <- colnames(covar.mat)

corr.mat <- corr_matrix
colnames(corr.mat) <- paste(as.character(channels),"nm")
rownames(corr.mat) <- colnames(corr.mat)

xmin <- as.integer(min(covar.mat)*100)/100
xmax <- as.integer(max(covar.mat)*100+1)/100
xlabs <- sprintf("%01.3f",seq(xmin,xmax,len=nchan))

cols <- rainbow(nchan*20)

picname <- paste("./pngs/",corename,".covar.png",sep='')
png(picname,width = 750, height = 750,bg="white")
corrplot(covar.mat,"color",is.corr=FALSE,col=cols,cl.pos="r",
mar=c(0, 0, 0, 6.5),tl.col="black",tl.cex=1.25,tl.offset=1,
cl.lim=c(xmin,xmax),cl.ratio=0.25,cl.length=nchan+1,cl.cex=1.25)
mtext("Covariance x 100",side=3,line=-2,cex=1.75,adj=0.55)
dev.off()

xmin <- as.integer(min(corr.mat)*100)/100
xmax <- 1.

picname <- paste("./pngs/",corename,".corr.png",sep='')
png(picname,width = 750, height = 750,bg="white")
corrplot(corr.mat,"color",is.corr=FALSE,col=cols,cl.pos="r",
mar=c(0, 0, 0, 6.5),tl.col="black",tl.cex=1.25,tl.offset=1,
cl.lim=c(xmin,xmax),cl.ratio=0.25,cl.length=nchan+1,cl.cex=1.25)
mtext("Correlation",side=3,line=-2,cex=1.75,adj=0.55)
dev.off()



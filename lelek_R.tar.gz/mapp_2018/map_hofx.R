library(ncdf4)
library(fields)

indir <- "./indata_hofx"

infile <- "aod_nnr_terra_hofx_3dvar_2016060118.nc.ges"
varname_hofx <- "aerosol_optical_depth_4@Hofx"
infile <- "aod_nnr_terra_hofx_nomodel_2016060118.nc4.ges"
varname_hofx <- "aerosol_optical_depth_4@hofx"

aod_fname <- paste(indir,"/",infile,sep='')

nc <- nc_open(aod_fname,readunlim=FALSE, write=FALSE )
nlocs <- nc$dim[["nlocs"]]$len
hofx <-  ncvar_get(varid=varname_hofx,nc)
lat <- ncvar_get(varid="latitude@MetaData",nc)
lon <- ncvar_get(varid="longitude@MetaData",nc)
nc_close(nc)

picname <- paste("./pngs/hofx.png",sep='')
png(picname,width = 900, height = 500,bg="white")
quilt.plot(lon,lat,hofx,ncol=180,nrow=360,zlim=c(0,1.))
world(add=TRUE,lwd=1,col="black")
#drape.plot(x[1:ndata],y[1:ndata],correl[1:ndata],ncol=100,nrow=100)
dev.off()

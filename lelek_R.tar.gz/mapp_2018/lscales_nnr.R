#to plot lengthscales

library(ncdf4)

obstype <- "ocean"
obstype <- "land"
obstype <- "deep"

indir <- "./indata_hl/hl_DA_ENKF_nothin_logaod_eps_0.01"
fname <- paste("nnr_fv3.",obstype,".covar_hl_final.201508.nc",sep='')
aod_file <- paste(indir,"/",fname,sep='')

chname <- paste("channels_",obstype,sep='')

nc <- nc_open(aod_file,readunlim=FALSE, write=FALSE )
nchan <- nc$dim[[chname]]$len
ncovar <- nc$dim[["ncovar"]]$len
nbins <- nc$dim[["nbins"]]$len
covar <- ncvar_get(varid="covar",nc)
tension <- ncvar_get(varid="tension",nc)
covar_index <- ncvar_get(varid="covar_index",nc)
channels <- ncvar_get(varid=chname,nc)
counts_in_bins <- ncvar_get(varid="counts_in_bins",nc)
distance_bins <- ncvar_get(varid="distance_bins",nc)
nc_close(nc)

mycolors <- rainbow(ncovar)

ymin <- min(covar[1,])
ymax <- max(covar[1,])

picname <- paste(indir,"/lscale_",obstype,"_ch1.png",sep='')
png(picname,width = 650, height = 450,bg="white")
plot(distance_bins,covar[1,],xaxs="i",yaxs="i",col=mycolors[1],
type="l",lwd=2,
xlab="distance [km]",ylab="OmG covariance",ylim=c(ymin,ymax))
lines(distance_bins,tension[1,],lwd=2,col=mycolors[1],lty=3)
dev.off()

ymin <- 0
ymax <- max(covar)

picname <- paste(indir,"/lscale_",obstype,".png",sep='')
png(picname,width = 650, height = 450,bg="white")
plot(distance_bins,covar[1,],xaxs="i",yaxs="i",col=mycolors[1],
type="l",lwd=2,
xlab="distance [km]",ylab="OmG covariance",ylim=c(ymin,ymax))
lines(distance_bins,tension[1,],lwd=2,col=mycolors[1],lty=3)

for (i in 2:ncovar) {	
    lines(distance_bins,covar[i,],lwd=2,col=mycolors[i],lty=1)
    lines(distance_bins,tension[i,],lwd=2,col=mycolors[i],lty=3)       
}

dev.off()
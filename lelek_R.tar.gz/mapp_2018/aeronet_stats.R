#to plot AOD biases/rsq
#01-09 2016

nobs <- c(6216,7703,10361,12185,13652,13328,14133,14783,12138)

noda_bias <- c(-0.0627270284080875,-0.0571482170522034,
               -0.0596533307726152,-0.0303987037297224,
               -0.0321734669931637,-0.0332998606301022,
               -0.0229118753515118,-0.017773878159368,
               -0.0365307330794023)

noda_rsq <- c(0.625046627306272,0.543188711412012,
              0.557668518899398,0.499604714887553,
              0.522109296672555,0.519853891911911,
              0.466150877081881,0.393257254423931,
              0.493605133236205)

anal_bias <- c(-0.0159470230086102,-0.00988446964853176,
               -0.00239705370977124,0.00194371464388246,
               0.00222706689202635,-0.00307139228321352,
               0.0025916663606727,0.000260201677995518,
               0.000913385725442813)

anal_rsq <- c(0.768294351364281,0.780153890913152,
              0.729408550566397,0.639152422871158,
              0.649392904102116,0.645118792037194,
              0.648743623800341,0.569778743347872,
              0.636327897120646)

colors <- c("blue","red")
leglabels <- c("Free Forecast","Reanalysis")

pngname <- "./pics/aeronet_ts_bias.png"

picwidth <- 700
picratio <- 0.55

ymin <- min(noda_bias,anal_bias)-0.01
ymax <- max(noda_bias,anal_bias)+0.01
ymin <- -0.08
ymax <- 0.01
xmin <- 1
xmax <- 9

png(pngname,width=picwidth, height=picwidth*picratio,bg="white")
plot(1:9,noda_bias,type="l",lwd=5,cex=.5,cex.axis=1.2,cex.lab=1.5,
xaxs="i",yaxs="i",axes=FALSE,
ylim=c(ymin,ymax),col=colors[1],xlab="Month",ylab="AOD bias")
lines(1:9,anal_bias,type="l",lwd=5,col=colors[2])
xvec <- seq(xmin,xmax,by=1)
xlabs <- c("J","F","M","A","M","J","J","A","S")
axis(1, at=xvec,labels=xlabs,cex.axis=1.0,pos=ymin)
yvec=seq(ymin,ymax,by=0.01)
axis(2, at=yvec, cex.axis=1.0,pos=1)
legend(x=xmax,y=ymin,xjust=1,yjust=0,
col=colors,legend=leglabels,lwd=5)
dev.off()

pngname <- "./pics/aeronet_ts_rsq.png"

picwidth <- 700
picratio <- 0.55

ymin <- min(noda_rsq,anal_rsq)-0.01
ymax <- max(noda_rsq,anal_rsq)+0.01
ymin <- 0.
ymax <- 0.8

png(pngname,width=picwidth, height=picwidth*picratio,bg="white")
plot(1:9,noda_rsq,type="l",lwd=5,cex=.5,cex.axis=1.2,cex.lab=1.5,
xaxs="i",yaxs="i",axes=FALSE,
ylim=c(ymin,ymax),col=colors[1],xlab="Month",ylab="AOD r-sq")
lines(1:9,anal_rsq,type="l",lwd=5,col=colors[2])
axis(1, at=xvec,labels=xlabs,cex.axis=1.0,pos=ymin)
yvec=seq(ymin,ymax,by=0.1)
axis(2, at=yvec, cex.axis=1.0,pos=1)
legend(x=xmax,y=ymin,xjust=1,yjust=0,
col=colors,legend=leglabels,lwd=5)
dev.off()


pngname <- "./pics/aeronet_nobs.png"

picwidth <- 700
picratio <- 0.55

ymin <- min(nobs)
ymax <- max(nobs)
ymin <- 0
ymax <- 15000

png(pngname,width=picwidth, height=picwidth*picratio,bg="white")
plot(1:9,nobs,type="l",lwd=5,cex=.5,cex.axis=1.2,cex.lab=1.5,
xaxs="i",yaxs="i",axes=FALSE,
ylim=c(ymin,ymax),col="black",xlab="Month",ylab="AOD nobs")
axis(1, at=xvec,labels=xlabs,cex.axis=1.0,pos=ymin)
yvec=seq(ymin,ymax,by=5000)
axis(2, at=yvec, cex.axis=1.0,pos=1)
dev.off()





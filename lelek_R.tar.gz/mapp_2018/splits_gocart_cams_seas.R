#new code using ecmwf since splits from Zender(2003) do not work properly
#based on ECMWF gems_seas_mie_ecmwf_work.f

#--sigma_g : geometric standard deviation
#--r_0     : geometric number mean radius (um)/modal radius
#--Ntot    : total concentration in m-3


erf <- function(x) {
    2 * pnorm(x*sqrt(2)) - 1
}

#seas

n_seas_bins_gocart <- 5
n_seas_bins_cams <- 3

#gocart radii are dry
#cams radii are at 80% rh - need to be multiplied by rh_dry_factor=0.503
radii_seas_bins_gocart <- c(0.03,0.1,0.5,1.5,5.0,10.0)*1.e-6
rh_dry_factor <- 0.503
radii_seas_bins_cams <- c(0.03,0.5,5.,20.)*rh_dry_factor*1.e-6

#seas has two distributions that weighted 70. to 3. - only for numer calculation
#all assumed same for gocart
ndis <- 2
ntot <- c(70.,3.)
stdevs_seas_distrib_cams <- c(1.9,2.0)
stdevs_seas_distrib_gocart <- stdevs_seas_distrib_cams
sigma_g <- stdevs_seas_distrib_cams
r_0 <- c(0.19921, 1.992)*rh_dry_factor*1.e-6
pi <- 4.*atan(1.)

nbin <- 2000

#mm - mass/volume median radius
mm_radii_seas_bins_gocart <- array(NA,c(n_seas_bins_gocart))
masse_tot <- array(NA,n_seas_bins_gocart)

#determine mm_radii_seas_bins_gocart and total mass in each gocart bin

for (sbin in 1:n_seas_bins_gocart) {
    rmin <- radii_seas_bins_gocart[sbin]
    rmax <- radii_seas_bins_gocart[sbin+1]

    masse <- 0

    for (bin in 0:nbin) {
        r <- exp(log(rmin)+bin/nbin*(log(rmax)-log(rmin)))
        deltar <- 1./nbin*(log(rmax)-log(rmin))
	number=0.
	for (dis in 1:ndis) {
            number <- number+ntot[dis]/sqrt(2.*pi)/log(sigma_g[dis])*
               exp(-0.5*(log(r/r_0[dis])/log(sigma_g[dis]))**2)
	}
        masse <- masse+4./3.*pi*r**3*number*deltar # (*rho)
    }

    masse_tot[sbin] <- masse
    masse_half <- masse/2

    masse <- 0

    for (bin in 0:nbin) {
        r <- exp(log(rmin)+bin/nbin*(log(rmax)-log(rmin)))
        deltar <- 1./nbin*(log(rmax)-log(rmin))

        number=0.
        for (dis in 1:ndis) {
            number <- number+ntot[dis]/sqrt(2.*pi)/log(sigma_g[dis])*
               exp(-0.5*(log(r/r_0[dis])/log(sigma_g[dis]))**2)
        }
        masse <- masse+4./3.*pi*r**3*number*deltar # (*rho)

        if (masse > masse_half) {
           mm_radii_seas_bins_gocart[sbin] <- r
           break
        }

    }

}

#gocart bins are completely contained within CAMS

split_gocart2cams_seas <- array(0.,c(n_seas_bins_gocart,n_seas_bins_cams))

for (sbing in  1:n_seas_bins_gocart) {
    rming <- radii_seas_bins_gocart[sbing]
    rmaxg <- radii_seas_bins_gocart[sbing+1]

    for (sbinc in  1:n_seas_bins_cams) {

        rminc <- radii_seas_bins_cams[sbinc]
        rmaxc <- radii_seas_bins_cams[sbinc+1]

	masse <- 0

        for (bin in 0:nbin) {
	    r <- exp(log(rming)+bin/nbin*(log(rmaxg)-log(rming)))
            deltar <- 1./nbin*(log(rmaxg)-log(rming))
            number=0.
            for (dis in 1:ndis) {
            	number <- number+ntot[dis]/sqrt(2.*pi)/log(sigma_g[dis])*
               	exp(-0.5*(log(r/r_0[dis])/log(sigma_g[dis]))**2)
            }

	    if (r >= rminc) {
	       if (r < rmaxc) {
                  masse <- masse+4./3.*pi*r**3*number*deltar # (*rho)
	       } else {
	       	  split_gocart2cams_seas[sbing,sbinc] <- masse/
		  				      	 masse_tot[sbing]
		  break
	       }
            }
        }
	split_gocart2cams_seas[sbing,sbinc] <- masse/masse_tot[sbing]
    }
    print(c("sum: ",sum(split_gocart2cams_seas[sbing,])))
}
print(split_gocart2cams_seas)




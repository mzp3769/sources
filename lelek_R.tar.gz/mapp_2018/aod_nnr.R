#to plot obs and model interpolated values from aodnnr_multichannel_correlation_hl.f90

args <- commandArgs(TRUE)
corename <- args[1]

print(corename)

library(ncdf4)
library(fields)

indir <- "./indata_4hl"
#corename <- "nnr_fv3.MOD04.ocean.2015080900"

aod_fname <- paste(indir,"/",corename,".nc",sep='')

aod_files <- array(c(aod_fname),dim=1)

aod_file <- aod_files[1]

nc <- nc_open(aod_file,readunlim=FALSE, write=FALSE )
nchan <- nc$dim[["nchannels_ocean"]]$len
nobs <- nc$dim[["nobs"]]$len
nc_close(nc)

varname_obs <- "AOD_obs"
varname_model <- "AOD_model"

df <- data.frame()

i <- 0

for ( aod_file in aod_files ) {
    nc <- nc_open(aod_file,readunlim=FALSE, write=FALSE )
    aod_obs <- ncvar_get(varid=varname_obs,nc)
    aod_model <- ncvar_get(varid=varname_model,nc)
    lat <-  ncvar_get(varid='lat',nc)
    lon <-  ncvar_get(varid='lon',nc)
    nc_close(nc)
}

lon <- c(lon[1:nobs],-180,180)
lat <- c(lat[1:nobs],-90,90)
aod_obs <- c(aod_obs[3,1:nobs],NA,NA)

picname <- paste("./pngs/",corename,".obs.png",sep='')
png(picname,width = 900, height = 500,bg="white")
quilt.plot(lon,lat,aod_obs,ncol=180,nrow=360)
world(add=TRUE,lwd=1,col="black")
#drape.plot(x[1:ndata],y[1:ndata],correl[1:ndata],ncol=100,nrow=100)
dev.off()

aod_model <- c(aod_model[3,1:nobs],NA,NA)	

picname <- paste("./pngs/",corename,".model.png",sep='')
png(picname,width = 900, height = 500,bg="white")
quilt.plot(lon,lat,aod_model,ncol=180,nrow=360)
world(add=TRUE,lwd=1,col="black")
#drape.plot(x[1:ndata],y[1:ndata],correl[1:ndata],ncol=100,nrow=100)
dev.off()

#to read aeronet and hofx and compare AE

library("ncdf4")

speed_light <- 2.99792458E8 * 1.e9

obsdir <- "/work/noaa/gsd-fv3-dev/pagowski/DATA/OBS/aeronet"

obsfile <- paste(obsdir,"/","aeronet_aod.2016010100_v2.nc",sep="")

nc <- nc_open(obsfile,readunlim=FALSE, write=FALSE )
nlocs <- nc$dim[["nlocs"]]$len
nchans <- nc$dim[["nchans"]]$len
aods <- ncvar_get(varid="ObsValue/aerosol_optical_depth",nc)
preqc <- ncvar_get(varid="PreQC/aerosol_optical_depth",nc)
freqs <- ncvar_get(varid="VarMetaData/frequency",nc)
wavelenghts <- speed_light/freqs


#to fit autoregressive funcs to correlations

library(ncdf4)


indir <- "indata_hl/hl_BCKG_012_nothin_logaod_eps_0.01"
infile <- "nnr_fv3.deep.covar_hl_final.201508.nc"

ncfile <- paste(indir,"/",infile,sep="")

nc <- nc_open(ncfile,readunlim=FALSE, write=FALSE )
ncovar <- nc$dim[["ncovar"]]$len
nbins <- nc$dim[["nbins"]]$len
distance <- ncvar_get(varid="distance_bins",nc)
covar <- ncvar_get(varid="covar",nc)
nc_close(nc)

b <- 0.27
form <- yy ~ exp(-xx^b/(l^b))

lscale <- array(0,ncovar)
values <- array(0,c(ncovar,nbins))

ncovar <- 1

xx <- 2:nbins
dx <- distance[2]-distance[1]

for (k in 1:ncovar) {
    yy <- covar[k,2:nbins]
    data <- coef(nls(form, start=list(l = 3.),
    na.action=na.omit))
    lscale[k] <- data[1]*dx
    values[k,(2:nbins)]=exp(-(distance[2:nbins]/lscale[k])^b)
}



ylim <- c(0,max(covar,values,na.rm=TRUE))
xlim <- c(min(distance),max(distance))

k <-1 
plot(distance,covar[k,],type="l",col="black",
xlim=xlim,ylim=ylim,lwd=3)
lines(distance[2:nbins],values[k,(2:nbins)],col="red",lwd=3)

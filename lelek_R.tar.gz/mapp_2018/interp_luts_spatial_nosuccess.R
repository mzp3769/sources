#to fit curves or surfaces (SS) for ESRL GOCART species 
#using NASA's tables 

library(ncdf4)
library(spatial)
library(fields)

indir <- "./luts_in"
outdir <- "./luts_out"

species <- c("BC","DU","OC","SS","SU")

luts_in <- paste(indir,"/optics_",species,".nc",sep="")
luts_out <- paste(outdir,"/optics_",species,".nc",sep="")

for (lut in luts_in[1]) { 
    nc <- nc_open(lut,readunlim=FALSE, write=FALSE )
    nradius <- nc$dim[["radius"]]$len
    nlambda <- nc$dim[["lambda"]]$len
    nrh <- nc$dim[["rh"]]$len
    rh <- ncvar_get(varid="rh",nc)
    lambda <- ncvar_get(varid="lambda",nc)
    radius <- ncvar_get(varid="radius",nc)
    rlow <- ncvar_get(varid="rLow",nc)
    rup <- ncvar_get(varid="rUp",nc)
    reff <- ncvar_get(varid="rEff",nc)
    rmass <- ncvar_get(varid="rMass",nc)
    qext <- ncvar_get(varid="qext",nc)
    nc_close(nc)	
}
x <- log(lambda)
y <- rh
z <- qext[,,2] 

grid.l <- list(abcissa=x,ordinate=rh)
xg <- make.surface.grid(grid.l)

out.p <- as.surface(xg,z)

persp(out.p)
contour(out.p)
plot.surface(out.p,type="p")


sfc_2 <- surf.ls(2,x,y,z)
sfc_3 <- surf.ls(3,x,y,z)
sfc_4 <- surf.ls(4,x,y,z)
sfc_5 <- surf.ls(5,x,y,z)

interp_sfc_2 <- trmat(sfc_2,-15,-13,0.20,0.40,20)
interp_sfc_3 <- trmat(sfc_3,-15,-13,0.20,0.40,20)
interp_sfc_4 <- trmat(sfc_4,-15,-13,0.20,0.40,20)
interp_sfc_5 <- trmat(sfc_5,-15,-13,0.20,0.40,20)

plot(x ~ y,type="n")
contour(sfc_2)
contour(interp_sfc_2,add=T)

df <- data.frame(x=lambda,y=rh,z=qext[,,2])
surf <- 

picname <- paste("./pngs/",corename,".obs.png",sep='')
png(picname,width = 560, height = 500,bg="white")
quilt.plot(lon[1:nobs],lat[1:nobs],aod_obs[3,1:nobs],ncol=180,nrow=360)
#drape.plot(x[1:ndata],y[1:ndata],correl[1:ndata],ncol=100,nrow=100)
dev.off()

picname <- paste("./pngs/",corename,".model.png",sep='')
png(picname,width = 560, height = 500,bg="white")
quilt.plot(lon[1:nobs],lat[1:nobs],aod_model[3,1:nobs],ncol=180,nrow=360)
#drape.plot(x[1:ndata],y[1:ndata],correl[1:ndata],ncol=100,nrow=100)
dev.off()

#!/bin/ksh

test=DA_ENKF

satellite='MYD04' #aqua
#satellite='MOD04' # terra

obstype=deep
obstype=land
obstype=ocean

start_date=2015080500
end_date=2015081712

cycle_frequency=6

prefix_in=nnr_fv3.${satellite}.${obstype}.covar_hl

ndate=~/bin/ndate

ident=$start_date

while [[ $ident -le $end_date ]]
do

    year=`echo "${ident}" | cut -c1-4`
    month=`echo "${ident}" | cut -c5-6`
    day=`echo "${ident}" | cut -c7-8`
    hr=`echo "${ident}" | cut -c9-10`

    incore=${prefix_in}.${ident}

    Rscript aod_nnr_bincounts.R $incore

    ident=`$ndate $cycle_frequency $ident`

    echo $ident

done

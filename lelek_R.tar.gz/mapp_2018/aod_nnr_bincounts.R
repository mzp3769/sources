#to plot cross-channel correlations
args <- commandArgs(TRUE)
corename <- args[1]

print(corename)

library(ncdf4)

indir <- "./indata_hl"

aod_file <- paste(indir,"/",corename,".nc",sep='')

nc <- nc_open(aod_file,readunlim=FALSE, write=FALSE )

chname <- "channels_ocean"
nchan <- nc$dim[[chname]]$len

if (is.null(nchan)) {
   chname <- "channels_land"
   nchan <- nc$dim[[chname]]$len
   if (is.null(nchan)) {
      chname <- "channels_deep"
      nchan <- nc$dim[["chname"]]$len
   }
}

if (is.null(nchan)) {
  print("nchan not found - stopping")
  stop("nchan")
}

nbins <- nc$dim[["nbins"]]$len

covar <- ncvar_get(varid="covar",nc)
gaussian <- ncvar_get(varid="Gaussian",nc)
soar <- ncvar_get(varid="soar",nc)
covar_index <- ncvar_get(varid="covar_index",nc)
channels <- ncvar_get(varid=chname,nc)
counts_in_bins <- ncvar_get(varid="counts_in_bins",nc)
distance_bins <- ncvar_get(varid="distance_bins",nc)
nc_close(nc)

ncovars <- nchan*(nchan+1)/2

xmin <- min(distance_bins)
xmax <- max(distance_bins)
ymin <- 0
ymax <- max(covar[1,],gaussian[1,],soar[1,])

picname <- paste("./pngs/",corename,".covarbins.png",sep='')
png(picname,width = 750, height = 400,bg="white")
plot(distance_bins,covar[1,],col="black",xlim=c(xmin,xmax),ylim=c(ymin,ymax),type="l",
xaxs="i",yaxs="i",lwd=1)
points(distance_bins,covar[1,],type="p",col="black",pch=19)
lines(distance_bins,gaussian[1,],col="red",lwd=1)
points(distance_bins,gaussian[1,],type="p",col="red",pch=19)
lines(distance_bins,soar[1,],col="blue",lwd=1)
points(distance_bins,soar[1,],type="p",col="blue",pch=19)
dev.off()

xmin <- min(distance_bins)
xmax <- max(distance_bins)
ymin <- 0
ymax <- max(counts_in_bins)

picname <- paste("./pngs/",corename,".bincounts.png",sep='')
png(picname,width = 750, height = 400,bg="white")
plot(distance_bins,counts_in_bins,col="black",xlim=c(xmin,xmax),ylim=c(ymin,ymax),type="l",
xaxs="i",yaxs="i")
points(distance_bins,counts_in_bins,type="p",col="red",pch=19)
dev.off()






#to fit curves or surfaces (SS) for ESRL GOCART species 
#using NASA's tables 

library(ncdf4)
library(fields)

dust_radii_esrl <- c(0.55,1.4,2.4,4.5,8.0)*1.e-6
seasalt_radii_esrl <- c(0.3,1.0,3.25,7.5)*1.e-6

missval <- 1.e+30

indir <- "./luts_in"
outdir <- "./luts_out"

species <- c("BC","DU","OC","SS","SU")

luts_in <- paste(indir,"/optics_",species,".nc",sep="")
luts_out <- paste(outdir,"/optics_",species,"_esrl.nc",sep="")

i <- 0

for (spec in species) { 

    i <- i+1    

    lutin=luts_in[i]
    nc <- nc_open(lutin,readunlim=FALSE, write=FALSE )
    nradius <- nc$dim[["radius"]]$len
    nlambda <- nc$dim[["lambda"]]$len
    nrh <- nc$dim[["rh"]]$len
    rh <- ncvar_get(varid="rh",nc)
    lambda <- ncvar_get(varid="lambda",nc)
    radius <- ncvar_get(varid="radius",nc)
    rlow <- ncvar_get(varid="rLow",nc)
    rup <- ncvar_get(varid="rUp",nc)
    reff <- ncvar_get(varid="rEff",nc)
    rmass <- ncvar_get(varid="rMass",nc)
    qext <- ncvar_get(varid="qext",nc)
    nc_close(nc)	

    if (spec == "BC" || spec == "OC") {
       radiusout <- radius
       qextout <- qext
    }  else if (spec == "SU") {    
       radiusout <- radius[1]
       qextout <- qext[,,1]
    }  else if (spec == "DU") {
       radiusout <- dust_radii_esrl        

       x <- log(lambda)
       y <- rh
       z <- qext[,,2]

       grid.l <- list(abcissa=x,ordinate=y)
       xg <- make.surface.grid(grid.l)

       obj <- Tps( xg, c(z), lambda=0)

       grid_new.l <- list(abcissa=c(-10.5),ordinate=y)
       xg_new <- make.surface.grid(grid_new.l)

       newvals <- predict(obj,xpred)

       qextout <- qext[,,1:5]

    }  else if (spec == "SS") {
       radiusout <- seasalt_radii_esrl
       qextout <- qext[,,1:4]
    }  else {
       stop("undefined species")
    }

    nradiusout <- length(radiusout)
    radiusdim <- ncdim_def('nradius','m',1:nradiusout)
    radius_out <- ncvar_def('radius', 'm', list(radiusdim), missval)

    rhdim <- ncdim_def('nrh','fraction',1:nrh)    
    rh_out <- ncvar_def('rh', 'fraction', list(rhdim), 
    missval,'relative humidity')

    lambdadim <- ncdim_def('nlambda','m',1:nlambda)    
    lambda_out <- ncvar_def('lambda', 'm', list(lambdadim), 
    missval,'wavelength')

    qext_out <- ncvar_def('qext', 'dimensionless', 
    list(lambdadim,rhdim,radiusdim), 
    missval,'extinction efficiency')

    lutout=luts_out[i]
    mc <- nc_create(lutout,list(radius_out,rh_out,lambda_out,qext_out))
    ncvar_put(mc,radius_out,radiusout,start=1,count=nradiusout)
    ncvar_put(mc,rh_out,rh,start=1,count=nrh)
    ncvar_put(mc,lambda_out,lambda,start=1,count=nlambda)
    ncvar_put(mc,qext_out,qextout,start=c(1,1,1),
    count=c(nlambda,nrh,nradiusout))
    nc_close(mc)

}

stop("abc")

#x <- lambda #log is more linear
x <- log(lambda)
y <- rh
z <- qext[,,2]

grid.l <- list(abcissa=x,ordinate=y)
xg <- make.surface.grid(grid.l)

obj <- Tps( xg, c(z), lambda=0)

out.p <- as.surface(xg,z)
#plot.surface(out.p,type="p")
#persp(out.p)
#contour(out.p)
#plot.surface(out.p,type="C")



grid_new.l <- list(abcissa=c(-10.5),ordinate=y)
xg_new <- make.surface.grid(grid_new.l)

newvals <- predict(obj,xpred)

plot.surface(newvals,type="p")

picname <- paste("./pngs/",corename,".obs.png",sep='')
png(picname,width = 560, height = 500,bg="white")
quilt.plot(lon[1:nobs],lat[1:nobs],aod_obs[3,1:nobs],ncol=180,nrow=360)
#drape.plot(x[1:ndata],y[1:ndata],correl[1:ndata],ncol=100,nrow=100)
dev.off()

picname <- paste("./pngs/",corename,".model.png",sep='')
png(picname,width = 560, height = 500,bg="white")
quilt.plot(lon[1:nobs],lat[1:nobs],aod_model[3,1:nobs],ncol=180,nrow=360)
#drape.plot(x[1:ndata],y[1:ndata],correl[1:ndata],ncol=100,nrow=100)
dev.off()

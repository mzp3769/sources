#to plot AOD comparison between GSI and LUTS
library(ncdf4)

infile <- "./indata_aod_jedi/aod_obs_2018041500_m_new.nc4"

nc <- nc_open(infile,readunlim=FALSE, write=FALSE )
gsi <- ncvar_get(varid="aerosol_optical_depth_4@GsiHofX",nc)
luts <- ncvar_get(varid="aerosol_optical_depth_4@LutsHofx",nc)
nc_close(nc)

pngname <- "./pics/aod_comp.png"

picwidth <- 700
picratio <- 0.75

xmin <- 0
xmax <- length(gsi)

ymin <- 0
ymax <- max(gsi,luts)

png(pngname,width=picwidth, height=picwidth*picratio,bg="white")
plot(gsi,type="l",lwd=3,cex=.5,cex.axis=1.2,cex.lab=1.5,
xaxs="i",yaxs="i",
ylim=c(ymin,ymax),col="blue",xlab="Sample Index",ylab="AOD")
lines(luts,type="l",lwd=3,col="red")

lines(seq(mean(gsi),mean(gsi),length.out=length(gsi)),type="l",
lwd=10,col="blue")

lines(seq(mean(luts),mean(luts),length.out=length(luts)),type="l",
lwd=10,col="red")

legend(x=xmax,y=ymax,xjust=1,yjust=1,
col=c("blue","red"),legend=c("CRTM","NASA"),lwd=5,cex=1.25)

dev.off()

print(mean(luts)/mean(gsi))




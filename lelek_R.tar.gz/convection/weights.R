name <- "weivar"
lims <- c(-.5,.5)	
nlevs=10

#name <- "var"
#lims <- c(0.,10.)
#nlevs=10

#name <- "cov"
#lims <- c(-1.,1.)	
#nlevs=10


#name <- "neqs"
#lims <- c(50.,70.)	
#nlevs=10


#name <- "weights"
#lims <- c(-60.,60.)	
#nlevs=10

#name <- "nweights"
#lims <- c(-1.,1.)	
#nlevs=10


#name <- "rank"
#lims <- c(0.,6.)	
#nlevs=6

fruc <- file("ASCII.weights","ra")
nn <- array(0,c(3))	
nn <- array(scan(fruc,what=1,n=3),c(3))

nx <- nn[1]
ny <- nn[2]
nens <- nn[3]

#x11()
#nensc <- (1+sqrt(1+8*nens))/2
#charij <- array("00",c(nensc))
#for (i in 1:nensc) {
#for (j in i+1:nensc) {
#k <- k+1
#charij[k] <- paste(as.character(i),as.character(j),sep="")
#}}

x <- 1:nx
y <- 1:ny
ruc <- array(0,c(nx,ny,nens))
for (k in 1:nens) {

if (k < 10) chars <- paste("0",as.character(k),sep="")
else
chars <- as.character(k)

fname <- paste(name,".",chars,".png",sep="")
#fname <- paste(name,".",chars,".pdf",sep="")
ruc[,,k] <- array(scan(fruc,what=0.,n=nx*ny),c(nx,ny))
#png(fname,width = 670, height = 500,bg="lightgrey")
onefile <- TRUE
pdf(file=ifelse(onefile,fname))
filled.contour(x,y,ruc[,,k],nlevels=nlevs,zlim=lims,color.palette=rainbow)
dev.off()
}
close(fruc)
#lims <- range(ruc[,,])






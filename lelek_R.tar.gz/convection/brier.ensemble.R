"brier.ensemble" <-
function (obs, pred, baseline = NULL, n.members = 10, ...) 
{ ## Modification of brier if preds are a discrete number of values as
  ## in ensembles. 
  ## Error  pointed out by  Mariusz Pagowski. 
thresholds <- seq(0,1,1/n.members )
if(length(unique(pred)) > (n.members +
                           1)){stop("There are more unique values \n of predictions than warranted \n
by the number of ensemble members")  }

  if (max(pred) > 1 | min(pred) < 0) {
        cat("Predictions outside [0,1] range.  \n Are you certain this is a probability forecast? \n")
    }
    
    if (is.null(baseline)) {
        obar <- mean(obs)
        baseline.tf <- FALSE
    } else {
        obar <- baseline
        baseline.tf <- TRUE
    }
    bs.baseline <- mean((obar - obs)^2)

N.pred <- aggregate(pred, by = list(pred), length) ## number of
                                        # times each prediction used.

N.obs <- aggregate(obs, by = list(pred), sum) ## number of
                                        # times each prediction used.

obar.i <- N.obs$x/N.pred$x  # change int to numerics

y.i  <- as.numeric(as.character(N.obs$Group.1)) 

bs <- mean( (pred - obs)^2)

    n <- length(obs)
    ss <- 1 - bs/bs.baseline
    bs.rel <- sum(N.pred$x *(y.i - obar.i)^2)/n
    bs.res <- (sum(N.pred$x * (obar.i - obar)^2))/n
    bs.uncert <- obar * (1 - obar)
    check <- bs.rel - bs.res + bs.uncert
    prob.y <- N.pred$x/n

    return(list(baseline.tf = baseline.tf, bs = bs, bs.baseline = bs.baseline, 
        ss = ss, bs.reliability = bs.rel, bs.resol = bs.res, 
        bs.uncert = bs.uncert, y.i = y.i, obar.i = obar.i, prob.y = prob.y, 
        obar = obar, check = check))
}

nx <- 301
ny <- 225
nens <- 7
x <- 1:nx
y <- 1:ny
ruc <- array(0,c(nx,ny,nens))

#x11()
fruc <- file("ASCII.ruc","ra")
for (k in 1:(nens)) {
ruc[,,k] <- array(scan(fruc,what=0.,n=nx*ny),c(nx,ny))
if (k < 10) chars <- paste("0",as.character(k),sep="")
else	
chars <- as.character(k)
fname <- paste("ruc.",chars,".png",sep="")
png(fname,width = 670, height = 500,bg="lightgrey")
filled.contour(x,y,ruc[,,k],nlevels=10,zlim=c(0.,20.),color.palette=rainbow)
dev.off()
#filled.contour(x,y,ruc,nlevels=10,color.palette=rainbow)
}
close(fruc)
#for (k in (1:5)){
#ruc[,,k]=.3333333*(ruc[,,3*k-2]+ruc[,,3*k-1]+ruc[,,3*k])
#filled.contour(x,y,ruc[,,k],nlevels=10,zlim=c(0.,20.),color.palette=rainbow)
#}
#x11()




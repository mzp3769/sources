library(ncdf)
sim <- "MYJ_ens_0"
field <- "HFX"
freq <- ""
domain <- "_d_01_"

xlv <- 2.5E6

nc <- open.ncdf( paste("/export/scratch/pagowski/stuff/gapp2005/indata/processed/",field,domain,sim,"_2004-06-01_00:00:00",freq,"_1.nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
close.ncdf(nc)
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ixs <- 49
ixe <- 78
jxs <- 29
jxe <- 63

nx <- ixe-ixs+1
ny <- jxe-jxs+1

ntimes <- v1$varsize[3]
ndays <- ntimes%/%24

hfxdaily <- array(0.,c(nx,ndays))

for (i in 1:ntimes) {for (j in ixs:ixe) {
k <- (i-1)%/%24+1
hfxdaily[j-ixs+1,k] <- mean(data1[j,jxs:jxe,i])+hfxdaily[j-ixs+1,k]}}

rm(data1)

par(font.main=1)
par(font.sub=1)
par(font.lab=1)
par(cex.main=.5)
units <- expression(paste(Wm^{-2},"*","24h"))

if (field == "HFX") {
field <- "SHFX" 
png(paste("hovm_ew_",field,domain,sim,freq,".png",sep=""),
width = 414, height = 600,bg="white")
filled.contour(x=seq(1,nx),y=seq(1,ndays),z=hfxdaily,nlevels=6,
#levels=seq(0,5000,by=500),
#col = c("royalblue","lightblue","lightgreen","green",
#"yellow","orange","tomato","red1","red3","red4"),
levels=c(seq(0,5000,by=500),5500),
col = c("royalblue","lightblue","lightgreen","green",
"yellow","orange","tomato","red1","red3","red4","black"),
key.title = title(main=paste(field,"\n","W/m^2","\n","per day")),
plot.axes={axis(1,at=c(1,10,20,30),font=2);
axis(2,at=c(1,10,20,30),
labels=c("JUN01","JUN10","JUN20","JUN30"),font=2)},
font=2,
xlab="E-W domain size",ylab="Days",
#key.title = title(main=string),
#key.title = title(main=units,par(font=2),par(cex=1)),
#paste(mtext(expression(Wm^{-2}),font=2),"\n",
#      mtext(expression(Wm^{-2}),font=2))),
#mtext(paste(field,"\n",expression(Wm^{-2})),font=2)),
#key.title = title(main=text(expression(Wm^2))),
#key.title = title(main=paste(field, "\n", expression(W/m^2))),
#key.axes=axis(4,font=2))
key.axes=axis(4,font=2,at=seq(0,5000,by=1000)))
dev.off()
} else {
field <- "LHFX" 
hfxdaily <- hfxdaily*xlv 
png(paste("hovm_ew_",field,domain,sim,freq,".png",sep=""),
width = 414, height = 600,bg="white")
filled.contour(x=seq(1,nx),y=seq(1,ndays),z=hfxdaily,nlevels=6,
levels=c(seq(0,5000,by=500),5500),
col = c("royalblue","lightblue","lightgreen","green",
"yellow","orange","tomato","red1","red3","red4","black"),
#levels=c(seq(0,5000,by=500),5500),
#col = c("royalblue","lightblue","lightgreen","green",
#"yellow","orange","tomato","red1","red3","red4","black"),
#col = c("royalblue","lightblue","lightgreen","yellow","orange","red"),
plot.axes={axis(1,at=c(1,10,20,30),font=2);
axis(2,at=c(1,10,20,30),
labels=c("JUN01","JUN10","JUN20","JUN30"),font=2)},
font=2,
xlab="E-W domain size",ylab="Days",
key.title = title(main=paste(field,"\n","W/m^2","\n","per day")),
#key.title = title(main=string),
#key.title = title(main=paste(field, "\n", expression(W/m^2))),
key.axes=axis(4,font=2,at=seq(0,5000,by=1000)))
dev.off()
}



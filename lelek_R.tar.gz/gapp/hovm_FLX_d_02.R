library(ncdf)
domain <- "_d_02"
month="_jun"
year="_2004"
sims <- c("run_11aa","run_11ba","run_11ca",
          "run_12aa","run_12ba","run_12ca",
          "run_13aa","run_13ba","run_13ca",
          "run_14aa","run_14ba","run_14ca")

fields <- c("HFX","QFX")

for (sim in sims) {
for (field in fields) {

print(sim)
print(field)

xlv <- 2.5e6

print("getting data")

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/",field,domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
close.ncdf(nc)
ixs <- 1
ixe <- nx
jxs <- 1
jxe <- ny

ntimes <- v1$varsize[3]
ndays <- (ntimes-1)/24

hfxdaily <- array(0.,c(nx,ndays))

print("processing")
for (i in 2:ntimes) {
k <- (i-2)%/%24+1
for (j in ixs:ixe) {
hfxdaily[j-ixs+1,k] <- mean(data1[j,jxs:jxe,i])+hfxdaily[j-ixs+1,k]}}

print("plotting")

par(font.main=1)
par(font.sub=1)
par(font.lab=1)
par(cex.main=.5)
units <- expression(paste(Wm^{-2},"*","24h"))

if (field == "HFX") {
field <- "SHFX" 
png(paste("./pngs/hovm_ew_",field,domain,"_",sim,month,year,".png",sep=""),
width = 500, height = 600,bg="white")
filled.contour(x=seq(1,nx),y=seq(1,ndays),z=hfxdaily,nlevels=6,
levels=c(seq(0,5000,by=500),5500),
col = c("royalblue","lightblue","lightgreen","green",
"yellow","orange","tomato","red1","red3","red4","black"),
#key.title = title(main=paste(field,"\n","W/m^2","\n","per day")),
plot.axes={axis(1,at=c(1,50,100),font=2);
axis(2,at=c(1,10,20,30),
labels=c("JUN01","JUN10","JUN20","JUN30"),font=2)},
font=2,
xlab="E-W domain size",ylab="Days",
key.axes=axis(4,font=2,at=seq(0,5000,by=1000)))
dev.off()
} else {
field <- "LHFX" 
hfxdaily <- hfxdaily*xlv 
png(paste("./pngs/hovm_ew_",field,domain,"_",sim,month,year,".png",sep=""),
width = 500, height = 600,bg="white")
filled.contour(x=seq(1,nx),y=seq(1,ndays),z=hfxdaily,nlevels=6,
levels=c(seq(0,5000,by=500),5500),
col = c("royalblue","lightblue","lightgreen","green",
"yellow","orange","tomato","red1","red3","red4","black"),
plot.axes={axis(1,at=c(1,50,100),font=2);
axis(2,at=c(1,10,20,30),
labels=c("JUN01","JUN10","JUN20","JUN30"),font=2)},font=2,
xlab="E-W domain size",ylab="Days",
key.axes=axis(4,font=1,at=seq(0,5000,by=1000)))
#key.title = title(main=paste(field, "\n", expression(W/m^2))))

dev.off()
}
}}

dir <-'.'
fname <- "cpc.ascii"
month <- "_2004_07"

fobs <- file(paste(dir,'/',fname,sep=""),"ra")
dims <- array(scan(fobs,what=0,n=2),c(2))
nx <- dims[1]
ny <- dims[2]
obs <- array(scan(fobs,what=0.,n=nx*ny),c(nx,ny))
close(fobs)

#46+12/4+12/12
#81-1-12/4-12/12
ixs <- 50
ixe <- 76
#26+12/4+12/12
#66-1-12/4-12/12
jxs <- 30
jxe <- 61
nx <- ixe-ixs+1
ny <- jxe-jxs+1


lim <- 300
fname <- paste(	"./posts/cpc_accum",month,"_d01.eps",sep="")
#png(fname,bg="lightgrey")
#png(fname,width = 384, height = 530,bg="lightgrey")
#postscript(fname,width=6., height=6.,
postscript(fname,width=5.95, height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=obs[ixs:ixe,jxs:jxe],
levels=c(1,10,50,100,150,200,250,300),
asp=1,col = rainbow(7,start=.15,end=.75,
gamma=1.),plot.axes={axis(1,at=c(1,10,20,30),font=2);
axis(2,at=c(1,10,20,30,40),font=2)},
xaxs = "i", yaxs = "i",zlim=range(0.,lim),
font=2,xlab="E-W domain size",ylab="S-N domain size",
key.title = title(main="Precip\n(mm)"),
key.axes=axis(4,at=c(1,10,50,100,150,200,250,300),font=2))
dev.off()	



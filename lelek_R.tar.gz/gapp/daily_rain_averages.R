library(ncdf)
domain <- "_d_02"
month="_jun"
year="_2004"
fields=c("RAINTOT")
xlv <- 2.5e6

sims <- c("run_11aa","run_11ba","run_11ca",
          "run_12aa","run_12ba","run_12ca",
          "run_13aa","run_13ba","run_13ca",
          "run_14aa","run_14ba","run_14ca")

nsims <- length(sims)


k <- 0

for (field in fields) {

print(field)

varave <- array(0.,c(24,nsims))
k <- 0

for (sim in sims) {


k <- k+1

print(sim)

print("getting data")

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/","RAINNC_h","_total",domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
ntimes <- v1$varsize[1]
close.ncdf(nc)

nc <- open.ncdf( paste("/scratch/amb/pagowski/stuff/gapp/indata/d_02/",
sim,"/","RAINC_h","_total",domain,month,year,".nc",sep=""), readunlim=FALSE )

v1 <- nc$var[[1]]
data2 <- get.var.ncdf( nc, v1 )
close.ncdf(nc)

data1 <- data1+data2

ndays <- (ntimes)/24

for (i in 1:ntimes) {
j <- i%%24
if (j == 0) j <- 24 
varave[j,k] <- data1[i]+varave[j,k]
}
rm(data1)
}

varave <- varave/ndays

if (field=="QFX") varave=varave*xlv
 
png(paste("./pngs/diurnal_",field,domain,month,year,".png",sep=""),
width = 700, height = 500,bg="white")


ymin <- min(varave)
ymax <- max(varave)

xvec=c(1,6,12,18,24)
lxvec=c("01","06","12","18","00")

colors <- rainbow(nsims/3)

plot(c(1:24),varave[,1],"l",col=colors[1],ylim=c(ymin,ymax),
xlab="UTC (hour)",ylab="",xaxs="i",xaxt = "n",lwd=7,cex.axis=2)
axis(1, at=xvec, labels=lxvec,cex.axis=2)

for (i in 2:nsims) {
j <- i%%3
if (j==1) ltyp <- 1
if (j==2) ltyp <- 5
if (j==0) ltyp <- 3
k <- (i-1)%/%3 + 1
lines(c(1:24),varave[,i],col=colors[k],lwd=7,lty=ltyp)
}

if (field=="QFX") {
legend(2.5,ymax,cex=.75,
lwd=3,c("YR","MN","MR","YN"),
col=colors)
}

dev.off()

}
library(ncdf)
sim <- "MYJ_ens_0"
field <- "RAINNC"
freq <- "_accum"
domain <- "_d_01_"
nc <- open.ncdf( paste("/export/scratch/pagowski/stuff/gapp2005/indata/processed/",field,domain,sim,"_2004-07-01_00:00:00",freq,".nc",sep=""), readunlim=FALSE )
v1 <- nc$var[[1]]
data1 <- get.var.ncdf( nc, v1 )
nx <- v1$varsize[1]
ny <- v1$varsize[2]
ntimes <- v1$varsize[3]

ixs <- 49
ixe <- 78
jxs <- 29
jxe <- 63
nx <- ixe-ixs+1
ny <- jxe-jxs+1


par(mar=c(2.1,4.1,2.1,0.1))
par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)

png(paste("accum_",field,domain,sim,freq,".png",sep=""),
width = 414, height=414, bg="white")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=data1[ixs:ixe,jxs:jxe]/25.4,
nlevels=6,levels=c(0.1,.5,1,2,4,8,12),asp=1,
col = rainbow(7,start=.15,end=.75,
gamma=1.),plot.axes={axis(1,at=c(1,10,20,30),font=2);
axis(2,at=c(1,10,20,30),font=2)},
xaxs = "i", yaxs = "i",
font=2,xlab="E-W domain size",ylab="S-N domain size",
key.title = title(main="Precip\n(in)"),
key.axes=axis(4,at=c(0.1,.5,1,2,4,8,12),font=2))
dev.off()



#to plot berror stats
library(ncdf4)

diagfile <- paste("./indata/diag_nnr_ges.2015081012.nc4")

nc <- nc_open(diagfile,readunlim=FALSE, write=FALSE )
nobs <- nc$dim[["nobs"]]$len
nchans <- nc$dim[["nchans"]]$len
obs <- ncvar_get(varid="Observation",nc)
innov <-  ncvar_get(varid="Obs_Minus_Forecast_unadjusted",nc)
nc_close(nc)

i_obs_valid <- which(obs > 0.)
n_obs_valid <- length(i_obs_valid)
obs_valid <- obs[i_obs_valid]
innov_valid <- innov[i_obs_valid]

picname <- paste("./pics/histogram.png",sep='')
png(picname,width = 600, height = 400,bg="white")

h <- hist(innov_valid,breaks=1000,plot=FALSE)

xmin <- -.5
xmax <- 2.

ymin=0.
ymax <- max(as.integer(h$density+1))

hist(innov_valid,breaks=1000,probability=TRUE,xlim=c(xmin,xmax),main="",
xlab="Innovation",ylab="Density",axes=FALSE)

xvec <- seq(xmin,xmax,by=0.5)
axis(1, at=xvec, cex.axis=1.0,pos=0)

yvec=seq(ymin,ymax,by=1)
axis(2, at=yvec, cex.axis=1.0,pos=-0.5)

dev.off()


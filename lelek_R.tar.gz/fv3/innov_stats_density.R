#to plot berror stats
library(ncdf4)

eps <- 0.0001
bias=-1.

yyyymmdd <- "2015081012"

diagfile <- paste("./indata/diag_nnr_ges.",yyyymmdd,".nc4",sep="")

nc <- nc_open(diagfile,readunlim=FALSE, write=FALSE )
nobs <- nc$dim[["nobs"]]$len
nchans <- nc$dim[["nchans"]]$len
obs <- ncvar_get(varid="Observation",nc)
innov <-  ncvar_get(varid="Obs_Minus_Forecast_unadjusted",nc)
nc_close(nc)

i_obs_valid <- which(obs > 0.)
n_obs_valid <- length(i_obs_valid)
obs_valid <- obs[i_obs_valid]
innov_valid <- innov[i_obs_valid]
model_valid <- obs_valid-innov_valid

log_model_valid <- log(model_valid+eps)
log_obs_valid <- log(obs_valid+eps)
log_innov_valid <- log_obs_valid-(log_model_valid-bias)


picname <- paste("./pics/density_innovation.",yyyymmdd,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

xmin <- -0.25
xmax <- 0.75

di <- density(innov_valid,bw = "nrd0", adjust = 1,
kernel = "epanechnikov",n=256,from=xmin,to=xmax)


ymin=0.
ymax <- max(as.integer(di$y+1))

plot(di,xlim=c(xmin,xmax),ylim=c(ymin,ymax),main="",
xlab="Innovations Observations - Model",ylab="Density",axes=FALSE,col="black",lwd=3)

polygon(di,col="red",border="blue",lwd=2)

xvec <- seq(xmin,xmax,by=0.5)
axis(1, at=xvec, cex.axis=1.0,pos=0.0)

yvec=seq(ymin,ymax,by=1)
axis(2, at=yvec, cex.axis=1.0,pos=0.0)



dev.off()

picname <- paste("./pics/density_obs_model.",yyyymmdd,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

xmin <- -0.5
xmax <- 1.0

do <- density(obs_valid,bw = "nrd0", adjust = 1,kernel = "epanechnikov",n=256,
from=xmin,to=xmax)

dm <- density(model_valid,bw = "nrd0", adjust = 1,kernel = "epanechnikov",n=256,
from=xmin,to=xmax)

ymin=0.
ymax <- max(as.integer(do$y),as.integer(dm$y))+1

plot(do,xlim=c(xmin,xmax),ylim=c(ymin,ymax),main="",
xlab="Observations & Model",ylab="Density",axes=FALSE,col="red",lwd=3)

lines(dm,col="blue",lwd=3)

xvec <- seq(xmin,xmax,by=0.5)
axis(1, at=xvec, cex.axis=1.0,pos=0)

yvec=seq(ymin,ymax,by=1)
axis(2, at=yvec, cex.axis=1.0,pos=0)

dev.off()

picname <- paste("./pics/density_obs_model_log.",yyyymmdd,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

xmin <- as.integer(log(eps))-1
xmax <- 2.

dol <- density(log_obs_valid,bw = "nrd0", adjust = 1,kernel = "epanechnikov",n=256,
from=xmin,to=xmax)

dml <- density(log_model_valid,bw = "nrd0", adjust = 1,kernel = "epanechnikov",n=256,
from=xmin,to=xmax)

ymin=0.
ymax <- max(as.integer(dol$y),as.integer(dml$y))+1

plot(dol,xlim=c(xmin,xmax),ylim=c(ymin,ymax),main="",
xlab="Log(Observations) & Log(Model)",ylab="Density",axes=FALSE,col="red",lwd=3)

lines(dml,col="blue",lwd=3)

xvec <- seq(xmin,xmax,by=0.5)
axis(1, at=xvec, cex.axis=1.0,pos=0)

yvec=seq(ymin,ymax,by=0.25)
axis(2, at=yvec, cex.axis=1.0,pos=xmin)

dev.off()

picname <- paste("./pics/density_innovation_log.",yyyymmdd,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

xmin <- -3
xmax <- 3.

dil <- density(log_innov_valid,bw = "nrd0", adjust = 1,kernel = "epanechnikov",n=256,
from=xmin,to=xmax)

ymin=0.
ymax <- max(as.integer(dil$y*10.)/10.+0.1)

xlab <- paste("Innovations Log(Observations) - Log(Model) - bias",
sep="")

plot(dil,xlim=c(xmin,xmax),ylim=c(ymin,ymax),main="",
xlab=xlab,ylab="Density",axes=FALSE,col="black",lwd=3)

polygon(dil,col="red",border="blue",lwd=2)

xvec <- seq(xmin,xmax,by=1.)
axis(1, at=xvec, cex.axis=1.0,pos=0)

yvec=seq(ymin,ymax,by=0.1)
axis(2, at=yvec, cex.axis=1.0,pos=xmin)

dev.off()

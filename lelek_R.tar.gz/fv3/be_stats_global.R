#to plot berror stats
library(ncdf4)

varname="dust1"
#varname="oc2"

fvfile <- paste("./indata/be_tracer_",varname,".nc",sep='')	

nc <- nc_open(fvfile,readunlim=FALSE, write=FALSE )
nx <- nc$dim[["west_east"]]$len
ny <- nc$dim[["south_north"]]$len
nz <- nc$dim[["bottom_top"]]$len
stdev <- ncvar_get(varid="stdev",nc)
lscalex <- ncvar_get(varid="lscalex",nc)
lscaley <- ncvar_get(varid="lscaley",nc)
lscalez <- ncvar_get(varid="lscalez",nc)
player <- ncvar_get(varid="player",nc)
#player is -log(p/ps)
nc_close(nc)

lscale <- sqrt(lscalex^2+lscaley^2)

name <- "stdev"
data <- stdev

xmin <- 0
xmax <- 360
dx <- (xmax-xmin)/(nx-1)
xvec <- seq(xmin,xmax,dx)

ymin <- -90
ymax <- 90
dy <- (ymax-ymin)/(ny-1)
yvec <- seq(ymin,ymax,dy)


nticks=5

dxtick <- (xmax-xmin)/(nticks-1)
xticks <- seq(xmin,xmax,by=dxtick)

dytick <- (ymax-ymin)/(nticks-1)
yticks <- seq(ymin,ymax,by=dytick)


cols <- rainbow(15)

ilevel  <- 1

picname <- paste("./pics/",varname,"_",name,"_global.png",sep='')
png(picname,width = 600, height = 400,bg="white")

filled.contour(xvec,yvec,data[,,ilevel],
col=cols,
xaxs="i",yaxs="i",xlim=c(xmin,xmax),
xlab="Latitude",ylab="Pressure",
plot.axes = { axis(1, xticks)
                  axis(2, at=yticks,labels=yticks) })
dev.off()

nzl <- 41
zvec <- 1:nzl
nticks <- 5
dxtick <- (xmax-xmin)/(nticks-1)
xticks <- seq(xmin,xmax,by=dxtick)
zticks <- seq(0,nzl-1,by=10)
zticks[1] <- 1
pticks <- as.integer(pvec[seq(1,nzl,by=10)])

name <- "hlscale"
data <- lscale

picname <- paste("./pics/",varname,"_",name,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

filled.contour(xvec,zvec,data[,1:nzl],
nlevels=7,
col=c("white","lightgray","lightskyblue","limegreen","yellow",
"orange","red","violet","purple"),
xaxs="i",yaxs="i",xlim=c(xmin,xmax),
xlab="Latitude",ylab="Pressure",
plot.axes = { axis(1, xticks)
                  axis(2, at=zticks,labels=pticks) })
dev.off()

name <- "vlscale"
data <- lscalez

picname <- paste("./pics/",varname,"_",name,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

filled.contour(xvec,zvec,data[,1:nzl],
nlevels=7,
col=c("white","lightgray","lightskyblue","limegreen","yellow",
"orange","red","violet","purple"),
xaxs="i",yaxs="i",xlim=c(xmin,xmax),
xlab="Latitude",ylab="Pressure",
plot.axes = { axis(1, xticks)
                  axis(2, at=zticks,labels=pticks) })
dev.off()


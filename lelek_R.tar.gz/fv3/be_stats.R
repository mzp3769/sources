#to plot berror stats
library(ncdf4)

varname="dust_1"
#varname="oc2"

fvfile <- paste("./indata/be_tracer_",varname,"_zonal.nc",sep='')	

nc <- nc_open(fvfile,readunlim=FALSE, write=FALSE )
nx <- nc$dim[["south_north"]]$len
nz <- nc$dim[["bottom_top"]]$len
stdev <- ncvar_get(varid="stdev",nc)
lscalex <- ncvar_get(varid="lscalex",nc)
lscaley <- ncvar_get(varid="lscaley",nc)
lscalez <- ncvar_get(varid="lscalez",nc)
player <- ncvar_get(varid="player",nc)
#player is -log(p/ps)
nc_close(nc)

lscale <- sqrt(lscalex^2+lscaley^2)

name <- "stdev"
data <- stdev

xmin <- -90
xmax <- 90
dx <- (xmax-xmin)/(nx-1)
xvec <- seq(xmin,xmax,dx)
pvec <- colMeans(1000.*exp(-player), na.rm = FALSE, dims = 1)
pmin <- min(pvec)
pmax <- max(pvec)
zvec <- 1:nz
nticks <- 5
dxtick <- (xmax-xmin)/(nticks-1)
xticks <- seq(xmin,xmax,by=dxtick)
zticks <- seq(0,nz-1,by=10)
zticks[1] <- 1
pticks <- as.integer(pvec[seq(1,nz,by=10)])


picname <- paste("./pics/",varname,"_",name,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

filled.contour(xvec,zvec,data,
nlevels=7,
col=c("white","lightgray","lightskyblue","limegreen","yellow",
"orange","red","violet","purple"),
xaxs="i",yaxs="i",xlim=c(xmin,xmax),
xlab="Latitude",ylab="Pressure",
plot.axes = { axis(1, xticks)
                  axis(2, at=zticks,labels=pticks) })
dev.off()

nzl <- 41
zvec <- 1:nzl
nticks <- 5
dxtick <- (xmax-xmin)/(nticks-1)
xticks <- seq(xmin,xmax,by=dxtick)
zticks <- seq(0,nzl-1,by=10)
zticks[1] <- 1
pticks <- as.integer(pvec[seq(1,nzl,by=10)])

name <- "hlscale"
data <- lscale

picname <- paste("./pics/",varname,"_",name,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

filled.contour(xvec,zvec,data[,1:nzl],
nlevels=7,
col=c("white","lightgray","lightskyblue","limegreen","yellow",
"orange","red","violet","purple"),
xaxs="i",yaxs="i",xlim=c(xmin,xmax),
xlab="Latitude",ylab="Pressure",
plot.axes = { axis(1, xticks)
                  axis(2, at=zticks,labels=pticks) })
dev.off()

name <- "vlscale"
data <- lscalez

picname <- paste("./pics/",varname,"_",name,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

filled.contour(xvec,zvec,data[,1:nzl],
nlevels=7,
col=c("white","lightgray","lightskyblue","limegreen","yellow",
"orange","red","violet","purple"),
xaxs="i",yaxs="i",xlim=c(xmin,xmax),
xlab="Latitude",ylab="Pressure",
plot.axes = { axis(1, xticks)
                  axis(2, at=zticks,labels=pticks) })
dev.off()


#to plot berror stats
library(ncdf4)

diagfile <- paste("./indata/diag_nnr_ges.2015081012.nc4")

nc <- nc_open(diagfile,readunlim=FALSE, write=FALSE )
nobs <- nc$dim[["nobs"]]$len
nchans <- nc$dim[["nchans"]]$len
obs <- ncvar_get(varid="Observation",nc)
innov <-  ncvar_get(varid="Obs_Minus_Forecast_unadjusted",nc)
nc_close(nc)

i_obs_valid <- which(obs > 0.)
n_obs_valid <- length(i_obs_valid)
obs_valid <- obs[i_obs_valid]
innov_valid <- innov[i_obs_valid]

xmin <- -.5
xmax <- 2.

h <- hist(innov_valid,breaks=1000,plot=FALSE)

nbreaks <- length(h$breaks) 

dx <- h$breaks[2] - h$breaks[1]
xvec <- seq(0.5*(h$breaks[1]+h$breaks[2]),0.5*(h$breaks[nbreaks-1] + h$breaks[nbreaks]),by=dx)
plot(h$breaks,h$density)

plot(xvec,h$density,freq=FALSE,xlim=c(xmin,xmax),main="",
xlab="Innovation",ylab="Density",xaxt='n',)

hist(innov_valid,breaks=1000,probability=TRUE,xlim=c(xmin,xmax),main="",
xlab="Innovation",ylab="Density",xaxt='n')

xvec <- seq(xmin,xmax,by=0.5)
axis(1, at=xvec, cex.axis=1.0,pos=0)
yvec=seq(xmin,xmax,by=0.5)

axis(2, at=yvec, cex.axis=1.0,pos=-0.5)

d <- density(innov_valid,bw = "nrd0", adjust = 1,kernel = "epanechnikov",n=1024,
from=-0.5,to=2.)

xmin <- -.5
xmax <- 2.

plot(d,freq=FALSE,xlim=c(xmin,xmax),main="",
xlab="Innovation",ylab="Density",axes=FALSE)

xvec <- seq(xmin,xmax,by=0.5)
axis(1, at=xvec, cex.axis=1.0,pos=0)

ymin=0.
ymax <- max(as.integer(d$y+1))
yvec=seq(ymin,ymax,by=1)
axis(2, at=yvec, cex.axis=1.0,pos=-0.5)


lscale <- sqrt(lscalex^2+lscaley^2)

name <- "stdev"
data <- stdev

xmin <- -90
xmax <- 90
dx <- (xmax-xmin)/(nx-1)
xvec <- seq(xmin,xmax,dx)
pvec <- colMeans(1000.*exp(-player), na.rm = FALSE, dims = 1)
pmin <- min(pvec)
pmax <- max(pvec)
zvec <- 1:nz
nticks <- 5
dxtick <- (xmax-xmin)/(nticks-1)
xticks <- seq(xmin,xmax,by=dxtick)
zticks <- seq(0,nz-1,by=10)
zticks[1] <- 1
pticks <- as.integer(pvec[seq(1,nz,by=10)])


picname <- paste("./pics/",varname,"_",name,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

filled.contour(xvec,zvec,data,
nlevels=7,
col=c("white","lightgray","lightskyblue","limegreen","yellow",
"orange","red","violet","purple"),
xaxs="i",yaxs="i",xlim=c(xmin,xmax),
xlab="Latitude",ylab="Pressure",
plot.axes = { axis(1, xticks)
                  axis(2, at=zticks,labels=pticks) })
dev.off()

nzl <- 41
zvec <- 1:nzl
nticks <- 5
dxtick <- (xmax-xmin)/(nticks-1)
xticks <- seq(xmin,xmax,by=dxtick)
zticks <- seq(0,nzl-1,by=10)
zticks[1] <- 1
pticks <- as.integer(pvec[seq(1,nzl,by=10)])

name <- "hlscale"
data <- lscale

picname <- paste("./pics/",varname,"_",name,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

filled.contour(xvec,zvec,data[,1:nzl],
nlevels=7,
col=c("white","lightgray","lightskyblue","limegreen","yellow",
"orange","red","violet","purple"),
xaxs="i",yaxs="i",xlim=c(xmin,xmax),
xlab="Latitude",ylab="Pressure",
plot.axes = { axis(1, xticks)
                  axis(2, at=zticks,labels=pticks) })
dev.off()

name <- "vlscale"
data <- lscalez

picname <- paste("./pics/",varname,"_",name,".png",sep='')
png(picname,width = 600, height = 400,bg="white")

filled.contour(xvec,zvec,data[,1:nzl],
nlevels=7,
col=c("white","lightgray","lightskyblue","limegreen","yellow",
"orange","red","violet","purple"),
xaxs="i",yaxs="i",xlim=c(xmin,xmax),
xlab="Latitude",ylab="Pressure",
plot.axes = { axis(1, xticks)
                  axis(2, at=zticks,labels=pticks) })
dev.off()


#to plot berror stats

mu <- 1
sigma <- 0.5
xmin <- 0
xmax <- 10

seed <- 13 #11
#seed <- 11
set.seed(seed, kind = NULL)

names <- c(
"G. Grell (NOAA/ESRL/GSD)",
"J. Mcqueen (NOAA/EMC)",
"S. McKeen (NOAA/ESRL/CSD)", 
"L. Zhang (NOAA/ESRL/GSD)",
"S. Lu (State Univ. of NY at Albany)",
"I. Stajner (NOAA/NWS)",
"")
#"S. Kondragunta (NOAA/NESDIS)"
#)

shobha <- "S. Kondragunta (NOAA/NESDIS)"
nnames <- length(names)

x <- rlnorm(nnames, mean=mu, sd=sigma)
z <- dlnorm(x,mean=mu,sd=sigma, log = FALSE)


ymin=0.
ymax <- max(as.integer(z*10.)/10.+.1)

picname <- "./pics/authors_lognormal.png"
png(picname,width = 600, height = 350,bg="white")


plot(function(x) {dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
xlim=c(xmin,xmax),
ylim=c(ymin,ymax),
axes=FALSE,xlab="Co-authors randomly",
ylab="Lognormal probablity density",col="blue",lwd=4)
points(x,z,type="p",col="red",pch=19)
text(x,z,names,cex=1.35)
xvec <- seq(xmin,xmax,by=2.)
axis(1, at=xvec, cex.axis=1.0,pos=0)

text(x[7],z[7]-0.0135,shobha,cex=1.35)

yvec=seq(ymin,ymax,by=0.1)
axis(2, at=yvec, cex.axis=1.0,pos=xmin)

dev.off()



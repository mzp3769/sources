#to plot scatters for aod for two netcdf files
library(ncdf4)

fvfile <- "./indata/fv3_fcst.nc"

varnames_dust <- c("dust_1","dust_2","dust_3","dust_4","dust_5")
varnames_seas <- c("seas_1","seas_2","seas_3","seas_4")
varnames_carbons <- c("bc1","bc2","oc1","oc2")
varnames <- c(varnames_dust,varnames_seas,varnames_carbons)
varname_pressure <- "pres"
varname_psfc <- "psfc"

xy <- c(184,154) #dust
varname_1 <- varnames_dust[1]
varname_2 <- varnames_dust[5]

xy <- c(83,137) #seas
varname_1 <- varnames_seas[2]
varname_2 <- varnames_seas[4]

xy <- c(171,71) #bc1/oc2
varname_1 <- varnames_carbons[1]
varname_2 <- varnames_carbons[4]

nc <- nc_open(fvfile,readunlim=FALSE, write=FALSE )
nx <- nc$dim[["grid_xt"]]$len
ny <- nc$dim[["grid_yt"]]$len
nz <- nc$dim[["phalf"]]$len
cube_1 <- ncvar_get(varid=varname_1,nc)
cube_2 <- ncvar_get(varid=varname_2,nc)
cube_pressure <- ncvar_get(varid=varname_pressure,nc)
square_psfc <- ncvar_get(varid=varname_psfc,nc)
nc_close(nc)

#profile_pressure <- -log(cube_pressure[xy[1],xy[2],]/square_psfc[xy[1],xy[2]])
profile_pressure <- cube_pressure[xy[1],xy[2],] * 1.e-2

profile_1 <- cube_1[xy[1],xy[2],]
profile_2 <- cube_2[xy[1],xy[2],]

xmin <- 0
xmax <- max(profile_1,profile_2)
xmax <- floor(xmax) + 1

zmin <- min(profile_pressure)
zmax <- max(profile_pressure)
#zmax <- 2
zmin <- 500 #mb dust
zmin <- 850 # seas
zmin <- 300 #  bc1/oc2

picwidth <- 300
picratio <- 1.5

xlabstring <- "mixing ratio [ug/kg]"
#ylabstring <- "log(p/ps)"
ylabstring <- "pressure [hPa]"

colors <- c("red","blue")


pngname <- paste("./pics/profile_",varname_1,"_",varname_2,".png",sep="")
png(pngname,width=picwidth, height=picwidth*picratio,bg="white")

plot(x=profile_1,y=profile_pressure,xlim=c(xmin,xmax),ylim=c(zmax,zmin),
type="l",lwd=5,cex=.5,cex.axis=1.5,cex.lab=1.5,
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",col=colors[1])

lines(x=profile_2,y=profile_pressure,type='l',col=colors[2],lwd=5)

legend(x=xmax,y=zmin,xjust=1,yjust=1,
col=colors,legend=c(varname_1,varname_2),lwd=5)

dev.off()

stop("1")

df <- data.frame()
df <- rbind(df,data.frame(x=profile,y=profile_pressure))


#to plot scatters for aod for two netcdf files
library(ncdf4)

fvfilebckg <- "./indata/fv3_bckg.nc"
fvfileanal <- "./indata/fv3_anal.nc"

varnames_dust <- c("dust1","dust2","dust3","dust4","dust5")
varnames_seas <- c("seas1","seas2","seas3","seas4")
varnames_carbons <- c("bc1","bc2","oc1","oc2")
varnames <- c(varnames_dust,varnames_seas,varnames_carbons)
varname_psfc <- "psfc"

xy <- c(184,154) #dust
varname <- varnames_dust[1]

xy <- c(83,137) #seas
varname <- varnames_seas[4]

#xy <- c(171,71) #bc1/oc2
#varname <- varnames_carbons[4]

nhrfcst <- 6
nhranal <- 1
nc <- nc_open(fvfilebckg,readunlim=FALSE, write=FALSE )
nx <- nc$dim[["grid_xt"]]$len
ny <- nc$dim[["grid_yt"]]$len
nz <- nc$dim[["pfull"]]$len
cube_bckg <- ncvar_get(varid=varname,nc)
pfull <- ncvar_get(varid="pfull",nc)
nc_close(nc)

profile_pressure <- pfull

profile_1 <- cube_bckg[xy[1],xy[2],,nhrfcst]

nc <- nc_open(fvfileanal,readunlim=FALSE, write=FALSE )
cube_anal <- ncvar_get(varid=varname,nc)
nc_close(nc)

profile_2 <- cube_anal[xy[1],xy[2],,nhranal]

xmin <- 0
xmax <- max(profile_1,profile_2)
xmax <- floor(xmax) + 1

zmin <- min(profile_pressure)
zmax <- max(profile_pressure)
zmin <- 500 #mb dust
#zmin <- 850 # seas
zmin <- 100 #  bc1/oc2

picwidth <- 300
picratio <- 1.5

xlabstring <- "mixing ratio [ug/kg]"
ylabstring <- "pressure [hPa]"

colors <- c("blue","red")

pngname <- paste("./pics/profile_",varname,".png",sep="")
png(pngname,width=picwidth, height=picwidth*picratio,bg="white")

plot(x=profile_1,y=profile_pressure,xlim=c(xmin,xmax),ylim=c(zmax,zmin),
type="l",lwd=5,cex=.5,cex.axis=1.5,cex.lab=1.5,
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",col=colors[1])

lines(x=profile_2,y=profile_pressure,type='l',col=colors[2],lwd=5)

legend(x=xmax,y=zmin,xjust=1,yjust=1,
col=colors,legend=c("bckg","anal"),lwd=5)

dev.off()



fname <- "ASCII.ruc"
nx <- 451
ny <- 337
nz <- 1

#nx <- 51
#ny <- 51
#nz <- 30


test <- array(scan(fname,what=0.,n=nx*ny*nz),c(nx,ny,nz))
#close(fname)
png("test.png",width = 630, height = 530,bg="lightgrey")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=test[,,1])
dev.off()

#bubble sort

a <- c(8,7,12,4,9,6,5)
print(a)

len <- length(a)
#print(len)

exch <- 1
totexch <- 0

while (exch > 0) {
      exch <- 0
      l <- 1
      while (l < len) {
      	    if (a[l] > a[l+1]) {
	    b <- a[l+1]
	    a[l+1] <- a[l]
	    a[l] <- b
	    exch <- exch + 1
	    }
	    l <- l+1
#	    print(l)
#	    print(a)
     }
     totexch <- totexch + 1
}

print(a)

print(totexch)

#thresholds

plot(c(1:ntthresh),threshholds[1,1:ntthresh],type="l",lwd=2,col="blue")
for (iday in 1:ndays) {
    print(iday)
    lines(c(1:ntthresh),threshholds[iday,1:ntthresh],
          type="l",lwd=1,col="black")
}


cols <- rainbow(100)

icol <- 40
plot(p_models[2,],p_obs[2,],xlim=c(0,1),ylim=c(0,1),
type="l",lwd=1,col=cols[icol])
for (iday in 3:ndays) {
    print(iday)
    lines(p_models[iday,],p_obs[iday,],
          type="l",lwd=1,col=cols[iday+icol])
}

lines(p_models[ndays+1,],p_obs[ndays+1,],type="l",lwd=4,col="red")
lines(p_models[ndays+1,],p_obs[ndays+1,],type="p",lwd=4,col="red")
lines(seq(0,1,by=.1),seq(0,1,by=.1),type="l",lwd=4,col="blue")

plot(c(0:nens), p_obs[ndays+1,],type="l",lwd=4,col="red")
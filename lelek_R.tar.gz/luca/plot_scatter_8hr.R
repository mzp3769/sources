postscript("scatter_kf_8hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlims <- c(0,100)
ylims <- c(0,100)


for (j in 1:nstations) {
    for (i in 1:ndays) {
        if (is.na(allobs8hrmax[i,j]) || is.na(eqw8hrmax[i,j])) {
            next
        }
        if ((allobs8hrmax[i,j] <= 10 ) && (eqw8hrmax[i,j] >=50)) {
           allobs8hrmax[i,j] <- NA 
        }
    }
}

xlabstring <- expression(paste("Observations ",O[3]," (ppbv)"))
ylabstring <- expression(paste("DLR ",O[3]," (ppbv)"))

plot(allobs8hrmax,kf8hrmax,type="p",col="black",
     xlim=xlims,ylim=ylims,pch=19,cex=.2,xaxs="i",yaxs="i",
     xlab=xlabstring,ylab=ylabstring)
lines(xlims,ylims,type="l",col="black")

text(10,90,labels="a",cex=1.3,vfont=c("serif","plain"))

dev.off()


postscript("scatter_eqw_8hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring <- expression(paste("Observations ",O[3]," (ppbv)"))
ylabstring <- expression(paste("AVE ",O[3]," (ppbv)"))

plot(allobs8hrmax,eqw8hrmax,type="p",col="black",
     xlim=xlims,ylim=ylims,pch=19,cex=.2,xaxs="i",yaxs="i",
     xlab=xlabstring,ylab=ylabstring)
lines(xlims,ylims,type="l",col="black")

text(10,90,labels="b",cex=1.3,vfont=c("serif","plain"))

dev.off()


postscript("scatter_persist_8hr.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

xlabstring <- expression(paste("Observations ",O[3]," (ppbv)"))
ylabstring <- expression(paste("Persistence ",O[3]," (ppbv)"))

plot(allobs8hrmax,persist8hrmax,type="p",col="black",
     xlim=xlims,ylim=ylims,pch=19,cex=.2,xaxs="i",yaxs="i",
     xlab=xlabstring,ylab=ylabstring)
lines(xlims,ylims,type="l",col="black")

text(10,90,labels="c",cex=1.3,vfont=c("serif","plain"))

dev.off()

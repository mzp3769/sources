for (iday in 1:ndays) {
    for (ist in 1:nstations) {
        for (iens in 1:nens) {
            if (!is.na(allmodels8hrmax[iday,iens,ist])) { 
                if (allmodels8hrmax[iday,iens,ist] < 0.) {
                    allmodels8hrmax[iday,iens,ist] <- NA
                }
            }
            if (! is.na(allmodels1hrmax[iday,iens,ist])) {
               if (allmodels1hrmax[iday,iens,ist] < 0.) {
                   allmodels1hrmax[iday,iens,ist] <- NA
               }  
            }
        }
        if (! is.na(allobs8hrmax[iday,ist])) {
            if (allobs8hrmax[iday,ist] < 0.) {
                allobs8hrmax[iday,ist] <- NA
            }
        }  
        if (! is.na(allobs1hrmax[iday,ist])) {
            if (allobs1hrmax[iday,ist] < 0.) {
                allobs1hrmax[iday,ist] <- NA
            }
        }  
    }
}        
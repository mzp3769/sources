cols <- rainbow(100)

#reliability
icol <- 40

dev.set(2)
plot(c(0:nmodels),p_obs_singlem[1,],type="l",lwd=1,col=cols[icol],
xlim=c(0,1),ylim=c(0,1.))
for (iday in 2:ndays) {
    print(iday)
    lines(c(0:nmodels)/nmodels,p_obs_singlem[iday,],type="l",
    lwd=1,col=cols[iday+icol])
}

lines(c(0:nmodels)/nmodels,p_obs_singlem[ndays+1,],
type="l",lwd=4,col="red")
lines(c(0:nmodels)/nmodels,p_obs_singlem[ndays+1,],
type="p",lwd=4,col="red")
lines(seq(0,1,by=.1),seq(0,1,by=.1),type="l",lwd=4,col="blue")


#sharpness
dev.set(3)
#x11()
plot(c(0:nmodels),p_models_singlem[1,],type="l",lwd=1,
col=cols[icol],xlim=c(0,nmodels+1),
ylim=c(0,1.))
for (iday in 2:ndays) {
    print(iday)
    lines(c(0:nmodels),p_models_singlem[iday,],type="l",
    lwd=1,col=cols[iday+icol])
}
lines(c(0:nmodels),p_models_singlem[ndays+1,],type="l",lwd=4,col="red")
lines(c(0:nmodels),p_models_singlem[ndays+1,],type="p",lwd=4,col="red")
#plot(c(0:nmodels),p_models_singlem[ndays+1,],type="l",lwd=4,col="red")

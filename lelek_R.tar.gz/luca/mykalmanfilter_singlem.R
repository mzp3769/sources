# myKalmanFilter(obs, models, delta)
# Author: MP CIRA, June 2005 

myKalmanFilter_singlem <- function(obs, models, delta, nnens) {

    tlength  <- length(obs)	    
    mykf <- array(NA,tlength)
    weights <- array(NA,c(tlength,nnens))
    phi <- array(NA,nnens)
    psi <- array(NA,nnens)

    for (hour in 1:24) {

       n <- 1
       d <- .1
       s <- d/n
       m <- array(1./nnens,nnens)	
       m[1] <- 0.
       m[2:nnens] <- 1./(nnens-1)
       		
       c <- array(1.,nnens)
       for (t in seq(hour,tlength,by=24)) {
           modelst <- models[t,]
           obst <- obs[t]

           if (min(modelst) < 0.) {
               mykf[t] <- NA
               weights[t,] <- NA
               next
           } 

           if (obst < 0) {
               mykf[t] <- NA
               weights[t,] <- NA
               next
           }

           f <- as.numeric(crossprod(modelst,m))
           mykf[t] <- f
           weights[t,] <- m
           phi <- c/delta
           psi <- as.numeric(crossprod(modelst^2,phi)) + s

           n <- n+1
           e <- obst-f
           d <- d + s*e^2/psi
           s <- d/n

           k <- c(modelst * phi)/psi
           m <- m + k*e
           c <- s/psi * phi

       }
    }

  kflist <- list("kf"=mykf,"weights"=weights)

return(kflist)

}



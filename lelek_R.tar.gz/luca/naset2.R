for (iday in 1:ndays) {
    print(iday)
    for (ist in 1:nstations) {
        if (any(is.na(allmodels8hrmax[iday,,ist]))) {
            singlem_kf8hrmax[iday,,ist] <- NA
        } else {
             if (any(is.na(singlem_kf8hrmax[iday,,ist]))) {
             allmodels8hrmax[iday,,ist] <- NA
             }
        }
        if (any(is.na(allmodels1hrmax[iday,,ist]))) {
            singlem_kf1hrmax[iday,,ist] <- NA
        } else {
             if (any(is.na(singlem_kf1hrmax[iday,,ist]))) {
             allmodels1hrmax[iday,,ist] <- NA
             }
        }
    }
}        
ecvfunc <- function(a,b,c,n) {
   r <- seq(0.,1,by=(1./n))
   o <- a+c
   ecv <- array(NA,n)
   for (i in 1:n) {
      ecv[i] <- (min(o,r[i])-(a+b)*r[i]-c)/(min(o,r[i])-o*r[i])
   }
   return(ecv)
}

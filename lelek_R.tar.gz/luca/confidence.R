#calculates confidence intervals

alpha <- .05

qd <- qchisq((1-alpha/2),df=ntot)
qu <- qchisq(alpha/2,df=ntot)

rrmsekfd <- rrmsekfave*sqrt(ntot/qd) 
rrmsekfu <- rrmsekfave*sqrt(ntot/qu) 

rmsekfd <- rmsekfave*sqrt(ntot/qd) 
rmsekfu <- rmsekfave*sqrt(ntot/qu) 

rrmsepredd <- rrmsepredave*sqrt(ntot/qd) 
rrmsepredu <- rrmsepredave*sqrt(ntot/qu) 

rmsepredd <- rmsepredave*sqrt(ntot/qd) 
rmsepredu <- rmsepredave*sqrt(ntot/qu) 

qd <- qchisq((1-alpha/2),df=n8hrtot)
qu <- qchisq(alpha/2,df=n8hrtot)

rrmse8hrd <- rrmse8hrmaxave*sqrt(n8hrtot/qd) 
rrmse8hru <- rrmse8hrmaxave*sqrt(n8hrtot/qu)

rmse8hrd <- rmse8hrmaxave*sqrt(n8hrtot/qd) 
rmse8hru <- rmse8hrmaxave*sqrt(n8hrtot/qu)

rrmse8hr_svdd <- rrmse8hrmaxave_svd*sqrt(n8hrtot/qd) 
rrmse8hr_svdu <- rrmse8hrmaxave_svd*sqrt(n8hrtot/qu)

rmse8hr_svdd <- rmse8hrmaxave_svd*sqrt(n8hrtot/qd)
rmse8hr_svdu <- rmse8hrmaxave_svd*sqrt(n8hrtot/qu)

qd <- qchisq((1-alpha/2),df=n1hrtot)
qu <- qchisq(alpha/2,df=n1hrtot)

rrmse1hrd <- rrmse1hrmaxave*sqrt(n1hrtot/qd) 
rrmse1hru <- rrmse1hrmaxave*sqrt(n1hrtot/qu)

rmse1hrd <- rmse1hrmaxave*sqrt(n1hrtot/qd) 
rmse1hru <- rmse1hrmaxave*sqrt(n1hrtot/qu)

rrmse1hr_svdd <- rrmse1hrmaxave_svd*sqrt(n1hrtot/qd) 
rrmse1hr_svdu <- rrmse1hrmaxave_svd*sqrt(n1hrtot/qu)

rmse1hr_svdd <- rmse1hrmaxave_svd*sqrt(n1hrtot/qd)
rmse1hr_svdu <- rmse1hrmaxave_svd*sqrt(n1hrtot/qu)

x <- 1.96

z <- .5*log((1+corkfave)/(1-corkfave))
zd <- z - x/sqrt(ntot) 
zu <- z + x/sqrt(ntot)
corkfd <- (exp(2*zd)-1)/(exp(2*zd)+1)
corkfu <- (exp(2*zu)-1)/(exp(2*zu)+1)

z <- .5*log((1+corpredave)/(1-corpredave))
zd <- z - x/sqrt(ntot) 
zu <- z + x/sqrt(ntot)
corpredd <- (exp(2*zd)-1)/(exp(2*zd)+1)
corpredu <- (exp(2*zu)-1)/(exp(2*zu)+1)

z <- .5*log((1+ccorkfave)/(1-ccorkfave))
zd <- z - x/sqrt(ntot) 
zu <- z + x/sqrt(ntot)
ccorkfd <- (exp(2*zd)-1)/(exp(2*zd)+1)
ccorkfu <- (exp(2*zu)-1)/(exp(2*zu)+1)

z <- .5*log((1+ccorpredave)/(1-ccorpredave))
zd <- z - x/sqrt(ntot) 
zu <- z + x/sqrt(ntot)
ccorpredd <- (exp(2*zd)-1)/(exp(2*zd)+1)
ccorpredu <- (exp(2*zu)-1)/(exp(2*zu)+1)

cor8hrmaxave_all <- c(cor8hrmaxave,cor8hrmaxave_svd)
ccor8hrmaxave_all <- c(ccor8hrmaxave,ccor8hrmaxave_svd)

z <- .5*log((1+cor8hrmaxave_all)/(1-cor8hrmaxave_all))
zd <- z - x/sqrt(n8hrtot)
zu <- z + x/sqrt(n8hrtot)
cor8hrmaxaved <- (exp(2*zd)-1)/(exp(2*zd)+1)
cor8hrmaxaveu <- (exp(2*zu)-1)/(exp(2*zu)+1)

z <- .5*log((1+ccor8hrmaxave_all)/(1-ccor8hrmaxave_all))
zd <- z - x/sqrt(n8hrtot)
zu <- z + x/sqrt(n8hrtot)
ccor8hrmaxaved <- (exp(2*zd)-1)/(exp(2*zd)+1)
ccor8hrmaxaveu <- (exp(2*zu)-1)/(exp(2*zu)+1)

cor1hrmaxave_all <- c(cor1hrmaxave,cor1hrmaxave_svd)
ccor1hrmaxave_all <- c(ccor1hrmaxave,ccor1hrmaxave_svd)

z <- .5*log((1+cor1hrmaxave_all)/(1-cor1hrmaxave_all))
zd <- z - x/sqrt(n1hrtot)
zu <- z + x/sqrt(n1hrtot)
cor1hrmaxaved <- (exp(2*zd)-1)/(exp(2*zd)+1)
cor1hrmaxaveu <- (exp(2*zu)-1)/(exp(2*zu)+1)

z <- .5*log((1+ccor1hrmaxave_all)/(1-ccor1hrmaxave_all))
zd <- z - x/sqrt(n1hrtot)
zu <- z + x/sqrt(n1hrtot)
ccor1hrmaxaved <- (exp(2*zd)-1)/(exp(2*zd)+1)
ccor1hrmaxaveu <- (exp(2*zu)-1)/(exp(2*zu)+1)


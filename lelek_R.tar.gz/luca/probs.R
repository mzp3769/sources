j <- 0
o <- 0
no <- 0

for (iday in 1:ndays) {
    print(iday)
    for (ist in 1:nstations) {
        if (is.na(allobsxhrmax[iday,ist]) ||
            any(is.na(allmodelsxhrmax[iday,,ist]))) {
           next
        }

        j <- j+1


        pm <- 1
        for (iens in 1:nmodels) {
            if (allmodelsxhrmax[iday,iens,ist] > thres) { 
               pm <- pm + 1 
            }
	}

	if (allobsxhrmax[iday,ist] > thres) {
	   o <- o+1
	   a[1:pm] <- a[1:pm] + 1
	   if (pm < nintervals) {
              c[(pm+1):nintervals] <- c[(pm+1):nintervals] + 1
            }
        } else {
	   no <- no+1
           b[1:pm] <- b[1:pm] + 1
           if (pm < nintervals) {
	      d[(pm+1):nintervals] <- d[(pm+1):nintervals] + 1
           }
        }
    }
}

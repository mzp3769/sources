source("readmax.R")

print("KF")

delta <- .9

source("mykalmanfiltermax.R")

kf8hrmax_new <- array(NA,c(ndays,nstations))
weights8hrmax <- array(NA,c(ndays,nens,nstations))

for (i in 1:nstations) {
    print(i)
    models <- allmodels8hrmax[,,i]
    obs <- allobs8hrmax[,i]
    kalmanlist8hrmax <- myKalmanFiltermax(obs, models, delta)
    kf8hrmax_new[,i] <- kalmanlist8hrmax$kfmax
    weights8hrmax[,,i] <- kalmanlist8hrmax$weightsmax
}


kf1hrmax_new <- array(NA,c(ndays,nstations))
weights1hrmax <- array(NA,c(ndays,nens,nstations))

for (i in 1:nstations) {
    print(i)
    models <- allmodels1hrmax[,,i]
    obs <- allobs1hrmax[,i]
    kalmanlist1hrmax <- myKalmanFiltermax(obs, models, delta)
    kf1hrmax_new[,i] <- kalmanlist1hrmax$kfmax
    weights1hrmax[,,i] <- kalmanlist1hrmax$weightsmax
}

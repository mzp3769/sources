#scatter
xlims <- c(0,110)
ylims <- c(0,110)

plot(allobs8hrmax,eqw8hrmax,type="p",col="red",
     xlim=xlims,ylim=ylims,pch=19,cex=.2)
lines(xlims,ylims,type="l",col="black")

plot(allobs8hrmax,kf8hrmax,type="p",col="blue",
     xlim=xlims,ylim=ylims,pch=19,cex=.2)
lines(xlims,ylims,type="l",col="black")

plot(allobs8hrmax,kf8hrmax_new,type="p",col="blue",
     xlim=xlims,ylim=ylims,pch=19,cex=.2)
lines(xlims,ylims,type="l",col="black")


plot(allobs8hrmax,persist8hrmax,type="p",col="green",
     xlim=xlims,ylim=ylims,pch=19,cex=.2)
lines(xlims,ylims,type="l",col="black")

xlims <- c(0,110)
ylims <- c(0,110)

plot(allobs1hrmax,eqw1hrmax,type="p",col="red",
     xlim=xlims,ylim=ylims,pch=19,cex=.2)
lines(xlims,ylims,type="l",col="black")

plot(allobs1hrmax,kf1hrmax,type="p",col="blue",
     xlim=xlims,ylim=ylims,pch=19,cex=.2)
lines(xlims,ylims,type="l",col="black")

plot(allobs1hrmax,persist1hrmax,type="p",col="green",
     xlim=xlims,ylim=ylims,pch=19,cex=.2)
lines(xlims,ylims,type="l",col="black")


plot(kalmanlist$time[nt1:nt2],obs[nt1:nt2],type="l",lwd=2,
col="red")
lines(kalmanlist$time[nt1:nt2],pred[nt1:nt2],type="l",lwd=2,col="blue")
lines(kalmanlist$time[nt1:nt2],kalmanfilter[nt1:nt2,i],
type="l",lwd=2,col="purple")

nst <-12
i <- nst
obs <- allobs[,i]
models <- allmodels[,,i]

plot(seq(nt1,nt2),eqwpredplt[nt1:nt2,nst],type="l",lwd=2,col="blue",
ylim=c(0,70))
lines(seq(nt1,nt2),obsplt[nt1:nt2,nst],type="l",lwd=2,col="red")
lines(seq(nt1,nt2),kalmanfilter[nt1:nt2,nst],type="l",lwd=2,col="purple")




plot(seq(nt1,nt2),weights[nt1:nt2,1,nst],type="l",lwd=2,col="red",
ylim=c(0.05,.2))
lines(seq(nt1,nt2),weights[nt1:nt2,2,nst],type="l",lwd=2,col="blue")
lines(seq(nt1,nt2),weights[nt1:nt2,3,nst],type="l",lwd=2,col="purple")
lines(seq(nt1,nt2),weights[nt1:nt2,4,nst],type="l",lwd=2,col="green")
lines(seq(nt1,nt2),weights[nt1:nt2,5,nst],type="l",lwd=2,col="yellow")
lines(seq(nt1,nt2),weights[nt1:nt2,6,nst],type="l",lwd=2,col="orange")
lines(seq(nt1,nt2),weights[nt1:nt2,7,nst],type="l",lwd=2,col="brown")
#lines(seq(nt1,nt2),weights[nt1:nt2,8,nst],type="l",lwd=2,col="maroon")



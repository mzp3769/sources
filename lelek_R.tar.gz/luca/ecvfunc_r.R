ecvfunc <- function(h,f,s,n) {
   r <- seq(0.,1,by=(1./n))
   ecv <- array(NA,n)
   for (i in 1:n) {
      ecv[i] <- (min(s,r[i])-f*(1-s)*r[i]+h*s*(1-r[i])-s)/
                 (min(s,r[i])-s*r[i])
   }
   return(ecv)
}

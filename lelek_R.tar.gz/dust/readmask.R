library("fields")
fname <- "fort.110"
infile <- file(fname,"ra")
a <- readLines(infile)       
close(infile)
nvals <- length(a)

infile <- file(fname,"ra")

latlonmask <- array(NA,c(nvals,3))

for (k in 1:nvals) {
    	latlonmask[k,] <- scan(infile,what=0,n=3,quiet=TRUE)
}

close(infile)

png("mask_quilt.png",width = 575, height = 500,bg="white")
quilt.plot(latlonmask[,2],latlonmask[,1],latlonmask[,3],nrow=300,ncol=300)
dev.off()

#png("mask_image.png",width = 575, height = 500,bg="white")
#image.plot(latlonmask[,2],latlonmask[,1],latlonmask[,3],nrow=200,ncol=200)
#dev.off()

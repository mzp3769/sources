fname <- "fort.100"
infile <- file(fname,"ra")
data <- array(scan(infile,what=0,n=2,nlines=1))
nx <- data[1]
ny <- data[2]
mask <- array(NA,c(nx,ny))
for (i in 1:nx) {
for (j in 1:ny) {
    mask[i,j] <- scan(infile,what=0.,n=1,nlines=1,quiet=TRUE)
    }
}
close(infile)
png("mask.png",width = 630, height = 530,bg="lightgrey")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=mask)
dev.off()

stop("end")

fname <- "fort.102"
infile <- file(fname,"ra")
data <- array(scan(infile,what=0,n=2,nlines=1))
nx <- data[1]
ny <- data[2]
mask <- array(NA,c(nx,ny))
for (i in 1:nx) {
for (j in 1:ny) {
    mask[i,j] <- scan(infile,what=0.,n=1,nlines=1,quiet=TRUE)
    }
}
close(infile)
png("mask_2.png",width = 630, height = 530,bg="lightgrey")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=mask)
dev.off()



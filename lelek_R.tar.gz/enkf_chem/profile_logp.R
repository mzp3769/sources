#to plot two pm25 profiles
library(ncdf)

ncname <- './indata/test_824/dust_prof.nc'
nc <- open.ncdf(ncname, readunlim=FALSE )
dust_1 <- get.var.ncdf(nc,"DUST_1")
pb <- get.var.ncdf(nc,"PB")
pp <- get.var.ncdf(nc,"P")
close.ncdf(nc)

top <- 40
levels <- 1:top

pprof <- -log((pp+pb)/(pp[1]+pb[1]))

enkfprof1 <- dust_1
enkfprof2 <- dust_1


ymin <- min(pprof[1:top])
ymax <- max(pprof[1:top])
xmin <- min(enkfprof1,enkfprof2)
xmax <- max(enkfprof1,enkfprof2)+0.1*max(enkfprof1,enkfprof2)


xlabstring <- expression(
paste("DUST_1 ","[",mu,"g","  ",kg^{-1},"]",sep=""))
ylabstring <- expression(paste(-log,"(p/",p[s],")"))

#pdf("./pics/profile_dust.pdf",width = 3.5, height = 7,
#bg="white")

width <- 400
height <- 600

ylabstring <- expression(paste(-log,"(p/",p[s],")"))

png(paste("./pics/dust_prof.png",sep=''),
    width = width, height = height ,bg="white")

par(mar=c(5, 4.5, 4, 2)+0.1)

plot(enkfprof1[1:top],pprof[1:top],type="l",col="black",
xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",
cex.axis=1.5,cex.lab=1.5,lwd=3,cex=1.5,
xlim=c(xmin,xmax),ylim=c(ymin,ymax))
#lines(enkfprof2[1:top],pprof[1:top],col="orange",lwd=3)
#legend(x=xmax,y=ymax,xjust=1,yjust=1,
#col=c("violet","orange"),legend=c("No_Met","Met"),
#lwd=3,cex=0.9)

dev.off()



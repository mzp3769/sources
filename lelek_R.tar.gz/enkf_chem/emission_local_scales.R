library(ncdf)
library(spatial)
#library(nlme)
#require(stats)

resolution <- "24km"

system("cp ./indata/wrfchemi_12z_d01_24km ./outdata/wrfchemi_12z_d01_lscales_24km")

ncname <- "./outdata/wrfchemi_12z_d01_lscales_24km"

emismin <- 1.e-8

undef <- 1.  
missing <- 1.e+30

#undefined scale is when there is no enough points - no correlation

varnames <- c("E_PM25J","E_PM25I",
	      "E_ECJ","E_ECI",
              "E_ORGJ","E_ORGI",
	      "E_SO4J","E_SO4I",
	      "E_NO3J","E_NO3I")

nvars <- length(varnames)

scalenames <- paste("L_",varnames,sep='')

nc <- open.ncdf(ncname, readunlim=FALSE, write=TRUE )

xdim <- nc$dim[["west_east"]]
ydim <- nc$dim[["south_north"]]
zdim <- nc$dim[["emissions_zdim"]]
tdim <- nc$dim[["Time"]]

nx <- xdim$len 
ny <- ydim$len
nz <- zdim$len
nt <- tdim$len

xvec <- xdim$val
yvec <- ydim$val

nxy=nx*ny

tilesize <- 10

minpoints <- 100
nbins <- minpoints

varins <- array(NA,c(nvars,nx,ny,nz,nt))

for (ivar in 1:nvars) {

    print(varnames[ivar])
	 
    varins[ivar,,,,] <- get.var.ncdf(nc,varnames[ivar])

    xx <- array(NA,c(nxy))
    yy <- array(NA,c(nxy))
    varvec <- array(NA,c(nxy))

    scales <- array(undef,c(nx,ny,nt))	

    for (it in 1:nt) {

    print(it)

    var <- varins[ivar,,,1,it]

    for (jj in 1:ny) {
    for (ii in 1:nx) {

        k <- 1

	jmin <- max(1,jj-tilesize)
	jmax <- min(ny,jj+tilesize)

    	imin <- max(1,ii-tilesize)
    	imax <- min(nx,ii+tilesize)


    	for (j in (jmin:jmax)) {
    	for (i in (imin:imax)) {
    	    if (var[i,j] > emismin) {
       	    xx[k] <- xvec[i]
            yy[k] <- yvec[j] 
#    	    varvec[k] <- log(var[i,j])
            varvec[k] <- var[i,j]
		  k <- k+1
	    }
        }}

	npoints <- k-1

	if (npoints < minpoints) next 

	varframe <- data.frame(y=yy[1:npoints],x=xx[1:npoints],
	z=varvec[1:npoints])

	surface <- surf.ls(2,varframe)

        #correlogram(surface,nbins,lty=1,pch=19,cex=0.75,col="blue")

	corr <- correlogram(surface,nbins,plotit=FALSE)

	ind <- which(corr$y < 0.)
	ind1 <- ind[1]

	dx <- corr$x[ind1] - corr$x[ind1-1]
	y1 <- corr$y[ind1-1]
	y2 <- corr$y[ind1]

	scales[ii,jj,it] <- corr$x[ind1-1]+y1*dx/(y1-y2)

#print(c(ii,jj,scales[ii,jj]))
#locator()

#	print(c(ii,jj))

    }}

    xp <- 1:nx
    yp <- 1:ny

#    x11(width=6,height=6)

#    filled.contour(xp,yp,scales,xlim=range(xp),ylim=range(yp),
#    nlevels=10,color.palette=rainbow)

    }

    lscalevar <- var.def.ncdf(scalenames[ivar], 'gpoints', 
    list(xdim,ydim,tdim), missing )

    nc <- var.add.ncdf( nc, lscalevar )

    for( it in 1:nt) {
    	 put.var.ncdf(nc,scalenames[ivar],scales[,,it],start=c(1,1,it), 
    	 count=c(-1,-1,1))
    }
}

close.ncdf(nc)

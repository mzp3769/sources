#to plot modis stats for several test on single plot

tests <- c("test_816","test_817","test_818","test_824","test_825","test_826")
#danames <- c("NODA","SFC","SFC+AOD_M","SFC+AOD_EC")

tests <- c("test_903","test_904","test_910","test_911","test_912")

#tests <- c("test_824","test_825") #gsi: pm+aod vs. aod
#tests <- c("test_904","test_910")  #enkf: pm+aod vs. aod

#tests <- c("test_825","test_826")
#tests <- c("test_824","test_825")

#tests <- c("test_809","test_816","test_817","test_821","test_824","test_825","test_826")

#tests <- c("test_824","test_825")
#tests <- c("test_903","test_904","test_910")
#tests <- c("test_904","test_910")

#1:
tests <- c("test_821","test_809","test_818","test_825","test_826")
danames <- c("CLEAN","MOZ","AOD_MOZ","AOD_EC","AOD_NASA")

tests <- c("test_826","test_828")
danames <- tests

indir <- './outdata/'
outdir <- './pics/modis/'

ntests <- length(tests)

cols <- rainbow(ntests+1,start=0.,end=1.)

i <- 0       

for (test in tests) {

    i <- i+1

    fname <- paste(indir,'modis_',test,'.txt',sep='')    

    if (i == 1) {
        infile <- file(fname,"ra")
	header <-  scan(infile,what='a',nlines=1,sep=' ',quiet=TRUE)
    	a <- readLines(infile)       
    	close(infile)
	nfcsts <- length(a)
	nvars <- length(header)
	allvars <- array(NA,c(ntests,nfcsts,nvars))

    }

    infile <- file(fname,"ra")
    header <-  scan(infile,what='a',nlines=1,sep=' ',quiet=TRUE)
    
    for (j in 1:nfcsts) {
        allvars[i,j,] <- scan(infile,what=1,nlines=1,n=nvars,
	quiet=TRUE,sep=',')
    }

    close(infile)

}

xmin <- min(allvars[,1,1])
xmax <- max(allvars[,nfcsts,1])

for  (k in 2:nvars) {
    
    name <- header[k]

    if (name == 'correlation') {
        ymin <- -0.2
    	ymax <- 1
    } else { 
        ymin <- min(allvars[,,k])
        ymax <- max(allvars[,,k])+0.5
    }

    if (name == 'bias') {
	xpos <- xmin
	xjust <- 0
        ypos <- ymax
	yjust <- 1
    } else if (name == 'rmse') {
	xpos <- xmax
	xjust <- 1
        ypos <- ymin
	yjust <- 0
    } else { 
	xpos <- xmax
	xjust <- 1
      	ypos <- ymax
	yjust <- 1
    }


    xlabstring <- "forecast hour"
    ylabstring <- name

    pngname <- paste(outdir,'modis_',name,'.png',sep="")

    png(pngname,width=600, height=400,bg="white")

    plot(allvars[1,,1],allvars[1,,k],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
	type="l",pch=20,cex=.5,
    	cex.axis=1.,cex.lab=1.,
    	xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i",col=cols[1],
	lwd=4)

    for (j in 1:ntests) {
        lines(allvars[1,,1],allvars[j,,k],type='l',col=cols[j],lwd=4)
    }

    legend(x=xpos,y=ypos,xjust=xjust,yjust=yjust,col=cols,
           lwd=4,legend=danames,cex=1)


    dev.off()

}
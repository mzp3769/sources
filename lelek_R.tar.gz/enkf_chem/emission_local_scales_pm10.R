library(ncdf)
library(spatial)
#library(nlme)
#require(stats)

system("cp ./indata/wrfchemi_00z_d01.corr ./indata/wrfchemi_00z_d01_lscales_sector")

ncname <- "./indata/wrfchemi_00z_d01_lscales_sector"

varnames <- c("E_PM_10")

nvars <- length(varnames)


#for Canada and Mexico
emismin <- c(1.e-4,1.e-4,
             1.e-4,1.e-5,
             1.e-4,1.e-5,
             1.e-5,1.e-6,
             1.e-6,1.e-7,
	     1.e-2)


emismin <- array(1.e-3,nvars)


undef <- 1.  
missing <- 1.e+30

#undefined scale is when there is no enough points - no correlation


scalenames <- paste("L_",varnames,sep='')

nc <- open.ncdf(ncname, readunlim=FALSE, write=TRUE )

xdim <- nc$dim[["west_east"]]
ydim <- nc$dim[["south_north"]]
zdim <- nc$dim[["emissions_zdim"]]
tdim <- nc$dim[["Time"]]

nx <- xdim$len 
ny <- ydim$len
nz <- zdim$len
nt <- tdim$len

xvec <- xdim$val
yvec <- ydim$val

nxy=nx*ny

tilesize <- 10

minpoints <- 100
nbins <- minpoints

varins <- array(NA,c(nvars,nx,ny,nz,nt))

for (ivar in 1:nvars) {

    string <- varnames[ivar]

    if ( substr(string,nchar(string),nchar(string)) == 'I' ) {
        skip <- TRUE
    } else {
        skip <- FALSE
    }    

    if ( !skip ) {

    varins[ivar,,,,] <- get.var.ncdf(nc,varnames[ivar])

    xx <- array(NA,c(nxy))
    yy <- array(NA,c(nxy))
    varvec <- array(NA,c(nxy))

    scales <- array(undef,c(nx,ny,nt))	

    for (it in 1:nt) {

        print(c(it,varnames[ivar]))

    	var <- varins[ivar,,,1,it]

    	for (jj in 1:ny) {
    	for (ii in 1:nx) {

	if (var[ii,jj] <= emismin[ivar]) next	

            k <- 1

	    jmin <- max(1,jj-tilesize)
	    jmax <- min(ny,jj+tilesize)

    	    imin <- max(1,ii-tilesize)
    	    imax <- min(nx,ii+tilesize)

    	    for (j in (jmin:jmax)) {
    	    for (i in (imin:imax)) {
    	    	if (var[i,j] > emismin[ivar]) {
       	    	   xx[k] <- xvec[i]
            	   yy[k] <- yvec[j] 
    	    	   varvec[k] <- log(var[i,j])
           	   #varvec[k] <- var[i,j]
		   k <- k+1
	    	}
            }}

	    npoints <- k-1

	    if (npoints < minpoints) next 

	    varframe <- data.frame(y=yy[1:npoints],x=xx[1:npoints],
	    z=varvec[1:npoints])

	    surface <- surf.ls(2,varframe)

            #correlogram(surface,nbins,lty=1,pch=19,cex=0.75,col="blue")

	    corr <- correlogram(surface,nbins,plotit=FALSE)

	    ind <- which(corr$y < 0.)
	    ind1 <- ind[1]

	    dx <- corr$x[ind1] - corr$x[ind1-1]
	    y1 <- corr$y[ind1-1]
	    y2 <- corr$y[ind1]

	    scales[ii,jj,it] <- corr$x[ind1-1]+y1*dx/(y1-y2)

#print(c(ii,jj,scales[ii,jj,it]))
#locator()

#	    print(c(ii,jj))

        }}

    	xp <- 1:nx
    	yp <- 1:ny

#       x11(width=6,height=6)

#       filled.contour(xp,yp,scales,xlim=range(xp),ylim=range(yp),
#       nlevels=10,color.palette=rainbow)

    }

    } #skip=TRUE

    lscalevar <- var.def.ncdf(scalenames[ivar], 'gpoints', 
    list(xdim,ydim,tdim), missing )

    nc <- var.add.ncdf( nc, lscalevar )

    put.var.ncdf(nc,scalenames[ivar],scales,start=c(1,1,1), 
    	      count=c(-1,-1,-1))

}

close.ncdf(nc)

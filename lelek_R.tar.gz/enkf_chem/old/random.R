#2006
#o3 stations = 1325
#pm stations = 626
#2007 -07-08
#o3 stations = 1393 
#pm stations = 685

nsto3 <- 1392
nstpm <- 695
fraction=.5
 
for (i in 1:100) {
    x <- sort(sample(1:nsto3, fraction*nsto3, replace=F))
    write(x,file=paste('random_o3_',fraction*100,'.',i,sep=''),
    ncolumns=1,append=FALSE)
    }

for (i in 1:100) {
    x <- sort(sample(1:nstpm, fraction*nstpm, replace=F))
    write(x,file=paste('random_pm2.5_',fraction*100,'.',i,sep=''),
    ncolumns=1,append=FALSE)
    }



cycle_times <- seq(date_skip,by=cycle_freq*3600,length=ncycles)

i <- 1
times_ave <- dateseries[[i]][1:fcst_length]

for (i in 2:ncycles) {
    times_ave <- c(times_ave,dateseries[[i]][1:fcst_length])
}

i <- 0

for (k in 1:ntests) {
for (j in 1:ncycles) {
i <- i+1
allstatseries[[i]][1:(days2skip*fcst_length)] <- NA
}}


#for pm(seed <- ?,black), voc(seed <- ?,red)  nh3(seed <- 18,green)
#bio(seed <- 51)

mu <- -.1
sigma <- .55
x11(width=5,height=5)
plot(function(x) {dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
xlim=c(0,5))
ex <- exp(mu+.5*sigma^2)
varx <- exp(2*mu + sigma^2)*(exp(sigma^2) - 1)

#new 
mu <- .1
sigma <- .55
plot(function(x) {dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
xlim=c(0,5))
ex <- exp(mu+.5*sigma^2)
varx <- exp(2*mu + sigma^2)*(exp(sigma^2) - 1)




#for no (seed <- 21)
mu <- -.08
sigma <- .35
plot(function(x) {dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
xlim=c(0,5))
ex <- exp(mu+.5*sigma^2)
varx <- exp(2*mu + sigma^2)*(exp(sigma^2) - 1)

seed <- 10
mu <- 0
sigma <- 1
m <- mu
s <- sigma
set.seed(seed, kind = NULL)

x <- rlnorm(50, mean=mu, sd=sigma)
z <- dlnorm(x,mean=mu,sd=sigma, log = FALSE)


points(x,z,type="p",col="red")

x11(width=5,height=5)
#plot(function(x) {dlnorm(x,meanlog=mu,sdlog=sigma, log = FALSE)},
#xlim=c(-5,5))

plot(x,z,type="p",cex=.5,col="blue",xlim=c(-5,5))

y <- log(x)

plot(function(y) {dnorm(y,mean=mu,sd=sigma)},xlim=c(-5,5))


#points(x,z,type="p")
points(y,z,type="p",cex=.5,col="red")



v <- dnorm(y,mean=mu,sd=sigma)
x11(width=5,height=5)
plot(function(y) {dnorm(y,mean=mu,sd=sigma)})
points(y,v)


par(col="black")


qlnorm(x), meanlog = mu, sdlog = sigma, lower.tail = TRUE, log.p = FALSE)
plnorm(x), meanlog = 0, sdlog = 1, lower.tail = TRUE, log.p = FALSE)


par(col="black")
plot(function(x) {dnorm(x,mean=1,sd=0.5, log = FALSE)},0:5)
x <- rnorm(100, mean=1, sd=.5)
qqnorm(x)# to check for normal distribution




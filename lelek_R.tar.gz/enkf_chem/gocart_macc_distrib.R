#to calculate dust and sea salt fractions from macc to wrf-chem
#from zender 2003 split function

erf <- function(x) {
    2 * pnorm(x*sqrt(2)) - 1
}

split_function <- function(dmin_j,dmax_j,stdev_i,dv_i) {

    xmin <- log(dmin_j/dv_i)/(sqrt(2)*log(stdev_i))
    xmax <- log(dmax_j/dv_i)/(sqrt(2)*log(stdev_i))
    split_function <- 0.5*(erf(xmax)-erf(xmin))

}

diameter_tot <- 1000. # a large diameter to get total valus of integral


#dust 

n_dust_bins_gocart <- 5
n_dust_bins_macc <- 3

#gocart dust bins from Stu. here only for reference not used
#0.2 - 2.0 micron diameter  = 0.11
#2.0-3.6 micron diameter = 0.22
#3.6-6.0 micron diameter = 0.27
#6.0-12.0 micron diameter = 0.30
#12.0 - 20.0 micron diameter = 0.11

diameters_dust_bins_gocart <- c(0.2,2.0,3.6,6.0,12.0,20.0)
diameters_dust_bins_macc <- c(0.03,0.55,0.9,20.)*2 # from radius to diameter

n_dust_distrib_macc <- 1
stdevs_dust_distrib_macc <- c(2.0)
diameters_dust_distrib_macc <- c(0.29)*2

diameters_v_dust_distrib_macc <- exp(log(diameters_dust_distrib_macc)+
		       3.*(log(stdevs_dust_distrib_macc))^2)

n_conc <- c(1.0)

integrals_dust_gocart <- array(0.,n_dust_bins_gocart+1)
splits_dust_gocart <- array(0.,c(n_dust_bins_macc,n_dust_bins_gocart))

for (i in 1:n_dust_distrib_macc) {
    for (j in 1:(n_dust_bins_gocart+1)) {
        integrals_dust_gocart[j] <- integrals_dust_gocart[j] + 
    	split_function(0,
		       diameters_dust_bins_gocart[j],
                       stdevs_dust_distrib_macc[i],
		       diameters_v_dust_distrib_macc[i])*n_conc[i]

}}

integrals_dust_macc <- array(0.,n_dust_bins_macc+1)

for (i in 1:n_dust_distrib_macc) {
    for (j in 1:n_dust_bins_macc+1) {
        integrals_dust_macc[j] <- integrals_dust_macc[j] + 
    	split_function(0,
		       diameters_dust_bins_macc[j],
                       stdevs_dust_distrib_macc[i],
		       diameters_v_dust_distrib_macc[i])*n_conc[i]

}}

integral_dust_macc_tot <- 0

for (i in 1:n_dust_distrib_macc) {
        integral_dust_macc_tot <- integral_dust_macc_tot+
        split_function(0,
                       diameter_tot,
                       stdevs_dust_distrib_macc[i],
                       diameters_v_dust_distrib_macc[i])*n_conc[i]
}


integrals_dust_gocart <- integrals_dust_gocart/integral_dust_macc_tot
integrals_dust_macc <- integrals_dust_macc/integral_dust_macc_tot

#p25 = macc_1*(integrals_dust_gocart[1]-integrals_dust_macc[1])

p25_dust_split <- (integrals_dust_gocart[1]-integrals_dust_macc[1])/
	      (integrals_dust_macc[2]-integrals_dust_macc[1]) 
	     

#gocart_bins
splits_dust_gocart[1,1] <- (1-p25_dust_split)
splits_dust_gocart[2,1] <- 1

splits_dust_gocart[3,1] <- (integrals_dust_gocart[2]-
			   integrals_dust_macc[3])/
			   (integrals_dust_macc[4]-
			    integrals_dust_macc[3])

splits_dust_gocart[1,2] <- 0
splits_dust_gocart[2,2] <- 0
splits_dust_gocart[3,2] <- (integrals_dust_gocart[3]-
			   integrals_dust_gocart[2])/
			   (integrals_dust_macc[4]-
                            integrals_dust_macc[3])

for (i in 3:n_dust_bins_gocart) {
    splits_dust_gocart[3,i] <- (integrals_dust_gocart[i+1]-
                               integrals_dust_gocart[i])/
			       (integrals_dust_macc[4]-
                                integrals_dust_macc[3])

}

print("p25_dust_split")
print(p25_dust_split)
print("splits_dust_gocart[i,j], i_mac -> j_gocart")
print(splits_dust_gocart)


#seas 
#gocart bins are for dry seasalt
#macc bins are for seasalt at 80% rh - need to be factored by 0.503
#from  macc table
#      DATA RH_tab/0.,10.,20,30.,40.,50.,60.,70.,80.,85.,90.,95./
#      DATA rh_growth/0.503, 0.503, 0.503, 0.503, 0.724,
#      0.782, 0.838, 0.905, 1.000, 1.072, 1.188, 1.447/

rh_dry_factor <- 0.503

n_seas_bins_gocart <- 4
n_seas_bins_macc <- 3

#gocart seas salt
#0.2 - 1.0 micron diameter  
#1.0 - 3.0 micron diameter 
#3.0 - 10.0 micron diameter 
#10.0 - 20.0 micron diameter 

#macc diameters are assumed dry on output and  
#distribution is corrected to be dry
#also macc bins are for wet not dry seas so need to be corrected

diameters_seas_bins_gocart <- c(0.2,1.0,3.0,10.0,20.0)
diameters_seas_bins_macc <- c(0.03,0.5,5.,20.)*2 # from radius to diameter
#diameters_seas_bins_macc <- diameters_seas_bins_macc*rh_dry_factor 


n_seas_distrib_macc <- 2
stdevs_seas_distrib_macc <- c(1.9,2.0)
diameters_seas_distrib_macc <- c(0.19921, 1.992)*rh_dry_factor

diameters_v_seas_distrib_macc <- exp(log(diameters_seas_distrib_macc)+
		       3.*(log(stdevs_seas_distrib_macc))^2)

n_conc <- c(70.,3.)

integrals_seas_gocart <- array(0.,n_seas_bins_gocart+1)
splits_seas_gocart <- array(0.,c(n_seas_bins_macc,n_seas_bins_gocart))

for (i in 1:n_seas_distrib_macc) {
    for (j in 1:(n_seas_bins_gocart+1)) {
        integrals_seas_gocart[j] <- integrals_seas_gocart[j]+	 
    	split_function(0,
		       diameters_seas_bins_gocart[j],
                       stdevs_seas_distrib_macc[i],
		       diameters_v_seas_distrib_macc[i])*n_conc[i]

}}


integrals_seas_macc <- array(0.,n_seas_bins_macc+1)

for (i in 1:n_seas_distrib_macc) {
    for (j in 1:n_seas_bins_macc+1) {
        integrals_seas_macc[j] <- integrals_seas_macc[j] + 
    	split_function(0,
		       diameters_seas_bins_macc[j],
                       stdevs_seas_distrib_macc[i],
		       diameters_v_seas_distrib_macc[i])*n_conc[i]
}}

integral_seas_macc_tot <- 0

for (i in 1:n_seas_distrib_macc) {
        integral_seas_macc_tot <- integral_seas_macc_tot+
        split_function(0,
                       diameter_tot,
                       stdevs_seas_distrib_macc[i],
                       diameters_v_seas_distrib_macc[i])*n_conc[i]
}


integrals_seas_gocart <- integrals_seas_gocart/integral_seas_macc_tot
integrals_seas_macc <- integrals_seas_macc/integral_seas_macc_tot


#p25 = macc_1*(integrals_seas_gocart[1]-integrals_seas_macc[1])

p25_seas_split <- (integrals_seas_gocart[1]-integrals_seas_macc[1])/
	      (integrals_seas_macc[2]-integrals_seas_macc[1]) 
	     

#gocart_bin_1
splits_seas_gocart[1,1] <- (1-p25_seas_split)
splits_seas_gocart[2,1] <- 0
splits_seas_gocart[3,1] <- 0

splits_seas_gocart[1,2] <- 0
splits_seas_gocart[2,2] <- (integrals_seas_gocart[3]-
                            integrals_seas_macc[2])/
                            (integrals_seas_macc[3]-
			     integrals_seas_macc[2])
splits_seas_gocart[3,2] <- 0

splits_seas_gocart[1,3] <- 0
splits_seas_gocart[2,3] <- 1 - splits_seas_gocart[2,2]
splits_seas_gocart[3,3] <- 0

splits_seas_gocart[1,4] <- 0
splits_seas_gocart[2,4] <- 0
splits_seas_gocart[3,4] <- (integrals_seas_gocart[5]-
                            integrals_seas_macc[3])/
                            (integrals_seas_macc[4]-
                             integrals_seas_macc[3])

print("p25_seas_split")
print(p25_seas_split)
print("splits_seas_gocart[i,j], i_mac -> j_gocart")
print(splits_seas_gocart)




recfilter1d <- function(field,rf_scale,pass) {
#from routine da_recursive_filter_1d.inc in wrfvar

a <- field
n <- length(a)
b <- c(0,n)
c <- b

e <- 0.25 * pass / (rf_scale * rf_scale)
alpha <- 1 + e - sqrt(e * (e + 2.0))
one_alpha <- 1-alpha

if (pass == 1) {
   b[1] <- one_alpha * a[1]
} else if (pass == 2) {
     b[1] <- a[1] / (1.0 + alpha)	
     } else {
     b[1] <- one_alpha * (a[1] - alpha**3 * a[2]) / (1.0 - alpha^2)^2	
}


for (j in 2:n) {
      b[j] <- alpha * b[j-1] + one_alpha * a[j]
}

if (pass == 1) {
   c[n] <- b[n] / (1.0 + alpha)
} else {
   c[n] <- one_alpha * (b[n] - alpha**3 * b[n-1]) / (1.0 - alpha**2)**2
}

for (j in (seq(from=(n-1),to=1,by=-1))) {
   c[j] <- alpha * c[j+1] + one_alpha * b[j]
}

fieldnew <- c[1:n]

recfilter1d <- fieldnew
}


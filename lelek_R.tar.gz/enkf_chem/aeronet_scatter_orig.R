#to plot stats for aeronet with forecasts of different length separately

test <- "test_818"
indir <- paste('./indata/',test,'/aeronet',sep='')
outdir <- './pics/aeronet/'

picratio <- 1.07

fcsts <- as.character(seq(from=0,to=9,by=1))
nfcsts <- length(fcsts)

year <- "2012"
months <- c("06","07","08")
nmonths <- length(months)

nvals <-  array(0,nmonths)
ncols <- 3
aods <- c(1640,1020,870,675,500,440,340)

#340 for model is not calculated
l_340 <- 7


naods <- length(aods)

correls <-  array(NA,c(naods,nfcsts)) 
ndatas <- array(NA,c(naods,nfcsts))
bias <- array(NA,c(naods,nfcsts))

n <- 0	

for (fcst in fcsts) {

    fnames <- paste(indir,'/fcst_',year,months,'_',fcst,'.txt',sep='')

    i <- 0

    for (fname in fnames) {
        infile <- file(fname,"ra")
    	a <- readLines(infile)       
    	close(infile)
    	i <- i+1
    	nvals[i] <- (length(a)-1)/4
    }

    allnvals <- sum(nvals)

    vars <- array(NA,c(allnvals,2,naods))
    site <- array(NA,allnvals)
    coords <- array(NA,c(allnvals,3))

    j <- 0
    i <- 0

    for (fname in fnames) {
    infile <- file(fname,"ra")
    date <-  scan(infile,what='a',nlines=1,quiet=TRUE)
    print(date)

    i <- i+1

    for (k in 1:nvals[i]) {
    	j <- j+1
    	site[j] <- scan(infile,what='a',nlines=1,quiet=TRUE)
	coords[j,] <- array(scan(infile,what=0,n=ncols,nlines=1,
	       quiet=TRUE))
        vars[j,1,] <- array(scan(infile,what=0,n=naods,nlines=1,
	       quiet=TRUE))
 	vars[j,2,] <- array(scan(infile,what=0,n=naods,nlines=1,
	       quiet=TRUE))
    }

    close(infile)

    }

    for (l in 1:naods) {

    	xmin <- 0
    	xmax <- max(vars[,,l])
#    xmax <- 1.5
        xlabstring <- paste("obs_",aods[l],sep='')
    	ylabstring <-  paste("model_",aods[l],sep='')	

    	pngname <- paste(outdir,'fcst_',aods[l],'_',fcst,'_',test,
	'.png',sep="")

	png(pngname,width=600, height=600*picratio,bg="white")

	plot(vars[,2,l],vars[,1,l],xlim=c(xmin,xmax),ylim=c(xmin,xmax),
	type="p",pch=20,cex=.5,
    	cex.axis=1.,cex.lab=1.,
    	xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

	x <- seq(0,xmax,by=xmax/10)

    	lines(x,x,type='l',col='red',lwd=2)

	dev.off()
	
    }

    n <- n+1 

    for (l in 1:naods) {    

    newvar <- apply(vars[,,l],1:2,FUN=function(x) ifelse(x >= 0,x,NA))

    correls[l,n] <-  cor(newvar[,1],newvar[,2],
    use='pairwise.complete.obs')
    ndatas[l,n] <- sum(!!is.na(newvar[,2]))
    bias[l,n] <- mean(newvar[,1]-newvar[,2],na.rm=TRUE)

    }

}

l <- 0

while (l < l_340) {

    l <- l+1

    pngname <- paste(outdir,'correl_',aods[l],'_',test,'.png',sep="")
    png(pngname,width=600, height=400.,bg="white")

    xlabstring <- 'Forecast hour'
    ylabstring <- paste('Correlation',aods[l])

    plot(as.numeric(fcsts),correls[l,],xlim=c(0,nfcsts-1),ylim=c(0,1),
        type="l",lwd=4,
        cex.axis=1.,cex.lab=1.,
        xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

    dev.off()

    pngname <- paste(outdir,'bias_',aods[l],'_',test,'.png',sep="")
    png(pngname,width=600, height=400.,bg="white")

    xlabstring <- 'Forecast hour'
    ylabstring <- paste('Bias',aods[l])

    ymax <- max(bias[l,],na.rm=TRUE)
    ymin <- min(bias[l,],na.rm=TRUE)

    plot(as.numeric(fcsts),bias[l,],
	xlim=c(0,nfcsts-1),ylim=c(ymin,ymax),
        type="l",lwd=4,
        cex.axis=1.,cex.lab=1.,
        xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

    dev.off()

    pngname <- paste(outdir,'ndatas_',aods[l],'_',test,'.png',sep="")
    png(pngname,width=600, height=400.,bg="white")

    xlabstring <- 'Forecast hour'
    ylabstring <- paste('Number of observations',aods[l])

    ymax <- max(ndatas[l,],na.rm=TRUE)
    ymin <- min(ndatas[l,],na.rm=TRUE)

    plot(as.numeric(fcsts),ndatas[l,],
	xlim=c(0,nfcsts-1),ylim=c(ymin,ymax),
        type="l",lwd=4,
        cex.axis=1.,cex.lab=1.,
        xlab=xlabstring,ylab=ylabstring,xaxs="i",yaxs="i")

    dev.off()

    }    

    outfile <- paste('./outdata/aeronet_',aods[l],'_',test,'.txt',sep='')

    system(paste('rm -f',outfile))

    write('fcst_hour ndatas bias correlations',
    file=outfile,append=TRUE,sep='   ')

    i <- 0
    for (fcst in fcsts) {
    	i <- i+1
    	write(c(i-1,ndatas[l,i],bias[l,i],correls[l,i]),
	    file=outfile,append=TRUE,sep=',   ',ncolumns=4)
    }
   
}


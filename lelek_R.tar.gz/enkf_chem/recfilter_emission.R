library(ncdf)
require(stats)

varname <- "E_PM25J"
source("recfilter1d.R")

emismin <- 1.e-10

ncname <- "./indata/wrfchemi_00z_d01"
nc <- open.ncdf(ncname, readunlim=FALSE )
x <- get.var.ncdf(nc,"west_east")
y <- get.var.ncdf(nc,"south_north")
z <- get.var.ncdf(nc,"emissions_zdim")
nx <- length(x)
ny <- length(y)
nz <- length(z)

nxy=nx*ny
varin <- get.var.ncdf(nc,varname)

close.ncdf(nc)

var <- varin[,,1,1]
varold <- var
var_incr <- array(NA,c(nx,ny))

#var <- log(pmax(varin[,,1,1],emismin))

seed <- 3
stdev <- 10
mu <- 0

set.seed(seed, kind = NULL)
randvect <- rnorm(nxy, mean=mu, sd=stdev)
#randvect <- rlnorm(nxy, mean=mu, sd=stdev)

ij <- 0

for (i in 1:nx) {
for (j in 1:ny) {
ij <- ij+1
var_incr[i,j] <- randvect[ij]
}}

l_log_gaspari <- 10 #E_PM25J all log scalea are same after removing water

lscale <- l_log_gaspari*0.388/sqrt(8)

num_passes <- 4

for (pass in 1:num_passes) {
#   Perform filter in I-direction:
   for (j in 1:ny) {
      var_incr[1:nx,j] <- recfilter1d(var_incr[1:nx,j],lscale,pass)
#         call da_recursive_filter_1d(pass, alpha, field(1:ni,j), ni)

   }
#   Perform filter in J-direction:
   for (i in 1:nx) {
      var_incr[i,1:ny] <- recfilter1d(var_incr[i,1:ny],lscale,pass)
#         call da_recursive_filter_1d(pass, alpha, field(i,1:nj), nj)
   }
}

#par(mai=c(0.2,0.2,0.2,0.2))
#x11(width=6,height=4)
#filled.contour(x[1:nx],y[1:ny],exp(var_incr[1:nx,1:ny]),
#xaxs = "i", yaxs = "i",nlevels=20,color.palette=rainbow)

x11(width=6,height=4)
filled.contour(x[1:nx],y[1:ny],
var[1:nx,1:ny]*(exp(var_incr[1:nx,1:ny])-1.),
xaxs = "i", yaxs = "i",nlevels=20,color.palette=rainbow)


#x11(width=8,height=5)
#filled.contour(x[1:nx],y[1:ny],var[1:nx,1:ny],
#xaxs = "i", yaxs = "i",nlevels=20,color.palette=rainbow)

#x11(width=8,height=5)
#filled.contour(x[1:nx],y[1:ny],var[1:nx,1:ny]*exp(var_incr[1:nx,1:ny]),
#xaxs = "i", yaxs = "i",nlevels=20,color.palette=rainbow)





#image(x[1:nx1], y[1:ny1], var_incr[1:nx1,1:ny1],col=rainbow(20))

#dx <- 1
#dy <- 1

#emiss <- setup.image.smooth( nrow=ny, ncol=nx,  dx=dx, dy=dy,
#             theta=5, xwidth=5, ywidth=5)

# <- image.smooth(var_incr, dx=dx, dy=dy, emiss)
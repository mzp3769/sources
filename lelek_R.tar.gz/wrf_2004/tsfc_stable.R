namea <- "./stable/myjsfc_cor.txt"
nameb <- "./stable/mrfsfc_cor.txt"
namec <- "./stable/ysusfc_cor.txt"
ncols <- 12
colz <- 2
colsim <- 9
colphy <- 10

xlabstring=expression((Theta - Theta[s]) / Theta["*"])
ylabstring=expression(log ( Z / z[h]) )

#png("theta.png",width = 380, height = 360,bg="lightblue")

pdf("tsfc_stable.pdf")

#colc <- 5
#xlabstring="            v                                [m/s]                                 u          "
#x11()
#dev.set(11)

infile <- file(namea,"ra")
a <- readLines(infile)
nlevs <- length(a)
close(infile)

infile <- file(namea,"ra")
vara <-array(0,c(nlevs,ncols))	
for (i in 1:nlevs) {
	vara[i,] <- array(scan(infile,what=0.,n=ncols))
}
close(infile)

infile <- file(nameb,"ra")
varb <-array(0,c(nlevs,ncols))	
for (i in 1:nlevs) {
	varb[i,] <- array(scan(infile,what=0.,n=ncols))
}
close(infile)

infile <- file(namec,"ra")
varc <-array(0,c(nlevs,ncols))	
for (i in 1:nlevs) {
	varc[i,] <- array(scan(infile,what=0.,n=ncols))
}
close(infile)

xmin <- round(min(vara[,colphy]-1,varb[,colphy]-1,varc[,colphy]-1,
vara[,colsim]-1,varb[,colsim]-1,varc[,colsim]-1))
xmax <- round(max(vara[,colphy]+1,varb[,colphy]+1,varc[,colphy]+1))
margin=c(.9,.9,.1,.15)
par(mai=margin)
plot(vara[,colphy],vara[,colz],"l",col="red",
xlim=c(xmin,xmax),lwd=5,font.lab=1,
xlab=xlabstring,ylab=ylabstring,
cex.axis=1.15,cex.lab=1.45)#
lines(varb[,colphy],varb[,colz],"l",col="blue",lwd=5)
lines(varc[,colphy],varc[,colz],"l",col="green",lwd=5)

lines(vara[,colsim],vara[,colz],"l",col="red",lwd=5,lty=5)
lines(varb[,colsim],varb[,colz],"l",col="blue",lwd=5,lty=5)
lines(varc[,colsim],varc[,colz],"l",col="green",lwd=5,lty=5)


#legend(68.,3.6,c("MYJ","MRF","YSU"),col=c("red","blue","green"),
#lwd=5,bty="o")
text(10.5,5.45,labels="b",cex=1.6)

#par(omi=margin,xlim=c(xmin,xmax),lwd=5,font.lab=1,
#xlab=xlabstring,ylab=ylabstring,
#xaxs="i",yaxs="i",cex.axis=1.25,cex.lab=1.25)
#plot.new()



#dev.off()

#demo(Hershey)

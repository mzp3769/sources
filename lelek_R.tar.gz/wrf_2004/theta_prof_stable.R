namea <- "./stable/myjprof_cor.txt"
nameb <- "./stable/mrfprof_cor.txt"
namec <- "./stable/ysuprof_cor.txt"
ncols <- 16
cola <- 1
colb <- 6

xlabstring=expression(Theta(K))
ylabstring=expression(Z(m))

#png("theta.png",width = 380, height = 360,bg="lightblue")

pdf("theta_stable.pdf")

#colc <- 5
#xlabstring="            v                                [m/s]                                 u          "
#x11()
#dev.set(11)

infile <- file(namea,"ra")
a <- readLines(infile)
nlevs <- length(a)
close(infile)

infile <- file(namea,"ra")
vara <-array(0,c(nlevs,ncols))	
for (i in 1:nlevs) {
	vara[i,] <- array(scan(infile,what=0.,n=ncols))
}
close(infile)

infile <- file(nameb,"ra")
varb <-array(0,c(nlevs,ncols))	
for (i in 1:nlevs) {
	varb[i,] <- array(scan(infile,what=0.,n=ncols))
}
close(infile)

infile <- file(namec,"ra")
varc <-array(0,c(nlevs,ncols))	
for (i in 1:nlevs) {
	varc[i,] <- array(scan(infile,what=0.,n=ncols))
}
close(infile)

xmin <- round(min(vara[,colb]-1,varb[,colb]-1,varc[,colb]-1))
xmax <- 300.
ymin <- 0
ymax <- 1600.
margin=c(.9,.9,.1,.15)
par(mai=margin)
plot(vara[,colb],vara[,cola],"l",col="red",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),
lwd=5,font.lab=1,
xlab=xlabstring,ylab=ylabstring,
xaxs="i",yaxs="i",cex.axis=1.15,cex.lab=1.45)#
lines(varb[,colb],varb[,cola],"l",col="blue",lwd=5)
lines(varc[,colb],varc[,cola],"l",col="green",lwd=5)
text(285.25,1500,labels="a",cex=1.6)

#par(omi=margin,xlim=c(xmin,xmax),lwd=5,font.lab=1,
#xlab=xlabstring,ylab=ylabstring,
#xaxs="i",yaxs="i",cex.axis=1.25,cex.lab=1.25)
#plot.new()



#dev.off()

#demo(Hershey)

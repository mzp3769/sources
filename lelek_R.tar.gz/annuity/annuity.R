initial_capital=100.e3
nyears <- 22
maxyears <- 12
first_year <- 1996
years <- seq(first_year,first_year+nyears-1,by=1)

jpm <- array(NA,c(nyears,maxyears+1))
sp <- array(NA,c(nyears,maxyears+1))

jpm_growth <- 
c(2.42,8.09,7.63,4.30,6.30,2.37,6.74,14.42,4.13,6.43,4.63,6.77,
  4.27,2.32,6.71,5.74,4.51,7.65,10.23,0.09,11.82,7.36)/100.

sp_growth <- 
c(NA,  NA,  NA,  NA,   NA,  NA, -22.10,28.70,10.90,5.80, 15.80,5.50,
-37.00,26.50, 15.10,-18.00,16.00,32.40,13.70,1.30,12.16,21.76)/100.

i <- 0
for (year in years) {
    i <- i+1
    if (is.na(jpm_growth[i])) next
    jpm_init <- initial_capital
    jpm[i,1] <- jpm_init
    k <- 1
    if (i <= nyears) {
        for (j in i:nyears)	{
    	    jpm_init <- jpm_init*(1.+jpm_growth[j])        
	    k <- k+1
            jpm[i,k] <- jpm_init
	    if (k == maxyears+1 ) break
	}
    }
#    print(c(year,jpm_init)) 
}

i <- 0
for (year in years) {
    i <- i+1
    if (is.na(sp_growth[i])) next
    sp_init <- initial_capital
    sp[i,1] <- sp_init
    k <- 1
    if (i <= nyears) {
        for (j in i:nyears)	{
    	    sp_init <- sp_init*(1.+sp_growth[j])        
	    k <- k+1
            sp[i,k] <- sp_init
	    if (k == maxyears+1 ) break
	}
    }
#    print(c(year,sp_init)) 
}

xmin <- years[1]
xmax <- years[nyears]
ymax <- max(sp,jpm,na.rm=TRUE)
ymin <- 0.


fict <- seq(ymin,ymax,length.out=nyears)

ymax_axis <- (ymax%/%initial_capital+1)*initial_capital
 
png("jpm.png",width = 750, height = 500,bg="white")
plot(1:nyears,fict,type='n',axes=FALSE,ann=FALSE,xlim=c(xmin,xmax),
ylim=c(ymin,ymax))
i <- 1
for (year in years) {
    lines(year:(year+maxyears),jpm[i,],col='blue',lwd=3)
#    lines(year:(year+maxyears),sp[i,],col='red',lwd=3)
    i <- i+1
}   
axis(side=1,pos=ymin,at=seq(years[1],years[nyears],by=2))
axis(side=2,pos=xmin,at=seq(0,ymax_axis,by=initial_capital))
dev.off()


png("sp.png",width = 750, height = 500,bg="white")
plot(1:nyears,fict,type='n',axes=FALSE,ann=FALSE,xlim=c(xmin,xmax),
ylim=c(ymin,ymax))
i <- 1
for (year in years) {
    lines(year:(year+maxyears),sp[i,],col='red',lwd=3)
    i <- i+1
}   
axis(side=1,pos=ymin,at=seq(years[1],years[nyears],by=2))
axis(side=2,pos=xmin,at=seq(0,ymax_axis,by=initial_capital))
dev.off()


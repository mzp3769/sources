library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
timeall <- c("23:30z")
pblall <- c("ysu","mrf","myj")#,"gfs")
pblall <- c("myj")
soilall <- c("noah","ruc","frb","flux")
soilall <- c("frb")
#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13

ufield <- "U"
vfield <- "V"
varname <- "UV"
ugfield <- "U_G"
vgfield <- "V_G"


for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

print(time)
print(pbl)
print(soil)


ncname <- paste(dir,"/","obs_prof.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varnameu <- ufield
uobs <- get.var.ncdf( nc, varnameu )
varnamev <- vfield
vobs <- get.var.ncdf( nc, varnamev )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)

uvobs <- sqrt(uobs^2+vobs^2)

if (pbl == "mrf") laba <- "a"
if (pbl == "ysu") laba <- "b"
if (pbl == "myj") laba <- "c"
if (pbl == "gfs") laba <- "d"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
if (soil == "frb") lab <- paste(laba,"c",sep="")
if (soil == "flux") lab <- paste(laba,"d",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

levs <- "Z"
plevs <- "P"

nc <- open.ncdf(ncname, readunlim=FALSE )
varnameu <- ufield
um <- get.var.ncdf( nc, varnameu )
varnamev <- vfield
vm <- get.var.ncdf( nc, varnamev )


varnameug <- ugfield
ugm <- get.var.ncdf( nc, varnameug )
varnamevg <- vgfield
vgm <- get.var.ncdf( nc, varnamevg )


uvm <- sqrt(um^2+vm^2)
uvgm <-  sqrt(ugm^2+vgm^2)

if (length(dim(uvm)) == 2) {
nz <- dim(uvm)[1] 
ntimes <- dim(uvm)[2]
beg <- c(1,1,1)
end <- c(nz,1,1)
zlevels <- get.var.ncdf( nc, levs, start=beg, count=end )
plevels <- get.var.ncdf( nc, plevs, start=beg, count=end )
mtimes <- get.var.ncdf( nc, "time" )
} 

close.ncdf(nc)

ndays <- ntimes/nhours

indd <- array(0.,5)

uvmm <- array(0.,c(nz,5))
uvgmm <- array(0.,c(nz,5))
uvoo <- array(0.,c(nz,5))
uvobsall <- array(NA,c(nz,ndays))
uvmall <- array(NA,c(nz,ndays))
uvgmall <- array(NA,c(nz,ndays))


kkk <- 0

for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=3)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)/3+1
#        print(k)
#        print(ind)
	if (ind==1 || ind==3 || ind==5) {
           kk <- match(mtimes[k],obstimes,nomatch=NA)
#           print(kk)
           if (!is.na(kk)) {
               indd[ind] <- indd[ind]+1
               uvmm[,ind] <- uvmm[,ind]+uvm[,k]
               uvgmm[,ind] <- uvgmm[,ind]+uvgm[,k]
               uvoo[,ind] <- uvoo[,ind]+uvobs[,kk]
               if (ind==5) {
                   kkk=kkk+1
                   kkkk <- match(kkk,c(3,5,6,8,10,12,14,33))
                   if (!is.na(kkkk)) {
#                     print(kk)
                   }

#                   print(kk)
                   if (kkk==1) print(kk)
                   if (kkk==2) print(kk)
                   if (kkk==3) print(kk)
                   if (kkk==6) print(kk)
                   if (kkk==9) print(kk)
                   if (kkk==10) print(kk)
                   if (kkk==11) print(kk)
                   if (kkk==12) print(kk)
                   if (kkk==20) print(kk)
                   uvobsall[,kkk] <- uvobs[,kk]
                   uvmall[,kkk] <- uvm[,k]
                   uvgmall[,kkk] <- uvgm[,k]
               }
           }
        } else {
           indd[ind] <- indd[ind]+1
           uvmm[,ind] <- uvmm[,ind]+uvm[,k]
           uvgmm[,ind] <- uvgmm[,ind]+uvgm[,k]
        }           
    }
}

stop

for (ind in 1:5) {
    uvmm[,ind] <- uvmm[,ind]/indd[ind]
    uvgmm[,ind] <- uvgmm[,ind]/indd[ind]
    uvoo[,ind] <- uvoo[,ind]/indd[ind]
}


par(mar=c(1.,.1,.1,0.1))
par(mai=c(1.,.1,.1,0.1))

par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)
par(font=2)
#par(tcl=-0.01)
#par(xaxp=c(18,30,1))
#par(ann=FALSE)

if (time == "00z") {
avecolor <- "blue"
obscolor <- "red"
xmin <- 0.
xmax <- 30.
} else {
avecolor <- "blue"
obscolor <- "red"
secondcolor <- "tomato1"
xmin <- 0.
xmax <- 30.
}

ymin <- 0.
ymax <- 4500.

ntimes <- kkk

for (i in 1:ntimes) {

print(i)
plot(uvobsall[1:(nz-1),i],zlevels[1:(nz-1)],"l",col="purple",
lwd=8,xlab=expression(abs(U)~(ms^{-1})),
ylab=paste("Z"," (m)",sep=""),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xaxs="i",yaxs="i",cex.axis=1.1,cex.lab=1.4,cex.axis=1.4,axes=TRUE)
text(1,2700,labels=lab,cex=1.6,lty=1)

   lines(uvmall[1:(nz-1),i],zlevels[1:(nz-1)],"l",col=avecolor,
        lwd=1,lty=1)
   lines(uvgmall[1:(nz-1),i],zlevels[1:(nz-1)],"l",col="black",
        lwd=1,lty=1)
locator()

}


}}}

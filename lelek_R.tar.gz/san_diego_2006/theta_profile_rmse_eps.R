library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","myj")#,"gfs")
soilall <- c("noah","ruc","flux")
#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13



field <- "T"

#ncname <- paste(dir,"/","obs_prof_day.nc",sep="")
ncname <- paste(dir,"/","obs_prof.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
tobs <- get.var.ncdf( nc, varname )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)

for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

print(time)
print(pbl)
print(soil)


#if (pbl == "mrf") laba <- "a"
if (pbl == "ysu") laba <- "a"
if (pbl == "myj") laba <- "b"
#if (pbl == "gfs") laba <- "d"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
#if (soil == "frb") lab <- paste(laba,"c",sep="")
if (soil == "flux") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

xlv <- 2.5e6
pref <- 1.e5
rcp <- 287.04/1004.

levs <- "Z"
plevs <- "P"

nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
tm <- get.var.ncdf( nc, varname )
if (length(dim(tm)) == 2) {
nz <- dim(tm)[1] 
ntimes <- dim(tm)[2]
beg <- c(1,1,1)
end <- c(nz,1,1)
zlevels <- get.var.ncdf( nc, levs, start=beg, count=end )
plevels <- get.var.ncdf( nc, plevs, start=beg, count=end )
mtimes <- get.var.ncdf( nc, "time" )
} 

close.ncdf(nc)

ndays <- ntimes/nhours

indd <- array(0.,5)

thm <- array(0.,c(nz,5,ndays))
thobs <- array(0.,c(nz,5,ndays))
kkk <- 0

for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=3)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)/3+1
#        print(k)
#        print(ind)
	if (ind==1 || ind==3 || ind==5) {
           kk <- match(mtimes[k],obstimes,nomatch=NA)
#           print(kk)
           if (!is.na(kk)) {
               indd[ind] <- indd[ind]+1
               thm[,ind,indd[ind]] <- tm[,k]*(pref/plevels)^rcp
               thobs[,ind,indd[ind]] <- tobs[,kk]*(pref/plevels)^rcp
           }
        } else {
           indd[ind] <- indd[ind]+1
           thm[,ind,indd[ind]] <- tm[,k]*(pref/plevels)^rcp
        }           
    }
}


for (ind in c(1,3,5)) {
for (j in 1:nz) {

#real rmse
#    rmse <- sqrt(var(thm[j,ind,1:indd[ind]]-
#                             thobs[j,ind,1:indd[ind]]))

#absolute error
    rmse <- sum(abs(thm[j,ind,1:indd[ind]]-thobs[j,ind,1:indd[ind]]))/
               indd[ind]

#correlation
#    rmse <- cor(thm[j,ind,1:indd[ind]],thobs[j,ind,1:indd[ind]])

    thm[j,ind,1] <- rmse
}
}



par(mar=c(1.,.1,.1,0.1))
par(mai=c(1.,.1,.1,0.1))

par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)
par(font=2)
#par(tcl=-0.01)
#par(xaxp=c(18,30,1))
#par(ann=FALSE)

if (time == "00z") {
avecolor <- "black"
obscolor <- "red"
xmin <- 0.
xmax <- 10.
} else {
avecolor <- "black"
obscolor <- "red"
secondcolor <- "tomato1"
xmin <- 0.
xmax <- 10.
#xmin <- 240.
#xmax <- 305.
}

png(paste("./pngs/",varname,"_prof_rmse_",time,"_",sim,".png",sep=""),
width = 500, height = 500,bg="lightblue")

#postscript(paste("./eps/",varname,"_prof_",time,"_",sim,".eps",sep=""),
#width = 6, height = 6,
#horizontal = FALSE, onefile = FALSE, paper = "special",
#           family = "Helvetica")



ymin <- 0.
ymax <- 3000.

plot(thm[1:(nz-1),3,1],zlevels[1:(nz-1)],"l",col="black",
lwd=4,xlab=expression(Theta(K)),ylab=paste("Z"," (m)",sep=""),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),lty=1,
xaxs="i",yaxs="i",cex.lab=1.4,cex.axis=1.4,axes=TRUE)
text(292,2700,labels=lab,cex=1.6)

lines(thm[1:(nz-1),5,1],zlevels[1:(nz-1)],"l",col=avecolor,lwd=4,lty=5)

dev.off()


}}}
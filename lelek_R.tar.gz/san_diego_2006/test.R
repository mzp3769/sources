#testing

#plot(thm[1:(nz-1),3,7],zlevels[1:(nz-1)],"l",col="purple")
#lines(thobs[1:(nz-1),3,7],zlevels[1:(nz-1)],"l",col="red")
#lines(thobs[1:(nz-1),5,7],zlevels[1:(nz-1)],"l",col="blue")
#lines(thm[1:(nz-1),5,7],zlevels[1:(nz-1)],"l",col="green")


plot(thm[1:(nz-1),5,14],zlevels[1:(nz-1)],"l",col="purple")
lines(thobs[1:(nz-1),5,14],zlevels[1:(nz-1)],"l",col="red")
#lines(thobs[1:(nz-1),5,7],zlevels[1:(nz-1)],"l",col="blue")
#lines(thm[1:(nz-1),5,7],zlevels[1:(nz-1)],"l",col="green")


library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","myj")#,"gfs")
soilall <- c("noah","ruc")#,"flux")
ncas <- length(timeall)*length(pblall)*length(soilall)
nstats <- 6

nhours <- 13

indd <- array(0.,nhours)



#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"


field <- "PBLH"

ncname <- paste(dir,"/","smos.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- "temp"
tobs <- get.var.ncdf( nc, varname )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)

stat <- array(0.,c(ncas,nstats))
statt <- array(0.,c(ncas,nhours))

icas <- 0

for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

icas <- icas+1

print(time)
print(pbl)
print(soil)


#if (pbl == "mrf") laba <- "a"
if (pbl == "ysu") laba <- "a"
if (pbl == "myj") laba <- "b"
#if (pbl == "gfs") laba <- "d"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
#if (soil == "frb") lab <- paste(laba,"c",sep="")
if (soil == "flux") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")


nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
tm <- get.var.ncdf( nc, varname )
if (length(dim(tm)) == 1) {
ntimes <- dim(tm)
mtimes <- get.var.ncdf( nc, "time" )
} 

close.ncdf(nc)


#calculate seconds since 2003-05-01 00:00:00 as in obs file

cmtimes <- as.character(chron(mtimes,
                   origin.=c(month=1,day=1,year=1601)))


cobstimes <- as.character(chron(obstimes/(24*3600),
                     origin.=c(month=1,day=1,year=1970)))

ndays <- ntimes/nhours

indd <- array(0.,13)

thm <- array(0.,c(nhours,ndays))
thobs <- array(0.,c(nhours,ndays))

tmseries <- array(0.,nhours*ndays)
toseries <- array(0.,nhours*ndays)


kkk <- 0

for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=1)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)%%13+1
#        print(k)
#        print(ind)
	 if (i == 1) next
         kk <- match(cmtimes[k],cobstimes,nomatch=NA)
#           print(kk)
         if (!is.na(kk)) {
               indd[ind] <- indd[ind]+1
               thm[ind,indd[ind]] <- tm[k]-273.15
               kkk <- kkk+1
	       tmseries[kkk] <- thm[ind,indd[ind]]
               thobs[ind,indd[ind]] <- tobs[kk]
               toseries[kkk] <- tobs[kk]
         }
    }
}

nt <- kkk

#average
stat[icas,1] <- sum(tmseries[1:nt])/nt


statt[icas,1] <- NA
for (ihour in 2:nhours) {
statt[icas,ihour] <- mean(thm[ihour,1:indd[ind]])
}

#rmse
stat[icas,2] <- 0.

#absolute error
stat[icas,3] <- 0.


#correlation
stat[icas,4] <- 1

#bias
stat[icas,5]  <- 0.

stat[icas,6] <- 0.

}}}

statts <- array(NA,c(4,25))
statts[1,1:13] <- statt[1,] 
statts[1,14:25] <- statt[5,2:13] 
statts[2,1:13] <- statt[2,] 
statts[2,14:25] <- statt[6,2:13] 
statts[3,1:13] <- statt[3,] 
statts[3,14:25] <- statt[7,2:13] 
statts[4,1:13] <- statt[4,] 
statts[4,14:25] <- statt[8,2:13] 

statts <- pmax(statts,0.)

ymin <- 0.
ymax <- max(statt,na.rm=TRUE)+100
xmin <- 5.5
xmax <- 29.5
hvec <- seq(xmin,xmax,by=1)
xvec=c(6,8,10,12,14,16,18,20,22,24,26,28)
lxvec=c("06","08","10","12","14","16","18","20","22","00","02","04")


postscript("./eps/stats_hpblts_day.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")
plot(hvec[1:13],statts[1,1:13],"l",col="black",
lwd=8,xlab="LST (hour)",ylab="PBL height (m)",
ylim=c(ymin,ymax),xlim=c(xmin,xmax),cex.lab=1.4,cex.axis=1.4,
xaxs="i",yaxs="i",axes=TRUE, xaxt = "n")
lines(hvec[14:25],statts[1,14:25],"l",col="black",lwd=8)
lines(hvec[1:13],statts[2,1:13],"l",col="blue",lwd=8)
lines(hvec[14:25],statts[2,14:25],"l",col="blue",lwd=8)
lines(hvec[1:13],statts[3,1:13],"l",col="purple",lwd=8)
lines(hvec[14:25],statts[3,14:25],"l",col="purple",lwd=8)
lines(hvec[1:13],statts[4,1:13],"l",col="red",lwd=8)
lines(hvec[14:25],statts[4,14:25],"l",col="red",lwd=8)
vveca <- c(17.5,17.5)
vvecb <- c(0.,ymax)
lines(vveca,vvecb,"l",col="black",lwd=8,lty=2)
axis(1, at=xvec, labels=lxvec,cex.axis=1.4)
legend(23,ymax,c("YN","YR","MN","MR"),
col=c("black","blue","purple","red"),
lwd=8,bty="o",ncol=1,cex=1.4)
dev.off()




postscript("./eps/stats_hpbl_day.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

xlabstring=""#expression("Parameterizations")
ylabstring=expression("Average PBL height (m)")

#ymin <- min(stat[1:4,1])-mean(stat[1:4,1])-100
#ymax <- max(stat[1:4,1])-mean(stat[1:4,1])+100
ymin <- 0
ymax <- max(stat[1:4,1])+200
#barplot(stat[1:4,1]-ave(stat[1:4,1]),#width=1,
barplot(stat[1:4,1],
beside=TRUE,xlim=c(2,6),space=c(0,2),width=1.,
#names.arg=c("50","70","85"),col=rainbow(4),
#names.arg=c("A","B","C","D"),
col=grey(4:0/4),
ylim=c(ymin,ymax),xlab=xlabstring,ylab=ylabstring,
legend=c("YN","YR","MN","MR"))
dev.off()


postscript("./eps/stats_hpbl_night.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

xlabstring=""#expression("Parameterizations")
ylabstring=expression("Bias T 2m (K)")

ymin <- min(stat[5:8,1])-mean(stat[5:8,1])-100
ymax <- max(stat[5:8,1])-mean(stat[5:8,1])+100
barplot(stat[5:8,1]-ave(stat[5:8,1]),#width=1,
beside=TRUE,xlim=c(2,6),space=c(0,2),width=1.,
#names.arg=c("50","70","85"),col=rainbow(4),
#names.arg=c("A","B","C","D"),
col=grey(4:0/4),
ylim=c(ymin,ymax),xlab=xlabstring,ylab=ylabstring,
legend=c("YN","YR","MN","MR"))
#axis(1,at=c(0,6))
text(2.5,2.5,labels="b",cex=1.5,vfont=c("serif","plain"))

dev.off()




cstring <- paste(paste(pblall[1],"_",soilall[1],sep=""),
                 paste(pblall[1],"_",soilall[2],sep=""),
                 paste(pblall[2],"_",soilall[1],sep=""),
                 paste(pblall[2],"_",soilall[2],sep=""),sep=" ")

cstring <- paste(cstring,cstring,sep=" ")

write(cstring,
      file="prof_stats_hpbl.dat",ncolumns=ncas,sep="  ",
      append=FALSE)
write(format(stat[,1],trim=TRUE,nsmall=1,digits=3,justify="right"),
      file="prof_stats_hpbl.dat",ncolumns=ncas,sep="     ",
      append=TRUE)
write(format(stat[,2],trim=TRUE,nsmall=1,digits=2,justify="right"),
      file="prof_stats_hpbl.dat",ncolumns=ncas,sep="      ",
      append=TRUE)
write(format(stat[,3],trim=TRUE,nsmall=1,digits=2,justify="right"),
      file="prof_stats_hpbl.dat",ncolumns=ncas,sep="      ",
      append=TRUE)
write(format(stat[,4],trim=TRUE,nsmall=1,digits=2,justify="right"),
      file="prof_stats_hpbl.dat",ncolumns=ncas,sep="     ",
      append=TRUE)
write(format(stat[,5],trim=TRUE,nsmall=1,digits=1,justify="right"),
      file="prof_stats_hpbl.dat",ncolumns=ncas,sep="     ",
      append=TRUE)




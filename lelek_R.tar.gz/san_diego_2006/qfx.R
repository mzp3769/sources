library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","mrf","myj")#,"gfs")
soilall <- c("noah","ruc","frb")#,"flux")
#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13



field <- "e"

ncname <- paste(dir,"/","ebbr.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
lhfxo <- get.var.ncdf( nc, varname )
qclhfxo <- get.var.ncdf( nc, paste("qc_",varname,sep=""))
tair <- get.var.ncdf( nc, "tair_bot")
qctair <- get.var.ncdf( nc, "qc_tair_bot")
pair <- get.var.ncdf( nc, "pres")
qcpair <- get.var.ncdf( nc, "qc_pres")
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)
obstimes <- obstimes/86400 + 134774

lhfxo <- -lhfxo

field <- "QFX"

for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

print(time)
print(pbl)
print(soil)



if (pbl == "ysu") laba <- "a"
if (pbl == "mrf") laba <- "b"
if (pbl == "myj") laba <- "c"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
if (soil == "frb") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

xlv <- 2.5e6
rgas <- 287.04

nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
lhfxm <- get.var.ncdf( nc, varname )
mtimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)

ntimesm <- length(mtimes)

ndays <- ntimesm/nhours

lhfxmm <- array(NA,c(ndays,nhours))
lhfxoo <- array(NA,c(ndays,nhours))

for (j in 1:ndays) { 
    for (i in 1:nhours) {
        k <- (j-1)*nhours+i    
        kk <- match(mtimes[k],obstimes,nomatch=NA)
	if (is.na(kk)) next
        if (qclhfxo[kk]  > 0) kk <- NA
	if (!is.na(kk)) {
            if ((qctair[kk] > 0) || (qctair[kk] > 0)) next
            if ((lhfxo[kk] >  150) && (i < 4)) next
            lhfxmm[j,i] <- lhfxm[k]*1.e4
            rho <- 1.e3*pair[kk]/(rgas*(tair[kk]+273.15))
#old bug            lhfxoo[j,i] <- lhfxo[kk]/(rho*xlv)*1.e4
            lhfxoo[j,i] <- lhfxo[kk]/xlv*1.e4
        }
    }
}

#par(mar=c(1.,.1,.1,0.1))
#par(mai=c(1.,1.,1.,1.))
#par(plt=c(.2,.8,.2,.8))
#par(omi=c(1,1,1,1))

par(cex.axis=1.3)
par(cex.lab=1.5)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)
par(font=2)


if (time == "11:30z") {
mcolor <- "red"
obscolor <- "purple"
ymin <- -100.e-2
ymax <- 300.e-2
xmin <- 5.5
xmax <- 17.5
hvec <- seq(xmin,xmax,by=1)
} else {
mcolor <- "red"
obscolor <- "purple"
ymin <- -100.e-2
ymax <- 200.e-2
xmin <- 17.5
xmax <- 5.5
hvec <- seq(xmin,xmax,by=1)
}


pdf(paste("./pdfs/",varname,"_",time,"_",sim,".pdf",sep=""))

plot(hvec,lhfxmm[1,],"l",col=mcolor,
lwd=1,xlab="LST (hour)",ylab=expression(QFX~x~10^{4}~(kg~m^{-2}~s^{-1})),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),cex.lab=1.1,
xaxs="i",yaxs="i",axes=TRUE)
text(16.5,2.65,labels=lab,cex=1.6)

lines(hvec,lhfxoo[1,],"l",col=obscolor,lwd=1)

for (i in 1:ndays){
    lines(hvec,lhfxmm[i,],"l",col=mcolor,lwd=1)
    lines(hvec,lhfxoo[i,],"l",col=obscolor,lwd=1)
}

mlhfxoo <- array(NA,nhours)
mlhfxmm <- array(NA,nhours)

for (i in 1:nhours){
    mlhfxmm[i] <- mean(lhfxmm[,i],na.rm=TRUE)
    mlhfxoo[i] <- mean(lhfxoo[,i],na.rm=TRUE)
}

lines(hvec,mlhfxmm,"l",col="darkred",lwd=10)
lines(hvec,mlhfxoo,"l",col="blue",lwd=10)

dev.off()

}}}

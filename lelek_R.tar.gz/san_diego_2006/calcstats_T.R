library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","myj")#,"gfs")
soilall <- c("noah","ruc")#,"flux")
ncas <- length(timeall)*length(pblall)*length(soilall)
nstats <- 4

indd <- array(0.,5)

#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13

field <- "T"

ncname <- paste(dir,"/","obs_prof.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
tobs <- get.var.ncdf( nc, varname )
nz <- dim(tobs)[1] 
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)

thmm <- array(0.,c(ncas,nz,5,4))


icas <- 0

for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

if (time=="11:30z") {
   zpbl <- 3000
}  else {
   zpbl <- 3000
}


icas <- icas+1

print(time)
print(pbl)
print(soil)


#if (pbl == "mrf") laba <- "a"
if (pbl == "ysu") laba <- "a"
if (pbl == "myj") laba <- "b"
#if (pbl == "gfs") laba <- "d"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
#if (soil == "frb") lab <- paste(laba,"c",sep="")
if (soil == "flux") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

xlv <- 2.5e6
pref <- 1.e5
rcp <- 287.04/1004.

levs <- "Z"
plevs <- "P"

nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
tm <- get.var.ncdf( nc, varname )
if (length(dim(tm)) == 2) {
nz <- dim(tm)[1] 
ntimes <- dim(tm)[2]
beg <- c(1,1,1)
end <- c(nz,1,1)
zlevels <- get.var.ncdf( nc, levs, start=beg, count=end )
plevels <- get.var.ncdf( nc, plevs, start=beg, count=end )
mtimes <- get.var.ncdf( nc, "time" )
} 

close.ncdf(nc)

ndays <- ntimes/nhours


thm <- array(0.,c(nz,5,ndays))
thobs <- array(0.,c(nz,5,ndays))
kkk <- 0

j <- 1
while (zlevels[j] < zpbl) {
   j <- j+1
}   
nzpbl <- j

indd <- array(0.,5)

for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=3)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)/3+1
#        print(k)
#        print(ind)
	if (ind==1 || ind==3 || ind==5) {
           kk <- match(mtimes[k],obstimes,nomatch=NA)
#           print(kk)
           if (!is.na(kk)) {
               indd[ind] <- indd[ind]+1
               thm[,ind,indd[ind]] <- tm[,k]*(pref/plevels)^rcp
               thobs[,ind,indd[ind]] <- tobs[,kk]*(pref/plevels)^rcp
           }
        } else {
           indd[ind] <- indd[ind]+1
           thm[,ind,indd[ind]] <- tm[,k]*(pref/plevels)^rcp
        }           
    }
}


for (ind in c(1,3,5)) {
for (j in 1:nzpbl) {

#rmse
    rmse <- sqrt(var(thm[j,ind,1:indd[ind]]-
                             thobs[j,ind,1:indd[ind]]))
#    print(thm[j,ind,1:indd[ind]]-thobs[j,ind,1:indd[ind]])

#    break
#absolute error
    abserr <- sum(abs(thm[j,ind,1:indd[ind]]-thobs[j,ind,1:indd[ind]]))/
               indd[ind]

#correlation
    correl <- cor(thm[j,ind,1:indd[ind]],thobs[j,ind,1:indd[ind]])

#bias
    bias <- sum(thm[j,ind,1:indd[ind]]-thobs[j,ind,1:indd[ind]])/
               indd[ind]

    thmm[icas,j,ind,1] <- rmse
    thmm[icas,j,ind,2] <- abserr
    thmm[icas,j,ind,3] <- correl
    thmm[icas,j,ind,4] <- bias

}
}

}}}

stat <- thmm[,,1,1]

for (icas in 1:ncas) {
stat[icas,] <- .5*(thmm[icas,,3,2]+thmm[icas,,5,2])
}

ymin <- 0
ymax <- 2500
xmin <- 0
xmax <- max(stat[1:4,])+.2

#rmse
postscript("./eps/stats2Tday.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

plot(stat[1,1:(nz-1)],zlevels[1:(nz-1)],"l",col="black",
lwd=8,xlab=expression(AE~Theta~(K)),ylab=paste("Z"," (m)",sep=""),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),lty=1,
xaxs="i",yaxs="i",cex.lab=1.4,cex.axis=1.4,axes=TRUE)
lines(stat[2,1:(nz-1)],zlevels[1:(nz-1)],"l",col="blue",lwd=8)
lines(stat[3,1:(nz-1)],zlevels[1:(nz-1)],"l",col="purple",lwd=8)
lines(stat[4,1:(nz-1)],zlevels[1:(nz-1)],"l",col="red",lwd=8)
legend(xmin,ymax,c("YN","YR","MN","MR"),
col=c("black","blue","purple","red"),
lwd=8,bty="o",ncol=1,cex=1.4)
#text(.2,2250,labels='a',cex=1.6)
dev.off()

ymin <- 0
ymax <- 1500
xmin <- 0
xmax <- max(stat[5:8,])+.5


postscript("./eps/stats2_T_night.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

plot(stat[5,1:(nz-1)],zlevels[1:(nz-1)],"l",col="black",
lwd=8,xlab=expression(AE~Theta~(K)),ylab=paste("Z"," (m)",sep=""),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),lty=1,
xaxs="i",yaxs="i",cex.lab=1.4,cex.axis=1.4,axes=TRUE)
#text(292,2700,labels=lab,cex=1.6)
lines(stat[6,1:(nz-1)],zlevels[1:(nz-1)],"l",col="blue",lwd=8)
lines(stat[7,1:(nz-1)],zlevels[1:(nz-1)],"l",col="purple",lwd=8)
lines(stat[8,1:(nz-1)],zlevels[1:(nz-1)],"l",col="red",lwd=8)
#text(.35,1350,labels='b',cex=1.6)
legend(2.85,ymax,c("YN","YR","MN","MR"),
col=c("black","blue","purple","red"),
lwd=8,bty="o",ncol=1,cex=1.4)
dev.off()


#write(format(stat[,3,1],trim=TRUE,digits=2,justify="right"),
#      file="prof_stats_T.dat",ncolumns=ncas,sep="  ",
#      append=FALSE)
#write(format(stat[,3,4],trim=TRUE,digits=1,justify="right"),
#      file="prof_stats_T.dat",ncolumns=ncas,sep=" ",
#      append=TRUE)
#write(format(stat[,5,1],trim=TRUE,digits=2),
#      file="prof_stats_T.dat",ncolumns=ncas,sep="  ",
#      append=TRUE)
#write(format(stat[,5,4],trim=TRUE,digits=1),
#      file="prof_stats_T.dat",ncolumns=ncas,sep=" ",
#      append=TRUE)




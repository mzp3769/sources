library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","myj")#,"gfs")
soilall <- c("noah","ruc","flux")
#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13

ufield <- "U"
vfield <- "V"
varname <- "UV"
ugfield <- "U_G"
vgfield <- "V_G"


for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

print(time)
print(pbl)
print(soil)


ncname <- paste(dir,"/","obs_prof.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varnameu <- ufield
uobs <- get.var.ncdf( nc, varnameu )
varnamev <- vfield
vobs <- get.var.ncdf( nc, varnamev )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)

uvobs <- sqrt(uobs^2+vobs^2)

#if (pbl == "mrf") laba <- "a"
if (pbl == "ysu") laba <- "a"
if (pbl == "myj") laba <- "b"
if (pbl == "gfs") laba <- "d"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
#if (soil == "frb") lab <- paste(laba,"c",sep="")
if (soil == "flux") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

levs <- "Z"
plevs <- "P"

nc <- open.ncdf(ncname, readunlim=FALSE )
varnameu <- ufield
um <- get.var.ncdf( nc, varnameu )
varnamev <- vfield
vm <- get.var.ncdf( nc, varnamev )


varnameug <- ugfield
ugm <- get.var.ncdf( nc, varnameug )
varnamevg <- vgfield
vgm <- get.var.ncdf( nc, varnamevg )


uvm <- sqrt(um^2+vm^2)
uvgm <-  sqrt(ugm^2+vgm^2)

if (length(dim(uvm)) == 2) {
nz <- dim(uvm)[1] 
ntimes <- dim(uvm)[2]
beg <- c(1,1,1)
end <- c(nz,1,1)
zlevels <- get.var.ncdf( nc, levs, start=beg, count=end )
plevels <- get.var.ncdf( nc, plevs, start=beg, count=end )
mtimes <- get.var.ncdf( nc, "time" )
} 

close.ncdf(nc)

ndays <- ntimes/nhours

indd <- array(0.,5)

uvmm <- array(0.,c(nz,5))
uvgmm <- array(0.,c(nz,5))
uvoo <- array(0.,c(nz,5))
for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=3)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)/3+1
#        print(k)
#        print(ind)
	if (ind==1 || ind==3 || ind==5) {
           kk <- match(mtimes[k],obstimes,nomatch=NA)
#           print(kk)
           if (!is.na(kk)) {
               indd[ind] <- indd[ind]+1
               uvmm[,ind] <- uvmm[,ind]+uvm[,k]
               uvgmm[,ind] <- uvgmm[,ind]+uvgm[,k]
               uvoo[,ind] <- uvoo[,ind]+uvobs[,kk]
           }
        } else {
           indd[ind] <- indd[ind]+1
           uvmm[,ind] <- uvmm[,ind]+uvm[,k]
           uvgmm[,ind] <- uvgmm[,ind]+uvgm[,k]
        }           
    }
}

for (ind in 1:5) {
    uvmm[,ind] <- uvmm[,ind]/indd[ind]
    uvgmm[,ind] <- uvgmm[,ind]/indd[ind]
    uvoo[,ind] <- uvoo[,ind]/indd[ind]
}

par(mar=c(1.,.1,.1,0.1))
par(mai=c(1.,.1,.1,0.1))

par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)
par(font=2)
#par(tcl=-0.01)
#par(xaxp=c(18,30,1))
#par(ann=FALSE)

if (time == "00z") {
avecolor <- "blue"
obscolor <- "red"
xmin <- 0.
xmax <- 14.
} else {
avecolor <- "blue"
obscolor <- "red"
secondcolor <- "tomato1"
xmin <- 0.
xmax <- 14.
}

postscript(paste("./eps/",varname,"G_prof_",time,"_",sim,".eps",sep=""),
width = 6, height = 6,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

ymin <- 0.
ymax <- 4500.

plot(uvoo[1:(nz-1),1],zlevels[1:(nz-1)],"l",col="purple",
lwd=8,xlab=expression(abs(U)~(ms^{-1})),
ylab=paste("Z"," (m)",sep=""),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xaxs="i",yaxs="i",cex.axis=1.1,cex.lab=1.4,cex.axis=1.4,axes=TRUE)
text(1,2700,labels=lab,cex=1.6,lty=1)

#for (i in c(2,4)){
#    lines(uvmm[1:(nz-1),i],zlevels[1:(nz-1)],"l",col=avecolor,
#     lwd=3,lty=6)
#}

#lines(uvoo[1:(nz-1),1],zlevels[1:(nz-1)],"l",col=obscolor,lwd=4,lty=1)

lines(uvmm[1:(nz-1),3],zlevels[1:(nz-1)],"l",col=avecolor,lwd=4,lty=5)
lines(uvmm[1:(nz-1),5],zlevels[1:(nz-1)],"l",col=avecolor,lwd=4,lty=1)

lines(uvgmm[1:(nz-1),3],zlevels[1:(nz-1)],"l",col="black",lwd=4,lty=5)
lines(uvgmm[1:(nz-1),5],zlevels[1:(nz-1)],"l",col="black",lwd=4,lty=1)

lines(uvoo[1:(nz-1),3],zlevels[1:(nz-1)],"l",col=obscolor,lwd=4,lty=5)
lines(uvoo[1:(nz-1),5],zlevels[1:(nz-1)],"l",col=obscolor,lwd=4,lty=1)


dev.off()

}}}

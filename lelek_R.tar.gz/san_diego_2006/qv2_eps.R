library(ncdf)
library(chron)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","myj")#,"gfs")
soilall <- c("noah","ruc")#,"flux")
ncas <- length(timeall)*length(pblall)*length(soilall)
nstats <- 6
tobsave <- array(NA,c(2,nhours))
tmave <- array(NA,c(ncas,nhours))
nhours <- 13
ccol <- c("green","blue","purple","red","green","blue","purple","red")


#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"


field <- "Q2"

ncname <- paste(dir,"/","smos.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- "bar_pres"
pres <- get.var.ncdf( nc, varname )
varname <- "rh"
rhobs <- get.var.ncdf( nc, varname )
varname <- "temp"
tobs <- get.var.ncdf( nc, varname )
varname <- "vap_pres"
epres <- get.var.ncdf( nc, varname )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)

rhobs <- pmin(rhobs,100.)
thobs <- tobs+273.15
pres <- pres*1.e3
epres <- epres*1.e3
esat <-   611.2*exp(17.67*(thobs-273.15)/(thobs-29.65))
qvobs <- .622*esat/(pres-0.378*esat)*rhobs*1.e-2
qvobs <- .622*epres/(pres-0.378*epres)
tobs <- qvobs

icas <- 0

for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

icas <- icas+1

print(time)
print(pbl)
print(soil)


#if (pbl == "mrf") laba <- "a"
if (pbl == "ysu") laba <- "a"
if (pbl == "myj") laba <- "b"
#if (pbl == "gfs") laba <- "d"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
#if (soil == "frb") lab <- paste(laba,"c",sep="")
if (soil == "flux") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")


nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
tm <- get.var.ncdf( nc, varname )
if (length(dim(tm)) == 1) {
ntimes <- dim(tm)
mtimes <- get.var.ncdf( nc, "time" )
} 

close.ncdf(nc)


#calculate seconds since 2003-05-01 00:00:00 as in obs file

cmtimes <- as.character(chron(mtimes,
                   origin.=c(month=1,day=1,year=1601)))


cobstimes <- as.character(chron(obstimes/(24*3600),
                     origin.=c(month=1,day=1,year=1970)))

ndays <- ntimes/nhours

indd <- array(0.,13)

thm <- array(0.,c(nhours,ndays))
thobs <- array(0.,c(nhours,ndays))

tmseries <- array(0.,nhours*ndays)
toseries <- array(0.,nhours*ndays)


kkk <- 0

for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=1)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)%%13+1
#        print(k)
#        print(ind)
	 if (i == 1) next
         kk <- match(cmtimes[k],cobstimes,nomatch=NA)
#           print(kk)
         if (!is.na(kk)) {
               indd[ind] <- indd[ind]+1
               thm[ind,indd[ind]] <- tm[k]*1.e3
               kkk <- kkk+1
	       tmseries[kkk] <- thm[ind,indd[ind]]
               thobs[ind,indd[ind]] <- tobs[kk]*1.e3
               toseries[kkk] <- tobs[kk]
         }
    }
}



nt <- kkk

#average
if (icas==1 || icas==5) {
    j <- icas%/%4 + 1
    for (i in 2:nhours) {
        tobsave[j,i] <- mean(thobs[i,],na.rm=TRUE)
    }
} 
for (i in 2:nhours) {
    tmave[icas,i] <- mean(thm[i,],na.rm=TRUE)
}
}}

if (time == "11:30z") {

ymin <- 10.
ymax <- 20.
xmin <- 5.5
xmax <- 17.5
hvec <- seq(xmin,xmax,by=1)
xlabs <- 6.5
ylabs <- 30
xvec=c(6,8,10,12,14,16)
lxvec=c("06","08","10","12","14","16")

postscript("./eps/QV2_day.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

par(mar = c(5,5,3,3))

plot(hvec,tobsave[1,],type="l",col="black",lwd=10,xlab="LST (hour)",
     ylab=expression(q[v2m]~(g~kg^{-1})),
     ylim=c(ymin,ymax),xlim=c(xmin,xmax),cex.lab=1.4,cex.axis=1.4,
     xaxs="i",yaxs="i",axes=TRUE, xaxt = "n")

#text(xlabs,ylabs,labels=lab,cex=1.6)
axis(1, at=xvec, labels=lxvec,cex.axis=1.4)

for (icas in 1:4) {
    lines(hvec,tmave[icas,],"l",col=ccol[icas],lwd=10) 

}

legend(xmin,ymax,c("OBS","YN","YR","MN","MR"),
col=c("black","green","blue","purple","red"),
lwd=8,bty="o",ncol=1,cex=1.4)

dev.off()

} else {

ymin <- 10.
ymax <- 20.
xmin <- 17.5
xmax <- 29.5
hvec <- seq(xmin,xmax,by=1)
xlabs <- 18.5
ylabs <- 20
xvec=c(18,20,22,24,26,28)
lxvec=c("18","20","22","00","02","04")


postscript("./eps/QV2_night.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

par(mar = c(5,5,3,3))

plot(hvec,tobsave[2,],type="l",col="black",lwd=10,xlab="LST (hour)",
     ylab=expression(q[v2m]~(g~kg^{-1})),
     ylim=c(ymin,ymax),xlim=c(xmin,xmax),cex.lab=1.4,cex.axis=1.4,
     xaxs="i",yaxs="i",axes=TRUE, xaxt = "n")

#text(xlabs,ylabs,labels=lab,cex=1.6)
axis(1, at=xvec, labels=lxvec,cex.axis=1.4)

for (icas in 5:8) {
    lines(hvec,tmave[icas,],"l",col=ccol[icas],lwd=10) 

}

legend(xmax-3.80,ymax,c("OBS","YN","YR","MN","MR"),
col=c("black","green","blue","purple","red"),
lwd=8,bty="o",ncol=1,cex=1.4)

dev.off()

}}


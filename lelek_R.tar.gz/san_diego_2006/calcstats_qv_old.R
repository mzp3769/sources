library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","myj")#,"gfs")
soilall <- c("noah","ruc")#,"flux")
ncas <- length(timeall)*length(pblall)*length(soilall)
nstats <- 4

indd <- array(0.,5)

stat <- array(0.,c(ncas,length(indd),nstats))


#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13

if (timeall=="11:30z") {
   zpbl <- 2000
else {
   zpbl <- 1500
}


field <- "QV"

ncname <- paste(dir,"/","obs_prof.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
tobs <- get.var.ncdf( nc, varname )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)

icas <- 0

for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

icas <- icas+1

print(time)
print(pbl)
print(soil)


#if (pbl == "mrf") laba <- "a"
if (pbl == "ysu") laba <- "a"
if (pbl == "myj") laba <- "b"
#if (pbl == "gfs") laba <- "d"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
#if (soil == "frb") lab <- paste(laba,"c",sep="")
if (soil == "flux") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")


levs <- "Z"
plevs <- "P"

nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
tm <- get.var.ncdf( nc, varname )
if (length(dim(tm)) == 2) {
nz <- dim(tm)[1] 
ntimes <- dim(tm)[2]
beg <- c(1,1,1)
end <- c(nz,1,1)
zlevels <- get.var.ncdf( nc, levs, start=beg, count=end )
plevels <- get.var.ncdf( nc, plevs, start=beg, count=end )
mtimes <- get.var.ncdf( nc, "time" )
} 

j <- 1
while (zlevels[j] < 1500.) {
   j <- j+1
}   
nzpbl <- j-1

close.ncdf(nc)

ndays <- ntimes/nhours

indd <- array(0.,5)

thm <- array(0.,c(nz,5,ndays))
thobs <- array(0.,c(nz,5,ndays))
kkk <- 0


j <- 1
while (zlevels[j] < zpbl) {
   j <- j+1
}   
nzpbl <- j-1


for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=3)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)/3+1
#        print(k)
#        print(ind)
	if (ind==1 || ind==3 || ind==5) {
           kk <- match(mtimes[k],obstimes,nomatch=NA)
#           print(kk)
           if (!is.na(kk)) {
               indd[ind] <- indd[ind]+1
               thm[,ind,indd[ind]] <- tm[,k]*1.e3
               thobs[,ind,indd[ind]] <- tobs[,kk]*1.e3
           }
        } else {
           indd[ind] <- indd[ind]+1
           thm[,ind,indd[ind]] <- tm[,k]*1.e3
        }           
    }
}


for (ind in c(1,3,5)) {
for (j in 1:nz) {

#rmse
    rmse <- sqrt(var(thm[j,ind,1:indd[ind]]-
                             thobs[j,ind,1:indd[ind]]))

#absolute error
    abserr <- sum(abs(thm[j,ind,1:indd[ind]]-thobs[j,ind,1:indd[ind]]))/
               indd[ind]

#correlation
    correl <- cor(thm[j,ind,1:indd[ind]],thobs[j,ind,1:indd[ind]])

#bias
    bias <- sum(thm[j,ind,1:indd[ind]]-thobs[j,ind,1:indd[ind]])/
               indd[ind]

    thm[j,ind,1] <- rmse
    thm[j,ind,2] <- abserr
    thm[j,ind,3] <- correl
    thm[j,ind,4] <- bias

}


stat[icas,ind,1] <- mean(thm[1:nzpbl,ind,1])
stat[icas,ind,2] <- mean(thm[1:nzpbl,ind,2])
stat[icas,ind,3] <- mean(thm[1:nzpbl,ind,3])
stat[icas,ind,4] <- mean(thm[1:nzpbl,ind,4])
}


}}}


write(format(stat[,3,1],trim=TRUE,digits=2,justify="right"),
      file="prof_stats_qv.dat",ncolumns=ncas,sep="  ",
      append=FALSE)
write(format(stat[,3,4],trim=TRUE,digits=1,justify="right"),
      file="prof_stats_qv.dat",ncolumns=ncas,sep=" ",
      append=TRUE)
write(format(stat[,5,1],trim=TRUE,digits=2),
      file="prof_stats_qv.dat",ncolumns=ncas,sep="  ",
      append=TRUE)
write(format(stat[,5,4],trim=TRUE,digits=1),
      file="prof_stats_qv.dat",ncolumns=ncas,sep=" ",
      append=TRUE)




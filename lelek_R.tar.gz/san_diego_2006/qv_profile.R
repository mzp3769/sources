library(ncdf)

dir <- "./data"
time <- "23:30z"
pbl <- "ysu"
pbl <- "mrf"
#pbl <- "gfs"
pbl <- "myj"
soil <- "noah"
soil <- "ruc"
#soil <- "frb"
soil <- "flux"
nhours <- 13

field <- "QV"

ncname <- paste(dir,"/","obs_prof.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
qvobs <- get.var.ncdf( nc, varname )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)


if (pbl == "ysu") laba <- "a"
if (pbl == "mrf") laba <- "b"
if (pbl == "myj") laba <- "c"
if (pbl == "gfs") laba <- "d"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
if (soil == "frb") lab <- paste(laba,"c",sep="")
if (soil == "flux") lab <- paste(laba,"d",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

levs <- "Z"
plevs <- "P"

nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
qvm <- get.var.ncdf( nc, varname )
if (length(dim(qvm)) == 2) {
nz <- dim(qvm)[1] 
ntimes <- dim(qvm)[2]
beg <- c(1,1,1)
end <- c(nz,1,1)
zlevels <- get.var.ncdf( nc, levs, start=beg, count=end )
plevels <- get.var.ncdf( nc, plevs, start=beg, count=end )
mtimes <- get.var.ncdf( nc, "time" )
} 

close.ncdf(nc)

ndays <- ntimes/nhours

indd <- array(0.,5)

qvmm <- array(0.,c(nz,5))
qvoo <- array(0.,c(nz,5))
for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=3)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)/3+1
#        print(k)
#        print(ind)
	if (ind==1 || ind==3 || ind==5) {
           kk <- match(mtimes[k],obstimes,nomatch=NA)
#           print(kk)
           if (!is.na(kk)) {
               indd[ind] <- indd[ind]+1
               qvmm[,ind] <- qvmm[,ind]+qvm[,k]
               qvoo[,ind] <- qvoo[,ind]+qvobs[,kk]
           }
        } else {
           indd[ind] <- indd[ind]+1
           qvmm[,ind] <- qvmm[,ind]+qvm[,k]
        }           
    }
}

for (ind in 1:5) {
    qvmm[,ind] <- qvmm[,ind]/indd[ind]*1.e3
    qvoo[,ind] <- qvoo[,ind]/indd[ind]*1.e3
}

par(mar=c(1.,.1,.1,0.1))
par(mai=c(1.,.1,.1,0.1))

par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)
par(font=2)
#par(tcl=-0.01)
#par(xaxp=c(18,30,1))
#par(ann=FALSE)

if (time == "00z") {
avecolor <- "blue"
obscolor <- "navy"
xmin <- 4.
xmax <- 14.
} else {
avecolor <- "red"
obscolor <- "purple"
secondcolor <- "tomato1"
xmin <- 4.
xmax <- 14.
}

pdf(paste("./pdfs/",varname,"_prof_",time,"_",sim,".pdf",sep=""))
#width = 500, height = 500,bg="white")

ymin <- 0.
ymax <- 3000.

plot(qvmm[1:(nz-1),1],zlevels[1:(nz-1)],"l",col=avecolor,
lwd=3,xlab=expression(qv~(gkg^{-1})),
ylab=paste("Z"," (m)",sep=""),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xaxs="i",yaxs="i",cex.axis=1.2,cex.lab=1.3,axes=TRUE)
text(13,2700,labels=lab,cex=1.6,lty=1)

#for (i in c(2,4)){
#    lines(qvmm[1:(nz-1),i],zlevels[1:(nz-1)],"l",col=avecolor,
#     lwd=3,lty=6)
#}

lines(qvoo[1:(nz-1),1],zlevels[1:(nz-1)],"l",col=obscolor,lwd=3,lty=1)

lines(qvmm[1:(nz-1),3],zlevels[1:(nz-1)],"l",col=avecolor,lwd=3,lty=5)
lines(qvmm[1:(nz-1),5],zlevels[1:(nz-1)],"l",col=avecolor,lwd=3,lty=6)

lines(qvoo[1:(nz-1),3],zlevels[1:(nz-1)],"l",col=obscolor,lwd=3,lty=5)
lines(qvoo[1:(nz-1),5],zlevels[1:(nz-1)],"l",col=obscolor,lwd=3,lty=6)


dev.off()



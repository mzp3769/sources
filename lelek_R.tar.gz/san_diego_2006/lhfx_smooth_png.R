library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","mrf","myj")#,"gfs")
soilall <- c("noah","ruc","frb")#,"flux")
#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13

field <- "qvflux"

ncname <- paste(dir,"/","sfc_smooth.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
lhfxo <- get.var.ncdf( nc, varname )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)
obstimes <- obstimes/86400 + 134774

lhfxo <- lhfxo

field <- "QFX"

for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

print(time)
print(pbl)
print(soil)



if (pbl == "ysu") laba <- "b"
if (pbl == "mrf") laba <- "a"
if (pbl == "myj") laba <- "c"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
if (soil == "frb") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

xlv <- 2.502e6
rgas <- 287.04

nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
lhfxm <- get.var.ncdf( nc, varname )
mtimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)

ntimesm <- length(mtimes)

ndays <- ntimesm/nhours

lhfxmm <- array(NA,c(ndays,nhours))
lhfxoo <- array(NA,c(ndays,nhours))

for (j in 1:ndays) { 
    for (i in 1:nhours) {
        k <- (j-1)*nhours+i    
        kk <- match(mtimes[k],obstimes,nomatch=NA)
	if (is.na(kk)) next
#        if (qclhfxo[kk]  > 0) kk <- NA #no need if smoothed file
	if (!is.na(kk)) {
#            if ((lhfxo[kk] >  150) && (i < 4)) next
            lhfxmm[j,i] <- lhfxm[k]*xlv
            lhfxoo[j,i] <- lhfxo[kk]*xlv
        }
    }
}

#par(mar=c(1.,.1,.1,0.1))
#par(mai=c(1.,1.,1.,1.))
#par(plt=c(.2,.8,.2,.8))
#par(omi=c(1,1,1,1))

par(cex.axis=1.3)
par(cex.lab=1.5)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)
par(font=2)


if (time == "11:30z") {
mcolor <- "blue"
obscolor <- "red"
ymin <- -100.
ymax <- 700.
xmin <- 5.5
xmax <- 17.5
hvec <- seq(xmin,xmax,by=1)
xlabs <- 6.5
ylabs <- 633.3
xvec=c(6,8,10,12,14,16)
lxvec=c("06","08","10","12","14","16")
} else {
mcolor <- "blue"
obscolor <- "red"
ymin <- -50.
ymax <- 250.
xmin <- 17.5
xmax <- 29.5
hvec <- seq(xmin,xmax,by=1)
xlabs <- 18.5
ylabs <- 225
xvec=c(18,20,22,24,26,28)
lxvec=c("18","20","22","00","02","04")

}


png(paste("./pngs/",varname,"_",time,"_",sim,".png",sep=""),
width = 500, height = 500,bg="lightblue")

plot(hvec,lhfxmm[1,],"l",col=mcolor,
lwd=1,xlab="LST (hour)",ylab=expression(E~(Wm^{-2})),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),cex.lab=1.2,cex.axis=1.4,
xaxs="i",yaxs="i",axes=TRUE,xaxt = "n")
text(xlabs,ylabs,labels=lab,cex=1.6)
axis(1, at=xvec, labels=lxvec,cex.axis=1.4)

lines(hvec,lhfxoo[1,],"l",col=obscolor,lwd=1)

lhfxmm[,1] <- NA

for (i in 1:ndays){
#    if (i==6) next # to fix missing value for some reason
#    if (any(is.na(lhfxmm[i,]))) next
    lines(hvec,lhfxmm[i,],"l",col=mcolor,lwd=1)
    lines(hvec,lhfxoo[i,],"l",col=obscolor,lwd=1)
}

mlhfxoo <- array(NA,nhours)
mlhfxmm <- array(NA,nhours)

for (i in 1:nhours){
    mlhfxmm[i] <- mean(lhfxmm[,i],na.rm=TRUE)
    mlhfxoo[i] <- mean(lhfxoo[,i],na.rm=TRUE)
}

lines(hvec,mlhfxmm,"l",col="darkblue",lwd=10)
lines(hvec,mlhfxoo,"l",col="darkred",lwd=10)

dev.off()

}}}

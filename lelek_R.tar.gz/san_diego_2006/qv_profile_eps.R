library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","myj")#,"gfs")
soilall <- c("noah","ruc","flux")

#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13

field <- "QV"

for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

print(time)
print(pbl)
print(soil)


ncname <- paste(dir,"/","obs_prof.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
qvobs <- get.var.ncdf( nc, varname )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)


#if (pbl == "mrf") laba <- "a"
if (pbl == "ysu") laba <- "a"
if (pbl == "myj") laba <- "b"
#if (pbl == "gfs") laba <- "d"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
#if (soil == "frb") lab <- paste(laba,"c",sep="")
if (soil == "flux") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

levs <- "Z"
plevs <- "P"

nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
qvm <- get.var.ncdf( nc, varname )
if (length(dim(qvm)) == 2) {
nz <- dim(qvm)[1] 
ntimes <- dim(qvm)[2]
beg <- c(1,1,1)
end <- c(nz,1,1)
zlevels <- get.var.ncdf( nc, levs, start=beg, count=end )
plevels <- get.var.ncdf( nc, plevs, start=beg, count=end )
mtimes <- get.var.ncdf( nc, "time" )
} 

close.ncdf(nc)

ndays <- ntimes/nhours

indd <- array(0.,5)

qvmm <- array(0.,c(nz,5))
qvoo <- array(0.,c(nz,5))
for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=3)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)/3+1
#        print(k)
#        print(ind)
	if (ind==1 || ind==3 || ind==5) {
           kk <- match(mtimes[k],obstimes,nomatch=NA)
#           print(kk)
           if (!is.na(kk)) {
#	       print(j)
               indd[ind] <- indd[ind]+1
               qvmm[,ind] <- qvmm[,ind]+qvm[,k]
               qvoo[,ind] <- qvoo[,ind]+qvobs[,kk]
           }
        } else {
           indd[ind] <- indd[ind]+1
           qvmm[,ind] <- qvmm[,ind]+qvm[,k]
        }           
    }
}

qvlimit <- 15.0
for (ind in 1:5) {
    qvmm[,ind] <- qvmm[,ind]/indd[ind]*1.e3
    qvmm[,ind] <- pmin(qvlimit,qvmm[,ind])
    qvoo[,ind] <- qvoo[,ind]/indd[ind]*1.e3
}

par(mar=c(1.,.1,.1,0.1))
par(mai=c(1.,.1,.1,0.1))

par(cex.axis=1.2)
par(cex.lab=1.2)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)
par(font=2)
#par(tcl=-0.01)
#par(xaxp=c(18,30,1))
#par(ann=FALSE)

if (time == "11:30z") {
avecolor <- "blue"
obscolor <- "red"
xmin <- 3.
xmax <- 15.
} else {
avecolor <- "blue"
obscolor <- "red"
secondcolor <- "tomato1"
xmin <- 3.
xmax <- 15.
}

postscript(paste("./eps/",varname,"_prof_",time,"_",sim,".eps",sep=""),
width = 6, height = 6,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")


ymin <- 0.
if (time=="11:30z") {
   ymax <- 2500.
   tmax <- 2250
} else {
   ymax <- 1500
   tmax <- 1350
}


plot(qvmm[1:(nz-1),1],zlevels[1:(nz-1)],"l",col="purple",
lwd=8,xlab=expression(q[v]~(gkg^{-1})),
ylab=paste("Z"," (m)",sep=""),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),
xaxs="i",yaxs="i",cex.axis=1.1,cex.lab=1.4,cex.axis=1.4,axes=TRUE)
text(13.7,tmax,labels=lab,cex=1.6,lty=1)

#for (i in c(2,4)){
#    lines(qvmm[1:(nz-1),i],zlevels[1:(nz-1)],"l",col=avecolor,
#     lwd=3,lty=6)
#}

#lines(qvoo[1:(nz-1),1],zlevels[1:(nz-1)],"l",col=obscolor,lwd=4,lty=1)

lines(qvmm[1:(nz-1),3],zlevels[1:(nz-1)],"l",col=avecolor,lwd=4,lty=5)
lines(qvmm[1:(nz-1),5],zlevels[1:(nz-1)],"l",col=avecolor,lwd=4,lty=1)

lines(qvoo[1:(nz-1),3],zlevels[1:(nz-1)],"l",col=obscolor,lwd=4,lty=5)
lines(qvoo[1:(nz-1),5],zlevels[1:(nz-1)],"l",col=obscolor,lwd=4,lty=1)


dev.off()

}}}

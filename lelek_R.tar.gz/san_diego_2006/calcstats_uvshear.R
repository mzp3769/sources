library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","myj")#,"gfs")
soilall <- c("noah","ruc")#,"flux")
ncas <- length(timeall)*length(pblall)*length(soilall)
nstats <- 4

indd <- array(0.,5)

#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13

ufield <- "U"
vfield <- "V"
field <- "UV"


ncname <- paste(dir,"/","obs_prof.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varnameu <- ufield
uobs <- get.var.ncdf( nc, varnameu )
varnamev <- vfield
vobs <- get.var.ncdf( nc, varnamev )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)

ntimesobs <- dim(obstimes)

#tobs <- sqrt(uobs^2+vobs^2)

shearm <- array(0,c(ncas,nz,5))
shearobs <- array(0,c(ncas,nz,5))

icas <- 0

for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

if (time=="11:30z") {
   zpbl <- 3000
}  else {
   zpbl <- 3000
}


icas <- icas+1

print(time)
print(pbl)
print(soil)


sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

xlv <- 2.5e6
pref <- 1.e5
rcp <- 287.04/1004.

levs <- "Z"
plevs <- "P"

nc <- open.ncdf(ncname, readunlim=FALSE )
varnameu <- ufield
um <- get.var.ncdf( nc, varnameu )
varnamev <- vfield
vm <- get.var.ncdf( nc, varnamev )

if (length(dim(tm)) == 2) {
nz <- dim(tm)[1] 
ntimes <- dim(tm)[2]
beg <- c(1,1,1)
end <- c(nz,1,1)
zlevels <- get.var.ncdf( nc, levs, start=beg, count=end )
plevels <- get.var.ncdf( nc, plevs, start=beg, count=end )
mtimes <- get.var.ncdf( nc, "time" )
} 
close.ncdf(nc)

zlevelsm <- array(NA,nz)

for (k in 1:(nz-1)) {
     zlevelsm[k] <- .5*(zlevels[k]+zlevels[k+1])
}

ndays <- ntimes/nhours


uum <- array(0.,c(nz,5,ndays))
vvm <- array(0.,c(nz,5,ndays))
uuobs <- array(0.,c(nz,5,ndays))
vvobs <- array(0.,c(nz,5,ndays))
kkk <- 0

j <- 1
while (zlevels[j] < zpbl) {
   j <- j+1
}   
nzpbl <- j

indd <- array(0.,5)

for (j in 1:ndays) { 
    for (i in seq(1,nhours,by=3)) {
        k <- (j-1)*nhours+i    
        ind <- (i-1)/3+1
#        print(k)
#        print(ind)
	if (ind==1 || ind==3 || ind==5) {
           kk <- match(mtimes[k],obstimes,nomatch=NA)
#           print(kk)
           if (!is.na(kk)) {
               indd[ind] <- indd[ind]+1
               uum[,ind,indd[ind]] <- um[,k]
               vvm[,ind,indd[ind]] <- vm[,k]
               uuobs[,ind,indd[ind]] <- uobs[,kk]
               vvobs[,ind,indd[ind]] <- vobs[,kk]
           }
        }           
    }
}

for (ind in c(1,3,5)) {
for (j in 1:nzpbl) {

    dz <- zlevels[j+1]-zlevels[j]

    shearm[icas,j,ind] <- mean(sqrt(
                   (uum[j+1,ind,1:indd[ind]]-
                    uum[j  ,ind,1:indd[ind]])^2 +
                   (vvm[j+1,ind,1:indd[ind]]-
                    vvm[j  ,ind,1:indd[ind]])^2)/dz)

    if (icas==1 || icas==5) {
        shearobs[icas,j,ind] <- mean(sqrt(
                   (uuobs[j+1,ind,1:indd[ind]]-
                    uuobs[j  ,ind,1:indd[ind]])^2 +
                   (vvobs[j+1,ind,1:indd[ind]]-
                    vvobs[j  ,ind,1:indd[ind]])^2)/dz)
    }

}}

}}}

shearm[,,1] <- .5*(shearm[,,3]+shearm[,,5])
shearobs[,,1] <- .5*(shearobs[,,3]+shearobs[,,5])

ymin <- 0
ymax <- 2500
xmin <- 0
xmax <- max(shearobs[1,,1],shearm[1:4,,1])+0.0025

#rmse
postscript("./eps/shear_uv_day.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

plot(shearobs[1,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="green",
lwd=8,xlab=expression(Wind~shear~(s^{-1})),
ylab=paste("Z"," (m)",sep=""),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),lty=1,
xaxs="i",yaxs="i",cex.lab=1.4,cex.axis=1.4,axes=TRUE)
lines(shearm[1,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="black",lwd=8)
lines(shearm[2,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="blue",lwd=8)
lines(shearm[3,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="purple",lwd=8)
lines(shearm[4,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="red",lwd=8)
text(.0015,2250,labels='a',cex=1.6)
legend(0.0180,ymax,c("OBS","YN","YR","MN","MR"),
col=c("green","black","blue","purple","red"),
lwd=8,bty="o",ncol=1,cex=1.4)
dev.off()

ymin <- 0
ymax <- 1500
xmin <- 0
xmax <- max(shearobs[5,,1],shearm[5:8,,1])+0.0025
postscript("./eps/shear_uv_night.eps",width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

plot(shearobs[5,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="green",
lwd=8,xlab=expression(Wind~shear~(s^{-1})),
ylab=paste("Z"," (m)",sep=""),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),lty=1,
xaxs="i",yaxs="i",cex.lab=1.4,cex.axis=1.4,axes=TRUE)
lines(shearm[5,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="black",lwd=8)
lines(shearm[6,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="blue",lwd=8)
lines(shearm[7,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="purple",lwd=8)
lines(shearm[8,1:(nz-1),1],zlevelsm[1:(nz-1)],"l",col="red",lwd=8)
legend(0.058,ymax,c("OBS","YN","YR","MN","MR"),
col=c("green","black","blue","purple","red"),
lwd=8,bty="o",ncol=1,cex=1.4)
#text(.005,1350,labels='b',cex=1.6)
dev.off()


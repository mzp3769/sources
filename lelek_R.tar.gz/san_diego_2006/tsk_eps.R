library(ncdf)
#library(chron)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","myj")#,"gfs")
soilall <- c("noah","ruc")#,"flux")
#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13


field <- "hflux"

ncname <- paste(dir,"/","sfc_smooth.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
shfxo <- get.var.ncdf( nc, varname )
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)
obstimes <- obstimes/86400 + 134774

shfxo <- shfxo

field <- "TSK"

for (time in timeall) {

it <- 0


postscript(paste("./eps/",field,"_",time,".eps",sep=""),
width = 6, height = 6,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "Helvetica")

par(mar = c(5,5,3,3))

for (pbl in pblall) {

for (soil in soilall) {

it <- it+1	

print(time)
print(pbl)
print(soil)


#if (pbl == "mrf") laba <- "a"
if (pbl == "ysu") laba <- "a"
if (pbl == "myj") laba <- "b"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
#if (soil == "frb") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

xlv <- 2.5e6
pref <- 1.e5
rcp <- 287.04/1004.

nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
shfxm <- get.var.ncdf( nc, varname )
mtimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)

ntimesm <- length(mtimes)

ndays <- ntimesm/nhours

shfxmm <- array(NA,c(ndays,nhours))
shfxoo <- array(NA,c(ndays,nhours))

kkk <- 0
for (j in 1:ndays) { 
    for (i in 1:nhours) {
        k <- (j-1)*nhours+i    
        kk <- match(mtimes[k],obstimes,nomatch=NA)
	if (is.na(kk)) next
	if (!is.na(kk)) {
            shfxmm[j,i] <- shfxm[k]
            shfxoo[j,i] <- shfxo[kk]
        }
    }
}

#par(mar=c(1.,.1,.1,0.1))
#par(mai=c(1.,1.,1.,1.))
#par(plt=c(.2,.8,.2,.8))
#par(omi=c(1,1,1,1))

#par(cex.axis=1.3)
#par(cex.lab=1.5)
#par(font.axis=2)
#par(cex.main=2)
#par(font.lab=2)
#par(font.sub=2)
#par(font=2)
#par(mex=1.5)
#par(mgp=c(3,1,0))
#par(omi=c(1.,2.,1.,1.))

if (time == "11:30z") {
mcolor <- "blue"
obscolor <- "red"
ymin <- 285.
ymax <- 315.
xmin <- 5.5
xmax <- 17.5
hvec <- seq(xmin,xmax,by=1)
xlabs <- 6.5
ylabs <- 270
xvec=c(6,8,10,12,14,16) 
lxvec=c("06","08","10","12","14","16")
} else {
mcolor <- "blue"
obscolor <- "red"
ymin <- 290
ymax <- 302
xmin <- 17.5
xmax <- 29.5
hvec <- seq(xmin,xmax,by=1)
xlabs <- 18.5
ylabs <- 166
xvec=c(18,20,22,24,26,28) 
lxvec=c("18","20","22","00","02","04")
}




shfxmm[,1] <- NA
shfxoo[1,] <- NA
if (it == 1) {
plot(hvec,shfxoo[1,],"l",col=mcolor,
lwd=1,xlab="LST (hour)",ylab=expression(T[SK]~(K)),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),cex.lab=1.4,cex.axis=1.4,
xaxs="i",yaxs="i",axes=TRUE, xaxt = "n")
text(xlabs,ylabs,labels=lab,cex=1.6)
#text(16.5,450,labels=lab,cex=1.6)
axis(1, at=xvec, labels=lxvec,cex.axis=1.4)

if (time == "11:30z") {
legend(xmin,ymax,c("YN","YR","MN","MR"),
col=c("green","blue","purple","red"),
lwd=8,bty="o",ncol=1,cex=1.4)
} else {
legend(xmax-3.6,ymax,c("YN","YR","MN","MR"),
col=c("green","blue","purple","red"),
lwd=8,bty="o",ncol=1,cex=1.4)
}

} 
#lines(hvec,shfxoo[1,],"l",col=obscolor,lwd=1)


#for (i in 1:ndays){
#    lines(hvec,shfxmm[i,],"l",col=mcolor,lwd=1)
#    lines(hvec,shfxoo[i,],"l",col=obscolor,lwd=1)
#}

mshfxoo <- array(NA,nhours)
mshfxmm <- array(NA,nhours)


for (i in 1:nhours){
    mshfxmm[i] <- mean(shfxmm[,i],na.rm=TRUE)
#    mshfxoo[i] <- mean(shfxoo[,i],na.rm=TRUE)
}


if (pbl == "ysu" &&  soil == "noah") ccol="green"
if (pbl == "ysu" &&  soil == "ruc") ccol="blue"
if (pbl == "myj" &&  soil == "noah") ccol="purple"
if (pbl == "myj" &&  soil == "ruc") ccol="red"

lines(hvec,mshfxmm,"l",col=ccol,lwd=10)
#lines(hvec,mshfxoo,"l",col="darkorange4",lwd=10)




}}
dev.off()
}


library(ncdf)

dir <- "./data"
timeall <- c("11:30z","23:30z")
pblall <- c("ysu","mrf","myj")#,"gfs")
soilall <- c("noah","ruc","frb")#,"flux")
#pbl <- "mrf"
#pbl <- "gfs"
#pbl <- "myj"
#soil <- "noah"
#soil <- "ruc"
#soil <- "frb"
#soil <- "flux"
nhours <- 13


field <- "h"

ncname <- paste(dir,"/","ebbr.nc",sep="")
nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
shfxo <- get.var.ncdf( nc, varname )
qcshfxo <- get.var.ncdf( nc, paste("qc_",varname,sep=""))
obstimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)
ntimesobs <- dim(obstimes)
obstimes <- obstimes/86400 + 134774

shfxo <- -shfxo

field <- "HFX"


for (time in timeall) {
for (pbl in pblall) {
for (soil in soilall) {

print(time)
print(pbl)
print(soil)


if (pbl == "ysu") laba <- "a"
if (pbl == "mrf") laba <- "b"
if (pbl == "myj") laba <- "c"
if (soil == "noah") lab <- paste(laba,"a",sep="")
if (soil == "ruc") lab <- paste(laba,"b",sep="")
if (soil == "frb") lab <- paste(laba,"c",sep="")

sim <- paste(pbl,"_",soil,sep="")

ncname <- paste(dir,"/",sim,"_",time,".nc",sep="")

xlv <- 2.5e6
pref <- 1.e5
rcp <- 287.04/1004.

nc <- open.ncdf(ncname, readunlim=FALSE )
varname <- field
shfxm <- get.var.ncdf( nc, varname )
mtimes <- get.var.ncdf( nc, "time" )
close.ncdf(nc)

ntimesm <- length(mtimes)

ndays <- ntimesm/nhours

shfxmm <- array(NA,c(ndays,nhours))
shfxoo <- array(NA,c(ndays,nhours))

for (j in 1:ndays) { 
    for (i in 1:nhours) {
        k <- (j-1)*nhours+i    
        kk <- match(mtimes[k],obstimes,nomatch=NA)
	if (is.na(kk)) next
        if (qcshfxo[kk]  > 0) kk <- NA
	if (!is.na(kk)) {
            if ((shfxo[kk] >  150) && (i < 4)) next
            shfxmm[j,i] <- shfxm[k]
            shfxoo[j,i] <- shfxo[kk]
        }
    }
}

#par(mar=c(1.,.1,.1,0.1))
#par(mai=c(1.,1.,1.,1.))
#par(plt=c(.2,.8,.2,.8))
#par(omi=c(1,1,1,1))

par(cex.axis=1.3)
par(cex.lab=1.5)
par(font.axis=2)
par(cex.main=2)
par(font.lab=2)
par(font.sub=2)
par(font=2)


if (time == "11:30z") {
mcolor <- "red"
obscolor <- "purple"
ymin <- -100.
ymax <- 500.
xmin <- 5.5
xmax <- 17.5
hvec <- seq(xmin,xmax,by=1)
xlabs <- 16.5
ylabs <- 450
} else {
mcolor <- "red"
obscolor <- "purple"
ymin <- -250.
ymax <- 200.
xmin <- 17.5
xmax <- 5.5
hvec <- seq(xmin,xmax,by=-1)
xlabs <- 6.5
ylabs <- 162
}


png(paste("./pngs/",varname,"_",time,"_",sim,".png",sep=""),
width = 500, height = 500,bg="lightblue")

plot(hvec,shfxmm[1,],"l",col=mcolor,
lwd=1,xlab="LST (hour)",ylab=expression(SHFX~(Wm^{-2})),
ylim=c(ymin,ymax),xlim=c(xmin,xmax),cex.lab=1.1,
xaxs="i",yaxs="i",axes=TRUE)
text(xlabs,ylabs,labels=lab,cex=1.6)
#text(16.5,450,labels=lab,cex=1.6)

lines(hvec,shfxoo[1,],"l",col=obscolor,lwd=1)

shfxmm[,1] <- NA
for (i in 1:ndays){
    lines(hvec,shfxmm[i,],"l",col=mcolor,lwd=1)
    lines(hvec,shfxoo[i,],"l",col=obscolor,lwd=1)
}

mshfxoo <- array(NA,nhours)
mshfxmm <- array(NA,nhours)


for (i in 1:nhours){
    mshfxmm[i] <- mean(shfxmm[,i],na.rm=TRUE)
    mshfxoo[i] <- mean(shfxoo[,i],na.rm=TRUE)
}

lines(hvec,mshfxmm,"l",col="darkred",lwd=10)
lines(hvec,mshfxoo,"l",col="blue",lwd=10)

dev.off()


}}}
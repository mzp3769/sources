tests <- c("test_816","test_818")
tests <- c("test_806","test_809","test_816","test_818")

ntests <- length(tests)

ftype1 <- "pprior" 
ftype1 <- "prior" 
ftype2 <- "posterior"

stats <- c("FBAR","OBAR","FSTDEV","OSTDEV","PR_CORR","ME",
      "BCMSE","RMSE")


statnames <- c("ME","RMSE")

nstats <- length(statnames)

tcolors <- c("violet","green","blue","red","orange","black","purple","paleturquoise","peachpuff","salmon")

tcolors <- c("blue","red","violet","green")




fields3d <- c("TT","UU","VV","GHT","QVAPOR")
nfields <- length(fields3d)

levels <- c("P925","P850","P700","P500","P400","P250","P100")
units <- c("T [K]"
          ,expression(paste("U [m",s^{-1},"]"))
          ,expression(paste("V [m",s^{-1},"]"))
          ,"GHT [m]"
          ,expression(paste("QV [g",kg^{-1},"]"))
          )

indir="./outdata"

itest=0

devcur <- array(NA,c(nfields,nstats))

for (test in tests) {

itest <- itest+1

istat <- 1

for (statname in statnames) {

fname <- paste(indir,'/',test,'_',ftype1,'_',statname,'.txt',sep="")

thisfile <- file(fname,"ra")

header <- scan(thisfile,what='a',nlines=1)

allvars_pr <- NULL

while (TRUE) {
  data <- unlist(scan(thisfile,sep=','
               ,what=list("","",1,1,1,1),nlines=1))
  allvars_pr <- unlist(rbind(allvars_pr,c(data[1:2],
                          mean(as.numeric(data[3:6]),na.rm=TRUE))))
  if (data[1] == "STOP" ) break
}

close(thisfile)


fname <- paste(indir,'/',test,'_',ftype2,'_',statname,'.txt',sep="")

thisfile <- file(fname,"ra")

header <- scan(thisfile,what='a',nlines=1)

allvars_po <- NULL

while (TRUE) {
  data <- unlist(scan(thisfile,sep=','
               ,what=list("","",1,1,1,1),nlines=1))
  allvars_po <- unlist(rbind(allvars_po,c(data[1:2],
                          mean(as.numeric(data[3:6]),na.rm=TRUE))))

  if (data[1] == "STOP" ) break

}

close(thisfile)

ifield <- 1

for (field in fields3d) {
   locs <- which(!is.na(match(allvars_pr[, 1],field)))
   x_pr <- as.numeric(allvars_pr[locs,3])
   if (field == "QVAPOR") x_pr <- x_pr*1.e3
   y_pr <- as.numeric(gsub("P","",allvars_pr[locs,2]))

   unit <- units[ifield]

   locs <- which(!is.na(match(allvars_po[, 1],field)))
   x_po <- as.numeric(allvars_po[locs,3])
   if (field == "QVAPOR") x_po <- x_po*1.e3
   y_po <- as.numeric(gsub("P","",allvars_po[locs,2]))

   picname <- paste("./pics/pr_po_",field,"_",statname,"_alltests.png"
                   ,sep="")

   if ( itest == 1) {

   png(picname,height=600,width=400)  
   
   xmin <- min(x_pr,x_po,na.rm=TRUE)
   xmax <- max(x_po,x_pr,na.rm=TRUE)
   ymin <- min(y_pr,y_pr,na.rm=TRUE)
   ymax <- max(y_pr,y_po,na.rm=TRUE)

   plot(x_pr,y_pr,xlim=c(xmin,xmax),ylim=c(ymax,ymin),xlab=unit,
   ylab="p [hPa]",cex.axis=1.5,type="l",lwd=4,col=tcolors[itest],
   cex.lab=1.5,
   main=paste(statname,sep=''),lty=2)
   devcur[ifield,istat] <- dev.cur()
   } else {
   dev.set(devcur[ifield,istat])
   lines(x_pr,y_pr,lwd=4,col=tcolors[itest],lty=2)
   }
   
   lines(x_po,y_po,lwd=4,col=tcolors[itest],lty=1)

#   print(picname)
#   print(c(statname,test,field))

   if (itest == ntests) {   
   xmin <- min(x_pr,x_po,na.rm=TRUE)
   xmax <- max(x_po,x_pr,na.rm=TRUE)
   ymin <- min(y_pr,y_pr,na.rm=TRUE)
   ymax <- max(y_pr,y_po,na.rm=TRUE)
   legend(x=xmax,y=ymin,xjust=1,yjust=1,col=tcolors,
   lwd=4,legend=tests,cex=1)
   dev.off()

   }

   ifield <- ifield+1
}
   istat <- istat+1
}
}
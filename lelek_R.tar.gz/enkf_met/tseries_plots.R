#to plot domain-averaged fluxes from different tests for aerosols

library(ncdf)

tests <- c("test_806","test_816","test_817","test_818","test_823")
ntests <- length(tests)
tcolors <- rainbow(ntests+1,start=0.,end=1.)

hours <- c("00","06","12","18")
nhours <- length(hours)

names <-  c("GLW","SWDOWN","RAINNC","RAINC","HFX","LH")

outdir <- "./pics/tseries/"

it <- 1
for (test in tests) {
    ih <- 1
    for (hour in hours) {
        ncname <- paste('./indata/',test,'/tseries/vars_land_ave_',
			hour,'.nc',sep='')
	print(ncname)
	nc <- open.ncdf(ncname, readunlim=FALSE )
	nt <- length(get.var.ncdf(nc,"Time"))
	if (it == 1 && ih == 1) {
	glw <- array(NA,dim=c(ntests,nhours,nt))
	swdown <- array(NA,dim=c(ntests,nhours,nt))
	rainnc <- array(NA,dim=c(ntests,nhours,nt))
	rainc <- array(NA,dim=c(ntests,nhours,nt))
	rain <- array(NA,dim=c(ntests,nhours,nt))
	hfx <- array(NA,dim=c(ntests,nhours,nt))
	lh <- array(NA,dim=c(ntests,nhours,nt))
	}
	glw[it,ih,] <- get.var.ncdf(nc,names[1])
	swdown[it,ih,] <- get.var.ncdf(nc,names[2])
	rainnc[it,ih,] <- get.var.ncdf(nc,names[3])
	rainc[it,ih,] <- get.var.ncdf(nc,names[4])
	hfx[it,ih,] <- get.var.ncdf(nc,names[5])
	lh[it,ih,] <- get.var.ncdf(nc,names[6])
	ih <- ih+1		
     }
it <- it+1
}

close.ncdf(nc)

i <- 1
rain[,,i]= rainc[,,i]+rainnc[,,i]

for (i in nt:2) {
    rainnc[,,i] <- rainnc[,,i]-rainnc[,,i-1]
    rainc[,,i] <- rainc[,,i]-rainc[,,i-1]
    rain[,,i] <- rainc[,,i]+rainnc[,,i]
}

pngname <- paste(outdir,names[1],'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

maxhours <- 24+nt-6

xmin <- 0
xmax <- maxhours
ymin <- min(glw)
ymax <- max(glw)

ymin <- max(0,ymin-0.025*ymin)
ymax <- ymax+0.025*ymax

plot(1:maxhours,1:maxhours,yaxs="i",xaxs="i",
     type="n",xlim=c(xmin,xmax),ylim=c(ymin,ymax))

it <- 1
for (test in tests) {
    ih <- 1
    for (hour in hours) {
    xminl <- as.numeric(hour)+1
    xmaxl <- xminl+nt-1
    lines(xminl:xmaxl,glw[it,ih,],col=tcolors[it],lwd=4)
    points(xminl:xmaxl,glw[it,ih,],col=tcolors[it],pch=19,cex=1)
    ih <- ih+1 
}
it <- it+1
}

yloc <- ymax
yjust <- 1

xloc <- xmin
xjust <- 0

legend(x=xloc,y=yloc,xjust=xjust,yjust=yjust,col=tcolors[1:ntests],
lwd=3,legend=tests,cex=0.9)


dev.off()


pngname <- paste(outdir,names[2],'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

maxhours <- 24+nt-6

xmin <- 0
xmax <- maxhours
ymin <- min(swdown)
ymax <- max(swdown)

ymin <- max(0,ymin-0.025*ymin)
ymax <- ymax+0.025*ymax

plot(1:maxhours,1:maxhours,yaxs="i",xaxs="i",
     type="n",xlim=c(xmin,xmax),ylim=c(ymin,ymax))

it <- 1
for (test in tests) {
    ih <- 1
    for (hour in hours) {
    xminl <- as.numeric(hour)+1
    xmaxl <- xminl+nt-1
    lines(xminl:xmaxl,swdown[it,ih,],col=tcolors[it],lwd=4)
    points(xminl:xmaxl,swdown[it,ih,],col=tcolors[it],pch=19,cex=1)
    ih <- ih+1 
}
it <- it+1
}

yloc <- ymax
yjust <- 1

xloc <- xmin
xjust <- 0

legend(x=xloc,y=yloc,xjust=xjust,yjust=yjust,col=tcolors[1:ntests],
lwd=3,legend=tests,cex=0.9)


dev.off()


pngname <- paste(outdir,names[3],'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

maxhours <- 24+nt-6

xmin <- 0
xmax <- maxhours
ymin <- min(rainnc)
ymax <- max(rainnc)

ymin <- max(0,ymin-0.025*ymin)
ymax <- ymax+0.025*ymax

plot(1:maxhours,1:maxhours,yaxs="i",xaxs="i",
     type="n",xlim=c(xmin,xmax),ylim=c(ymin,ymax))

it <- 1
for (test in tests) {
    ih <- 1
    for (hour in hours) {
    xminl <- as.numeric(hour)+1
    xmaxl <- xminl+nt-1
    lines(xminl:xmaxl,rainnc[it,ih,],col=tcolors[it],lwd=4)
    points(xminl:xmaxl,rainnc[it,ih,],col=tcolors[it],pch=19,cex=1)
    ih <- ih+1 
}
it <- it+1
}

yloc <- ymax
yjust <- 1

xloc <- xmin
xjust <- 0

legend(x=xloc,y=yloc,xjust=xjust,yjust=yjust,col=tcolors[1:ntests],
lwd=3,legend=tests,cex=0.9)


dev.off()


pngname <- paste(outdir,names[4],'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

maxhours <- 24+nt-6

xmin <- 0
xmax <- maxhours
ymin <- min(rainc)
ymax <- max(rainc)

ymin <- max(0,ymin-0.025*ymin)
ymax <- ymax+0.025*ymax

plot(1:maxhours,1:maxhours,yaxs="i",xaxs="i",
     type="n",xlim=c(xmin,xmax),ylim=c(ymin,ymax))

it <- 1
for (test in tests) {
    ih <- 1
    for (hour in hours) {
    xminl <- as.numeric(hour)+1
    xmaxl <- xminl+nt-1
    lines(xminl:xmaxl,rainc[it,ih,],col=tcolors[it],lwd=4)
    points(xminl:xmaxl,rainc[it,ih,],col=tcolors[it],pch=19,cex=1)
    ih <- ih+1 
}
it <- it+1
}

yloc <- ymax
yjust <- 1

xloc <- xmin
xjust <- 0

legend(x=xloc,y=yloc,xjust=xjust,yjust=yjust,col=tcolors[1:ntests],
lwd=3,legend=tests,cex=0.9)


dev.off()

pngname <- paste(outdir,names[5],'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

maxhours <- 24+nt-6

xmin <- 0
xmax <- maxhours
ymin <- min(hfx)
ymax <- max(hfx)

ymin <- ymin-0.025*ymin
ymax <- ymax+0.025*ymax

plot(1:maxhours,1:maxhours,yaxs="i",xaxs="i",
     type="n",xlim=c(xmin,xmax),ylim=c(ymin,ymax))

it <- 1
for (test in tests) {
    ih <- 1
    for (hour in hours) {
    xminl <- as.numeric(hour)+1
    xmaxl <- xminl+nt-1
    lines(xminl:xmaxl,hfx[it,ih,],col=tcolors[it],lwd=4)
    points(xminl:xmaxl,hfx[it,ih,],col=tcolors[it],pch=19,cex=1)
    ih <- ih+1 
}
it <- it+1
}

yloc <- ymax
yjust <- 1

xloc <- xmin
xjust <- 0

legend(x=xloc,y=yloc,xjust=xjust,yjust=yjust,col=tcolors[1:ntests],
lwd=3,legend=tests,cex=0.9)


dev.off()


pngname <- paste(outdir,names[6],'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

maxhours <- 24+nt-6

xmin <- 0
xmax <- maxhours
ymin <- min(lh)
ymax <- max(lh)

ymin <- max(0,ymin-0.025*ymin)
ymax <- ymax+0.025*ymax

plot(1:maxhours,1:maxhours,yaxs="i",xaxs="i",
     type="n",xlim=c(xmin,xmax),ylim=c(ymin,ymax))

it <- 1
for (test in tests) {
    ih <- 1
    for (hour in hours) {
    xminl <- as.numeric(hour)+1
    xmaxl <- xminl+nt-1
    lines(xminl:xmaxl,lh[it,ih,],col=tcolors[it],lwd=4)
    points(xminl:xmaxl,lh[it,ih,],col=tcolors[it],pch=19,cex=1)
    ih <- ih+1 
}
it <- it+1
}

yloc <- ymax
yjust <- 1

xloc <- xmin
xjust <- 0

legend(x=xloc,y=yloc,xjust=xjust,yjust=yjust,col=tcolors[1:ntests],
lwd=3,legend=tests,cex=0.9)


dev.off()

name <- "RAIN"

pngname <- paste(outdir,name,'.png',sep="")
png(pngname,width=600, height=400.,bg="white")

maxhours <- 24+nt-6

xmin <- 0
xmax <- maxhours
ymin <- min(rain)
ymax <- max(rain)

ymin <- max(0,ymin-0.025*ymin)
ymax <- ymax+0.025*ymax

plot(1:maxhours,1:maxhours,yaxs="i",xaxs="i",
     type="n",xlim=c(xmin,xmax),ylim=c(ymin,ymax))

it <- 1
for (test in tests) {
    ih <- 1
    for (hour in hours) {
    xminl <- as.numeric(hour)+1
    xmaxl <- xminl+nt-1
    lines(xminl:xmaxl,rain[it,ih,],col=tcolors[it],lwd=4)
    points(xminl:xmaxl,rain[it,ih,],col=tcolors[it],pch=19,cex=1)
    ih <- ih+1 
}
it <- it+1
}

yloc <- ymax
yjust <- 1

xloc <- xmin
xjust <- 0

legend(x=xloc,y=yloc,xjust=xjust,yjust=yjust,col=tcolors[1:ntests],
lwd=3,legend=tests,cex=0.9)


dev.off()



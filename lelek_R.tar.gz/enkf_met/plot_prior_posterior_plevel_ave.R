test <- "test_815"

ftype1="pprior" 
ftype1="prior" 
ftype2="posterior"

stats <- c("FBAR","OBAR","FSTDEV","OSTDEV","PR_CORR","ME",
      "BCMSE","RMSE")


statnames <- c("ME","RMSE")

tcolors <- c("black","red")

fields3d <- c("TT","UU","VV","GHT","QVAPOR")
levels <- c("P925","P850","P700","P500","P400","P250","P100")
units <- c("T [K]"
          ,expression(paste("U [m",s^{-1},"]"))
          ,expression(paste("V [m",s^{-1},"]"))
          ,"GHT [m]"
          ,expression(paste("QV [g",kg^{-1},"]"))
          )

ncols=6

indir="./outdata"

for (statname in statnames) {

fname <- paste(indir,'/',test,'_',ftype1,'_',statname,'.txt',sep="")

thisfile <- file(fname,"ra")

header <- scan(thisfile,what='a',nlines=1)

allvars_pr <- NULL

while (TRUE) {
  data <- unlist(scan(thisfile,sep=','
               ,what=list("","",1,1,1,1),nlines=1))
  allvars_pr <- unlist(rbind(allvars_pr,c(data[1:2],
                          mean(as.numeric(data[3:6]),na.rm=TRUE))))
  if (data[1] == "STOP" ) break
}

close(thisfile)


fname <- paste(indir,'/',test,'_',ftype2,'_',statname,'.txt',sep="")

thisfile <- file(fname,"ra")

header <- scan(thisfile,what='a',nlines=1)

allvars_po <- NULL

while (TRUE) {
  data <- unlist(scan(thisfile,sep=','
               ,what=list("","",1,1,1,1),nlines=1))
  allvars_po <- unlist(rbind(allvars_po,c(data[1:2],
                          mean(as.numeric(data[3:6]),na.rm=TRUE))))

  if (data[1] == "STOP" ) break

}

close(thisfile)

i <- 1

for (field in fields3d) {
   locs <- which(!is.na(match(allvars_pr[, 1],field)))
   x_pr <- as.numeric(allvars_pr[locs,3])
   if (field == "QVAPOR") x_pr <- x_pr*1.e3
   y_pr <- as.numeric(gsub("P","",allvars_pr[locs,2]))

   unit <- units[i]

   locs <- which(!is.na(match(allvars_po[, 1],field)))
   x_po <- as.numeric(allvars_po[locs,3])
   if (field == "QVAPOR") x_po <- x_po*1.e3
   y_po <- as.numeric(gsub("P","",allvars_po[locs,2]))

   picname <- paste("./pics/pr_po_",field,"_",statname,"_",test,".png"
                   ,sep="")

   xmin <- min(x_pr,x_po,na.rm=TRUE)
   xmax <- max(x_po,x_pr,na.rm=TRUE)
   ymin <- min(y_pr,y_pr,na.rm=TRUE)
   ymax <- max(y_pr,y_po,na.rm=TRUE)

   png(picname,height=600,width=400)  
   plot(x_pr,y_pr
   ,xlim=c(xmin,xmax)
   ,ylim=c(ymax,ymin)
   ,xlab=unit,ylab="p [hPa]"
   ,cex.axis=1.5,type="l",lwd=4,col=tcolors[1],cex.lab=1.5,
   main=paste(statname,sep=''))
   lines(x_po,y_po,lwd=4,col=tcolors[2])
   legend(x=xmax,y=ymin,xjust=1,yjust=1,col=tcolors,
   lwd=4,legend=c(ftype1,ftype2),cex=1)

   dev.off()

   i <- i+1
}

}
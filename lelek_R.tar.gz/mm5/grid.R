namea <- 
nameb <- "./sigmah.txt"
ncols <- 3
cola <- 1
colb <- 3

xlabstring=expression("level number")
ylabstring=expression("pressure(mb)")

png("grid.png",width = 380, height = 360,bg="lightblue")

infile <- file(namea,"ra")
a <- readLines(infile)
nlevs <- length(a)
close(infile)

infile <- file(namea,"ra")
vara <-array(0,c(nlevs,ncols))	
for (i in 1:nlevs) {
	vara[i,] <- array(scan(infile,what=0.,n=ncols))
}
close(infile)

levs <- c(1:nlevs)

#xmin <- round(min(vara[,colb]-1,varb[,colb]-1,varc[,colb]-1))
#xmax <- round(max(vara[,colb]+1,varb[,colb]+1,varc[,colb]+1))
xmin=0
xmax <- nlevs
ymin=1000
ymax=0
margin <- c(.9,.9,.1,.15)
par(mai=margin)
plot(vara[,cola],vara[,colb],"l",col="blue",
xlim=c(xmin,xmax),ylim=c(ymin,ymax),
lwd=5,font.lab=1,
xlab=xlabstring,ylab=ylabstring,
xaxs="i",yaxs="i",cex.axis=1.15,cex.lab=1.45)#

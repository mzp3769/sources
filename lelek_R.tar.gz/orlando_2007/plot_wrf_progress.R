#to plot r, bias, rmse, and skill for wrf/chem

rcoeff <- c(0.67,0.73,0.72,0.83,0.83)
bias <-   c(14.3,3.4,11.5,6.4,3.3)
rmse <- c(20.9,11.6,16.3,11.2,9.8)
skill <- c(24,61,30,73,81)

xvec <- c(1:5)
xlabs <- "WRF/Chem Version"
ylabs <- "Correlation"
lxvec <- c("v-1","v-2.0","v-2.0.3",
          "v-2.1.2","v-2.2")

png("corr.png",width = 600, height = 500,bg="white")
plot(xvec,rcoeff,"l",col="red",
ylim=c(.6,.9),yaxs="i",xaxt = "n",xlab=xlabs,ylab=ylabs,lwd=4)
axis(1, at=xvec, labels=lxvec,cex.axis=1.2)
points(xvec,rcoeff,type="p",col="red",pch=19,cex=2)
dev.off()

png("bias.png",width = 600, height = 500,bg="white")
ylabs <- "Bias [ppbv]"
plot(xvec,bias,"l",col="blue",
ylim=c(0.,15),yaxs="i",xaxt = "n",xlab=xlabs,ylab=ylabs,lwd=4)
axis(1, at=xvec, labels=lxvec,cex.axis=1.2)
points(xvec,bias,type="p",col="blue",pch=19,cex=2)
dev.off()


png("rmse.png",width = 600, height = 500,bg="white")
ylabs <- "RMSE [ppbv]"
plot(xvec,rmse,"l",col="green",
ylim=c(5.,25),yaxs="i",xaxt = "n",xlab=xlabs,ylab=ylabs,lwd=4)
axis(1, at=xvec, labels=lxvec,cex.axis=1.2)
points(xvec,rmse,type="p",col="green",pch=19,cex=2)
dev.off()

png("skill.png",width = 600, height = 500,bg="white")
ylabs <- "Skill [%]"
plot(xvec,skill,"l",col="purple",
ylim=c(0,100),yaxs="i",xaxt = "n",xlab=xlabs,ylab=ylabs,lwd=4)
axis(1, at=xvec, labels=lxvec,cex.axis=1.2)
points(xvec,skill,type="p",col="purple",pch=19,cex=2)
dev.off()


#to plot single station increment
name <- "/export/scratch2/pagowski/stuff/R/gsi/indata/increment.txt"
infile <- file(name,"ra")

number <- 1000
increment <- array(NA,c(2,number))

for (i in 1:number) {
   data <- scan(infile,what=1,n=2,quiet=TRUE)
   if (is.na(data[1]))  break
   increment[1,i] <- data[1]*dx
   increment[2,i] <- data[2]
} 
n <- i-1

close(infile)

xmin <- min(increment[1,],na.rm=TRUE)
xmax <- max(increment[1,],na.rm=TRUE)
ymin <- min(increment[2,],na.rm=TRUE)
ymax <- max(increment[2,],na.rm=TRUE)	

#png("./pngs/increment.png",width = 500, height = 500,bg="white")
x11(width=5,height=5)

plot(increment[1,1:n],increment[2,1:n],type="l",
     xlim=c(xmin,xmax),ylim=c(ymin,ymax),lwd=3,col="red",
     xaxs="i",yaxs="i",xlab="Distance [km]",ylab="Increment")

#dev.off()
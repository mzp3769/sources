#to plot vertical correlations for gsi
name <- "/export/scratch2/pagowski/stuff/R/gsi/nmm/indata/vlevel_cor.txt"
infile <- file(name,"ra")
nz <- scan(infile,what=1,n=1)

correl <- array(1,c(nz,nz))

for (k in 1:(nz-1)) {
    for (l in (k+1):nz) {
        data <- scan(infile,what=1,n=3,quiet=TRUE)
	correl[k,l] <- data[3]
        correl[l,k] <- data[3]
    }
} 

close(infile)

nlevs=20
zmin <- min(correl)
zmax <- max(correl)	
x <- 1:(nz-1)
y <- x

#graphics.off()

png("./pngs/vcor.png",width = 575, height = 500,bg="white")

labels <- "Vertical level"
filled.contour(x,y,correl[1:(nz-1),1:(nz-1)],
               nlevels=nlevs,zlim=range(zmin,zmax),
               color.palette=rainbow,xlab=labels,ylab=labels)

dev.off()


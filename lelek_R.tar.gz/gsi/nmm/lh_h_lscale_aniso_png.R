#to plot anisotropic correlations scales for gsi
library(fields)


BIN <- FALSE

if (BIN==FALSE) {

#begin ascii read

name <- "./indata/lh_hdist_corbin_aniso.txt"

infile <- file(name,"ra")
ndata <- scan(infile,what=1,n=1)
x <- array(NA,ndata)
y <- array(NA,ndata)
correl <- array(NA,ndata)

ii <- 0
for (i in 1:ndata) {
   data <- scan(infile,what=1,n=3)
   x[i] <- data[1]
   y[i] <- data[2]
   correl[i] <- data[3] 
   if (is.na(correl[i]))  break
}
close(infile)
#end ascii read
ndata <- i-1

x <- x*dx
y <- y*dy

xmin <- 0
xmax <- max(x,na.rm=TRUE)
ymin <- 0
ymax <- max(x,na.rm=TRUE)
zmin <- -1
zmax <- 1

png("./pngs/lh_aniso.png",
width = 560, height = 500,bg="white")

quilt.plot(x[1:ndata],y[1:ndata],correl[1:ndata],ncol=100,nrow=100)
#drape.plot(x[1:ndata],y[1:ndata],correl[1:ndata],ncol=100,nrow=100)

dev.off()
}

if (BIN==TRUE) {
#begin bin read
name <- "./indata/hdist_cor_aniso.bin"
infile <- file(name,"rb")
trash <- readBin(infile,what=numeric(), n=1,size=4)
trash <- readBin(infile,what=integer(), n=4,size=4)
nx <- trash[1]
ny <- trash[2]
nz <- trash[3]
trash <- readBin(infile,what=numeric(), n=1,size=4)

correl <- array(NA,c(nx,ny,nz))
for (k in 1:nz) {
for (j in 1:ny) {
trash <- readBin(infile,what=numeric(), n=1,size=4)
correl[,j,k] <- readBin(infile,what=numeric(), n=nx,size=4)
trash <- readBin(infile,what=numeric(), n=1,size=4)
}}
close(infile)
#end binary read

x11(width=5.6,height=5)



}

#to plot correlations for gsi
name <- "./indata/hdist_cor.txt"
infile <- file(name,"ra")
data <- scan(infile,what=1,n=6)
nbin <- data[6]
distmax <- data[5]

dist <- array(NA,nbin)
correl <- array(NA,nbin)
freq <- array(NA,nbin)

print("Reading data")
   data <- scan(infile,what=1,n=1,quiet=TRUE)
   for (ibin in 1:nbin) {
       data <- scan(infile,what=1,n=4,quiet=TRUE)
       dist[ibin] <- data[2]*dx
       correl[ibin] <- data[3]
       freq[ibin] <- data[4]
   }
 
close(infile)

freq <- freq/sum(freq,na.rm=TRUE)
xmin <- 0
xmax <- max(dist,na.rm=TRUE)
ymin <- 0 
ymax <- 0.015 #max(freq,na.rm=TRUE)


png("./pngs/hcor_distfreq_bin.png",width = 500, height = 500,bg="white")

plot(dist,freq,col="red",xlim=c(xmin,xmax),ylim=c(ymin,ymax),
xlab="Distance [km]",ylab="Frequency",xaxs="i",yaxs="i",
cex.axis=2,type="l",lwd=2)

dev.off()


#to plot scales and variances for wrfvar gaussian

indir <- "./indata"

method <- "nmc"

varnames <- c("sulf","BC1","BC2","OC1","OC2",
              "DUST1","DUST2","DUST3","DUST4","DUST5",
              "SEAS1","SEAS2","SEAS3","SEAS4",
              "P25","PMTOT")


times <- c("00z","06z","12z","18z")
timesl <- c("00 UTC","06 UTC","12 UTC","18 UTC")
ntimes <- length(times)
cols <- c("orange","black","blue","red")

names <- paste(indir,'/','dsig.txt',sep="")
infile <- file(names,"ra")
nz <- scan(infile,what=1,n=1,quiet=TRUE)
dsig <- array(NA,nz)
for (k in 1:nz) {
   data <- scan(infile,what=1,n=2,quiet=TRUE)
   dsig[k] <- data[2]
}
close(infile)


namep <- paste(indir,'/','eta_pave.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1,quiet=TRUE)
etalevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=2,quiet=TRUE)
   etalevels[k] <- data[1]
}
close(infile)

vlscale <- array(NA,c(ntimes,nzp))

for (varname in varnames) {

for (i in 1:ntimes) {

    name <- paste("./outdata/v_lscale_wrfvar_R_4gsi_",method,"_",varname,"_",
                   times[i],".txt",sep='')
    infile <- file(name,"ra")

    nzl <- scan(infile,what=1,n=1,quiet=TRUE)
    if (nzp != nzl)  stop("Levels don't match")
    for (k in 1:nzl) {
       data <- scan(infile,what=1,n=2,quiet=TRUE)
       vlscale[i,k] <- 1./data[2]/dsig[k]
    }

    close(infile)
}


nz <- nzl

xmin <- 0
xmax <- ((max(vlscale)%/%1)*1+2)
ymin <- 0
ymax <- 1

png(paste("./pics/vcor_scales_wrfvar_gauss_",method,"_",varname,
	  "_sigma.png",sep=""),width = 600,height = 600,bg="white")

plot(vlscale[1,1:nz],etalevels[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymax,ymin),
   xlab="Grid unit",ylab="Sigma",xaxs="i",yaxs="i",
   cex.axis=1,cex.lab=1,type="l",lwd=3,cex=1)
points(vlscale[1,1:nz],etalevels[1:nz],col=cols[1],pch=22,cex=0.65)

for (i in 2:ntimes) {
    lines(vlscale[i,1:nz],etalevels[1:nz],lwd=3,col=cols[i])
    points(vlscale[i,1:nz],etalevels[1:nz],col=cols[i],pch=22,cex=0.65)
}

legend(x=xmax,y=0,lwd=3,pch=c(22,22,22,22),
legend=timesl,col=cols,xjust=1,cex=0.75) 

dev.off()

}
#!/bin/sh

outfile=pm2_5_scales_00z

OUTDIR=/Volumes/local/scratch/stuff/R/gsi/arw/indata
R CMD BATCH h_lscale_batch.R h_lscale.log
R CMD BATCH vcor_batch.R vcor.log
R CMD BATCH vcov_batch.R vcov.log

cd $OUTDIR
cat h_lscale_R.txt v_lscale_R.txt vlevel_stdev_R.txt > $outfile

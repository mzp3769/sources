#plot scales and variances

method="nmc"
prefix <- paste("./indata/outdata_ysu_",method,"_24km_",sep='')

stdevlabel <- expression(paste("Stdev [",mu,g," ",g^{-1},"]",,sep="")) 

times <- "all"
timesl <- "ALL"
cols <- "black"

#times <- c("00z","06z","12z","18z")
#timesl <- c("00 UTC","06 UTC","12 UTC","18 UTC")
#cols <- c("orange","black","blue","red")

varnames <- c("sulf","BC1","BC2","OC1","OC2",
              "DUST1","DUST2","DUST3","DUST4","DUST5",
              "SEAS1","SEAS2","SEAS3","SEAS4",
              "P25","PMTOT")


ntimes <- length(times)

source("magnitude_func.R")

namep <- paste('indata/eta_pave.txt',sep="")
infile <- file(namep,"ra")
nzp <- scan(infile,what=1,n=1,quiet = TRUE)
etalevels <- array(NA,nzp)
plevels <- array(NA,nzp)

for (k in 1:nzp) {
   data <- scan(infile,what=1,n=2,quiet = TRUE)
   etalevels[k] <- data[1]
   plevels[k] <- data[2]
}
close(infile)

for (varname in varnames) {

    print(varname)

for (i in 1:ntimes) {
    namefile <- paste(prefix,times[i],'/aero_be.txt',sep='')
    infile <- file(namefile,"ra")
    data <- scan(infile,what=1,n=4,quiet = TRUE)
    naeros <- data[1]
    nz <- data[2]
    ncats <- data[3]
    nstats <- data[4]

    dsig <- array(NA,nz)
    for (k in 1:nz) {
        junk <- scan(infile,what=1,n=2,quiet = TRUE)
	dsig[k] <- junk[1]
    }

    if ( i == 1) {
        stats <- array(NA,c(ntimes,nz,nstats))
    }

    while (TRUE) {
      name <- scan(infile,what='a',n=1,quiet = TRUE)
      if ( name != varname ) {
         for (k in 1:nz) {
      	     junk <- scan(infile,what=1,n=4,quiet = TRUE)
	 }

      } else {
         print(c(name,timesl[i]))	
         for (k in 1:nz) {
             stats[i,k,] <- scan(infile,what=1,n=4,quiet = TRUE)
         }
         break
      }
    }

    close(infile)

}

stdev <- stats[,,2]
hlscale <- stats[,,3]
vlscale <- stats[,,4]


#bounds <- log10_ceiling(c(xmin,xmax))

xmin <- min(stdev)
xmax <- max(stdev)+0.1*max(stdev)

logplevs <- -log(plevels/plevels[1])

ymin <- logplevs[1]
ymax <- logplevs[nz]

#xmin <- bounds[1]
#xmax <- bounds[2]

width <- 400
height <- 600

ylabstring <- expression(paste(-log,"(p/",p[s],")"))

png(paste("./pics/stdev_wrfvar_",method,"_",varname,"_plevs.png",sep=''),
    width = width, height = height ,bg="white")

par(mar=c(5, 4.5, 4, 2)+0.1)

if ( is.null(dim(stdev)) ) {
   plot(stdev[1:nz],logplevs[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab=stdevlabel,ylab=ylabstring,xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=3,cex=1.5)
   points(stdev[1:nz],logplevs[1:nz],col=cols[1],pch=22,cex=0.25,
       lwd=3)
} else {

plot(stdev[1,1:nz],logplevs[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab=stdevlabel,ylab=ylabstring,xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=3,cex=1.5)
points(stdev[1,1:nz],logplevs[1:nz],col=cols[1],pch=22,cex=0.25,
       lwd=3)

}

if ( !is.null(dim(stdev)) ) {

for (i in 2:ntimes) {
    lines(stdev[i,1:nz],logplevs[1:nz],lwd=3,col=cols[i])
    points(stdev[i,1:nz],logplevs[1:nz],col=cols[i],pch=22,cex=0.25,
       lwd=3)
}
}

legend(x=xmax,y=ymax,lwd=3,pch=c(22,22,22,22),
legend=varname,col=cols,xjust=1,cex=1.5) 

dev.off()

hlscale <- hlscale/1000.

xmin <-  ((min(hlscale)%/%1)-10)
xmax <- ((max(hlscale)%/%1)+10)

png(paste("./pics/hlscale_wrfvar_",method,"_",varname,"_plevs.png",sep=''),
width = width, height = height,bg="white")

par(mar=c(5, 4.5, 4, 2)+0.1)

if (is.null(dim(hlscale))) {

plot(hlscale[1:nz],logplevs[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab="L [km]",ylab=ylabstring,xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=3,cex=1.5)
points(hlscale[1:nz],logplevs[1:nz],col=cols[1],pch=22,cex=0.25,
       lwd=3)
} else {

plot(hlscale[1,1:nz],logplevs[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab="L [km]",ylab=ylabstring,xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=3,cex=1.5)
points(hlscale[1,1:nz],logplevs[1:nz],col=cols[1],pch=22,cex=0.25,
       lwd=3)

}

if ( !is.null(dim(hlscale)) ) {

for (i in 2:ntimes) {
    lines(hlscale[i,1:nz],logplevs[1:nz],lwd=3,col=cols[i])
    points(hlscale[i,1:nz],logplevs[1:nz],col=cols[i],pch=22,cex=0.25,
       lwd=3)
}
}

legend(x=xmin,y=ymax,lwd=3,pch=c(22,22,22,22),
legend=varname,col=cols,xjust=0,cex=1.5) 

dev.off()

xmin <- 0
xmax <- ((max(vlscale)%/%1)*1+2)

png(paste("./pics/vlscale_wrfvar_",method,"_",varname,"_plevs.png",sep=''),
width = width, height = height,bg="white")

par(mar=c(5, 4.5, 4, 2)+0.1)

if ( is.null(dim(vlscale))) {

plot(vlscale[1:nz],logplevs[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab="Grid unit",ylab=ylabstring,xaxs="i",yaxs="i",
   cex.axis=1.5,cex.lab=1.5,type="l",lwd=3,cex=1.5)
points(vlscale[1:nz],logplevs[1:nz],col=cols[1],pch=22,cex=0.25,
       lwd=3)

} else {

plot(vlscale[1,1:nz],logplevs[1:nz],
   col=cols[1],xlim=c(xmin,xmax),ylim=c(ymin,ymax),
   xlab="Grid unit",ylab=ylabstring,xaxs="i",yaxs="i",
   cex.axis=1.6,cex.lab=1.5,type="l",lwd=3,cex=1.5)
points(vlscale[1,1:nz],logplevs[1:nz],col=cols[1],pch=22,cex=0.25,
       lwd=3)

}

if ( !is.null(dim(vlscale))) {

for (i in 2:ntimes) {
    lines(vlscale[i,1:nz],logplevs[1:nz],lwd=3,col=cols[i])
    points(vlscale[i,1:nz],logplevs[1:nz],col=cols[i],pch=22,cex=0.25,
       lwd=3)
}

}

legend(x=xmax,y=ymax,lwd=3,pch=c(22,22,22,22),
legend=varname,col=cols,xjust=1,cex=1.5) 

dev.off()

}
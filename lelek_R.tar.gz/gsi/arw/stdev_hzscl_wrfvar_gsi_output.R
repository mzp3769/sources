#to write out lat independent stdev and hzscl for GSI

method <- "nmc"

prefix <- paste("./indata/outdata_ysu_",method,"_24km_",sep='')

times <- "all"
timesl <- "ALL"

times <- c("00z","06z","12z","18z")
timesl <- c("00 UTC","06 UTC","12 UTC","18 UTC")

ntimes <- length(times)
indir <- "./indata"

varnames <- c("sulf","BC1","BC2","OC1","OC2",
              "DUST1","DUST2","DUST3","DUST4","DUST5",
              "SEAS1","SEAS2","SEAS3","SEAS4",
              "P25","PMTOT")


source("magnitude_func.R")

#namep <- paste(indir,'/','eta.txt',sep="")
#infile <- file(namep,"ra")
#nzp <- scan(infile,what=1,n=1,quiet = TRUE)
#etalevels <- array(NA,nzp)

#for (k in 1:nzp) {
#   data <- scan(infile,what=1,n=1,quiet = TRUE)
#   etalevels[k] <- data
#}
#close(infile)

for (varname in varnames) {

for (i in 1:ntimes) {
    namefile <- paste(prefix,times[i],'/aero_be.txt',sep='')
    infile <- file(namefile,"ra")
    data <- scan(infile,what=1,n=4,quiet = TRUE)
    naeros <- data[1]
    nz <- data[2]
    ncats <- data[3]
    nstats <- data[4]

    for (k in 1:nz) {
             junk <- scan(infile,what=1,n=2,quiet = TRUE)
    }

    if ( i == 1) {
        stats <- array(NA,c(ntimes,nz,nstats))
    }

    while (TRUE) {
      name <- scan(infile,what='a',n=1,quiet = TRUE)
      if ( name != varname ) {
         for (k in 1:nz) {
      	     junk <- scan(infile,what=1,n=4,quiet = TRUE)
	 }

      } else {
         print(c(name,timesl[i]))	
         for (k in 1:nz) {
             stats[i,k,] <- scan(infile,what=1,n=4,quiet = TRUE)
         }
         break
      }
    }

    close(infile)

    out <- array(NA,c(3,nz))
    out[1,] <- seq(1,nz)
    out[2,] <- stats[i,,2]
    out[3,] <- stats[i,,3]


    title <- paste("./outdata/stdev_wrfvar_R_4gsi_",
                    varname,'_',times[i],".txt",sep='')
    write(nz,file=title,ncolumns=1,append=FALSE)
    write(out[1:2,],file=title,ncolumns=2,append=TRUE)

    title <- paste("./outdata/h_lscale_wrfvar_R_4gsi_",
                    varname,'_',times[i],".txt",sep='')
    write(nz,file=title,ncolumns=1,append=FALSE)
    write(out[c(1,3),],file=title,ncolumns=2,append=TRUE)


}
}
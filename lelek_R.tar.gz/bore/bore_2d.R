name <- "SHFLUX_2d.ascii"
#x11()
dev.set(3)
infile <- file(name,"ra")
header <- list(varname="A",date="A")
header <- scan(infile,what=header,nmax=1)
a <- readLines(infile)

ntimes <- (length(a)+1)/2
close(infile)
infile <- file(name,"ra")
var <-array(0,c(ntimes))
for (i in 1:ntimes) {
    	header <- scan(infile,what=header,nmax=1) 
	dates[i] <- header$date
	var[i] <- array(scan(infile,what=0.,n=1))
}

var[1] <- var[2]
close(infile)
plot(seq(0,ntimes-1,1),var,"l")

#plot(seq(0,ntimes-1,1),var[1,,]
#filled.contour(seq(0,ntimes-1,1),var[2,1,],var[1,,],nlevels=20,
#color.palette=rainbow)

#col=c("blue","skyblue1","violet","yellow2"))
#color.palette=terrain.colors)
#color.palette=topo.colors)
#color.palette=cm.colors)
#col = topo.colors(20))
#color.palette=rainbow,col = rainbow(10))
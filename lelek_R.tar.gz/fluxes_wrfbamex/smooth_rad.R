library(ncdf)
dir <- 
"/export/scratch2/pagowski/stuff/wrf1d/DART_iceland/models/PBL_1d/indata"
fname <- "sgpsirsE13.b1.BAMEX.nc"

nc <- open.ncdf(paste(dir,"/",fname,sep=""), write=TRUE,readunlim=FALSE)

print("opened ncfile")
downshortname <- "down_short_hemisp"
downlongname <- "down_long_hemisp_shaded"
uplongname <- "up_long_hemisp"

times <- get.var.ncdf( nc, "time")
timeoffset <- get.var.ncdf( nc, "time_offset")
dt <- times[2]-times[1]


ntimes <- dim(times)

downshort <- get.var.ncdf( nc, downshortname )
downlong <- get.var.ncdf( nc, downlongname )
uplong <- get.var.ncdf( nc, uplongname )

close.ncdf(nc)

interval <- 15
window <- 5

ntimesnew <- ntimes/interval
downshortnew <- array(NA,ntimesnew)
downlongnew <- array(NA,ntimesnew)
uplongnew <- array(NA,ntimesnew)
timesnew <- array(NA,ntimesnew)
timeoffsetnew <- array(NA,ntimesnew)

print("before loop")

for (i in 1:ntimesnew) {
    i1 <- max(((i-1)*interval+1-window),1)
    i2 <- min(((i-1)*interval+1+window),ntimes)
    print(i)
    downshortnew[i] <- pmax(mean(downshort[i1:i2]),0.)
    downlongnew[i] <- pmax(mean(downlong[i1:i2]),0.)
    uplongnew[i] <- pmax(mean(uplong[i1:i2]),0.)
    timesnew[i] <- times[(i-1)*interval+1]
    timeoffsetnew[i] <- timeoffset[(i-1)*interval+1]
}

print("after loop")

allflux <- array(c(timesnew,timeoffsetnew,
                   downshortnew,downlongnew,uplongnew),
              c(ntimesnew,5))
file("rad_smooth.txt","w")
for (i in 1:ntimesnew) {
    write(allflux[i,],file="rad_smooth.txt",
    ncolumns=5,append=TRUE)
}


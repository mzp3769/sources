library(ncdf)
dir <- 
"/export/scratch2/pagowski/stuff/wrf1d/DART_iceland/models/PBL_1d/indata"
fname <- "sgpsirsE13.b1.BAMEX.nc"

nc <- open.ncdf(paste(dir,"/",fname,sep=""), write=TRUE,readunlim=FALSE)

print("opened ncfile")
downshortname <- "down_short_hemisp"
downlongname <- "down_long_hemisp_shaded"
uplongname <- "up_long_hemisp"

times <- get.var.ncdf( nc, "time")
timeoffset <- get.var.ncdf( nc, "time_offset")
dt <- times[2]-times[1]


ntimes <- dim(times)

downshort <- get.var.ncdf( nc, downshortname )
downlong <- get.var.ncdf( nc, downlongname )
uplong <- get.var.ncdf( nc, uplongname )

window <- 15

ntimesnew <- ntimes/window+1
downshortnew <- array(NA,ntimesnew)
downlongnew <- array(NA,ntimesnew)
uplongnew <- array(NA,ntimesnew)
timesnew <- array(NA,ntimesnew)
timeoffsetnew <- array(NA,ntimesnew)

downshortnew[1] <- max(mean(downshort[1:window]),0)
downshortnew[ntimesnew] <- max(mean(downshort[(ntimes-window+1):ntimes]),
                               0)

downlongnew[1] <- mean(downlong[1:window])
downlongnew[ntimesnew] <- mean(downlong[(ntimes-window+1):ntimes])

uplongnew[1] <- mean(uplong[1:window])
uplongnew[ntimesnew] <- mean(uplong[(ntimes-window+1):ntimes])

timesnew[1] <- times[1]
timesnew[ntimesnew] <- times[ntimes]+dt

timeoffsetnew[1] <- timeoffset[1]
timeoffsetnew[ntimesnew] <- timeoffset[ntimes]+dt

for (i in 2:(ntimesnew-2)) {
    i1 <- ((i-2)*window+1)
    i2 <- (i*window+1)
    downshortnew[i] <- pmax(mean(downshort[i1:i2]),0.)
    downlongnew[i] <- mean(downlong[i1:i2])
    uplongnew[i] <- mean(uplong[i1:i2])
    timesnew[i] <- times[(i-1)*window+1]
    timeoffsetnew[i] <- timeoffset[(i-1)*window+1]
}

i1 <- ((ntimesnew-3)*window+1)
i2 <- ((ntimesnew-1)*window)
downshortnew[ntimesnew-1] <- max(mean(downshort[]),0.)
downlongnew[ntimesnew-1] <- mean(downlong[i1:i2])
uplongnew[ntimesnew-1] <- mean(uplong[i1:i2])
timeoffsetnew[ntimesnew-1] <- timeoffset[(ntimesnew-2)*window+1]
timesnew[ntimesnew-1] <- times[(ntimesnew-2)*window+1]

allflux <- array(c(timesnew,timeoffsetnew,
                   downshortnew,downlongnew,uplongnew),
              c(ntimesnew,5))
file("rad_smooth.txt","w")
for (i in 1:ntimesnew) {
    write(allflux[i,],file="rad_smooth.txt",
    ncolumns=5,append=TRUE)
}


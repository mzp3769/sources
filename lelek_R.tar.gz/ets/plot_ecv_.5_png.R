#To run etsfunc for the range of f's and q's 

o <- .5
r <- .15

nf <- 251
nq <- nf
fmin <- 0
fmax <- .3
delf <- (fmax-fmin)/(nf-1)

qmin <- 0
qmax <- 1
delq <- (qmax-qmin)/(nq-1)

etsmin <- 0.
etsmax <- 1.
nets <- nf
delets <- (etsmax-etsmin)/(nets-1)

etsvec <- seq(etsmin,etsmax,by=delets)
qvec <- seq(qmin,qmax,by=delq)

ecvarray <- array(NA,c(nets,nq))

source("ecv.R")

i <- 0
for (ets in etsvec) {
    i <- i+1
    j <- 0
    for (q in qvec) {
         j <- j+1
         f <- ets*o*(q+1)/(1.-ets*q)
	 if ((q >= f/o-1) && (f > 0.))  {
             ecvarray[i,j] <- ecvfunc(o,r,f,q)
         } else {
             ecvarray[i,j] <- NA
         }
    }
}


qfunc <- array(NA,c(nets,nq))
for (i in 1:nets) {
    for (j in 1:nq) {
        f <- etsvec[i]*o*(qvec[j]+1)/(1-etsvec[i]*qvec[j])
        qfunc[i,j] <- f/o-1-qvec[j]
    }
}

xstring <- expression("ETS")
ystring <- expression("q")

name <- paste("ecv_",as.character(o),".png",sep="")

png(name,width = 900, height = 900,bg="white")


if (o == .5) {
   filled.contour(etsvec,qvec,ecvarray,
               levels=c(-5,0,.2,.4,.6,.8,1.),
               zlim=c(-5,0,.2,.4,.6,.8,1.),
               xlab=xstring,ylab=ystring,
               xlim=range(etsmin,etsmax),
	       ylim=range(qmin,qmax),
	       color.palette=rainbow,
	       key.axes=axis(4,c(-5,0,.2,.4,.6,.8,1.)),
               plot.axes={axis(1); axis(2);
                          axis(3,seq(-1,10,by=10));
                          axis(4,seq(-1,10,by=10));
#                          contour(etsvec,qvec,qfunc,add=TRUE,
#                                  levels=seq(0,2,by=100.),
#                                  xlim=range(0,1),ylim=range(0,1),
#                                  zlim=range(0,1),method="flattest",
#                                  labcex=0.0001,lwd=1.)
                         })


#   text(.02,1.8,labels="a",cex=2.5,vfont=c("serif","plain"))
}

dev.off()


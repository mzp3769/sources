fefunc <- function(ets,o) {
  
   fe <- ets*o/(1+ets*o-o)

   return(fe)

}
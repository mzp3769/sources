#To run etsfunc for the range of f's and q's 

o <- .1

nf <- 251
nq <- nf
fmin <- 0
fmax <- .3
delf <- (fmax-fmin)/(nf-1)

qmin <- 0
qmax <- 2
delq <- (qmax-qmin)/(nq-1)

source("ets.R")

etsarray <- array(NA,c(nf,nq))

fvec <- seq(fmin,fmax,by=delf)
qvec <- seq(qmin,qmax,by=delq)

i <- 0
for (f in fvec) {
    i <- i+1
    j <- 0
    for (q in qvec) {
         j <- j+1
	 if (q >= f/o-1) {
             etsarray[i,j] <- etsfunc(f,q,o)
         } else {
             etsarray[i,j] <- NA
         }
    }
}



qfunc <- array(NA,c(nf,nq))
for (i in 1:nf) {
    for (j in 1:nq) {
        qfunc[i,j] <- fvec[i]/o-1-qvec[j]
    }
}

xstring <- expression("f")
ystring <- expression("q")

name <- paste("ets_",as.character(o),".eps",sep="")
postscript(name,width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

if (o == .1) {
   pal <- palette(gray(seq(1.,0.,len=8)))
   filled.contour(fvec,qvec,etsarray,
               levels=c(-.4,-.2,,0.,.2,.4,,.6,.8,,1.),zlim=c(-.4,1),
               xlab=xstring,ylab=ystring,xlim=range(0,.3),ylim=range(0,2),
               col=pal,key.axes=axis(4,c(-.4,-.2,0.,.2,.4,.6,.8,1.)),
               plot.axes={axis(1); axis(2);
                          axis(3,seq(-1,10,by=10));
                          axis(4,seq(-1,10,by=10));
                          contour(fvec,qvec,qfunc,add=TRUE,
                                  levels=seq(0,2,by=0.05),
                                  xlim=range(0,1),ylim=range(0,1),
                                  zlim=range(0,1),method="flattest",
                                  labcex=0.0001,lwd=1.)
                         })


   text(.007,1.8,labels="a",cex=1.5,vfont=c("serif","plain"))
}

dev.off()


#To run etsfunc for the range of o's, f's and q's 

omin <- .0
omax <- 1.
delo <- .01
no <- (omax-omin)/delo+1

fmin <- 0
fmax <- 1
delf <- 0.01
nf <- (fmax-fmin)/delf+1

qmin <- 0
qmax <- 5
delq <- .05
nq <- (qmax-qmin)/delq+1

source("detsdf.R")

detsarray <- array(NA,c(nf,nq,no))

fvec <- seq(fmin,fmax,by=delf)
qvec <- seq(qmin,qmax,by=delq)
ovec <- seq(omin,omax,by=delo)

i <- 0
for (f in fvec) {
    i <- i+1
    print(f)
    j <- 0
    for (q in qvec) {
         j <- j+1
         k <- 0
         for (o in ovec) {
             k <- k+1
             if ((f > 0) && (o > 0) && (q >= f/o-1) && (o < 1/(q+1))) {
                 detsarray[i,j,k] <- detsdffunc(f,q,o)
                 if (is.infinite(detsarray[i,j,k])) {
                    print("warning")
                    print(o)
                    print(f)
                    print(q)
                 }

             } else {
                 detsarray[i,j,k] <- NA
             }
         }
    }
}


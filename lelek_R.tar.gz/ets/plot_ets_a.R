#To run etsfunc for the range of a's and q's 

o <- .1

amin <- 0
amax <- o
dela <- 0.01
na <- (amax-amin)/dela+1

qmin <- 0
qmax <- 1
delq <- .01
nq <- (qmax-qmin)/delq+1

source("ets_a.R")

etsarray <- array(NA,c(na,nq))

avec <- seq(amin,amax,by=dela)
qvec <- seq(qmin,qmax,by=delq)

i <- 0
for (a in avec) {
    i <- i+1
    j <- 0
    for (q in qvec) {
         j <- j+1
	 if (o >=a) {
             etsarray[i,j] <- etsfunc(a,q,o)
         } else {
             etsarray[i,j] <- NA
         }
    }
}


qfunc <- avec/o -1

xstring <- expression("a")
ystring <- expression("q")

name <- paste("ets_",as.character(o),".eps",sep="")
postscript(name,width=6., height=6.,
horizontal = FALSE, onefile = FALSE, paper = "special",
           family = "URWHelvetica")

if (o == .1) {
   pal <- palette(gray(seq(1.,0.,len=8)))
   filled.contour(avec,qvec,etsarray,
               levels=c(-.6,-.4,-.2,,0.,.2,.4,,.6,.8,,1.),zlim=c(-.6,1),
               xlab=xstring,ylab=ystring,
               col=pal,key.axes=axis(4,c(-.6,-.4,-.2,0.,.2,.4,.6,.8,1.)))
   text(.05,4.5,labels="a",cex=1.5,vfont=c("serif","plain"))

#wrong               plot.axes={axis(1); axis(2);lines(fvec,qfunc)})
dev.off()
nx <- 348
ny <- 414
x <- 1:nx
y <- 1:ny
obs <- array(0,c(nx,ny))

fobs <- file("ASCII.obs","ra")
obs <- array(scan(fobs,what=0.,n=nx*ny),c(nx,ny))
close(fobs)
#lim <- max(obs)
lim <- 4
#lim <- 30
#x11()
fname <- "obs.png"
png(fname,width = 548, height = 548,bg="lightgrey")
filled.contour(x,y,obs,zlim=range(0.,lim),nlevels=20,color.palette=rainbow)
dev.off()	



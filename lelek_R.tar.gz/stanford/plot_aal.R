years <- c("12 years","15 years","20 years")

files <- c("adj_aal_values_12.txt","adj_aal_values_15.txt",
           "adj_aal_values_20.txt")

Sys.setenv(TZ="UTC")

tcolors <- c("red","blue","green")

nfiles <- length(files)	
ntimes <- 5

plotdates <- c(as.POSIXlt("2008/07/01 UTC"),
               as.POSIXlt("2009/07/01 UTC"),
	       as.POSIXlt("2010/07/01 UTC"),
               as.POSIXlt("2011/07/01 UTC"),
               as.POSIXlt("2012/07/01 UTC"))

alldates <- plotdates

picname <- "./pics/adj_aal_values.png"
png(picname,width=800,height=600)

values <- array(NA,c(nfiles,ntimes))

i <- 1
for (fname in files) {
    infile <- file(fname,"ra")
    for (j in 1:ntimes) {
        data <- scan(infile,what=1,nlines=1)
	values[i,(ntimes-j+1)] <- data[2]/1.e3
	print(ntimes-j+1)
    }
    close(infile)
    i <- i+1
}

xmin <- min(alldates)
xmax <- max(alldates)

ymin <- min(values)
ymax <- max(values)*1.05

ylabstring <- "AAL (millions of $)"
maintitle <- "AAL as a Function of Treasury Yields"

i <- 1
plot(alldates,values[i,],ylim=c(ymin,ymax),col=tcolors[1],main=maintitle,
xlab='',ylab=ylabstring,xaxt='n',
cex.axis=1.25,cex.lab=1.25,type="l",lwd=5,cex=1.25,cex.main=1.5)
axis.POSIXct(1,alldates,format="%Y/%m/%d",at=plotdates,cex.axis=1.25)

for (i in 2:nfiles) {
lines(alldates,values[i,],col=tcolors[i],lwd=5)
}

legend(x=xmax,y=ymax,xjust=1,yjust=1,col=tcolors[1:nfiles],
lwd=5,legend=years,cex=1.25)

dev.off()


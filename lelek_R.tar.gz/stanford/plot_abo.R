ntimes <- 5
nfiles <- 999
ndata <- 4 #year,asset,inflation,return_rate
maxlines <- 50

tcolors <- c("violetred2","blue","green","orange","red")
indir <- "./indata/"

suffixes <- paste("_",as.character(seq(1,ntimes)),".txt",sep='')

alldata <- array(NA,c(nfiles,maxlines,ndata))

for (i in 1:ntimes) {
    print(i)
    for (j in 1:nfiles) {
    	fname <- paste(indir,sprintf("%03i",j),suffixes[i],sep='')
	infile <- file(fname,"ra")	
	nlines <- length(readLines(infile))
	close(infile)
	infile <- file(fname,"ra")
	for (k in 1:nlines) {
	    alldata[j,k,] <- scan(infile,what=1,nlines=1,quiet=TRUE)
        }
	close(infile)
	alldata[j,1,1] <- nlines
    }

    k <- 2 

    xmin <- 1
    xmax <- max(alldata[,1,1],na.rm=TRUE)

    alldata[,,k] <- alldata[,,k]*1.e-3
    ymin <- 0
    ymax <- max(alldata[,,k],na.rm=TRUE)*1.1

    nyears <- alldata[1,1,1]

    ylabstring <- "Assets"
    picname <- paste("./pics/",ylabstring,"_",i,".png",sep="")
    png(picname,width=800,height=600)    
    plot(1:nyears,alldata[1,1:nyears,k],xlim=c(xmin,xmax),
         ylim=c(ymin,ymax),main=paste("AOB",ylabstring),
	 ylab=paste(ylabstring,' ( millions $ )'),
	 xlab="Years",col=tcolors[i],xaxs="i",yaxs="i",
	 cex.axis=1.25,cex.lab=1.25,type="l",lwd=1,cex=1.25,cex.main=1.5)

    for (j in 2:nfiles) {
        nyears <- alldata[j,1,1]    
    	lines(1:nyears,alldata[j,1:nyears,k],col=tcolors[i],lwd=1)
    }
    dev.off()

    xmin <- min(alldata[,1,1],na.rm=TRUE)-1
    xmax <- max(alldata[,1,1],na.rm=TRUE)+1

    ats <- seq(from=(xmin+.5),to=(xmax-.5),by=1)
    labs <- as.character(seq(from=(xmin+1),to=xmax,by=1))

    histbreaks <- seq(from=0,to=xmax,by=1)
    ylabstring <- "Probability"
    picname <- paste("./pics/",ylabstring,"_",i,".png",sep="")
    png(picname,width=800,height=600)    
    hist(alldata[,1,1],breaks=histbreaks,probability=TRUE,
	xaxs="i",yaxs="i",xlim=c(xmin,xmax),col=tcolors[i],xaxt='n',
        main="Probability Density: Years Assets to Last",
	ylab=ylabstring,xlab="Years",
	cex.axis=1.25,cex.lab=1.25,cex=1.25,cex.main=1.5)
    axis(1,at=ats,labels=labs,line=-1.15,
    cex.axis=1.25,cex.lab=1.25,cex=1.25)
    dev.off()

    k <- 3

    xmin <- 1
    xmax <- max(alldata[,1,1],na.rm=TRUE)

    alldata[,,k] <- alldata[,,k]
    ymin <- min(alldata[,,k],na.rm=TRUE)*1.1
    ymax <- max(alldata[,,k],na.rm=TRUE)*1.1

    nyears <- alldata[1,1,1]

    ylabstring <- "Inflation"
    picname <- paste("./pics/",ylabstring,"_",i,".png",sep="")
    png(picname,width=800,height=600)    
    plot(1:nyears,alldata[1,1:nyears,k],xlim=c(xmin,xmax),
         ylim=c(ymin,ymax),main=paste(ylabstring,"rate"),
	 ylab=paste(ylabstring,' % '),
	 xlab="Years",col=tcolors[i],xaxs="i",yaxs="i",
	 cex.axis=1.25,cex.lab=1.25,type="l",lwd=1,cex=1.25,cex.main=1.5)

    for (j in 2:nfiles) {
        nyears <- alldata[j,1,1]    
    	lines(1:nyears,alldata[j,1:nyears,k],col=tcolors[i],lwd=1)
    }
    dev.off()

    k <- 4 

    xmin <- 1
    xmax <- max(alldata[,1,1],na.rm=TRUE)

    alldata[,,k] <- alldata[,,k]
    ymin <- min(alldata[,,k],na.rm=TRUE)*1.1	
    ymax <- max(alldata[,,k],na.rm=TRUE)*1.1

    nyears <- alldata[1,1,1]

    ylabstring <- "Return"
    picname <- paste("./pics/",ylabstring,"_",i,".png",sep="")
    png(picname,width=800,height=600)    
    plot(1:nyears,alldata[1,1:nyears,k],xlim=c(xmin,xmax),
         ylim=c(ymin,ymax),main=paste(ylabstring,"rate"),
	 ylab=paste(ylabstring,' %'),
	 xlab="Years",col=tcolors[i],xaxs="i",yaxs="i",
	 cex.axis=1.25,cex.lab=1.25,type="l",lwd=1,cex=1.25,cex.main=1.5)

    for (j in 2:nfiles) {
        nyears <- alldata[j,1,1]    
    	lines(1:nyears,alldata[j,1:nyears,k],col=tcolors[i],lwd=1)
    }

#    meandata <- apply(alldata[,,k],2,mean,na.rm=TRUE)

    dev.off()

}


fname <- "out"
nx <- 301
ny <- 225
test <- array(scan(fname,what=0.,n=nx*ny),c(nx,ny))
#close(fname)
png("test.png",width = 630, height = 530,bg="lightgrey")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=test)
dev.off()

fname1 <- "topo1"
fname2 <- "topo2"
nx <- 301
ny <- 225
test1 <- array(scan(fname1,what=0.,n=nx*ny),c(nx,ny))
test2 <- array(scan(fname2,what=0.,n=nx*ny),c(nx,ny))

png("topo1.png",width = 630, height = 530,bg="lightgrey")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=test1)
dev.off()

png("topo2.png",width = 630, height = 530,bg="lightgrey")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=test2)
dev.off()


png("topodiff.png",width = 630, height = 530,bg="lightgrey")
filled.contour(x=seq(1,nx),y=seq(1,ny),z=(test2-test1))
dev.off()

